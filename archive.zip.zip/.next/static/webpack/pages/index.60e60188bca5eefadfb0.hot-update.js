webpackHotUpdate_N_E("pages/index",{

/***/ "./redux/entry/entryActions.js":
/*!*************************************!*\
  !*** ./redux/entry/entryActions.js ***!
  \*************************************/
/*! exports provided: Login, UserRegister, LogOut, UpdateUser, PayByBalanceAction, IncreaseBalanceAction */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Login", function() { return Login; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserRegister", function() { return UserRegister; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogOut", function() { return LogOut; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UpdateUser", function() { return UpdateUser; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PayByBalanceAction", function() { return PayByBalanceAction; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IncreaseBalanceAction", function() { return IncreaseBalanceAction; });
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/regenerator */ "./node_modules/next/node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! sweetalert2 */ "./node_modules/sweetalert2/dist/sweetalert2.all.js");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./actions */ "./redux/entry/actions.js");






var Login = function Login(url, data) {
  var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return function (dispatch) {
    axios__WEBPACK_IMPORTED_MODULE_2___default.a.post("".concat("https://166api.titr.az/api/").concat(url), data, {
      headers: headers
    }).then( /*#__PURE__*/function () {
      var _ref = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(res) {
        var data;
        return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return res.data;

              case 2:
                data = _context.sent;
                dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["login"])(data));
                next_router__WEBPACK_IMPORTED_MODULE_3___default.a.push('/packages');

              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));

      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }())["catch"](function (errors) {
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["login"])({
        isError: true,
        errors: errors.response.data
      }));
    });
  };
};
var UserRegister = function UserRegister(url, data) {
  var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return function (dispatch) {
    axios__WEBPACK_IMPORTED_MODULE_2___default.a.post("".concat("https://166api.titr.az/api/").concat(url), data, {
      headers: headers
    }).then( /*#__PURE__*/function () {
      var _ref2 = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2(res) {
        var data;
        return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                sweetalert2__WEBPACK_IMPORTED_MODULE_4___default.a.fire({
                  text: 'Əməliyyat uğurla tamamlandı',
                  icon: 'success',
                  confirmButtonText: 'OK'
                }).then(function (res) {
                  if (res.isConfirmed) {
                    next_router__WEBPACK_IMPORTED_MODULE_3___default.a.push('/myaddresses');
                  }
                });
                _context2.next = 3;
                return res.data;

              case 3:
                data = _context2.sent;
                dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["register"])(data));

              case 5:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }));

      return function (_x2) {
        return _ref2.apply(this, arguments);
      };
    }())["catch"](function (err) {
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["register"])({
        isError: true,
        errors: err.response.data
      }));
    });
  };
};
var LogOut = function LogOut() {
  return function (dispatch) {
    dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["logout"])());
  };
};
var UpdateUser = function UpdateUser(url, data) {
  var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return function (dispatch) {
    axios__WEBPACK_IMPORTED_MODULE_2___default.a.put("".concat("https://166api.titr.az/api/").concat(url), data, {
      headers: headers
    }).then(function (res) {
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["updateUser"])(res.data));
      sweetalert2__WEBPACK_IMPORTED_MODULE_4___default.a.fire({
        text: 'Əməliyyat uğurla yerinə yetirildi',
        icon: 'success',
        confirmButtonText: 'OK'
      });
    })["catch"](function (err) {
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["updateUser"])({
        isError: true,
        errors: err.response.data
      }));
    });
  };
};
var PayByBalanceAction = function PayByBalanceAction(url, data, headers) {
  return function (dispatch) {
    axios__WEBPACK_IMPORTED_MODULE_2___default.a.post("".concat("https://166api.titr.az/api/").concat(url), data, {
      headers: headers
    }).then(function (res) {
      console.log('req', res.data.balance);
      sweetalert2__WEBPACK_IMPORTED_MODULE_4___default.a.fire({
        text: res.data.message,
        icon: 'success',
        confirmButtonText: 'OK'
      });
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["PayByBalance"])(res.data.balance));
      next_router__WEBPACK_IMPORTED_MODULE_3___default.a.push("/success?message=".concat(res.data.message));
    })["catch"](function (err) {
      return console.log(err);
    });
  };
};
var IncreaseBalanceAction = function IncreaseBalanceAction(balance) {
  return function (dispatch) {
    dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["IncreaseBalance"])(balance));
  };
};

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcmVkdXgvZW50cnkvZW50cnlBY3Rpb25zLmpzIl0sIm5hbWVzIjpbIkxvZ2luIiwidXJsIiwiZGF0YSIsImhlYWRlcnMiLCJkaXNwYXRjaCIsImF4aW9zIiwicG9zdCIsInByb2Nlc3MiLCJ0aGVuIiwicmVzIiwibG9naW4iLCJyb3V0ZXIiLCJwdXNoIiwiZXJyb3JzIiwiaXNFcnJvciIsInJlc3BvbnNlIiwiVXNlclJlZ2lzdGVyIiwiU3dhbCIsImZpcmUiLCJ0ZXh0IiwiaWNvbiIsImNvbmZpcm1CdXR0b25UZXh0IiwiaXNDb25maXJtZWQiLCJyZWdpc3RlciIsImVyciIsIkxvZ091dCIsImxvZ291dCIsIlVwZGF0ZVVzZXIiLCJwdXQiLCJ1cGRhdGVVc2VyIiwiUGF5QnlCYWxhbmNlQWN0aW9uIiwiY29uc29sZSIsImxvZyIsImJhbGFuY2UiLCJtZXNzYWdlIiwiUGF5QnlCYWxhbmNlIiwiSW5jcmVhc2VCYWxhbmNlQWN0aW9uIiwiSW5jcmVhc2VCYWxhbmNlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRU8sSUFBTUEsS0FBSyxHQUFHLFNBQVJBLEtBQVEsQ0FBQ0MsR0FBRCxFQUFLQyxJQUFMO0FBQUEsTUFBVUMsT0FBVix1RUFBb0IsRUFBcEI7QUFBQSxTQUEyQixVQUFBQyxRQUFRLEVBQUk7QUFDeERDLGdEQUFLLENBQUNDLElBQU4sV0FBY0MsNkJBQWQsU0FBZ0ROLEdBQWhELEdBQXNEQyxJQUF0RCxFQUEyRDtBQUN2REMsYUFBTyxFQUFDQTtBQUQrQyxLQUEzRCxFQUdHSyxJQUhIO0FBQUEsb1VBR1EsaUJBQU1DLEdBQU47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFDYUEsR0FBRyxDQUFDUCxJQURqQjs7QUFBQTtBQUNBQSxvQkFEQTtBQUVKRSx3QkFBUSxDQUFDTSxzREFBSyxDQUFDUixJQUFELENBQU4sQ0FBUjtBQUNBUyxrRUFBTSxDQUFDQyxJQUFQLENBQVksV0FBWjs7QUFISTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUhSOztBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU9XLFVBQUFDLE1BQU0sRUFBSTtBQUNqQlQsY0FBUSxDQUFDTSxzREFBSyxDQUFDO0FBQUNJLGVBQU8sRUFBQyxJQUFUO0FBQWNELGNBQU0sRUFBQ0EsTUFBTSxDQUFDRSxRQUFQLENBQWdCYjtBQUFyQyxPQUFELENBQU4sQ0FBUjtBQUNELEtBVEg7QUFVSCxHQVhvQjtBQUFBLENBQWQ7QUFjQSxJQUFNYyxZQUFZLEdBQUcsU0FBZkEsWUFBZSxDQUFDZixHQUFELEVBQUtDLElBQUw7QUFBQSxNQUFVQyxPQUFWLHVFQUFvQixFQUFwQjtBQUFBLFNBQTJCLFVBQUFDLFFBQVEsRUFBSTtBQUNqRUMsZ0RBQUssQ0FBQ0MsSUFBTixXQUFjQyw2QkFBZCxTQUFnRE4sR0FBaEQsR0FBc0RDLElBQXRELEVBQTJEO0FBQ3ZEQyxhQUFPLEVBQUNBO0FBRCtDLEtBQTNELEVBR0dLLElBSEg7QUFBQSxxVUFHUSxrQkFBTUMsR0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDSlEsa0VBQUksQ0FBQ0MsSUFBTCxDQUFVO0FBQ1JDLHNCQUFJLEVBQUUsNkJBREU7QUFFUkMsc0JBQUksRUFBRSxTQUZFO0FBR1JDLG1DQUFpQixFQUFFO0FBSFgsaUJBQVYsRUFJR2IsSUFKSCxDQUlRLFVBQUFDLEdBQUcsRUFBSTtBQUNiLHNCQUFHQSxHQUFHLENBQUNhLFdBQVAsRUFBbUI7QUFDakJYLHNFQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaO0FBQ0Q7QUFDRixpQkFSRDtBQURJO0FBQUEsdUJBVWFILEdBQUcsQ0FBQ1AsSUFWakI7O0FBQUE7QUFVQUEsb0JBVkE7QUFXSkUsd0JBQVEsQ0FBQ21CLHlEQUFRLENBQUNyQixJQUFELENBQVQsQ0FBUjs7QUFYSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUhSOztBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQWVXLFVBQUFzQixHQUFHLEVBQUk7QUFDZHBCLGNBQVEsQ0FBQ21CLHlEQUFRLENBQUM7QUFBQ1QsZUFBTyxFQUFDLElBQVQ7QUFBY0QsY0FBTSxFQUFDVyxHQUFHLENBQUNULFFBQUosQ0FBYWI7QUFBbEMsT0FBRCxDQUFULENBQVI7QUFDRCxLQWpCSDtBQWtCRCxHQW5CMkI7QUFBQSxDQUFyQjtBQXFCQSxJQUFNdUIsTUFBTSxHQUFHLFNBQVRBLE1BQVM7QUFBQSxTQUFNLFVBQUFyQixRQUFRLEVBQUk7QUFDcENBLFlBQVEsQ0FBQ3NCLHVEQUFNLEVBQVAsQ0FBUjtBQUNILEdBRnFCO0FBQUEsQ0FBZjtBQUlBLElBQU1DLFVBQVUsR0FBRyxTQUFiQSxVQUFhLENBQUMxQixHQUFELEVBQUtDLElBQUw7QUFBQSxNQUFVQyxPQUFWLHVFQUFvQixFQUFwQjtBQUFBLFNBQTJCLFVBQUFDLFFBQVEsRUFBSTtBQUU3REMsZ0RBQUssQ0FBQ3VCLEdBQU4sV0FBYXJCLDZCQUFiLFNBQStDTixHQUEvQyxHQUFxREMsSUFBckQsRUFBMEQ7QUFDdERDLGFBQU8sRUFBRUE7QUFENkMsS0FBMUQsRUFHR0ssSUFISCxDQUdTLFVBQUFDLEdBQUcsRUFBSTtBQUNaTCxjQUFRLENBQUN5QiwyREFBVSxDQUFDcEIsR0FBRyxDQUFDUCxJQUFMLENBQVgsQ0FBUjtBQUNDZSx3REFBSSxDQUFDQyxJQUFMLENBQVU7QUFDUkMsWUFBSSxFQUFFLG1DQURFO0FBRVJDLFlBQUksRUFBRSxTQUZFO0FBR1JDLHlCQUFpQixFQUFFO0FBSFgsT0FBVjtBQUtGLEtBVkgsV0FXUyxVQUFBRyxHQUFHLEVBQUk7QUFDWnBCLGNBQVEsQ0FBQ3lCLDJEQUFVLENBQUM7QUFBQ2YsZUFBTyxFQUFDLElBQVQ7QUFBY0QsY0FBTSxFQUFDVyxHQUFHLENBQUNULFFBQUosQ0FBYWI7QUFBbEMsT0FBRCxDQUFYLENBQVI7QUFDRCxLQWJIO0FBZUgsR0FqQnlCO0FBQUEsQ0FBbkI7QUFtQkUsSUFBTTRCLGtCQUFrQixHQUFHLFNBQXJCQSxrQkFBcUIsQ0FBQzdCLEdBQUQsRUFBS0MsSUFBTCxFQUFVQyxPQUFWO0FBQUEsU0FBc0IsVUFBQUMsUUFBUSxFQUFJO0FBQ2xFQyxnREFBSyxDQUFDQyxJQUFOLFdBQWNDLDZCQUFkLFNBQWdETixHQUFoRCxHQUFzREMsSUFBdEQsRUFBMkQ7QUFDekRDLGFBQU8sRUFBQ0E7QUFEaUQsS0FBM0QsRUFFR0ssSUFGSCxDQUVRLFVBQUFDLEdBQUcsRUFBSTtBQUNic0IsYUFBTyxDQUFDQyxHQUFSLENBQVksS0FBWixFQUFrQnZCLEdBQUcsQ0FBQ1AsSUFBSixDQUFTK0IsT0FBM0I7QUFDRWhCLHdEQUFJLENBQUNDLElBQUwsQ0FBVTtBQUNSQyxZQUFJLEVBQUVWLEdBQUcsQ0FBQ1AsSUFBSixDQUFTZ0MsT0FEUDtBQUVSZCxZQUFJLEVBQUUsU0FGRTtBQUdSQyx5QkFBaUIsRUFBRTtBQUhYLE9BQVY7QUFLQWpCLGNBQVEsQ0FBQytCLDZEQUFZLENBQUMxQixHQUFHLENBQUNQLElBQUosQ0FBUytCLE9BQVYsQ0FBYixDQUFSO0FBQ0F0Qix3REFBTSxDQUFDQyxJQUFQLDRCQUFnQ0gsR0FBRyxDQUFDUCxJQUFKLENBQVNnQyxPQUF6QztBQUNILEtBWEQsV0FXUyxVQUFBVixHQUFHO0FBQUEsYUFBSU8sT0FBTyxDQUFDQyxHQUFSLENBQVlSLEdBQVosQ0FBSjtBQUFBLEtBWFo7QUFZRCxHQWJpQztBQUFBLENBQTNCO0FBZUYsSUFBTVkscUJBQXFCLEdBQUcsU0FBeEJBLHFCQUF3QixDQUFDSCxPQUFEO0FBQUEsU0FBYSxVQUFBN0IsUUFBUSxFQUFJO0FBQzFEQSxZQUFRLENBQUNpQyxnRUFBZSxDQUFDSixPQUFELENBQWhCLENBQVI7QUFDSCxHQUZvQztBQUFBLENBQTlCIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2luZGV4LjYwZTYwMTg4YmNhNWVlZmFkZmIwLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xyXG5pbXBvcnQgcm91dGVyIGZyb20gXCJuZXh0L3JvdXRlclwiO1xyXG5pbXBvcnQgU3dhbCBmcm9tIFwic3dlZXRhbGVydDJcIjtcclxuaW1wb3J0IHsgSW5jcmVhc2VCYWxhbmNlLCBsb2dpbiwgbG9nb3V0LCBQYXlCeUJhbGFuY2UsIHJlZ2lzdGVyLCB1cGRhdGVVc2VyIH0gZnJvbSBcIi4vYWN0aW9uc1wiO1xyXG5cclxuZXhwb3J0IGNvbnN0IExvZ2luID0gKHVybCxkYXRhLGhlYWRlcnMgPSB7fSkgPT4gZGlzcGF0Y2ggPT4ge1xyXG4gICAgYXhpb3MucG9zdChgJHtwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19BUElfVVJMfSR7dXJsfWAsZGF0YSx7XHJcbiAgICAgICAgaGVhZGVyczpoZWFkZXJzLFxyXG4gICAgICB9KVxyXG4gICAgICAudGhlbihhc3luYyByZXMgPT4ge1xyXG4gICAgICAgIGxldCBkYXRhID0gYXdhaXQgcmVzLmRhdGE7XHJcbiAgICAgICAgZGlzcGF0Y2gobG9naW4oZGF0YSkpXHJcbiAgICAgICAgcm91dGVyLnB1c2goJy9wYWNrYWdlcycpXHJcbiAgICAgIH0pLmNhdGNoKGVycm9ycyA9PiB7XHJcbiAgICAgICAgZGlzcGF0Y2gobG9naW4oe2lzRXJyb3I6dHJ1ZSxlcnJvcnM6ZXJyb3JzLnJlc3BvbnNlLmRhdGF9KSlcclxuICAgICAgfSlcclxufVxyXG5cclxuXHJcbmV4cG9ydCBjb25zdCBVc2VyUmVnaXN0ZXIgPSAodXJsLGRhdGEsaGVhZGVycyA9IHt9KSA9PiBkaXNwYXRjaCA9PiB7XHJcbiAgYXhpb3MucG9zdChgJHtwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19BUElfVVJMfSR7dXJsfWAsZGF0YSx7XHJcbiAgICAgIGhlYWRlcnM6aGVhZGVycyxcclxuICAgIH0pXHJcbiAgICAudGhlbihhc3luYyByZXMgPT4ge1xyXG4gICAgICBTd2FsLmZpcmUoe1xyXG4gICAgICAgIHRleHQ6ICfGj23JmWxpeXlhdCB1xJ91cmxhIHRhbWFtbGFuZMSxJyxcclxuICAgICAgICBpY29uOiAnc3VjY2VzcycsXHJcbiAgICAgICAgY29uZmlybUJ1dHRvblRleHQ6ICdPSycsXHJcbiAgICAgIH0pLnRoZW4ocmVzID0+IHtcclxuICAgICAgICBpZihyZXMuaXNDb25maXJtZWQpe1xyXG4gICAgICAgICAgcm91dGVyLnB1c2goJy9teWFkZHJlc3NlcycpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuICAgICAgbGV0IGRhdGEgPSBhd2FpdCByZXMuZGF0YTtcclxuICAgICAgZGlzcGF0Y2gocmVnaXN0ZXIoZGF0YSkpXHJcbiAgICB9KS5jYXRjaChlcnIgPT4ge1xyXG4gICAgICBkaXNwYXRjaChyZWdpc3Rlcih7aXNFcnJvcjp0cnVlLGVycm9yczplcnIucmVzcG9uc2UuZGF0YX0pKVxyXG4gICAgfSlcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IExvZ091dCA9ICgpID0+IGRpc3BhdGNoID0+IHtcclxuICAgIGRpc3BhdGNoKGxvZ291dCgpKVxyXG59XHJcblxyXG5leHBvcnQgY29uc3QgVXBkYXRlVXNlciA9ICh1cmwsZGF0YSxoZWFkZXJzID0ge30pID0+IGRpc3BhdGNoID0+IHtcclxuXHJcbiAgICBheGlvcy5wdXQoYCR7cHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQVBJX1VSTH0ke3VybH1gLGRhdGEse1xyXG4gICAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgICAgfSlcclxuICAgICAgLnRoZW4oIHJlcyA9PiB7XHJcbiAgICAgICAgZGlzcGF0Y2godXBkYXRlVXNlcihyZXMuZGF0YSkpXHJcbiAgICAgICAgIFN3YWwuZmlyZSh7XHJcbiAgICAgICAgICAgdGV4dDogJ8aPbcmZbGl5eWF0IHXEn3VybGEgeWVyaW7JmSB5ZXRpcmlsZGknLFxyXG4gICAgICAgICAgIGljb246ICdzdWNjZXNzJyxcclxuICAgICAgICAgICBjb25maXJtQnV0dG9uVGV4dDogJ09LJyxcclxuICAgICAgICAgfSlcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKGVyciA9PiB7XHJcbiAgICAgICAgZGlzcGF0Y2godXBkYXRlVXNlcih7aXNFcnJvcjp0cnVlLGVycm9yczplcnIucmVzcG9uc2UuZGF0YX0pKVxyXG4gICAgICB9KVxyXG4gIFxyXG59XHJcblxyXG4gIGV4cG9ydCBjb25zdCBQYXlCeUJhbGFuY2VBY3Rpb24gPSAodXJsLGRhdGEsaGVhZGVycykgPT4gZGlzcGF0Y2ggPT4ge1xyXG4gICAgYXhpb3MucG9zdChgJHtwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19BUElfVVJMfSR7dXJsfWAsZGF0YSx7XHJcbiAgICAgIGhlYWRlcnM6aGVhZGVycyxcclxuICAgIH0pLnRoZW4ocmVzID0+IHtcclxuICAgICAgY29uc29sZS5sb2coJ3JlcScscmVzLmRhdGEuYmFsYW5jZSkgXHJcbiAgICAgICAgU3dhbC5maXJlKHtcclxuICAgICAgICAgIHRleHQ6IHJlcy5kYXRhLm1lc3NhZ2UsXHJcbiAgICAgICAgICBpY29uOiAnc3VjY2VzcycsXHJcbiAgICAgICAgICBjb25maXJtQnV0dG9uVGV4dDogJ09LJyxcclxuICAgICAgICB9KTtcclxuICAgICAgICBkaXNwYXRjaChQYXlCeUJhbGFuY2UocmVzLmRhdGEuYmFsYW5jZSkpO1xyXG4gICAgICAgIHJvdXRlci5wdXNoKGAvc3VjY2Vzcz9tZXNzYWdlPSR7cmVzLmRhdGEubWVzc2FnZX1gKTtcclxuICAgIH0pLmNhdGNoKGVyciA9PiBjb25zb2xlLmxvZyhlcnIpKTtcclxuICB9XHJcblxyXG5leHBvcnQgY29uc3QgSW5jcmVhc2VCYWxhbmNlQWN0aW9uID0gKGJhbGFuY2UpID0+IGRpc3BhdGNoID0+IHtcclxuICAgIGRpc3BhdGNoKEluY3JlYXNlQmFsYW5jZShiYWxhbmNlKSlcclxufVxyXG5cclxuXHJcblxyXG4iXSwic291cmNlUm9vdCI6IiJ9