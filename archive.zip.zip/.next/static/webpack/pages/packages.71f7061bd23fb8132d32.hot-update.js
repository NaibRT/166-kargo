webpackHotUpdate_N_E("pages/packages",{

/***/ "./pages/packages.js":
/*!***************************!*\
  !*** ./pages/packages.js ***!
  \***************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/toConsumableArray */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/regenerator */ "./node_modules/next/node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-hook-form */ "./node_modules/react-hook-form/dist/index.esm.js");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-intl */ "./node_modules/react-intl/lib/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _components_aside_menu_index__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../components/aside-menu/index */ "./components/aside-menu/index.js");
/* harmony import */ var _components_aside_aside__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../components/aside/aside */ "./components/aside/aside.js");
/* harmony import */ var _components_button__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../components/button */ "./components/button/index.js");
/* harmony import */ var _components_card_card__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../components/card/card */ "./components/card/card.js");
/* harmony import */ var _components_checkbox_checkbox__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../components/checkbox/checkbox */ "./components/checkbox/checkbox.js");
/* harmony import */ var _components_form_group_form_group__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../components/form-group/form-group */ "./components/form-group/form-group.js");
/* harmony import */ var _components_input_input__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../components/input/input */ "./components/input/input.js");
/* harmony import */ var _components_main_main__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../components/main/main */ "./components/main/main.js");
/* harmony import */ var _components_package_item_package_item__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../components/package_item/package-item */ "./components/package_item/package-item.js");
/* harmony import */ var _components_page_page__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../components/page/page */ "./components/page/page.js");
/* harmony import */ var _components_redirect_redirect__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../components/redirect/redirect */ "./components/redirect/redirect.js");
/* harmony import */ var _components_tabel_tabel__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../components/tabel/tabel */ "./components/tabel/tabel.js");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! sweetalert2 */ "./node_modules/sweetalert2/dist/sweetalert2.all.js");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var _redux_entry_entryActions__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ../redux/entry/entryActions */ "./redux/entry/entryActions.js");







var _jsxFileName = "C:\\Users\\Home\\Desktop\\166\\166-kargo\\pages\\packages.js",
    _s = $RefreshSig$();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }






















function Packages(props) {
  _s();

  var _this = this,
      _errors$promocode;

  if (!props.entry.isLoged) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_redirect_redirect__WEBPACK_IMPORTED_MODULE_21__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 12
    }, this);
  }

  var _useForm = Object(react_hook_form__WEBPACK_IMPORTED_MODULE_8__["useForm"])(),
      register = _useForm.register,
      handleSubmit = _useForm.handleSubmit,
      errors = _useForm.errors,
      setError = _useForm.setError;

  var _useIntl = Object(react_intl__WEBPACK_IMPORTED_MODULE_9__["useIntl"])(),
      f = _useIntl.formatMessage;

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])([]),
      packages = _useState[0],
      setPackages = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])([]),
      filteredPacks = _useState2[0],
      setFilteredPacks = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])([]),
      status = _useState3[0],
      setStatus = _useState3[1];

  var _useState4 = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])({
    packages: [],
    total: 0,
    discountTotal: 0,
    code: "",
    isAccepted: false,
    status: 0
  }),
      selectedPackages = _useState4[0],
      setSelectedPackages = _useState4[1];

  var _useRouter = Object(next_router__WEBPACK_IMPORTED_MODULE_6__["useRouter"])(),
      locale = _useRouter.locale;

  var mainCheckRef = Object(react__WEBPACK_IMPORTED_MODULE_7__["useRef"])();
  var checkRefs = Object(react__WEBPACK_IMPORTED_MODULE_7__["useRef"])([]);
  checkRefs.current = [];
  var tabRefs = Object(react__WEBPACK_IMPORTED_MODULE_7__["useRef"])([]);
  tabRefs.current = [];

  var submit = function submit(data) {
    console.log(data);
    axios__WEBPACK_IMPORTED_MODULE_5___default.a.post("".concat("https://166api.titr.az/api/", "promocode?promocode=").concat(data.promocode, "&status=").concat(selectedPackages.status), {}, {
      headers: {
        "content-type": "application/json",
        authorization: "Bearer ".concat(props.entry.user.accessToken)
      }
    }).then(function (res) {
      console.log(res.data.batches);
      setPackages(res.data.batches);
      setFilteredPacks(res.data.batches);
    })["catch"](function (err) {
      setError("promocode", {
        message: err.response.data.error
      });
    });
  };

  var PromisAll = /*#__PURE__*/function () {
    var _ref = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_4__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.mark(function _callee() {
      var batchesData, statusData;
      return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return axios__WEBPACK_IMPORTED_MODULE_5___default.a.get("".concat("https://166api.titr.az/api/", "batches?lan=").concat(locale), {
                headers: {
                  authorization: "Bearer ".concat(props.entry.user.accessToken)
                }
              });

            case 2:
              batchesData = _context.sent;
              _context.next = 5;
              return axios__WEBPACK_IMPORTED_MODULE_5___default.a.get("".concat("https://166api.titr.az/api/", "status?lan=").concat(locale), {
                headers: {
                  authorization: "Bearer ".concat(props.entry.user.accessToken)
                }
              });

            case 5:
              statusData = _context.sent;
              return _context.abrupt("return", {
                batchesData: batchesData.data,
                statusData: statusData.data
              });

            case 7:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function PromisAll() {
      return _ref.apply(this, arguments);
    };
  }();

  Object(react__WEBPACK_IMPORTED_MODULE_7__["useLayoutEffect"])(function () {
    PromisAll().then(function (res) {
      setPackages(res.batchesData);
      setFilteredPacks(res.batchesData);
      setStatus(res.statusData);
    })["catch"](function (err) {
      return console.log(err);
    });
  }, []);

  var addTabRefs = function addTabRefs(ref) {
    if (ref && !tabRefs.current.includes(ref)) {
      tabRefs.current.push(ref);
    }
  };

  var toggleTabRefs = /*#__PURE__*/function () {
    var _ref2 = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_4__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.mark(function _callee2(ev) {
      return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              tabRefs.current.forEach(function (x) {
                return x.classList.remove("pack-active");
              });
              ev.target.classList.add("pack-active");

            case 2:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2);
    }));

    return function toggleTabRefs(_x) {
      return _ref2.apply(this, arguments);
    };
  }();

  var getBatchesByStatausId = /*#__PURE__*/function () {
    var _ref3 = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_4__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.mark(function _callee3(id) {
      return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.wrap(function _callee3$(_context3) {
        while (1) {
          switch (_context3.prev = _context3.next) {
            case 0:
              axios__WEBPACK_IMPORTED_MODULE_5___default.a.get("".concat("https://166api.titr.az/api/", "batches?status=").concat(id, "&lan=").concat(locale), {
                headers: {
                  authorization: "Bearer ".concat(props.entry.user.accessToken)
                }
              }).then(function (res) {
                setPackages(res.data);
                setFilteredPacks(res.data);
              })["catch"](function (err) {
                return console.log(err);
              });

            case 1:
            case "end":
              return _context3.stop();
          }
        }
      }, _callee3);
    }));

    return function getBatchesByStatausId(_x2) {
      return _ref3.apply(this, arguments);
    };
  }();

  var tabButtonClick = function tabButtonClick(ev) {
    var id = ev.target.getAttribute("data-id");
    toggleTabRefs(ev);
    getBatchesByStatausId(id);

    if (id != 0) {
      var newPackages = packages.filter(function (x) {
        return x.status.id == id;
      });
      setFilteredPacks(Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(newPackages));
    } else {
      setFilteredPacks(Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(packages));
    }

    setSelectedPackages({
      discountTotal: 0,
      packages: [],
      total: 0,
      code: "",
      isAccepted: false,
      status: id
    });
  };

  var addCheckRefs = function addCheckRefs(ref) {
    if (ref && !checkRefs.current.includes(ref)) {
      checkRefs.current.push(ref);
    }
  };

  var checkHandler = function checkHandler(ev) {
    var _ev$target = ev.target,
        value = _ev$target.value,
        checked = _ev$target.checked;
    var price = ev.target.getAttribute("data-price");
    var dataDiscount = ev.target.getAttribute("data-discount");
    var total = 0;
    var disc = 0;
    console.log('dis', dataDiscount);

    if (checked) {
      selectedPackages.packages.push(value);

      if (dataDiscount != 0) {
        setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
          total: selectedPackages.total + parseFloat(price),
          discountTotal: selectedPackages.discountTotal + parseFloat(dataDiscount),
          packages: Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(selectedPackages.packages)
        }));
      } else {
        setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
          discountTotal: selectedPackages.discountTotal + parseFloat(price),
          total: selectedPackages.total + parseFloat(price),
          packages: Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(selectedPackages.packages)
        }));
      }
    } else {
      var newPackages = selectedPackages.packages.filter(function (x) {
        return x !== value;
      });

      if (dataDiscount != 0) {
        setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
          total: selectedPackages.total >= 0 && selectedPackages.total - parseFloat(price),
          discountTotal: selectedPackages.discountTotal >= 0 && selectedPackages.discountTotal - parseFloat(dataDiscount),
          packages: newPackages
        }));
      } else {
        setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
          discountTotal: selectedPackages.discountTotal >= 0 && selectedPackages.discountTotal - parseFloat(price),
          total: selectedPackages.total >= 0 && selectedPackages.total - parseFloat(price),
          packages: newPackages
        }));
      }
    }

    !selectedPackages.packages.some(function (x) {
      return x;
    }) ? mainCheckRef.current.checked = false : null;
  };

  var selectAll = function selectAll(e) {
    var total = 0;
    var discountTotal = 0;
    var packages = [];
    checkRefs.current.forEach(function (x) {
      x.checked = e.target.checked;

      if (e.target.checked && !packages.includes(x.value)) {
        packages.push(x.value);
        total += +x.getAttribute("data-price");
        discountTotal += +x.getAttribute("data-discount");
      } else {
        packages = packages.filter(function (p) {
          return p !== x.value;
        });
        total -= total >= 0 && +x.getAttribute("data-price");
        discountTotal -= discountTotal >= 0 && +x.getAttribute("data-discount");
      }
    });
    setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
      total: selectedPackages.total - total,
      packages: packages
    }));
  };

  var PaybyCard = function PaybyCard() {
    var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    axios__WEBPACK_IMPORTED_MODULE_5___default.a.post("".concat("https://166api.titr.az/api/", "payment"), data, {
      headers: {
        authorization: "Bearer ".concat(props.entry.user.accessToken)
      }
    }).then(function (res) {
      console.log('red', res.data.url);
      window.location.href = res.data.url;
    })["catch"](function (err) {
      return console.log(err);
    });
  };

  var PaybyBalance = function PaybyBalance() {
    if (props.entry.user.user.balance >= 0) {
      props.PayByBalanceAction('payment', {
        price: selectedPackages.discountTotal,
        sourcetype: 3,
        batches: selectedPackages.packages
      }, {
        'authorization': "Bearer ".concat(props.entry.user.accessToken)
      });
    } else {
      sweetalert2__WEBPACK_IMPORTED_MODULE_23___default.a.fire({
        text: 'Balansda kifayət qədər məbləğ yoxdur',
        icon: 'info',
        confirmButtonText: 'OK'
      });
    }
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_page_page__WEBPACK_IMPORTED_MODULE_20__["default"], {
    className: "bg-bg pt-lg pb-lg",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_aside_aside__WEBPACK_IMPORTED_MODULE_12__["default"], {
      className: "mr-sm",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_aside_menu_index__WEBPACK_IMPORTED_MODULE_11__["default"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 264,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 263,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_main_main__WEBPACK_IMPORTED_MODULE_18__["default"], {
      className: "bg-c p-none",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"], {
        className: "bg-bg pb-sm mgm_ss p-sm",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"].Header, {
          text: f({
            id: "active-pac"
          }),
          endElelment: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_checkbox_checkbox__WEBPACK_IMPORTED_MODULE_15__["default"], {
            text: f({
              id: "choose-all"
            }),
            Ref: function Ref(ref) {
              return mainCheckRef.current = ref;
            },
            onClick: selectAll,
            className: "bg-white border-subtitle"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 271,
            columnNumber: 15
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 268,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          "class": "ssc",
          style: {
            overflowX: "scroll"
          },
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: " pl-none",
            style: {
              display: "flex",
              marginBottom: "20px",
              width: "max-content"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
              label: "Hams\u0131 (".concat(packages.length, ")"),
              className: "mr-xs p-xs bg-bg pack-active",
              "data-id": 0,
              Ref: addTabRefs,
              onClick: tabButtonClick
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 289,
              columnNumber: 15
            }, this), status.map(function (x) {
              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                label: "".concat(x.name, " (").concat(x.count, ")"),
                className: " p-xs bg-bg ",
                "data-id": x.id,
                Ref: addTabRefs,
                onClick: tabButtonClick
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 298,
                columnNumber: 17
              }, _this);
            })]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 280,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 279,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"].Body, {
          className: "p-none",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "packages__fr",
            children: filteredPacks.filter(function (x) {
              return x.status.id !== 6;
            }).map(function (p) {
              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_package_item_package_item__WEBPACK_IMPORTED_MODULE_19__["default"], {
                checkRef: addCheckRefs,
                item: p,
                onCheck: checkHandler
              }, p.id, false, {
                fileName: _jsxFileName,
                lineNumber: 315,
                columnNumber: 19
              }, _this);
            })
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 311,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 310,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "footer__pck",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "package-total",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
              children: [selectedPackages.packages.length, " ", f({
                id: "chosed"
              })]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 326,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                display: "flex",
                justifyContent: "space-between"
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                children: [f({
                  id: "total"
                }), ":"]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 330,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                style: {
                  display: "flex",
                  flexDirection: "column"
                },
                children: selectedPackages.discountTotal > 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
                    style: {
                      textDecorationColor: "red"
                    },
                    children: [parseFloat(selectedPackages.total).toFixed(2), " AZN"]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 335,
                    columnNumber: 19
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                    children: [parseFloat(selectedPackages.discountTotal).toFixed(2), " AZN"]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 336,
                    columnNumber: 20
                  }, this)]
                }, void 0, true) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                  children: [parseFloat(selectedPackages.discountTotal).toFixed(2), " AZN"]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 338,
                  columnNumber: 23
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 331,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 329,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 325,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "package__btns",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("form", {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_form_group_form_group__WEBPACK_IMPORTED_MODULE_16__["default"], {
                bodyClass: "bg-white pl-xs",
                bodyStyle: {
                  height: "44px",
                  width: "200px"
                },
                className: "mr-xs chng__bodystyle",
                style: {
                  marginBottom: "0px"
                },
                error: (_errors$promocode = errors.promocode) === null || _errors$promocode === void 0 ? void 0 : _errors$promocode.message,
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_input_input__WEBPACK_IMPORTED_MODULE_17__["default"], {
                  placeholder: f({
                    id: "addcode"
                  }),
                  name: "promocode",
                  Ref: register({
                    required: {
                      value: true,
                      message: f({
                        id: "promo-requir"
                      })
                    }
                  }),
                  onChange: function onChange(e) {
                    return setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
                      code: e.target.value
                    }));
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 354,
                  columnNumber: 19
                }, this), selectedPackages.isAccepted ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                  className: "bg-white w-50",
                  style: {
                    textDecorationLine: "underline",
                    color: "darkblue",
                    padding: "0px 10px"
                  },
                  label: "L\u0259\u011Fv et",
                  onClick: function onClick() {
                    setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
                      isAccepted: false
                    }));
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 371,
                  columnNumber: 21
                }, this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                  disabled: !selectedPackages.code ? true : false,
                  style: {
                    padding: "0 10px"
                  },
                  className: "color-white bg-success",
                  label: f({
                    id: "confirm"
                  }),
                  type: "submit",
                  onClick: handleSubmit(submit) //  onClick={() =>{
                  //     //  setSelectedPackages({
                  //     //    ...selectedPackages,
                  //     //    isAccepted:true
                  //     //  });
                  //    }}

                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 387,
                  columnNumber: 21
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 347,
                columnNumber: 17
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 346,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
              style: {
                padding: "0 20px"
              },
              className: "color-white bg-success mr-xs desk",
              label: f({
                id: "paybycard"
              }),
              endElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                className: "color-white pl-sm",
                children: "\u2192"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 409,
                columnNumber: 29
              }, this),
              onClick: function onClick() {
                return PaybyCard({
                  price: selectedPackages.discountTotal,
                  sourcetype: 2,
                  batches: selectedPackages.packages
                });
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 405,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
              style: {
                padding: "0 10px"
              },
              className: "desk",
              label: f({
                id: "paybybalance"
              }),
              endElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                className: "color-black mr-xs pl-sm ",
                children: "\u2192"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 421,
                columnNumber: 19
              }, this),
              onClick: PaybyBalance
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 416,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "btn__fkl",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                style: {
                  padding: "0 10px"
                },
                className: "color-white bg-success mr-xs",
                label: f({
                  id: "paybycard"
                }),
                endElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "color-white pl-sm",
                  children: "\u2192"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 432,
                  columnNumber: 21
                }, this),
                onClick: function onClick() {
                  return PaybyCard({
                    price: selectedPackages.discountTotal,
                    sourcetype: 2,
                    batches: selectedPackages.packages
                  });
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 427,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                style: {
                  padding: "0 10px"
                },
                label: f({
                  id: "paybybalance"
                }),
                endElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "color-black mr-xs pl-sm",
                  children: "\u2192"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 444,
                  columnNumber: 21
                }, this),
                onClick: PaybyBalance
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 440,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 426,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 345,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 324,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 267,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"], {
        className: "p-sm bg-white",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"].Header, {
          text: f({
            id: "order-history"
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 454,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"].Body, {
          className: "p-none overflow__package",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_tabel_tabel__WEBPACK_IMPORTED_MODULE_22__["default"], {
            th: [f({
              id: "tracking"
            }), f({
              id: "shop"
            }), f({
              id: "category"
            }), f({
              id: "amount"
            }), f({
              id: "weight"
            }), f({
              id: "delivery"
            }), f({
              id: "status"
            })],
            data: packages.map(function (x) {
              if (x.status.id == 6) {
                return {
                  track_number: x.track_number,
                  shop: x.shop,
                  category: x.category,
                  price: "".concat(x.price, " ").concat(x.currency),
                  weight: "".concat(parseFloat(x.weight).toFixed(2) || 0, " kq"),
                  delivery_price: parseFloat(x.delivery_price).toFixed(2) || 0,
                  status: "".concat(x.status.name, "\n ").concat(x.date)
                };
              }
            }) || [],
            renderBody: function renderBody(x, i) {
              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {
                children: x
              }, i++, false, {
                fileName: _jsxFileName,
                lineNumber: 483,
                columnNumber: 24
              }, _this);
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 456,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 455,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 453,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 266,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 262,
    columnNumber: 5
  }, this);
}

_s(Packages, "3E201Kyf6S2uVJ0+DS1LdJkJE1g=", false, function () {
  return [react_hook_form__WEBPACK_IMPORTED_MODULE_8__["useForm"], react_intl__WEBPACK_IMPORTED_MODULE_9__["useIntl"], next_router__WEBPACK_IMPORTED_MODULE_6__["useRouter"]];
});

_c = Packages;

var mapStateToProps = function mapStateToProps(state) {
  return {
    entry: state.entry
  };
};

var mapDispatchToProps = {
  PayByBalanceAction: _redux_entry_entryActions__WEBPACK_IMPORTED_MODULE_24__["PayByBalanceAction"]
};
/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_10__["connect"])(mapStateToProps, mapDispatchToProps)( /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_7__["memo"])(Packages)));

var _c;

$RefreshReg$(_c, "Packages");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvcGFja2FnZXMuanMiXSwibmFtZXMiOlsiUGFja2FnZXMiLCJwcm9wcyIsImVudHJ5IiwiaXNMb2dlZCIsInVzZUZvcm0iLCJyZWdpc3RlciIsImhhbmRsZVN1Ym1pdCIsImVycm9ycyIsInNldEVycm9yIiwidXNlSW50bCIsImYiLCJmb3JtYXRNZXNzYWdlIiwidXNlU3RhdGUiLCJwYWNrYWdlcyIsInNldFBhY2thZ2VzIiwiZmlsdGVyZWRQYWNrcyIsInNldEZpbHRlcmVkUGFja3MiLCJzdGF0dXMiLCJzZXRTdGF0dXMiLCJ0b3RhbCIsImRpc2NvdW50VG90YWwiLCJjb2RlIiwiaXNBY2NlcHRlZCIsInNlbGVjdGVkUGFja2FnZXMiLCJzZXRTZWxlY3RlZFBhY2thZ2VzIiwidXNlUm91dGVyIiwibG9jYWxlIiwibWFpbkNoZWNrUmVmIiwidXNlUmVmIiwiY2hlY2tSZWZzIiwiY3VycmVudCIsInRhYlJlZnMiLCJzdWJtaXQiLCJkYXRhIiwiY29uc29sZSIsImxvZyIsImF4aW9zIiwicG9zdCIsInByb2Nlc3MiLCJwcm9tb2NvZGUiLCJoZWFkZXJzIiwiYXV0aG9yaXphdGlvbiIsInVzZXIiLCJhY2Nlc3NUb2tlbiIsInRoZW4iLCJyZXMiLCJiYXRjaGVzIiwiZXJyIiwibWVzc2FnZSIsInJlc3BvbnNlIiwiZXJyb3IiLCJQcm9taXNBbGwiLCJnZXQiLCJiYXRjaGVzRGF0YSIsInN0YXR1c0RhdGEiLCJ1c2VMYXlvdXRFZmZlY3QiLCJhZGRUYWJSZWZzIiwicmVmIiwiaW5jbHVkZXMiLCJwdXNoIiwidG9nZ2xlVGFiUmVmcyIsImV2IiwiZm9yRWFjaCIsIngiLCJjbGFzc0xpc3QiLCJyZW1vdmUiLCJ0YXJnZXQiLCJhZGQiLCJnZXRCYXRjaGVzQnlTdGF0YXVzSWQiLCJpZCIsInRhYkJ1dHRvbkNsaWNrIiwiZ2V0QXR0cmlidXRlIiwibmV3UGFja2FnZXMiLCJmaWx0ZXIiLCJhZGRDaGVja1JlZnMiLCJjaGVja0hhbmRsZXIiLCJ2YWx1ZSIsImNoZWNrZWQiLCJwcmljZSIsImRhdGFEaXNjb3VudCIsImRpc2MiLCJwYXJzZUZsb2F0Iiwic29tZSIsInNlbGVjdEFsbCIsImUiLCJwIiwiUGF5YnlDYXJkIiwidXJsIiwid2luZG93IiwibG9jYXRpb24iLCJocmVmIiwiUGF5YnlCYWxhbmNlIiwiYmFsYW5jZSIsIlBheUJ5QmFsYW5jZUFjdGlvbiIsInNvdXJjZXR5cGUiLCJTd2FsIiwiZmlyZSIsInRleHQiLCJpY29uIiwiY29uZmlybUJ1dHRvblRleHQiLCJvdmVyZmxvd1giLCJkaXNwbGF5IiwibWFyZ2luQm90dG9tIiwid2lkdGgiLCJsZW5ndGgiLCJtYXAiLCJuYW1lIiwiY291bnQiLCJqdXN0aWZ5Q29udGVudCIsImZsZXhEaXJlY3Rpb24iLCJ0ZXh0RGVjb3JhdGlvbkNvbG9yIiwidG9GaXhlZCIsImhlaWdodCIsInJlcXVpcmVkIiwidGV4dERlY29yYXRpb25MaW5lIiwiY29sb3IiLCJwYWRkaW5nIiwidHJhY2tfbnVtYmVyIiwic2hvcCIsImNhdGVnb3J5IiwiY3VycmVuY3kiLCJ3ZWlnaHQiLCJkZWxpdmVyeV9wcmljZSIsImRhdGUiLCJpIiwibWFwU3RhdGVUb1Byb3BzIiwic3RhdGUiLCJtYXBEaXNwYXRjaFRvUHJvcHMiLCJjb25uZWN0IiwibWVtbyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFNBQVNBLFFBQVQsQ0FBa0JDLEtBQWxCLEVBQXlCO0FBQUE7O0FBQUE7QUFBQTs7QUFDdkIsTUFBSSxDQUFDQSxLQUFLLENBQUNDLEtBQU4sQ0FBWUMsT0FBakIsRUFBMEI7QUFDeEIsd0JBQU8scUVBQUMsc0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUFQO0FBQ0Q7O0FBSHNCLGlCQUs4QkMsK0RBQU8sRUFMckM7QUFBQSxNQUtmQyxRQUxlLFlBS2ZBLFFBTGU7QUFBQSxNQUtMQyxZQUxLLFlBS0xBLFlBTEs7QUFBQSxNQUtTQyxNQUxULFlBS1NBLE1BTFQ7QUFBQSxNQUtpQkMsUUFMakIsWUFLaUJBLFFBTGpCOztBQUFBLGlCQU1NQywwREFBTyxFQU5iO0FBQUEsTUFNQUMsQ0FOQSxZQU1mQyxhQU5lOztBQUFBLGtCQU9TQyxzREFBUSxDQUFDLEVBQUQsQ0FQakI7QUFBQSxNQU9oQkMsUUFQZ0I7QUFBQSxNQU9OQyxXQVBNOztBQUFBLG1CQVFtQkYsc0RBQVEsQ0FBQyxFQUFELENBUjNCO0FBQUEsTUFRaEJHLGFBUmdCO0FBQUEsTUFRREMsZ0JBUkM7O0FBQUEsbUJBU0tKLHNEQUFRLENBQUMsRUFBRCxDQVRiO0FBQUEsTUFTaEJLLE1BVGdCO0FBQUEsTUFTUkMsU0FUUTs7QUFBQSxtQkFVeUJOLHNEQUFRLENBQUM7QUFDdkRDLFlBQVEsRUFBRSxFQUQ2QztBQUV2RE0sU0FBSyxFQUFFLENBRmdEO0FBR3ZEQyxpQkFBYSxFQUFDLENBSHlDO0FBSXZEQyxRQUFJLEVBQUUsRUFKaUQ7QUFLdkRDLGNBQVUsRUFBRSxLQUwyQztBQU12REwsVUFBTSxFQUFFO0FBTitDLEdBQUQsQ0FWakM7QUFBQSxNQVVoQk0sZ0JBVmdCO0FBQUEsTUFVRUMsbUJBVkY7O0FBQUEsbUJBbUJKQyw2REFBUyxFQW5CTDtBQUFBLE1BbUJmQyxNQW5CZSxjQW1CZkEsTUFuQmU7O0FBb0J2QixNQUFNQyxZQUFZLEdBQUdDLG9EQUFNLEVBQTNCO0FBQ0EsTUFBTUMsU0FBUyxHQUFHRCxvREFBTSxDQUFDLEVBQUQsQ0FBeEI7QUFDQUMsV0FBUyxDQUFDQyxPQUFWLEdBQW9CLEVBQXBCO0FBQ0EsTUFBTUMsT0FBTyxHQUFHSCxvREFBTSxDQUFDLEVBQUQsQ0FBdEI7QUFDQUcsU0FBTyxDQUFDRCxPQUFSLEdBQWtCLEVBQWxCOztBQUVBLE1BQU1FLE1BQU0sR0FBRyxTQUFUQSxNQUFTLENBQUNDLElBQUQsRUFBVTtBQUN2QkMsV0FBTyxDQUFDQyxHQUFSLENBQVlGLElBQVo7QUFFQUcsZ0RBQUssQ0FDRkMsSUFESCxXQUVPQyw2QkFGUCxpQ0FFNkRMLElBQUksQ0FBQ00sU0FGbEUscUJBRXNGaEIsZ0JBQWdCLENBQUNOLE1BRnZHLEdBR0ksRUFISixFQUlJO0FBQ0V1QixhQUFPLEVBQUU7QUFDUCx3QkFBZ0Isa0JBRFQ7QUFFUEMscUJBQWEsbUJBQVl4QyxLQUFLLENBQUNDLEtBQU4sQ0FBWXdDLElBQVosQ0FBaUJDLFdBQTdCO0FBRk47QUFEWCxLQUpKLEVBV0dDLElBWEgsQ0FXUSxVQUFDQyxHQUFELEVBQVM7QUFDYlgsYUFBTyxDQUFDQyxHQUFSLENBQVlVLEdBQUcsQ0FBQ1osSUFBSixDQUFTYSxPQUFyQjtBQUNBaEMsaUJBQVcsQ0FBQytCLEdBQUcsQ0FBQ1osSUFBSixDQUFTYSxPQUFWLENBQVg7QUFDQTlCLHNCQUFnQixDQUFDNkIsR0FBRyxDQUFDWixJQUFKLENBQVNhLE9BQVYsQ0FBaEI7QUFDRCxLQWZILFdBZ0JTLFVBQUNDLEdBQUQsRUFBUztBQUNkdkMsY0FBUSxDQUFDLFdBQUQsRUFBYztBQUFFd0MsZUFBTyxFQUFFRCxHQUFHLENBQUNFLFFBQUosQ0FBYWhCLElBQWIsQ0FBa0JpQjtBQUE3QixPQUFkLENBQVI7QUFDRCxLQWxCSDtBQW1CRCxHQXRCRDs7QUF3QkEsTUFBTUMsU0FBUztBQUFBLGtVQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQ1FmLDRDQUFLLENBQUNnQixHQUFOLFdBQWFkLDZCQUFiLHlCQUEyRFosTUFBM0QsR0FBcUU7QUFDM0ZjLHVCQUFPLEVBQUU7QUFDUEMsK0JBQWEsbUJBQVl4QyxLQUFLLENBQUNDLEtBQU4sQ0FBWXdDLElBQVosQ0FBaUJDLFdBQTdCO0FBRE47QUFEa0YsZUFBckUsQ0FEUjs7QUFBQTtBQUNaVSx5QkFEWTtBQUFBO0FBQUEscUJBTU9qQiw0Q0FBSyxDQUFDZ0IsR0FBTixXQUFhZCw2QkFBYix3QkFBMERaLE1BQTFELEdBQW9FO0FBQ3pGYyx1QkFBTyxFQUFFO0FBQ1BDLCtCQUFhLG1CQUFZeEMsS0FBSyxDQUFDQyxLQUFOLENBQVl3QyxJQUFaLENBQWlCQyxXQUE3QjtBQUROO0FBRGdGLGVBQXBFLENBTlA7O0FBQUE7QUFNWlcsd0JBTlk7QUFBQSwrQ0FZVDtBQUNMRCwyQkFBVyxFQUFDQSxXQUFXLENBQUNwQixJQURuQjtBQUVMcUIsMEJBQVUsRUFBQ0EsVUFBVSxDQUFDckI7QUFGakIsZUFaUzs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFIOztBQUFBLG9CQUFUa0IsU0FBUztBQUFBO0FBQUE7QUFBQSxLQUFmOztBQWlCQUksK0RBQWUsQ0FBQyxZQUFNO0FBQ3BCSixhQUFTLEdBQUdQLElBQVosQ0FBaUIsVUFBQUMsR0FBRyxFQUFJO0FBQ3RCL0IsaUJBQVcsQ0FBQytCLEdBQUcsQ0FBQ1EsV0FBTCxDQUFYO0FBQ0FyQyxzQkFBZ0IsQ0FBQzZCLEdBQUcsQ0FBQ1EsV0FBTCxDQUFoQjtBQUNBbkMsZUFBUyxDQUFDMkIsR0FBRyxDQUFDUyxVQUFMLENBQVQ7QUFDRCxLQUpELFdBSVMsVUFBQVAsR0FBRztBQUFBLGFBQUliLE9BQU8sQ0FBQ0MsR0FBUixDQUFZWSxHQUFaLENBQUo7QUFBQSxLQUpaO0FBTUQsR0FQYyxFQU9aLEVBUFksQ0FBZjs7QUFTQSxNQUFNUyxVQUFVLEdBQUcsU0FBYkEsVUFBYSxDQUFDQyxHQUFELEVBQVM7QUFDMUIsUUFBSUEsR0FBRyxJQUFJLENBQUMxQixPQUFPLENBQUNELE9BQVIsQ0FBZ0I0QixRQUFoQixDQUF5QkQsR0FBekIsQ0FBWixFQUEyQztBQUN6QzFCLGFBQU8sQ0FBQ0QsT0FBUixDQUFnQjZCLElBQWhCLENBQXFCRixHQUFyQjtBQUNEO0FBQ0YsR0FKRDs7QUFNQSxNQUFNRyxhQUFhO0FBQUEsbVVBQUcsa0JBQU9DLEVBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNwQjlCLHFCQUFPLENBQUNELE9BQVIsQ0FBZ0JnQyxPQUFoQixDQUF3QixVQUFDQyxDQUFEO0FBQUEsdUJBQU9BLENBQUMsQ0FBQ0MsU0FBRixDQUFZQyxNQUFaLENBQW1CLGFBQW5CLENBQVA7QUFBQSxlQUF4QjtBQUNBSixnQkFBRSxDQUFDSyxNQUFILENBQVVGLFNBQVYsQ0FBb0JHLEdBQXBCLENBQXdCLGFBQXhCOztBQUZvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFIOztBQUFBLG9CQUFiUCxhQUFhO0FBQUE7QUFBQTtBQUFBLEtBQW5COztBQUtBLE1BQU1RLHFCQUFxQjtBQUFBLG1VQUFHLGtCQUFPQyxFQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDM0JqQywwREFBSyxDQUFDZ0IsR0FBTixXQUFhZCw2QkFBYiw0QkFBOEQrQixFQUE5RCxrQkFBd0UzQyxNQUF4RSxHQUFrRjtBQUNqRmMsdUJBQU8sRUFBRTtBQUNQQywrQkFBYSxtQkFBWXhDLEtBQUssQ0FBQ0MsS0FBTixDQUFZd0MsSUFBWixDQUFpQkMsV0FBN0I7QUFETjtBQUR3RSxlQUFsRixFQUlFQyxJQUpGLENBSU8sVUFBQ0MsR0FBRCxFQUFTO0FBQ2YvQiwyQkFBVyxDQUFDK0IsR0FBRyxDQUFDWixJQUFMLENBQVg7QUFDQWpCLGdDQUFnQixDQUFDNkIsR0FBRyxDQUFDWixJQUFMLENBQWhCO0FBQ0QsZUFQQSxXQU9RLFVBQUFjLEdBQUc7QUFBQSx1QkFBSWIsT0FBTyxDQUFDQyxHQUFSLENBQVlZLEdBQVosQ0FBSjtBQUFBLGVBUFg7O0FBRDJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQUg7O0FBQUEsb0JBQXJCcUIscUJBQXFCO0FBQUE7QUFBQTtBQUFBLEtBQTNCOztBQWFBLE1BQU1FLGNBQWMsR0FBRyxTQUFqQkEsY0FBaUIsQ0FBQ1QsRUFBRCxFQUFRO0FBQzdCLFFBQUlRLEVBQUUsR0FBR1IsRUFBRSxDQUFDSyxNQUFILENBQVVLLFlBQVYsQ0FBdUIsU0FBdkIsQ0FBVDtBQUNBWCxpQkFBYSxDQUFDQyxFQUFELENBQWI7QUFDQU8seUJBQXFCLENBQUNDLEVBQUQsQ0FBckI7O0FBQ0EsUUFBSUEsRUFBRSxJQUFJLENBQVYsRUFBYTtBQUNYLFVBQUlHLFdBQVcsR0FBRzNELFFBQVEsQ0FBQzRELE1BQVQsQ0FBZ0IsVUFBQ1YsQ0FBRDtBQUFBLGVBQU9BLENBQUMsQ0FBQzlDLE1BQUYsQ0FBU29ELEVBQVQsSUFBZUEsRUFBdEI7QUFBQSxPQUFoQixDQUFsQjtBQUNBckQsc0JBQWdCLENBQUMsOEpBQUl3RCxXQUFMLEVBQWhCO0FBQ0QsS0FIRCxNQUdPO0FBQ0x4RCxzQkFBZ0IsQ0FBQyw4SkFBSUgsUUFBTCxFQUFoQjtBQUNEOztBQUVEVyx1QkFBbUIsQ0FBQztBQUNsQkosbUJBQWEsRUFBRSxDQURHO0FBRWxCUCxjQUFRLEVBQUUsRUFGUTtBQUdsQk0sV0FBSyxFQUFFLENBSFc7QUFJbEJFLFVBQUksRUFBRSxFQUpZO0FBS2xCQyxnQkFBVSxFQUFFLEtBTE07QUFNbEJMLFlBQU0sRUFBRW9EO0FBTlUsS0FBRCxDQUFuQjtBQVFELEdBbkJEOztBQXFCQSxNQUFNSyxZQUFZLEdBQUcsU0FBZkEsWUFBZSxDQUFDakIsR0FBRCxFQUFTO0FBQzVCLFFBQUlBLEdBQUcsSUFBSSxDQUFDNUIsU0FBUyxDQUFDQyxPQUFWLENBQWtCNEIsUUFBbEIsQ0FBMkJELEdBQTNCLENBQVosRUFBNkM7QUFDM0M1QixlQUFTLENBQUNDLE9BQVYsQ0FBa0I2QixJQUFsQixDQUF1QkYsR0FBdkI7QUFDRDtBQUNGLEdBSkQ7O0FBTUEsTUFBTWtCLFlBQVksR0FBRyxTQUFmQSxZQUFlLENBQUNkLEVBQUQsRUFBUTtBQUFBLHFCQUNGQSxFQUFFLENBQUNLLE1BREQ7QUFBQSxRQUNyQlUsS0FEcUIsY0FDckJBLEtBRHFCO0FBQUEsUUFDZEMsT0FEYyxjQUNkQSxPQURjO0FBRTNCLFFBQUlDLEtBQUssR0FBR2pCLEVBQUUsQ0FBQ0ssTUFBSCxDQUFVSyxZQUFWLENBQXVCLFlBQXZCLENBQVo7QUFDQSxRQUFJUSxZQUFZLEdBQUdsQixFQUFFLENBQUNLLE1BQUgsQ0FBVUssWUFBVixDQUF1QixlQUF2QixDQUFuQjtBQUNBLFFBQUlwRCxLQUFLLEdBQUMsQ0FBVjtBQUNBLFFBQUk2RCxJQUFJLEdBQUMsQ0FBVDtBQUNBOUMsV0FBTyxDQUFDQyxHQUFSLENBQVksS0FBWixFQUFrQjRDLFlBQWxCOztBQUNBLFFBQUlGLE9BQUosRUFBYTtBQUNYdEQsc0JBQWdCLENBQUNWLFFBQWpCLENBQTBCOEMsSUFBMUIsQ0FBK0JpQixLQUEvQjs7QUFDQSxVQUFHRyxZQUFZLElBQUUsQ0FBakIsRUFBbUI7QUFDakJ2RCwyQkFBbUIsaUNBQ2RELGdCQURjO0FBR2pCSixlQUFLLEVBQUdJLGdCQUFnQixDQUFDSixLQUFqQixHQUF1QjhELFVBQVUsQ0FBQ0gsS0FBRCxDQUh4QjtBQUtqQjFELHVCQUFhLEVBQUdHLGdCQUFnQixDQUFDSCxhQUFqQixHQUErQjZELFVBQVUsQ0FBQ0YsWUFBRCxDQUx4QztBQU1qQmxFLGtCQUFRLEVBQUUsOEpBQUlVLGdCQUFnQixDQUFDVixRQUF2QjtBQU5TLFdBQW5CO0FBU0QsT0FWRCxNQVVLO0FBQ0hXLDJCQUFtQixpQ0FDZEQsZ0JBRGM7QUFFakJILHVCQUFhLEVBQUdHLGdCQUFnQixDQUFDSCxhQUFqQixHQUErQjZELFVBQVUsQ0FBQ0gsS0FBRCxDQUZ4QztBQUdqQjNELGVBQUssRUFBR0ksZ0JBQWdCLENBQUNKLEtBQWpCLEdBQXVCOEQsVUFBVSxDQUFDSCxLQUFELENBSHhCO0FBSWpCakUsa0JBQVEsRUFBRSw4SkFBSVUsZ0JBQWdCLENBQUNWLFFBQXZCO0FBSlMsV0FBbkI7QUFNRDtBQUVGLEtBckJELE1BcUJPO0FBQ0wsVUFBSTJELFdBQVcsR0FBR2pELGdCQUFnQixDQUFDVixRQUFqQixDQUEwQjRELE1BQTFCLENBQWlDLFVBQUNWLENBQUQ7QUFBQSxlQUFPQSxDQUFDLEtBQUthLEtBQWI7QUFBQSxPQUFqQyxDQUFsQjs7QUFDQSxVQUFHRyxZQUFZLElBQUUsQ0FBakIsRUFBbUI7QUFDakJ2RCwyQkFBbUIsaUNBRWRELGdCQUZjO0FBSWpCSixlQUFLLEVBQUVJLGdCQUFnQixDQUFDSixLQUFqQixJQUF5QixDQUF6QixJQUErQkksZ0JBQWdCLENBQUNKLEtBQWpCLEdBQXVCOEQsVUFBVSxDQUFDSCxLQUFELENBSnREO0FBTWpCMUQsdUJBQWEsRUFBRUcsZ0JBQWdCLENBQUNILGFBQWpCLElBQWlDLENBQWpDLElBQXdDRyxnQkFBZ0IsQ0FBQ0gsYUFBakIsR0FBK0I2RCxVQUFVLENBQUNGLFlBQUQsQ0FOL0U7QUFPakJsRSxrQkFBUSxFQUFFMkQ7QUFQTyxXQUFuQjtBQVVELE9BWEQsTUFXSztBQUNIaEQsMkJBQW1CLGlDQUNkRCxnQkFEYztBQUVqQkgsdUJBQWEsRUFBQ0csZ0JBQWdCLENBQUNILGFBQWpCLElBQWlDLENBQWpDLElBQXVDRyxnQkFBZ0IsQ0FBQ0gsYUFBakIsR0FBK0I2RCxVQUFVLENBQUNILEtBQUQsQ0FGN0U7QUFHakIzRCxlQUFLLEVBQUNJLGdCQUFnQixDQUFDSixLQUFqQixJQUF5QixDQUF6QixJQUErQkksZ0JBQWdCLENBQUNKLEtBQWpCLEdBQXVCOEQsVUFBVSxDQUFDSCxLQUFELENBSHJEO0FBSWpCakUsa0JBQVEsRUFBQzJEO0FBSlEsV0FBbkI7QUFNRDtBQUVGOztBQUNELEtBQUNqRCxnQkFBZ0IsQ0FBQ1YsUUFBakIsQ0FBMEJxRSxJQUExQixDQUErQixVQUFDbkIsQ0FBRDtBQUFBLGFBQU9BLENBQVA7QUFBQSxLQUEvQixDQUFELEdBQ0twQyxZQUFZLENBQUNHLE9BQWIsQ0FBcUIrQyxPQUFyQixHQUErQixLQURwQyxHQUVJLElBRko7QUFHRCxHQXRERDs7QUF3REEsTUFBTU0sU0FBUyxHQUFHLFNBQVpBLFNBQVksQ0FBQ0MsQ0FBRCxFQUFPO0FBQ3ZCLFFBQUlqRSxLQUFLLEdBQUcsQ0FBWjtBQUNBLFFBQUlDLGFBQWEsR0FBRyxDQUFwQjtBQUNBLFFBQUlQLFFBQVEsR0FBRyxFQUFmO0FBQ0FnQixhQUFTLENBQUNDLE9BQVYsQ0FBa0JnQyxPQUFsQixDQUEwQixVQUFDQyxDQUFELEVBQU87QUFDL0JBLE9BQUMsQ0FBQ2MsT0FBRixHQUFZTyxDQUFDLENBQUNsQixNQUFGLENBQVNXLE9BQXJCOztBQUVBLFVBQUlPLENBQUMsQ0FBQ2xCLE1BQUYsQ0FBU1csT0FBVCxJQUFvQixDQUFDaEUsUUFBUSxDQUFDNkMsUUFBVCxDQUFrQkssQ0FBQyxDQUFDYSxLQUFwQixDQUF6QixFQUFxRDtBQUNuRC9ELGdCQUFRLENBQUM4QyxJQUFULENBQWNJLENBQUMsQ0FBQ2EsS0FBaEI7QUFDQXpELGFBQUssSUFBSSxDQUFDNEMsQ0FBQyxDQUFDUSxZQUFGLENBQWUsWUFBZixDQUFWO0FBQ0FuRCxxQkFBYSxJQUFJLENBQUMyQyxDQUFDLENBQUNRLFlBQUYsQ0FBZSxlQUFmLENBQWxCO0FBQ0QsT0FKRCxNQUlPO0FBQ0wxRCxnQkFBUSxHQUFHQSxRQUFRLENBQUM0RCxNQUFULENBQWdCLFVBQUNZLENBQUQ7QUFBQSxpQkFBT0EsQ0FBQyxLQUFLdEIsQ0FBQyxDQUFDYSxLQUFmO0FBQUEsU0FBaEIsQ0FBWDtBQUNBekQsYUFBSyxJQUFJQSxLQUFLLElBQUksQ0FBVCxJQUFjLENBQUM0QyxDQUFDLENBQUNRLFlBQUYsQ0FBZSxZQUFmLENBQXhCO0FBQ0FuRCxxQkFBYSxJQUFJQSxhQUFhLElBQUcsQ0FBaEIsSUFBcUIsQ0FBQzJDLENBQUMsQ0FBQ1EsWUFBRixDQUFlLGVBQWYsQ0FBdkM7QUFDRDtBQUNGLEtBWkQ7QUFjQS9DLHVCQUFtQixpQ0FDZEQsZ0JBRGM7QUFFakJKLFdBQUssRUFBRUksZ0JBQWdCLENBQUNKLEtBQWpCLEdBQXVCQSxLQUZiO0FBR2pCTixjQUFRLEVBQUVBO0FBSE8sT0FBbkI7QUFLRCxHQXZCRDs7QUF5QkEsTUFBTXlFLFNBQVMsR0FBRyxTQUFaQSxTQUFZLEdBQWU7QUFBQSxRQUFkckQsSUFBYyx1RUFBUCxFQUFPO0FBQy9CRyxnREFBSyxDQUFDQyxJQUFOLFdBQWNDLDZCQUFkLGNBQXVETCxJQUF2RCxFQUE0RDtBQUMxRE8sYUFBTyxFQUFDO0FBQ05DLHFCQUFhLG1CQUFZeEMsS0FBSyxDQUFDQyxLQUFOLENBQVl3QyxJQUFaLENBQWlCQyxXQUE3QjtBQURQO0FBRGtELEtBQTVELEVBSUdDLElBSkgsQ0FJUSxVQUFBQyxHQUFHLEVBQUk7QUFDYlgsYUFBTyxDQUFDQyxHQUFSLENBQVksS0FBWixFQUFrQlUsR0FBRyxDQUFDWixJQUFKLENBQVNzRCxHQUEzQjtBQUNDQyxZQUFNLENBQUNDLFFBQVAsQ0FBZ0JDLElBQWhCLEdBQXVCN0MsR0FBRyxDQUFDWixJQUFKLENBQVNzRCxHQUFoQztBQUNGLEtBUEQsV0FPUyxVQUFBeEMsR0FBRztBQUFBLGFBQUliLE9BQU8sQ0FBQ0MsR0FBUixDQUFZWSxHQUFaLENBQUo7QUFBQSxLQVBaO0FBUUQsR0FURDs7QUFXQSxNQUFNNEMsWUFBWSxHQUFHLFNBQWZBLFlBQWUsR0FBTTtBQUN6QixRQUFHMUYsS0FBSyxDQUFDQyxLQUFOLENBQVl3QyxJQUFaLENBQWlCQSxJQUFqQixDQUFzQmtELE9BQXRCLElBQWlDLENBQXBDLEVBQXNDO0FBQ3BDM0YsV0FBSyxDQUFDNEYsa0JBQU4sQ0FBeUIsU0FBekIsRUFBbUM7QUFDakNmLGFBQUssRUFBQ3ZELGdCQUFnQixDQUFDSCxhQURVO0FBRWpDMEUsa0JBQVUsRUFBQyxDQUZzQjtBQUdqQ2hELGVBQU8sRUFBQ3ZCLGdCQUFnQixDQUFDVjtBQUhRLE9BQW5DLEVBS0E7QUFDRSwwQ0FBMEJaLEtBQUssQ0FBQ0MsS0FBTixDQUFZd0MsSUFBWixDQUFpQkMsV0FBM0M7QUFERixPQUxBO0FBUUQsS0FURCxNQVNLO0FBQ0hvRCx5REFBSSxDQUFDQyxJQUFMLENBQVU7QUFDUkMsWUFBSSxFQUFFLHNDQURFO0FBRVJDLFlBQUksRUFBRSxNQUZFO0FBR1JDLHlCQUFpQixFQUFFO0FBSFgsT0FBVjtBQUtEO0FBRUYsR0FsQkQ7O0FBb0JBLHNCQUNFLHFFQUFDLDhEQUFEO0FBQU0sYUFBUyxFQUFDLG1CQUFoQjtBQUFBLDRCQUNFLHFFQUFDLGdFQUFEO0FBQU8sZUFBUyxFQUFDLE9BQWpCO0FBQUEsNkJBQ0UscUVBQUMscUVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQUlFLHFFQUFDLDhEQUFEO0FBQU0sZUFBUyxFQUFDLGFBQWhCO0FBQUEsOEJBQ0UscUVBQUMsOERBQUQ7QUFBTSxpQkFBUyxFQUFDLHlCQUFoQjtBQUFBLGdDQUNFLHFFQUFDLDhEQUFELENBQU0sTUFBTjtBQUNFLGNBQUksRUFBRXpGLENBQUMsQ0FBQztBQUFFMkQsY0FBRSxFQUFFO0FBQU4sV0FBRCxDQURUO0FBRUUscUJBQVcsZUFDVCxxRUFBQyxzRUFBRDtBQUNFLGdCQUFJLEVBQUUzRCxDQUFDLENBQUM7QUFBRTJELGdCQUFFLEVBQUU7QUFBTixhQUFELENBRFQ7QUFFRSxlQUFHLEVBQUUsYUFBQ1osR0FBRDtBQUFBLHFCQUFVOUIsWUFBWSxDQUFDRyxPQUFiLEdBQXVCMkIsR0FBakM7QUFBQSxhQUZQO0FBR0UsbUJBQU8sRUFBRTBCLFNBSFg7QUFJRSxxQkFBUyxFQUFDO0FBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFZRTtBQUFLLG1CQUFNLEtBQVg7QUFBaUIsZUFBSyxFQUFFO0FBQUVpQixxQkFBUyxFQUFFO0FBQWIsV0FBeEI7QUFBQSxpQ0FDRTtBQUNFLHFCQUFTLEVBQUMsVUFEWjtBQUVFLGlCQUFLLEVBQUU7QUFDTEMscUJBQU8sRUFBRSxNQURKO0FBRUxDLDBCQUFZLEVBQUUsTUFGVDtBQUdMQyxtQkFBSyxFQUFFO0FBSEYsYUFGVDtBQUFBLG9DQVNFLHFFQUFDLDJEQUFEO0FBQ0UsbUJBQUssd0JBQVkxRixRQUFRLENBQUMyRixNQUFyQixNQURQO0FBRUUsdUJBQVMsRUFBQyw4QkFGWjtBQUdFLHlCQUFTLENBSFg7QUFJRSxpQkFBRyxFQUFFaEQsVUFKUDtBQUtFLHFCQUFPLEVBQUVjO0FBTFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFURixFQWlCSXJELE1BQU0sQ0FBQ3dGLEdBQVAsQ0FBVyxVQUFDMUMsQ0FBRDtBQUFBLGtDQUNYLHFFQUFDLDJEQUFEO0FBQ0UscUJBQUssWUFBS0EsQ0FBQyxDQUFDMkMsSUFBUCxlQUFnQjNDLENBQUMsQ0FBQzRDLEtBQWxCLE1BRFA7QUFFRSx5QkFBUyxFQUFDLGNBRlo7QUFHRSwyQkFBUzVDLENBQUMsQ0FBQ00sRUFIYjtBQUlFLG1CQUFHLEVBQUViLFVBSlA7QUFLRSx1QkFBTyxFQUFFYztBQUxYO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRFc7QUFBQSxhQUFYLENBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWkYsZUEyQ0UscUVBQUMsOERBQUQsQ0FBTSxJQUFOO0FBQVcsbUJBQVMsRUFBQyxRQUFyQjtBQUFBLGlDQUNFO0FBQUsscUJBQVMsRUFBQyxjQUFmO0FBQUEsc0JBQ0d2RCxhQUFhLENBQ1gwRCxNQURGLENBQ1MsVUFBQ1YsQ0FBRDtBQUFBLHFCQUFPQSxDQUFDLENBQUM5QyxNQUFGLENBQVNvRCxFQUFULEtBQWdCLENBQXZCO0FBQUEsYUFEVCxFQUVFb0MsR0FGRixDQUVNLFVBQUNwQixDQUFEO0FBQUEsa0NBQ0gscUVBQUMsOEVBQUQ7QUFFRSx3QkFBUSxFQUFFWCxZQUZaO0FBR0Usb0JBQUksRUFBRVcsQ0FIUjtBQUlFLHVCQUFPLEVBQUVWO0FBSlgsaUJBQ09VLENBQUMsQ0FBQ2hCLEVBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERztBQUFBLGFBRk47QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkEzQ0YsZUF5REU7QUFBSyxtQkFBUyxFQUFDLGFBQWY7QUFBQSxrQ0FDRTtBQUFLLHFCQUFTLEVBQUMsZUFBZjtBQUFBLG9DQUNFO0FBQUEseUJBQ0c5QyxnQkFBZ0IsQ0FBQ1YsUUFBakIsQ0FBMEIyRixNQUQ3QixPQUNzQzlGLENBQUMsQ0FBQztBQUFFMkQsa0JBQUUsRUFBRTtBQUFOLGVBQUQsQ0FEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQURGLGVBSUU7QUFBSyxtQkFBSyxFQUFFO0FBQUVnQyx1QkFBTyxFQUFFLE1BQVg7QUFBbUJPLDhCQUFjLEVBQUU7QUFBbkMsZUFBWjtBQUFBLHNDQUNFO0FBQUEsMkJBQUlsRyxDQUFDLENBQUM7QUFBRTJELG9CQUFFLEVBQUU7QUFBTixpQkFBRCxDQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFERixlQUVFO0FBQUsscUJBQUssRUFBRTtBQUFFZ0MseUJBQU8sRUFBRSxNQUFYO0FBQW1CUSwrQkFBYSxFQUFFO0FBQWxDLGlCQUFaO0FBQUEsMEJBRUV0RixnQkFBZ0IsQ0FBQ0gsYUFBakIsR0FBaUMsQ0FBakMsZ0JBQ0E7QUFBQSwwQ0FDQTtBQUFLLHlCQUFLLEVBQUU7QUFBRTBGLHlDQUFtQixFQUFFO0FBQXZCLHFCQUFaO0FBQUEsK0JBQTZDN0IsVUFBVSxDQUFDMUQsZ0JBQWdCLENBQUNKLEtBQWxCLENBQVYsQ0FBbUM0RixPQUFuQyxDQUEyQyxDQUEzQyxDQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREEsZUFFQztBQUFBLCtCQUFJOUIsVUFBVSxDQUFDMUQsZ0JBQWdCLENBQUNILGFBQWxCLENBQVYsQ0FBMkMyRixPQUEzQyxDQUFtRCxDQUFuRCxDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFGRDtBQUFBLGdDQURBLGdCQUtJO0FBQUEsNkJBQUk5QixVQUFVLENBQUMxRCxnQkFBZ0IsQ0FBQ0gsYUFBbEIsQ0FBVixDQUEyQzJGLE9BQTNDLENBQW1ELENBQW5ELENBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUE47QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGLGVBcUJFO0FBQUsscUJBQVMsRUFBQyxlQUFmO0FBQUEsb0NBQ0U7QUFBQSxxQ0FDRSxxRUFBQywwRUFBRDtBQUNFLHlCQUFTLEVBQUMsZ0JBRFo7QUFFRSx5QkFBUyxFQUFFO0FBQUVDLHdCQUFNLEVBQUUsTUFBVjtBQUFrQlQsdUJBQUssRUFBRTtBQUF6QixpQkFGYjtBQUdFLHlCQUFTLEVBQUMsdUJBSFo7QUFJRSxxQkFBSyxFQUFFO0FBQUVELDhCQUFZLEVBQUU7QUFBaEIsaUJBSlQ7QUFLRSxxQkFBSyx1QkFBRS9GLE1BQU0sQ0FBQ2dDLFNBQVQsc0RBQUUsa0JBQWtCUyxPQUwzQjtBQUFBLHdDQU9FLHFFQUFDLGdFQUFEO0FBQ0UsNkJBQVcsRUFBRXRDLENBQUMsQ0FBQztBQUFFMkQsc0JBQUUsRUFBRTtBQUFOLG1CQUFELENBRGhCO0FBRUUsc0JBQUksRUFBQyxXQUZQO0FBR0UscUJBQUcsRUFBRWhFLFFBQVEsQ0FBQztBQUNaNEcsNEJBQVEsRUFBRTtBQUNSckMsMkJBQUssRUFBRSxJQURDO0FBRVI1Qiw2QkFBTyxFQUFFdEMsQ0FBQyxDQUFDO0FBQUUyRCwwQkFBRSxFQUFFO0FBQU4sdUJBQUQ7QUFGRjtBQURFLG1CQUFELENBSGY7QUFTRSwwQkFBUSxFQUFFLGtCQUFDZSxDQUFEO0FBQUEsMkJBQ1I1RCxtQkFBbUIsaUNBQ2RELGdCQURjO0FBRWpCRiwwQkFBSSxFQUFFK0QsQ0FBQyxDQUFDbEIsTUFBRixDQUFTVTtBQUZFLHVCQURYO0FBQUE7QUFUWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQVBGLEVBdUJHckQsZ0JBQWdCLENBQUNELFVBQWpCLGdCQUNDLHFFQUFDLDJEQUFEO0FBQ0UsMkJBQVMsRUFBQyxlQURaO0FBRUUsdUJBQUssRUFBRTtBQUNMNEYsc0NBQWtCLEVBQUUsV0FEZjtBQUVMQyx5QkFBSyxFQUFFLFVBRkY7QUFHTEMsMkJBQU8sRUFBRTtBQUhKLG1CQUZUO0FBT0UsdUJBQUssRUFBQyxtQkFQUjtBQVFFLHlCQUFPLEVBQUUsbUJBQU07QUFDYjVGLHVDQUFtQixpQ0FDZEQsZ0JBRGM7QUFFakJELGdDQUFVLEVBQUU7QUFGSyx1QkFBbkI7QUFJRDtBQWJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREQsZ0JBaUJDLHFFQUFDLDJEQUFEO0FBQ0UsMEJBQVEsRUFBRSxDQUFDQyxnQkFBZ0IsQ0FBQ0YsSUFBbEIsR0FBeUIsSUFBekIsR0FBZ0MsS0FENUM7QUFFRSx1QkFBSyxFQUFFO0FBQUUrRiwyQkFBTyxFQUFFO0FBQVgsbUJBRlQ7QUFHRSwyQkFBUyxFQUFDLHdCQUhaO0FBSUUsdUJBQUssRUFBRTFHLENBQUMsQ0FBQztBQUFFMkQsc0JBQUUsRUFBRTtBQUFOLG1CQUFELENBSlY7QUFLRSxzQkFBSSxFQUFDLFFBTFA7QUFNRSx5QkFBTyxFQUFFL0QsWUFBWSxDQUFDMEIsTUFBRCxDQU52QixDQU9FO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQXhDSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQURGLGVBNERFLHFFQUFDLDJEQUFEO0FBQ0UsbUJBQUssRUFBRTtBQUFFb0YsdUJBQU8sRUFBRTtBQUFYLGVBRFQ7QUFFRSx1QkFBUyxFQUFDLG1DQUZaO0FBR0UsbUJBQUssRUFBRTFHLENBQUMsQ0FBQztBQUFFMkQsa0JBQUUsRUFBRTtBQUFOLGVBQUQsQ0FIVjtBQUlFLHdCQUFVLGVBQUU7QUFBTSx5QkFBUyxFQUFDLG1CQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFKZDtBQUtFLHFCQUFPLEVBQUk7QUFBQSx1QkFBTWlCLFNBQVMsQ0FBQztBQUN6QlIsdUJBQUssRUFBQ3ZELGdCQUFnQixDQUFDSCxhQURFO0FBRXpCMEUsNEJBQVUsRUFBQyxDQUZjO0FBR3pCaEQseUJBQU8sRUFBQ3ZCLGdCQUFnQixDQUFDVjtBQUhBLGlCQUFELENBQWY7QUFBQTtBQUxiO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBNURGLGVBdUVFLHFFQUFDLDJEQUFEO0FBQ0UsbUJBQUssRUFBRTtBQUFFdUcsdUJBQU8sRUFBRTtBQUFYLGVBRFQ7QUFFRSx1QkFBUyxFQUFDLE1BRlo7QUFHRSxtQkFBSyxFQUFFMUcsQ0FBQyxDQUFDO0FBQUUyRCxrQkFBRSxFQUFFO0FBQU4sZUFBRCxDQUhWO0FBSUUsd0JBQVUsZUFDUjtBQUFNLHlCQUFTLEVBQUMsMEJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUxKO0FBT0UscUJBQU8sRUFBSXNCO0FBUGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkF2RUYsZUFpRkU7QUFBSyx1QkFBUyxFQUFDLFVBQWY7QUFBQSxzQ0FDRSxxRUFBQywyREFBRDtBQUNFLHFCQUFLLEVBQUU7QUFBRXlCLHlCQUFPLEVBQUU7QUFBWCxpQkFEVDtBQUVFLHlCQUFTLEVBQUMsOEJBRlo7QUFHRSxxQkFBSyxFQUFFMUcsQ0FBQyxDQUFDO0FBQUUyRCxvQkFBRSxFQUFFO0FBQU4saUJBQUQsQ0FIVjtBQUlFLDBCQUFVLGVBQ1I7QUFBTSwyQkFBUyxFQUFDLG1CQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFMSjtBQU9FLHVCQUFPLEVBQUk7QUFBQSx5QkFBTWlCLFNBQVMsQ0FBQztBQUN6QlIseUJBQUssRUFBQ3ZELGdCQUFnQixDQUFDSCxhQURFO0FBRXpCMEUsOEJBQVUsRUFBQyxDQUZjO0FBR3pCaEQsMkJBQU8sRUFBQ3ZCLGdCQUFnQixDQUFDVjtBQUhBLG1CQUFELENBQWY7QUFBQTtBQVBiO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBREYsZUFjRSxxRUFBQywyREFBRDtBQUNFLHFCQUFLLEVBQUU7QUFBRXVHLHlCQUFPLEVBQUU7QUFBWCxpQkFEVDtBQUVFLHFCQUFLLEVBQUUxRyxDQUFDLENBQUM7QUFBRTJELG9CQUFFLEVBQUU7QUFBTixpQkFBRCxDQUZWO0FBR0UsMEJBQVUsZUFDUjtBQUFNLDJCQUFTLEVBQUMseUJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUpKO0FBTUUsdUJBQU8sRUFBSXNCO0FBTmI7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBakZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQXpERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQTJMRSxxRUFBQyw4REFBRDtBQUFNLGlCQUFTLEVBQUMsZUFBaEI7QUFBQSxnQ0FDRSxxRUFBQyw4REFBRCxDQUFNLE1BQU47QUFBYSxjQUFJLEVBQUVqRixDQUFDLENBQUM7QUFBRTJELGNBQUUsRUFBRTtBQUFOLFdBQUQ7QUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQUVFLHFFQUFDLDhEQUFELENBQU0sSUFBTjtBQUFXLG1CQUFTLEVBQUMsMEJBQXJCO0FBQUEsaUNBQ0UscUVBQUMsZ0VBQUQ7QUFDRSxjQUFFLEVBQUUsQ0FDRjNELENBQUMsQ0FBQztBQUFFMkQsZ0JBQUUsRUFBRTtBQUFOLGFBQUQsQ0FEQyxFQUVGM0QsQ0FBQyxDQUFDO0FBQUUyRCxnQkFBRSxFQUFFO0FBQU4sYUFBRCxDQUZDLEVBR0YzRCxDQUFDLENBQUM7QUFBRTJELGdCQUFFLEVBQUU7QUFBTixhQUFELENBSEMsRUFJRjNELENBQUMsQ0FBQztBQUFFMkQsZ0JBQUUsRUFBRTtBQUFOLGFBQUQsQ0FKQyxFQUtGM0QsQ0FBQyxDQUFDO0FBQUUyRCxnQkFBRSxFQUFFO0FBQU4sYUFBRCxDQUxDLEVBTUYzRCxDQUFDLENBQUM7QUFBRTJELGdCQUFFLEVBQUU7QUFBTixhQUFELENBTkMsRUFPRjNELENBQUMsQ0FBQztBQUFFMkQsZ0JBQUUsRUFBRTtBQUFOLGFBQUQsQ0FQQyxDQUROO0FBVUUsZ0JBQUksRUFDRnhELFFBQVEsQ0FBQzRGLEdBQVQsQ0FBYSxVQUFDMUMsQ0FBRCxFQUFPO0FBQ2xCLGtCQUFJQSxDQUFDLENBQUM5QyxNQUFGLENBQVNvRCxFQUFULElBQWUsQ0FBbkIsRUFBc0I7QUFDcEIsdUJBQU87QUFDTGdELDhCQUFZLEVBQUV0RCxDQUFDLENBQUNzRCxZQURYO0FBRUxDLHNCQUFJLEVBQUV2RCxDQUFDLENBQUN1RCxJQUZIO0FBR0xDLDBCQUFRLEVBQUV4RCxDQUFDLENBQUN3RCxRQUhQO0FBSUx6Qyx1QkFBSyxZQUFLZixDQUFDLENBQUNlLEtBQVAsY0FBZ0JmLENBQUMsQ0FBQ3lELFFBQWxCLENBSkE7QUFLTEMsd0JBQU0sWUFBS3hDLFVBQVUsQ0FBQ2xCLENBQUMsQ0FBQzBELE1BQUgsQ0FBVixDQUFxQlYsT0FBckIsQ0FBNkIsQ0FBN0IsS0FBbUMsQ0FBeEMsUUFMRDtBQU1MVyxnQ0FBYyxFQUNaekMsVUFBVSxDQUFDbEIsQ0FBQyxDQUFDMkQsY0FBSCxDQUFWLENBQTZCWCxPQUE3QixDQUFxQyxDQUFyQyxLQUEyQyxDQVB4QztBQVFMOUYsd0JBQU0sWUFBSzhDLENBQUMsQ0FBQzlDLE1BQUYsQ0FBU3lGLElBQWQsZ0JBQXdCM0MsQ0FBQyxDQUFDNEQsSUFBMUI7QUFSRCxpQkFBUDtBQVVEO0FBQ0YsYUFiRCxLQWFNLEVBeEJWO0FBMEJFLHNCQUFVLEVBQUUsb0JBQUM1RCxDQUFELEVBQUk2RCxDQUFKLEVBQVU7QUFDcEIsa0NBQU87QUFBQSwwQkFBZTdEO0FBQWYsaUJBQVM2RCxDQUFDLEVBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBUDtBQUNEO0FBNUJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQTNMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQXNPRDs7R0FyZFE1SCxRO1VBSzhDSSx1RCxFQUN4Qkssa0QsRUFhVmdCLHFEOzs7S0FuQlp6QixROztBQXVkVCxJQUFNNkgsZUFBZSxHQUFHLFNBQWxCQSxlQUFrQixDQUFDQyxLQUFEO0FBQUEsU0FBWTtBQUNsQzVILFNBQUssRUFBRTRILEtBQUssQ0FBQzVIO0FBRHFCLEdBQVo7QUFBQSxDQUF4Qjs7QUFHQSxJQUFNNkgsa0JBQWtCLEdBQUk7QUFDMUJsQyxvQkFBa0IsRUFBbEJBLDZFQUFrQkE7QUFEUSxDQUE1QjtBQUllbUMsMkhBQU8sQ0FBQ0gsZUFBRCxFQUFrQkUsa0JBQWxCLENBQVAsZUFBNkNFLGtEQUFJLENBQUNqSSxRQUFELENBQWpELENBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvcGFja2FnZXMuNzFmNzA2MWJkMjNmYjgxMzJkMzIuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcbmltcG9ydCBSZWFjdCwgeyBtZW1vLCB1c2VMYXlvdXRFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlRm9ybSB9IGZyb20gXCJyZWFjdC1ob29rLWZvcm1cIjtcclxuaW1wb3J0IHsgdXNlSW50bCB9IGZyb20gXCJyZWFjdC1pbnRsXCI7XHJcbmltcG9ydCB7IGNvbm5lY3QgfSBmcm9tIFwicmVhY3QtcmVkdXhcIjtcclxuaW1wb3J0IEFzaWRlTWVudSBmcm9tIFwiLi4vY29tcG9uZW50cy9hc2lkZS1tZW51L2luZGV4XCI7XHJcbmltcG9ydCBBc2lkZSBmcm9tIFwiLi4vY29tcG9uZW50cy9hc2lkZS9hc2lkZVwiO1xyXG5pbXBvcnQgQnV0dG9uQ29tcG9uZW50IGZyb20gXCIuLi9jb21wb25lbnRzL2J1dHRvblwiO1xyXG5pbXBvcnQgQ2FyZCBmcm9tIFwiLi4vY29tcG9uZW50cy9jYXJkL2NhcmRcIjtcclxuaW1wb3J0IENoZWNrYm94IGZyb20gXCIuLi9jb21wb25lbnRzL2NoZWNrYm94L2NoZWNrYm94XCI7XHJcbmltcG9ydCBGcm9tR3JvdXAgZnJvbSBcIi4uL2NvbXBvbmVudHMvZm9ybS1ncm91cC9mb3JtLWdyb3VwXCI7XHJcbmltcG9ydCBJbnB1dCBmcm9tIFwiLi4vY29tcG9uZW50cy9pbnB1dC9pbnB1dFwiO1xyXG5pbXBvcnQgTWFpbiBmcm9tIFwiLi4vY29tcG9uZW50cy9tYWluL21haW5cIjtcclxuaW1wb3J0IFBhY2thZ2VJdGVtIGZyb20gXCIuLi9jb21wb25lbnRzL3BhY2thZ2VfaXRlbS9wYWNrYWdlLWl0ZW1cIjtcclxuaW1wb3J0IFBhZ2UgZnJvbSBcIi4uL2NvbXBvbmVudHMvcGFnZS9wYWdlXCI7XHJcbmltcG9ydCBSZWRpcmVjdCBmcm9tIFwiLi4vY29tcG9uZW50cy9yZWRpcmVjdC9yZWRpcmVjdFwiO1xyXG5pbXBvcnQgVGFiZWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvdGFiZWwvdGFiZWxcIjtcclxuaW1wb3J0IFN3YWwgZnJvbSBcInN3ZWV0YWxlcnQyXCI7XHJcbmltcG9ydCB7IFBheUJ5QmFsYW5jZUFjdGlvbiB9IGZyb20gJy4uL3JlZHV4L2VudHJ5L2VudHJ5QWN0aW9ucyc7XHJcblxyXG5mdW5jdGlvbiBQYWNrYWdlcyhwcm9wcykge1xyXG4gIGlmICghcHJvcHMuZW50cnkuaXNMb2dlZCkge1xyXG4gICAgcmV0dXJuIDxSZWRpcmVjdCAvPjtcclxuICB9XHJcblxyXG4gIGNvbnN0IHsgcmVnaXN0ZXIsIGhhbmRsZVN1Ym1pdCwgZXJyb3JzLCBzZXRFcnJvciB9ID0gdXNlRm9ybSgpO1xyXG4gIGNvbnN0IHsgZm9ybWF0TWVzc2FnZTogZiB9ID0gdXNlSW50bCgpO1xyXG4gIGNvbnN0IFtwYWNrYWdlcywgc2V0UGFja2FnZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtmaWx0ZXJlZFBhY2tzLCBzZXRGaWx0ZXJlZFBhY2tzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc3RhdHVzLCBzZXRTdGF0dXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFBhY2thZ2VzLCBzZXRTZWxlY3RlZFBhY2thZ2VzXSA9IHVzZVN0YXRlKHtcclxuICAgIHBhY2thZ2VzOiBbXSxcclxuICAgIHRvdGFsOiAwLFxyXG4gICAgZGlzY291bnRUb3RhbDowLFxyXG4gICAgY29kZTogXCJcIixcclxuICAgIGlzQWNjZXB0ZWQ6IGZhbHNlLFxyXG4gICAgc3RhdHVzOiAwLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCB7IGxvY2FsZSB9ID0gdXNlUm91dGVyKCk7XHJcbiAgY29uc3QgbWFpbkNoZWNrUmVmID0gdXNlUmVmKCk7XHJcbiAgY29uc3QgY2hlY2tSZWZzID0gdXNlUmVmKFtdKTtcclxuICBjaGVja1JlZnMuY3VycmVudCA9IFtdO1xyXG4gIGNvbnN0IHRhYlJlZnMgPSB1c2VSZWYoW10pO1xyXG4gIHRhYlJlZnMuY3VycmVudCA9IFtdO1xyXG5cclxuICBjb25zdCBzdWJtaXQgPSAoZGF0YSkgPT4ge1xyXG4gICAgY29uc29sZS5sb2coZGF0YSk7XHJcblxyXG4gICAgYXhpb3NcclxuICAgICAgLnBvc3QoXHJcbiAgICAgICAgYCR7cHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQVBJX1VSTH1wcm9tb2NvZGU/cHJvbW9jb2RlPSR7ZGF0YS5wcm9tb2NvZGV9JnN0YXR1cz0ke3NlbGVjdGVkUGFja2FnZXMuc3RhdHVzfWAsXHJcbiAgICAgICAge30sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICBcImNvbnRlbnQtdHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAgICAgICAgICAgYXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Byb3BzLmVudHJ5LnVzZXIuYWNjZXNzVG9rZW59YCxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgICAgIC50aGVuKChyZXMpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhyZXMuZGF0YS5iYXRjaGVzKTtcclxuICAgICAgICBzZXRQYWNrYWdlcyhyZXMuZGF0YS5iYXRjaGVzKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZFBhY2tzKHJlcy5kYXRhLmJhdGNoZXMpO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycikgPT4ge1xyXG4gICAgICAgIHNldEVycm9yKFwicHJvbW9jb2RlXCIsIHsgbWVzc2FnZTogZXJyLnJlc3BvbnNlLmRhdGEuZXJyb3IgfSk7XHJcbiAgICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IFByb21pc0FsbCA9IGFzeW5jICgpID0+IHtcclxuICAgIGxldCBiYXRjaGVzRGF0YSA9IGF3YWl0IGF4aW9zLmdldChgJHtwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19BUElfVVJMfWJhdGNoZXM/bGFuPSR7bG9jYWxlfWAsIHtcclxuICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgIGF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtwcm9wcy5lbnRyeS51c2VyLmFjY2Vzc1Rva2VufWAsXHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuICAgIGxldCBzdGF0dXNEYXRhID0gYXdhaXQgYXhpb3MuZ2V0KGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9c3RhdHVzP2xhbj0ke2xvY2FsZX1gLCB7XHJcbiAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICBhdXRob3JpemF0aW9uOiBgQmVhcmVyICR7cHJvcHMuZW50cnkudXNlci5hY2Nlc3NUb2tlbn1gLFxyXG4gICAgICB9LFxyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgYmF0Y2hlc0RhdGE6YmF0Y2hlc0RhdGEuZGF0YSxcclxuICAgICAgc3RhdHVzRGF0YTpzdGF0dXNEYXRhLmRhdGFcclxuICAgIH1cclxuICB9XHJcbiAgdXNlTGF5b3V0RWZmZWN0KCgpID0+IHtcclxuICAgIFByb21pc0FsbCgpLnRoZW4ocmVzID0+IHtcclxuICAgICAgc2V0UGFja2FnZXMocmVzLmJhdGNoZXNEYXRhKTtcclxuICAgICAgc2V0RmlsdGVyZWRQYWNrcyhyZXMuYmF0Y2hlc0RhdGEpO1xyXG4gICAgICBzZXRTdGF0dXMocmVzLnN0YXR1c0RhdGEpO1xyXG4gICAgfSkuY2F0Y2goZXJyID0+IGNvbnNvbGUubG9nKGVycikpXHJcblxyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgYWRkVGFiUmVmcyA9IChyZWYpID0+IHtcclxuICAgIGlmIChyZWYgJiYgIXRhYlJlZnMuY3VycmVudC5pbmNsdWRlcyhyZWYpKSB7XHJcbiAgICAgIHRhYlJlZnMuY3VycmVudC5wdXNoKHJlZik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgdG9nZ2xlVGFiUmVmcyA9IGFzeW5jIChldikgPT4ge1xyXG4gICAgdGFiUmVmcy5jdXJyZW50LmZvckVhY2goKHgpID0+IHguY2xhc3NMaXN0LnJlbW92ZShcInBhY2stYWN0aXZlXCIpKTtcclxuICAgIGV2LnRhcmdldC5jbGFzc0xpc3QuYWRkKFwicGFjay1hY3RpdmVcIik7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZ2V0QmF0Y2hlc0J5U3RhdGF1c0lkID0gYXN5bmMgKGlkKSA9PntcclxuICAgICBheGlvcy5nZXQoYCR7cHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQVBJX1VSTH1iYXRjaGVzP3N0YXR1cz0ke2lkfSZsYW49JHtsb2NhbGV9YCwge1xyXG4gICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgYXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Byb3BzLmVudHJ5LnVzZXIuYWNjZXNzVG9rZW59YCxcclxuICAgICAgfSxcclxuICAgIH0pLnRoZW4oKHJlcykgPT4ge1xyXG4gICAgICBzZXRQYWNrYWdlcyhyZXMuZGF0YSk7XHJcbiAgICAgIHNldEZpbHRlcmVkUGFja3MocmVzLmRhdGEpO1xyXG4gICAgfSkuY2F0Y2goZXJyID0+IGNvbnNvbGUubG9nKGVycikpXHJcblxyXG4gIFxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHRhYkJ1dHRvbkNsaWNrID0gKGV2KSA9PiB7XHJcbiAgICBsZXQgaWQgPSBldi50YXJnZXQuZ2V0QXR0cmlidXRlKFwiZGF0YS1pZFwiKTtcclxuICAgIHRvZ2dsZVRhYlJlZnMoZXYpO1xyXG4gICAgZ2V0QmF0Y2hlc0J5U3RhdGF1c0lkKGlkKVxyXG4gICAgaWYgKGlkICE9IDApIHtcclxuICAgICAgbGV0IG5ld1BhY2thZ2VzID0gcGFja2FnZXMuZmlsdGVyKCh4KSA9PiB4LnN0YXR1cy5pZCA9PSBpZCk7XHJcbiAgICAgIHNldEZpbHRlcmVkUGFja3MoWy4uLm5ld1BhY2thZ2VzXSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRGaWx0ZXJlZFBhY2tzKFsuLi5wYWNrYWdlc10pO1xyXG4gICAgfVxyXG5cclxuICAgIHNldFNlbGVjdGVkUGFja2FnZXMoe1xyXG4gICAgICBkaXNjb3VudFRvdGFsOiAwLFxyXG4gICAgICBwYWNrYWdlczogW10sXHJcbiAgICAgIHRvdGFsOiAwLFxyXG4gICAgICBjb2RlOiBcIlwiLFxyXG4gICAgICBpc0FjY2VwdGVkOiBmYWxzZSxcclxuICAgICAgc3RhdHVzOiBpZCxcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGFkZENoZWNrUmVmcyA9IChyZWYpID0+IHtcclxuICAgIGlmIChyZWYgJiYgIWNoZWNrUmVmcy5jdXJyZW50LmluY2x1ZGVzKHJlZikpIHtcclxuICAgICAgY2hlY2tSZWZzLmN1cnJlbnQucHVzaChyZWYpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNoZWNrSGFuZGxlciA9IChldikgPT4ge1xyXG4gICAgbGV0IHsgdmFsdWUsIGNoZWNrZWQgfSA9IGV2LnRhcmdldDtcclxuICAgIGxldCBwcmljZSA9IGV2LnRhcmdldC5nZXRBdHRyaWJ1dGUoXCJkYXRhLXByaWNlXCIpO1xyXG4gICAgbGV0IGRhdGFEaXNjb3VudCA9IGV2LnRhcmdldC5nZXRBdHRyaWJ1dGUoXCJkYXRhLWRpc2NvdW50XCIpO1xyXG4gICAgbGV0IHRvdGFsPTBcclxuICAgIGxldCBkaXNjPTBcclxuICAgIGNvbnNvbGUubG9nKCdkaXMnLGRhdGFEaXNjb3VudClcclxuICAgIGlmIChjaGVja2VkKSB7XHJcbiAgICAgIHNlbGVjdGVkUGFja2FnZXMucGFja2FnZXMucHVzaCh2YWx1ZSk7XHJcbiAgICAgIGlmKGRhdGFEaXNjb3VudCE9MCl7XHJcbiAgICAgICAgc2V0U2VsZWN0ZWRQYWNrYWdlcyh7XHJcbiAgICAgICAgICAuLi5zZWxlY3RlZFBhY2thZ2VzLFxyXG5cclxuICAgICAgICAgIHRvdGFsOiAoc2VsZWN0ZWRQYWNrYWdlcy50b3RhbCtwYXJzZUZsb2F0KHByaWNlKSksXHJcbiAgICAgICAgIFxyXG4gICAgICAgICAgZGlzY291bnRUb3RhbDogKHNlbGVjdGVkUGFja2FnZXMuZGlzY291bnRUb3RhbCtwYXJzZUZsb2F0KGRhdGFEaXNjb3VudCkpLFxyXG4gICAgICAgICAgcGFja2FnZXM6IFsuLi5zZWxlY3RlZFBhY2thZ2VzLnBhY2thZ2VzXSxcclxuICAgICAgICB9KTtcclxuICAgICAgXHJcbiAgICAgIH1lbHNle1xyXG4gICAgICAgIHNldFNlbGVjdGVkUGFja2FnZXMoe1xyXG4gICAgICAgICAgLi4uc2VsZWN0ZWRQYWNrYWdlcyxcclxuICAgICAgICAgIGRpc2NvdW50VG90YWw6IChzZWxlY3RlZFBhY2thZ2VzLmRpc2NvdW50VG90YWwrcGFyc2VGbG9hdChwcmljZSkpLFxyXG4gICAgICAgICAgdG90YWw6IChzZWxlY3RlZFBhY2thZ2VzLnRvdGFsK3BhcnNlRmxvYXQocHJpY2UpKSxcclxuICAgICAgICAgIHBhY2thZ2VzOiBbLi4uc2VsZWN0ZWRQYWNrYWdlcy5wYWNrYWdlc10sXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgICBcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGxldCBuZXdQYWNrYWdlcyA9IHNlbGVjdGVkUGFja2FnZXMucGFja2FnZXMuZmlsdGVyKCh4KSA9PiB4ICE9PSB2YWx1ZSk7XHJcbiAgICAgIGlmKGRhdGFEaXNjb3VudCE9MCl7XHJcbiAgICAgICAgc2V0U2VsZWN0ZWRQYWNrYWdlcyh7XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC4uLnNlbGVjdGVkUGFja2FnZXMsXHJcblxyXG4gICAgICAgICAgdG90YWw6IHNlbGVjdGVkUGFja2FnZXMudG90YWwgPj0wICYmIChzZWxlY3RlZFBhY2thZ2VzLnRvdGFsLXBhcnNlRmxvYXQocHJpY2UpKSxcclxuICAgICAgICAgXHJcbiAgICAgICAgICBkaXNjb3VudFRvdGFsOiBzZWxlY3RlZFBhY2thZ2VzLmRpc2NvdW50VG90YWwgPj0wICYmICAoc2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsLXBhcnNlRmxvYXQoZGF0YURpc2NvdW50KSksXHJcbiAgICAgICAgICBwYWNrYWdlczogbmV3UGFja2FnZXNcclxuICAgICAgICB9KTtcclxuICAgICAgXHJcbiAgICAgIH1lbHNle1xyXG4gICAgICAgIHNldFNlbGVjdGVkUGFja2FnZXMoe1xyXG4gICAgICAgICAgLi4uc2VsZWN0ZWRQYWNrYWdlcyxcclxuICAgICAgICAgIGRpc2NvdW50VG90YWw6c2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsID49MCAmJiAoc2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsLXBhcnNlRmxvYXQocHJpY2UpKSxcclxuICAgICAgICAgIHRvdGFsOnNlbGVjdGVkUGFja2FnZXMudG90YWwgPj0wICYmIChzZWxlY3RlZFBhY2thZ2VzLnRvdGFsLXBhcnNlRmxvYXQocHJpY2UpKSxcclxuICAgICAgICAgIHBhY2thZ2VzOm5ld1BhY2thZ2VzXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgICBcclxuICAgIH1cclxuICAgICFzZWxlY3RlZFBhY2thZ2VzLnBhY2thZ2VzLnNvbWUoKHgpID0+IHgpXHJcbiAgICAgID8gKG1haW5DaGVja1JlZi5jdXJyZW50LmNoZWNrZWQgPSBmYWxzZSlcclxuICAgICAgOiBudWxsO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHNlbGVjdEFsbCA9IChlKSA9PiB7XHJcbiAgICBsZXQgdG90YWwgPSAwO1xyXG4gICAgbGV0IGRpc2NvdW50VG90YWwgPSAwO1xyXG4gICAgbGV0IHBhY2thZ2VzID0gW107XHJcbiAgICBjaGVja1JlZnMuY3VycmVudC5mb3JFYWNoKCh4KSA9PiB7XHJcbiAgICAgIHguY2hlY2tlZCA9IGUudGFyZ2V0LmNoZWNrZWQ7XHJcblxyXG4gICAgICBpZiAoZS50YXJnZXQuY2hlY2tlZCAmJiAhcGFja2FnZXMuaW5jbHVkZXMoeC52YWx1ZSkpIHtcclxuICAgICAgICBwYWNrYWdlcy5wdXNoKHgudmFsdWUpO1xyXG4gICAgICAgIHRvdGFsICs9ICt4LmdldEF0dHJpYnV0ZShcImRhdGEtcHJpY2VcIik7XHJcbiAgICAgICAgZGlzY291bnRUb3RhbCArPSAreC5nZXRBdHRyaWJ1dGUoXCJkYXRhLWRpc2NvdW50XCIpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHBhY2thZ2VzID0gcGFja2FnZXMuZmlsdGVyKChwKSA9PiBwICE9PSB4LnZhbHVlKTtcclxuICAgICAgICB0b3RhbCAtPSB0b3RhbCA+PSAwICYmICt4LmdldEF0dHJpYnV0ZShcImRhdGEtcHJpY2VcIik7XHJcbiAgICAgICAgZGlzY291bnRUb3RhbCAtPSBkaXNjb3VudFRvdGFsID49MCAmJiAreC5nZXRBdHRyaWJ1dGUoXCJkYXRhLWRpc2NvdW50XCIpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgICBzZXRTZWxlY3RlZFBhY2thZ2VzKHtcclxuICAgICAgLi4uc2VsZWN0ZWRQYWNrYWdlcyxcclxuICAgICAgdG90YWw6IHNlbGVjdGVkUGFja2FnZXMudG90YWwtdG90YWwsXHJcbiAgICAgIHBhY2thZ2VzOiBwYWNrYWdlcyxcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IFBheWJ5Q2FyZCA9IChkYXRhID0ge30pID0+IHtcclxuICAgIGF4aW9zLnBvc3QoYCR7cHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQVBJX1VSTH1wYXltZW50YCxkYXRhLHtcclxuICAgICAgaGVhZGVyczp7XHJcbiAgICAgICAgYXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Byb3BzLmVudHJ5LnVzZXIuYWNjZXNzVG9rZW59YCxcclxuICAgICAgfVxyXG4gICAgfSkudGhlbihyZXMgPT4ge1xyXG4gICAgICBjb25zb2xlLmxvZygncmVkJyxyZXMuZGF0YS51cmwpO1xyXG4gICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSByZXMuZGF0YS51cmw7XHJcbiAgICB9KS5jYXRjaChlcnIgPT4gY29uc29sZS5sb2coZXJyKSlcclxuICB9XHJcblxyXG4gIGNvbnN0IFBheWJ5QmFsYW5jZSA9ICgpID0+IHtcclxuICAgIGlmKHByb3BzLmVudHJ5LnVzZXIudXNlci5iYWxhbmNlID49IDApe1xyXG4gICAgICBwcm9wcy5QYXlCeUJhbGFuY2VBY3Rpb24oJ3BheW1lbnQnLHtcclxuICAgICAgICBwcmljZTpzZWxlY3RlZFBhY2thZ2VzLmRpc2NvdW50VG90YWwsXHJcbiAgICAgICAgc291cmNldHlwZTozLFxyXG4gICAgICAgIGJhdGNoZXM6c2VsZWN0ZWRQYWNrYWdlcy5wYWNrYWdlcyAgICAgICAgICAgICAgICAgIFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgJ2F1dGhvcml6YXRpb24nOmBCZWFyZXIgJHtwcm9wcy5lbnRyeS51c2VyLmFjY2Vzc1Rva2VufWBcclxuICAgICAgfSlcclxuICAgIH1lbHNle1xyXG4gICAgICBTd2FsLmZpcmUoe1xyXG4gICAgICAgIHRleHQ6ICdCYWxhbnNkYSBraWZhecmZdCBxyZlkyZlyIG3JmWJsyZnEnyB5b3hkdXInLFxyXG4gICAgICAgIGljb246ICdpbmZvJyxcclxuICAgICAgICBjb25maXJtQnV0dG9uVGV4dDogJ09LJyxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gIH1cclxuIFxyXG4gIHJldHVybiAoXHJcbiAgICA8UGFnZSBjbGFzc05hbWU9XCJiZy1iZyBwdC1sZyBwYi1sZ1wiPlxyXG4gICAgICA8QXNpZGUgY2xhc3NOYW1lPVwibXItc21cIj5cclxuICAgICAgICA8QXNpZGVNZW51IC8+XHJcbiAgICAgIDwvQXNpZGU+XHJcbiAgICAgIDxNYWluIGNsYXNzTmFtZT1cImJnLWMgcC1ub25lXCI+XHJcbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwiYmctYmcgcGItc20gbWdtX3NzIHAtc21cIj5cclxuICAgICAgICAgIDxDYXJkLkhlYWRlclxyXG4gICAgICAgICAgICB0ZXh0PXtmKHsgaWQ6IFwiYWN0aXZlLXBhY1wiIH0pfVxyXG4gICAgICAgICAgICBlbmRFbGVsbWVudD17XHJcbiAgICAgICAgICAgICAgPENoZWNrYm94XHJcbiAgICAgICAgICAgICAgICB0ZXh0PXtmKHsgaWQ6IFwiY2hvb3NlLWFsbFwiIH0pfVxyXG4gICAgICAgICAgICAgICAgUmVmPXsocmVmKSA9PiAobWFpbkNoZWNrUmVmLmN1cnJlbnQgPSByZWYpfVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17c2VsZWN0QWxsfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyLXN1YnRpdGxlXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cInNzY1wiIHN0eWxlPXt7IG92ZXJmbG93WDogXCJzY3JvbGxcIiB9fT5cclxuICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIiBwbC1ub25lXCJcclxuICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICAgICAgICAgICAgICBtYXJnaW5Cb3R0b206IFwiMjBweFwiLFxyXG4gICAgICAgICAgICAgICAgd2lkdGg6IFwibWF4LWNvbnRlbnRcIixcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcblxyXG4gICAgICAgICAgICAgIDxCdXR0b25Db21wb25lbnRcclxuICAgICAgICAgICAgICAgIGxhYmVsPXtgSGFtc8SxICgke3BhY2thZ2VzLmxlbmd0aH0pYH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1yLXhzIHAteHMgYmctYmcgcGFjay1hY3RpdmVcIlxyXG4gICAgICAgICAgICAgICAgZGF0YS1pZD17MH1cclxuICAgICAgICAgICAgICAgIFJlZj17YWRkVGFiUmVmc31cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3RhYkJ1dHRvbkNsaWNrfVxyXG4gICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICB7c3RhdHVzLm1hcCgoeCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvbkNvbXBvbmVudFxyXG4gICAgICAgICAgICAgICAgICBsYWJlbD17YCR7eC5uYW1lfSAoJHt4LmNvdW50fSlgfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCIgcC14cyBiZy1iZyBcIlxyXG4gICAgICAgICAgICAgICAgICBkYXRhLWlkPXt4LmlkfVxyXG4gICAgICAgICAgICAgICAgICBSZWY9e2FkZFRhYlJlZnN9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3RhYkJ1dHRvbkNsaWNrfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICApKX0gXHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPENhcmQuQm9keSBjbGFzc05hbWU9XCJwLW5vbmVcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYWNrYWdlc19fZnJcIj5cclxuICAgICAgICAgICAgICB7ZmlsdGVyZWRQYWNrc1xyXG4gICAgICAgICAgICAgICAgLmZpbHRlcigoeCkgPT4geC5zdGF0dXMuaWQgIT09IDYpXHJcbiAgICAgICAgICAgICAgICAubWFwKChwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxQYWNrYWdlSXRlbVxyXG4gICAgICAgICAgICAgICAgICAgIGtleT17cC5pZH1cclxuICAgICAgICAgICAgICAgICAgICBjaGVja1JlZj17YWRkQ2hlY2tSZWZzfVxyXG4gICAgICAgICAgICAgICAgICAgIGl0ZW09e3B9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGVjaz17Y2hlY2tIYW5kbGVyfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9DYXJkLkJvZHk+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvb3Rlcl9fcGNrXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGFja2FnZS10b3RhbFwiPlxyXG4gICAgICAgICAgICAgIDxzbWFsbD5cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZFBhY2thZ2VzLnBhY2thZ2VzLmxlbmd0aH0ge2YoeyBpZDogXCJjaG9zZWRcIiB9KX1cclxuICAgICAgICAgICAgICA8L3NtYWxsPlxyXG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiB9fT5cclxuICAgICAgICAgICAgICAgIDxiPntmKHsgaWQ6IFwidG90YWxcIiB9KX06PC9iPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIiB9fT5cclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsID4gMCA/IFxyXG4gICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICA8ZGVsIHN0eWxlPXt7IHRleHREZWNvcmF0aW9uQ29sb3I6IFwicmVkXCIgfX0+e3BhcnNlRmxvYXQoc2VsZWN0ZWRQYWNrYWdlcy50b3RhbCkudG9GaXhlZCgyKX0gQVpOPC9kZWw+XHJcbiAgICAgICAgICAgICAgICAgICA8Yj57cGFyc2VGbG9hdChzZWxlY3RlZFBhY2thZ2VzLmRpc2NvdW50VG90YWwpLnRvRml4ZWQoMil9IEFaTjwvYj5cclxuICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgOiAgPGI+e3BhcnNlRmxvYXQoc2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsKS50b0ZpeGVkKDIpfSBBWk48L2I+XHJcbiAgICAgICAgICAgICAgICB9ICBcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhY2thZ2VfX2J0bnNcIj5cclxuICAgICAgICAgICAgICA8Zm9ybT5cclxuICAgICAgICAgICAgICAgIDxGcm9tR3JvdXBcclxuICAgICAgICAgICAgICAgICAgYm9keUNsYXNzPVwiYmctd2hpdGUgcGwteHNcIlxyXG4gICAgICAgICAgICAgICAgICBib2R5U3R5bGU9e3sgaGVpZ2h0OiBcIjQ0cHhcIiwgd2lkdGg6IFwiMjAwcHhcIiB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtci14cyBjaG5nX19ib2R5c3R5bGVcIlxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBtYXJnaW5Cb3R0b206IFwiMHB4XCIgfX1cclxuICAgICAgICAgICAgICAgICAgZXJyb3I9e2Vycm9ycy5wcm9tb2NvZGU/Lm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtmKHsgaWQ6IFwiYWRkY29kZVwiIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwcm9tb2NvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIFJlZj17cmVnaXN0ZXIoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IGYoeyBpZDogXCJwcm9tby1yZXF1aXJcIiB9KSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRQYWNrYWdlcyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnNlbGVjdGVkUGFja2FnZXMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvZGU6IGUudGFyZ2V0LnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZFBhY2thZ2VzLmlzQWNjZXB0ZWQgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbkNvbXBvbmVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgdy01MFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZXh0RGVjb3JhdGlvbkxpbmU6IFwidW5kZXJsaW5lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcImRhcmtibHVlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IFwiMHB4IDEwcHhcIixcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkzJmcSfdiBldFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkUGFja2FnZXMoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnNlbGVjdGVkUGFja2FnZXMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaXNBY2NlcHRlZDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b25Db21wb25lbnRcclxuICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshc2VsZWN0ZWRQYWNrYWdlcy5jb2RlID8gdHJ1ZSA6IGZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgcGFkZGluZzogXCIwIDEwcHhcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY29sb3Itd2hpdGUgYmctc3VjY2Vzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbD17Zih7IGlkOiBcImNvbmZpcm1cIiB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU3VibWl0KHN1Ym1pdCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAvLyAgb25DbGljaz17KCkgPT57XHJcbiAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgLy8gIHNldFNlbGVjdGVkUGFja2FnZXMoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gICAgIC8vICAgIC4uLnNlbGVjdGVkUGFja2FnZXMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgLy8gICAgaXNBY2NlcHRlZDp0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgLy8gIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9Gcm9tR3JvdXA+XHJcbiAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDxCdXR0b25Db21wb25lbnRcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IHBhZGRpbmc6IFwiMCAyMHB4XCIgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNvbG9yLXdoaXRlIGJnLXN1Y2Nlc3MgbXIteHMgZGVza1wiXHJcbiAgICAgICAgICAgICAgICBsYWJlbD17Zih7IGlkOiBcInBheWJ5Y2FyZFwiIH0pfVxyXG4gICAgICAgICAgICAgICAgZW5kRWxlbWVudD17PHNwYW4gY2xhc3NOYW1lPVwiY29sb3Itd2hpdGUgcGwtc21cIj4mIzg1OTQ7PC9zcGFuPn1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2sgPSB7KCkgPT4gUGF5YnlDYXJkKHtcclxuICAgICAgICAgICAgICAgICAgcHJpY2U6c2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsLFxyXG4gICAgICAgICAgICAgICAgICBzb3VyY2V0eXBlOjIsXHJcbiAgICAgICAgICAgICAgICAgIGJhdGNoZXM6c2VsZWN0ZWRQYWNrYWdlcy5wYWNrYWdlc1xyXG4gICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8QnV0dG9uQ29tcG9uZW50XHJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyBwYWRkaW5nOiBcIjAgMTBweFwiIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJkZXNrXCJcclxuICAgICAgICAgICAgICAgIGxhYmVsPXtmKHsgaWQ6IFwicGF5YnliYWxhbmNlXCIgfSl9XHJcbiAgICAgICAgICAgICAgICBlbmRFbGVtZW50PXtcclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY29sb3ItYmxhY2sgbXIteHMgcGwtc20gXCI+JiM4NTk0Ozwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2sgPSB7UGF5YnlCYWxhbmNlfVxyXG4gICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYnRuX19ma2xcIj5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25Db21wb25lbnRcclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgcGFkZGluZzogXCIwIDEwcHhcIiB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjb2xvci13aGl0ZSBiZy1zdWNjZXNzIG1yLXhzXCJcclxuICAgICAgICAgICAgICAgICAgbGFiZWw9e2YoeyBpZDogXCJwYXlieWNhcmRcIiB9KX1cclxuICAgICAgICAgICAgICAgICAgZW5kRWxlbWVudD17XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY29sb3Itd2hpdGUgcGwtc21cIj4mIzg1OTQ7PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2sgPSB7KCkgPT4gUGF5YnlDYXJkKHtcclxuICAgICAgICAgICAgICAgICAgICBwcmljZTpzZWxlY3RlZFBhY2thZ2VzLmRpc2NvdW50VG90YWwsXHJcbiAgICAgICAgICAgICAgICAgICAgc291cmNldHlwZToyLFxyXG4gICAgICAgICAgICAgICAgICAgIGJhdGNoZXM6c2VsZWN0ZWRQYWNrYWdlcy5wYWNrYWdlc1xyXG4gICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uQ29tcG9uZW50XHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHBhZGRpbmc6IFwiMCAxMHB4XCIgfX1cclxuICAgICAgICAgICAgICAgICAgbGFiZWw9e2YoeyBpZDogXCJwYXlieWJhbGFuY2VcIiB9KX1cclxuICAgICAgICAgICAgICAgICAgZW5kRWxlbWVudD17XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY29sb3ItYmxhY2sgbXIteHMgcGwtc21cIj4mIzg1OTQ7PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2sgPSB7UGF5YnlCYWxhbmNlfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L0NhcmQ+XHJcblxyXG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtc20gYmctd2hpdGVcIj5cclxuICAgICAgICAgIDxDYXJkLkhlYWRlciB0ZXh0PXtmKHsgaWQ6IFwib3JkZXItaGlzdG9yeVwiIH0pfSAvPlxyXG4gICAgICAgICAgPENhcmQuQm9keSBjbGFzc05hbWU9XCJwLW5vbmUgb3ZlcmZsb3dfX3BhY2thZ2VcIj5cclxuICAgICAgICAgICAgPFRhYmVsXHJcbiAgICAgICAgICAgICAgdGg9e1tcclxuICAgICAgICAgICAgICAgIGYoeyBpZDogXCJ0cmFja2luZ1wiIH0pLFxyXG4gICAgICAgICAgICAgICAgZih7IGlkOiBcInNob3BcIiB9KSxcclxuICAgICAgICAgICAgICAgIGYoeyBpZDogXCJjYXRlZ29yeVwiIH0pLFxyXG4gICAgICAgICAgICAgICAgZih7IGlkOiBcImFtb3VudFwiIH0pLFxyXG4gICAgICAgICAgICAgICAgZih7IGlkOiBcIndlaWdodFwiIH0pLFxyXG4gICAgICAgICAgICAgICAgZih7IGlkOiBcImRlbGl2ZXJ5XCIgfSksXHJcbiAgICAgICAgICAgICAgICBmKHsgaWQ6IFwic3RhdHVzXCIgfSksXHJcbiAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICBkYXRhPXtcclxuICAgICAgICAgICAgICAgIHBhY2thZ2VzLm1hcCgoeCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBpZiAoeC5zdGF0dXMuaWQgPT0gNikge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICB0cmFja19udW1iZXI6IHgudHJhY2tfbnVtYmVyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvcDogeC5zaG9wLFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2F0ZWdvcnk6IHguY2F0ZWdvcnksXHJcbiAgICAgICAgICAgICAgICAgICAgICBwcmljZTogYCR7eC5wcmljZX0gJHt4LmN1cnJlbmN5fWAsXHJcbiAgICAgICAgICAgICAgICAgICAgICB3ZWlnaHQ6IGAke3BhcnNlRmxvYXQoeC53ZWlnaHQpLnRvRml4ZWQoMikgfHwgMH0ga3FgLFxyXG4gICAgICAgICAgICAgICAgICAgICAgZGVsaXZlcnlfcHJpY2U6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhcnNlRmxvYXQoeC5kZWxpdmVyeV9wcmljZSkudG9GaXhlZCgyKSB8fCAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiBgJHt4LnN0YXR1cy5uYW1lfVxcbiAke3guZGF0ZX1gLFxyXG4gICAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pIHx8IFtdXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIHJlbmRlckJvZHk9eyh4LCBpKSA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gPHRkIGtleT17aSsrfT57eH08L3RkPjtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9DYXJkLkJvZHk+XHJcbiAgICAgICAgPC9DYXJkPlxyXG4gICAgICA8L01haW4+XHJcbiAgICA8L1BhZ2U+XHJcbiAgKTtcclxufVxyXG5cclxuY29uc3QgbWFwU3RhdGVUb1Byb3BzID0gKHN0YXRlKSA9PiAoe1xyXG4gIGVudHJ5OiBzdGF0ZS5lbnRyeSxcclxufSk7XHJcbmNvbnN0IG1hcERpc3BhdGNoVG9Qcm9wcyA9ICB7XHJcbiAgUGF5QnlCYWxhbmNlQWN0aW9uXHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBjb25uZWN0KG1hcFN0YXRlVG9Qcm9wcywgbWFwRGlzcGF0Y2hUb1Byb3BzKShtZW1vKFBhY2thZ2VzKSk7Il0sInNvdXJjZVJvb3QiOiIifQ==