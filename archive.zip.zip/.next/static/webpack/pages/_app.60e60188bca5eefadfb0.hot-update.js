webpackHotUpdate_N_E("pages/_app",{

/***/ "./redux/entry/entryActions.js":
/*!*************************************!*\
  !*** ./redux/entry/entryActions.js ***!
  \*************************************/
/*! exports provided: Login, UserRegister, LogOut, UpdateUser, PayByBalanceAction, IncreaseBalanceAction */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Login", function() { return Login; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserRegister", function() { return UserRegister; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogOut", function() { return LogOut; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UpdateUser", function() { return UpdateUser; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PayByBalanceAction", function() { return PayByBalanceAction; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IncreaseBalanceAction", function() { return IncreaseBalanceAction; });
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/regenerator */ "./node_modules/next/node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! sweetalert2 */ "./node_modules/sweetalert2/dist/sweetalert2.all.js");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./actions */ "./redux/entry/actions.js");






var Login = function Login(url, data) {
  var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return function (dispatch) {
    axios__WEBPACK_IMPORTED_MODULE_2___default.a.post("".concat("https://166api.titr.az/api/").concat(url), data, {
      headers: headers
    }).then( /*#__PURE__*/function () {
      var _ref = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(res) {
        var data;
        return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return res.data;

              case 2:
                data = _context.sent;
                dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["login"])(data));
                next_router__WEBPACK_IMPORTED_MODULE_3___default.a.push('/packages');

              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));

      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }())["catch"](function (errors) {
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["login"])({
        isError: true,
        errors: errors.response.data
      }));
    });
  };
};
var UserRegister = function UserRegister(url, data) {
  var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return function (dispatch) {
    axios__WEBPACK_IMPORTED_MODULE_2___default.a.post("".concat("https://166api.titr.az/api/").concat(url), data, {
      headers: headers
    }).then( /*#__PURE__*/function () {
      var _ref2 = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2(res) {
        var data;
        return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                sweetalert2__WEBPACK_IMPORTED_MODULE_4___default.a.fire({
                  text: 'Əməliyyat uğurla tamamlandı',
                  icon: 'success',
                  confirmButtonText: 'OK'
                }).then(function (res) {
                  if (res.isConfirmed) {
                    next_router__WEBPACK_IMPORTED_MODULE_3___default.a.push('/myaddresses');
                  }
                });
                _context2.next = 3;
                return res.data;

              case 3:
                data = _context2.sent;
                dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["register"])(data));

              case 5:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }));

      return function (_x2) {
        return _ref2.apply(this, arguments);
      };
    }())["catch"](function (err) {
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["register"])({
        isError: true,
        errors: err.response.data
      }));
    });
  };
};
var LogOut = function LogOut() {
  return function (dispatch) {
    dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["logout"])());
  };
};
var UpdateUser = function UpdateUser(url, data) {
  var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return function (dispatch) {
    axios__WEBPACK_IMPORTED_MODULE_2___default.a.put("".concat("https://166api.titr.az/api/").concat(url), data, {
      headers: headers
    }).then(function (res) {
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["updateUser"])(res.data));
      sweetalert2__WEBPACK_IMPORTED_MODULE_4___default.a.fire({
        text: 'Əməliyyat uğurla yerinə yetirildi',
        icon: 'success',
        confirmButtonText: 'OK'
      });
    })["catch"](function (err) {
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["updateUser"])({
        isError: true,
        errors: err.response.data
      }));
    });
  };
};
var PayByBalanceAction = function PayByBalanceAction(url, data, headers) {
  return function (dispatch) {
    axios__WEBPACK_IMPORTED_MODULE_2___default.a.post("".concat("https://166api.titr.az/api/").concat(url), data, {
      headers: headers
    }).then(function (res) {
      console.log('req', res.data.balance);
      sweetalert2__WEBPACK_IMPORTED_MODULE_4___default.a.fire({
        text: res.data.message,
        icon: 'success',
        confirmButtonText: 'OK'
      });
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["PayByBalance"])(res.data.balance));
      next_router__WEBPACK_IMPORTED_MODULE_3___default.a.push("/success?message=".concat(res.data.message));
    })["catch"](function (err) {
      return console.log(err);
    });
  };
};
var IncreaseBalanceAction = function IncreaseBalanceAction(balance) {
  return function (dispatch) {
    dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["IncreaseBalance"])(balance));
  };
};

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./redux/entry/reducer.js":
/*!********************************!*\
  !*** ./redux/entry/reducer.js ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! redux-persist */ "./node_modules/redux-persist/es/index.js");
/* harmony import */ var _actionTypes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./actionTypes */ "./redux/entry/actionTypes.js");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }



var initialState = {
  user: {},
  errorMessages: {},
  isLoged: false
};

var entryReducer = function entryReducer() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : initialState;
  var action = arguments.length > 1 ? arguments[1] : undefined;

  switch (action.type) {
    case redux_persist__WEBPACK_IMPORTED_MODULE_1__["REHYDRATE"]:
      break;

    case _actionTypes__WEBPACK_IMPORTED_MODULE_2__["LOGIN"]:
      if (action.payload.isError) {
        state = _objectSpread(_objectSpread({}, state), {}, {
          errorMessages: _objectSpread({}, action.payload.errors)
        });
      } else {
        state = _objectSpread(_objectSpread({}, state), {}, {
          errorMessages: {},
          user: _objectSpread({}, action.payload),
          isLoged: true
        });
      }

      break;

    case _actionTypes__WEBPACK_IMPORTED_MODULE_2__["LOGOUT"]:
      state = {
        user: {},
        errorMessages: [],
        isLoged: false
      };
      break;

    case _actionTypes__WEBPACK_IMPORTED_MODULE_2__["REGISTER"]:
      if (action.payload.isError) {
        state = _objectSpread(_objectSpread({}, state), {}, {
          errorMessages: _objectSpread({}, action.payload.errors)
        });
      } else {
        state = {
          user: _objectSpread({}, action.payload),
          errorMessages: {},
          isLoged: false
        };
      }

      break;

    case _actionTypes__WEBPACK_IMPORTED_MODULE_2__["UPDATE_USER"]:
      if (action.payload.isError) {
        state = _objectSpread(_objectSpread({}, state), {}, {
          user: _objectSpread({}, state.user),
          errorMessages: _objectSpread({}, action.payload.errors)
        });
      } else {
        state = _objectSpread(_objectSpread({}, state), {}, {
          user: _objectSpread(_objectSpread({}, state.user), {}, {
            user: _objectSpread({}, action.payload.user)
          }),
          errorMessages: {}
        });
      }

      break;

    case _actionTypes__WEBPACK_IMPORTED_MODULE_2__["INCREASE_BALANCE"]:
      state = _objectSpread(_objectSpread({}, state), {}, {
        user: _objectSpread(_objectSpread({}, state.user), {}, {
          user: _objectSpread(_objectSpread({}, state.user.user), {}, {
            balance: action.payload
          })
        })
      });
      break;

    case _actionTypes__WEBPACK_IMPORTED_MODULE_2__["PAY_BY_BALANCE"]:
      state = _objectSpread(_objectSpread({}, state), {}, {
        user: _objectSpread(_objectSpread({}, state.user), {}, {
          user: _objectSpread(_objectSpread({}, state.user.user), {}, {
            balance: action.payload
          })
        })
      });
      break;

    default:
      state = _objectSpread({}, state);
      break;
  }

  return state;
};

/* harmony default export */ __webpack_exports__["default"] = (entryReducer);

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcmVkdXgvZW50cnkvZW50cnlBY3Rpb25zLmpzIiwid2VicGFjazovL19OX0UvLi9yZWR1eC9lbnRyeS9yZWR1Y2VyLmpzIl0sIm5hbWVzIjpbIkxvZ2luIiwidXJsIiwiZGF0YSIsImhlYWRlcnMiLCJkaXNwYXRjaCIsImF4aW9zIiwicG9zdCIsInByb2Nlc3MiLCJ0aGVuIiwicmVzIiwibG9naW4iLCJyb3V0ZXIiLCJwdXNoIiwiZXJyb3JzIiwiaXNFcnJvciIsInJlc3BvbnNlIiwiVXNlclJlZ2lzdGVyIiwiU3dhbCIsImZpcmUiLCJ0ZXh0IiwiaWNvbiIsImNvbmZpcm1CdXR0b25UZXh0IiwiaXNDb25maXJtZWQiLCJyZWdpc3RlciIsImVyciIsIkxvZ091dCIsImxvZ291dCIsIlVwZGF0ZVVzZXIiLCJwdXQiLCJ1cGRhdGVVc2VyIiwiUGF5QnlCYWxhbmNlQWN0aW9uIiwiY29uc29sZSIsImxvZyIsImJhbGFuY2UiLCJtZXNzYWdlIiwiUGF5QnlCYWxhbmNlIiwiSW5jcmVhc2VCYWxhbmNlQWN0aW9uIiwiSW5jcmVhc2VCYWxhbmNlIiwiaW5pdGlhbFN0YXRlIiwidXNlciIsImVycm9yTWVzc2FnZXMiLCJpc0xvZ2VkIiwiZW50cnlSZWR1Y2VyIiwic3RhdGUiLCJhY3Rpb24iLCJ0eXBlIiwiUkVIWURSQVRFIiwiTE9HSU4iLCJwYXlsb2FkIiwiTE9HT1VUIiwiUkVHSVNURVIiLCJVUERBVEVfVVNFUiIsIklOQ1JFQVNFX0JBTEFOQ0UiLCJQQVlfQllfQkFMQU5DRSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVPLElBQU1BLEtBQUssR0FBRyxTQUFSQSxLQUFRLENBQUNDLEdBQUQsRUFBS0MsSUFBTDtBQUFBLE1BQVVDLE9BQVYsdUVBQW9CLEVBQXBCO0FBQUEsU0FBMkIsVUFBQUMsUUFBUSxFQUFJO0FBQ3hEQyxnREFBSyxDQUFDQyxJQUFOLFdBQWNDLDZCQUFkLFNBQWdETixHQUFoRCxHQUFzREMsSUFBdEQsRUFBMkQ7QUFDdkRDLGFBQU8sRUFBQ0E7QUFEK0MsS0FBM0QsRUFHR0ssSUFISDtBQUFBLG9VQUdRLGlCQUFNQyxHQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQ2FBLEdBQUcsQ0FBQ1AsSUFEakI7O0FBQUE7QUFDQUEsb0JBREE7QUFFSkUsd0JBQVEsQ0FBQ00sc0RBQUssQ0FBQ1IsSUFBRCxDQUFOLENBQVI7QUFDQVMsa0VBQU0sQ0FBQ0MsSUFBUCxDQUFZLFdBQVo7O0FBSEk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FIUjs7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFPVyxVQUFBQyxNQUFNLEVBQUk7QUFDakJULGNBQVEsQ0FBQ00sc0RBQUssQ0FBQztBQUFDSSxlQUFPLEVBQUMsSUFBVDtBQUFjRCxjQUFNLEVBQUNBLE1BQU0sQ0FBQ0UsUUFBUCxDQUFnQmI7QUFBckMsT0FBRCxDQUFOLENBQVI7QUFDRCxLQVRIO0FBVUgsR0FYb0I7QUFBQSxDQUFkO0FBY0EsSUFBTWMsWUFBWSxHQUFHLFNBQWZBLFlBQWUsQ0FBQ2YsR0FBRCxFQUFLQyxJQUFMO0FBQUEsTUFBVUMsT0FBVix1RUFBb0IsRUFBcEI7QUFBQSxTQUEyQixVQUFBQyxRQUFRLEVBQUk7QUFDakVDLGdEQUFLLENBQUNDLElBQU4sV0FBY0MsNkJBQWQsU0FBZ0ROLEdBQWhELEdBQXNEQyxJQUF0RCxFQUEyRDtBQUN2REMsYUFBTyxFQUFDQTtBQUQrQyxLQUEzRCxFQUdHSyxJQUhIO0FBQUEscVVBR1Esa0JBQU1DLEdBQU47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0pRLGtFQUFJLENBQUNDLElBQUwsQ0FBVTtBQUNSQyxzQkFBSSxFQUFFLDZCQURFO0FBRVJDLHNCQUFJLEVBQUUsU0FGRTtBQUdSQyxtQ0FBaUIsRUFBRTtBQUhYLGlCQUFWLEVBSUdiLElBSkgsQ0FJUSxVQUFBQyxHQUFHLEVBQUk7QUFDYixzQkFBR0EsR0FBRyxDQUFDYSxXQUFQLEVBQW1CO0FBQ2pCWCxzRUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWjtBQUNEO0FBQ0YsaUJBUkQ7QUFESTtBQUFBLHVCQVVhSCxHQUFHLENBQUNQLElBVmpCOztBQUFBO0FBVUFBLG9CQVZBO0FBV0pFLHdCQUFRLENBQUNtQix5REFBUSxDQUFDckIsSUFBRCxDQUFULENBQVI7O0FBWEk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FIUjs7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFlVyxVQUFBc0IsR0FBRyxFQUFJO0FBQ2RwQixjQUFRLENBQUNtQix5REFBUSxDQUFDO0FBQUNULGVBQU8sRUFBQyxJQUFUO0FBQWNELGNBQU0sRUFBQ1csR0FBRyxDQUFDVCxRQUFKLENBQWFiO0FBQWxDLE9BQUQsQ0FBVCxDQUFSO0FBQ0QsS0FqQkg7QUFrQkQsR0FuQjJCO0FBQUEsQ0FBckI7QUFxQkEsSUFBTXVCLE1BQU0sR0FBRyxTQUFUQSxNQUFTO0FBQUEsU0FBTSxVQUFBckIsUUFBUSxFQUFJO0FBQ3BDQSxZQUFRLENBQUNzQix1REFBTSxFQUFQLENBQVI7QUFDSCxHQUZxQjtBQUFBLENBQWY7QUFJQSxJQUFNQyxVQUFVLEdBQUcsU0FBYkEsVUFBYSxDQUFDMUIsR0FBRCxFQUFLQyxJQUFMO0FBQUEsTUFBVUMsT0FBVix1RUFBb0IsRUFBcEI7QUFBQSxTQUEyQixVQUFBQyxRQUFRLEVBQUk7QUFFN0RDLGdEQUFLLENBQUN1QixHQUFOLFdBQWFyQiw2QkFBYixTQUErQ04sR0FBL0MsR0FBcURDLElBQXJELEVBQTBEO0FBQ3REQyxhQUFPLEVBQUVBO0FBRDZDLEtBQTFELEVBR0dLLElBSEgsQ0FHUyxVQUFBQyxHQUFHLEVBQUk7QUFDWkwsY0FBUSxDQUFDeUIsMkRBQVUsQ0FBQ3BCLEdBQUcsQ0FBQ1AsSUFBTCxDQUFYLENBQVI7QUFDQ2Usd0RBQUksQ0FBQ0MsSUFBTCxDQUFVO0FBQ1JDLFlBQUksRUFBRSxtQ0FERTtBQUVSQyxZQUFJLEVBQUUsU0FGRTtBQUdSQyx5QkFBaUIsRUFBRTtBQUhYLE9BQVY7QUFLRixLQVZILFdBV1MsVUFBQUcsR0FBRyxFQUFJO0FBQ1pwQixjQUFRLENBQUN5QiwyREFBVSxDQUFDO0FBQUNmLGVBQU8sRUFBQyxJQUFUO0FBQWNELGNBQU0sRUFBQ1csR0FBRyxDQUFDVCxRQUFKLENBQWFiO0FBQWxDLE9BQUQsQ0FBWCxDQUFSO0FBQ0QsS0FiSDtBQWVILEdBakJ5QjtBQUFBLENBQW5CO0FBbUJFLElBQU00QixrQkFBa0IsR0FBRyxTQUFyQkEsa0JBQXFCLENBQUM3QixHQUFELEVBQUtDLElBQUwsRUFBVUMsT0FBVjtBQUFBLFNBQXNCLFVBQUFDLFFBQVEsRUFBSTtBQUNsRUMsZ0RBQUssQ0FBQ0MsSUFBTixXQUFjQyw2QkFBZCxTQUFnRE4sR0FBaEQsR0FBc0RDLElBQXRELEVBQTJEO0FBQ3pEQyxhQUFPLEVBQUNBO0FBRGlELEtBQTNELEVBRUdLLElBRkgsQ0FFUSxVQUFBQyxHQUFHLEVBQUk7QUFDYnNCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQVosRUFBa0J2QixHQUFHLENBQUNQLElBQUosQ0FBUytCLE9BQTNCO0FBQ0VoQix3REFBSSxDQUFDQyxJQUFMLENBQVU7QUFDUkMsWUFBSSxFQUFFVixHQUFHLENBQUNQLElBQUosQ0FBU2dDLE9BRFA7QUFFUmQsWUFBSSxFQUFFLFNBRkU7QUFHUkMseUJBQWlCLEVBQUU7QUFIWCxPQUFWO0FBS0FqQixjQUFRLENBQUMrQiw2REFBWSxDQUFDMUIsR0FBRyxDQUFDUCxJQUFKLENBQVMrQixPQUFWLENBQWIsQ0FBUjtBQUNBdEIsd0RBQU0sQ0FBQ0MsSUFBUCw0QkFBZ0NILEdBQUcsQ0FBQ1AsSUFBSixDQUFTZ0MsT0FBekM7QUFDSCxLQVhELFdBV1MsVUFBQVYsR0FBRztBQUFBLGFBQUlPLE9BQU8sQ0FBQ0MsR0FBUixDQUFZUixHQUFaLENBQUo7QUFBQSxLQVhaO0FBWUQsR0FiaUM7QUFBQSxDQUEzQjtBQWVGLElBQU1ZLHFCQUFxQixHQUFHLFNBQXhCQSxxQkFBd0IsQ0FBQ0gsT0FBRDtBQUFBLFNBQWEsVUFBQTdCLFFBQVEsRUFBSTtBQUMxREEsWUFBUSxDQUFDaUMsZ0VBQWUsQ0FBQ0osT0FBRCxDQUFoQixDQUFSO0FBQ0gsR0FGb0M7QUFBQSxDQUE5Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQy9FUDtBQUNBO0FBT0EsSUFBTUssWUFBWSxHQUFHO0FBQ25CQyxNQUFJLEVBQUUsRUFEYTtBQUVuQkMsZUFBYSxFQUFFLEVBRkk7QUFHbkJDLFNBQU8sRUFBRTtBQUhVLENBQXJCOztBQU1BLElBQU1DLFlBQVksR0FBRyxTQUFmQSxZQUFlLEdBQWtDO0FBQUEsTUFBakNDLEtBQWlDLHVFQUF6QkwsWUFBeUI7QUFBQSxNQUFYTSxNQUFXOztBQUNyRCxVQUFRQSxNQUFNLENBQUNDLElBQWY7QUFDRSxTQUFLQyx1REFBTDtBQUNFOztBQUNGLFNBQUtDLGtEQUFMO0FBQ0UsVUFBSUgsTUFBTSxDQUFDSSxPQUFQLENBQWVsQyxPQUFuQixFQUE0QjtBQUMxQjZCLGFBQUssbUNBQ0FBLEtBREE7QUFFSEgsdUJBQWEsb0JBQU9JLE1BQU0sQ0FBQ0ksT0FBUCxDQUFlbkMsTUFBdEI7QUFGVixVQUFMO0FBSUQsT0FMRCxNQUtPO0FBQ0w4QixhQUFLLG1DQUNBQSxLQURBO0FBRUhILHVCQUFhLEVBQUUsRUFGWjtBQUdIRCxjQUFJLG9CQUNDSyxNQUFNLENBQUNJLE9BRFIsQ0FIRDtBQU1IUCxpQkFBTyxFQUFFO0FBTk4sVUFBTDtBQVFEOztBQUVEOztBQUNGLFNBQUtRLG1EQUFMO0FBQ0VOLFdBQUssR0FBRztBQUNOSixZQUFJLEVBQUUsRUFEQTtBQUVOQyxxQkFBYSxFQUFFLEVBRlQ7QUFHTkMsZUFBTyxFQUFFO0FBSEgsT0FBUjtBQUtBOztBQUNGLFNBQUtTLHFEQUFMO0FBQ0UsVUFBSU4sTUFBTSxDQUFDSSxPQUFQLENBQWVsQyxPQUFuQixFQUE0QjtBQUMxQjZCLGFBQUssbUNBQ0FBLEtBREE7QUFFSEgsdUJBQWEsb0JBQU9JLE1BQU0sQ0FBQ0ksT0FBUCxDQUFlbkMsTUFBdEI7QUFGVixVQUFMO0FBSUQsT0FMRCxNQUtPO0FBQ0w4QixhQUFLLEdBQUc7QUFDTkosY0FBSSxvQkFBT0ssTUFBTSxDQUFDSSxPQUFkLENBREU7QUFFTlIsdUJBQWEsRUFBRSxFQUZUO0FBR05DLGlCQUFPLEVBQUU7QUFISCxTQUFSO0FBS0Q7O0FBQ0Q7O0FBQ0YsU0FBS1Usd0RBQUw7QUFDRSxVQUFJUCxNQUFNLENBQUNJLE9BQVAsQ0FBZWxDLE9BQW5CLEVBQTRCO0FBQzFCNkIsYUFBSyxtQ0FDQUEsS0FEQTtBQUVISixjQUFJLG9CQUNDSSxLQUFLLENBQUNKLElBRFAsQ0FGRDtBQUtIQyx1QkFBYSxvQkFBT0ksTUFBTSxDQUFDSSxPQUFQLENBQWVuQyxNQUF0QjtBQUxWLFVBQUw7QUFPRCxPQVJELE1BUU87QUFDTDhCLGFBQUssbUNBQ0FBLEtBREE7QUFFSEosY0FBSSxrQ0FDQ0ksS0FBSyxDQUFDSixJQURQO0FBRUZBLGdCQUFJLG9CQUFPSyxNQUFNLENBQUNJLE9BQVAsQ0FBZVQsSUFBdEI7QUFGRixZQUZEO0FBTUhDLHVCQUFhLEVBQUU7QUFOWixVQUFMO0FBUUQ7O0FBQ0Q7O0FBQ0YsU0FBS1ksNkRBQUw7QUFDRVQsV0FBSyxtQ0FDQUEsS0FEQTtBQUVISixZQUFJLGtDQUNDSSxLQUFLLENBQUNKLElBRFA7QUFFRkEsY0FBSSxrQ0FDQ0ksS0FBSyxDQUFDSixJQUFOLENBQVdBLElBRFo7QUFFRk4sbUJBQU8sRUFBQ1csTUFBTSxDQUFDSTtBQUZiO0FBRkY7QUFGRCxRQUFMO0FBVUE7O0FBQ0YsU0FBS0ssMkRBQUw7QUFDRVYsV0FBSyxtQ0FDQUEsS0FEQTtBQUVISixZQUFJLGtDQUNDSSxLQUFLLENBQUNKLElBRFA7QUFFRkEsY0FBSSxrQ0FDQ0ksS0FBSyxDQUFDSixJQUFOLENBQVdBLElBRFo7QUFFRk4sbUJBQU8sRUFBQ1csTUFBTSxDQUFDSTtBQUZiO0FBRkY7QUFGRCxRQUFMO0FBVUE7O0FBQ0Y7QUFDRUwsV0FBSyxxQkFBUUEsS0FBUixDQUFMO0FBQ0E7QUF4Rko7O0FBMkZBLFNBQU9BLEtBQVA7QUFDRCxDQTdGRDs7QUErRmVELDJFQUFmIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL19hcHAuNjBlNjAxODhiY2E1ZWVmYWRmYjAuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCByb3V0ZXIgZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcbmltcG9ydCBTd2FsIGZyb20gXCJzd2VldGFsZXJ0MlwiO1xyXG5pbXBvcnQgeyBJbmNyZWFzZUJhbGFuY2UsIGxvZ2luLCBsb2dvdXQsIFBheUJ5QmFsYW5jZSwgcmVnaXN0ZXIsIHVwZGF0ZVVzZXIgfSBmcm9tIFwiLi9hY3Rpb25zXCI7XHJcblxyXG5leHBvcnQgY29uc3QgTG9naW4gPSAodXJsLGRhdGEsaGVhZGVycyA9IHt9KSA9PiBkaXNwYXRjaCA9PiB7XHJcbiAgICBheGlvcy5wb3N0KGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9JHt1cmx9YCxkYXRhLHtcclxuICAgICAgICBoZWFkZXJzOmhlYWRlcnMsXHJcbiAgICAgIH0pXHJcbiAgICAgIC50aGVuKGFzeW5jIHJlcyA9PiB7XHJcbiAgICAgICAgbGV0IGRhdGEgPSBhd2FpdCByZXMuZGF0YTtcclxuICAgICAgICBkaXNwYXRjaChsb2dpbihkYXRhKSlcclxuICAgICAgICByb3V0ZXIucHVzaCgnL3BhY2thZ2VzJylcclxuICAgICAgfSkuY2F0Y2goZXJyb3JzID0+IHtcclxuICAgICAgICBkaXNwYXRjaChsb2dpbih7aXNFcnJvcjp0cnVlLGVycm9yczplcnJvcnMucmVzcG9uc2UuZGF0YX0pKVxyXG4gICAgICB9KVxyXG59XHJcblxyXG5cclxuZXhwb3J0IGNvbnN0IFVzZXJSZWdpc3RlciA9ICh1cmwsZGF0YSxoZWFkZXJzID0ge30pID0+IGRpc3BhdGNoID0+IHtcclxuICBheGlvcy5wb3N0KGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9JHt1cmx9YCxkYXRhLHtcclxuICAgICAgaGVhZGVyczpoZWFkZXJzLFxyXG4gICAgfSlcclxuICAgIC50aGVuKGFzeW5jIHJlcyA9PiB7XHJcbiAgICAgIFN3YWwuZmlyZSh7XHJcbiAgICAgICAgdGV4dDogJ8aPbcmZbGl5eWF0IHXEn3VybGEgdGFtYW1sYW5kxLEnLFxyXG4gICAgICAgIGljb246ICdzdWNjZXNzJyxcclxuICAgICAgICBjb25maXJtQnV0dG9uVGV4dDogJ09LJyxcclxuICAgICAgfSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgIGlmKHJlcy5pc0NvbmZpcm1lZCl7XHJcbiAgICAgICAgICByb3V0ZXIucHVzaCgnL215YWRkcmVzc2VzJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgICBsZXQgZGF0YSA9IGF3YWl0IHJlcy5kYXRhO1xyXG4gICAgICBkaXNwYXRjaChyZWdpc3RlcihkYXRhKSlcclxuICAgIH0pLmNhdGNoKGVyciA9PiB7XHJcbiAgICAgIGRpc3BhdGNoKHJlZ2lzdGVyKHtpc0Vycm9yOnRydWUsZXJyb3JzOmVyci5yZXNwb25zZS5kYXRhfSkpXHJcbiAgICB9KVxyXG59XHJcblxyXG5leHBvcnQgY29uc3QgTG9nT3V0ID0gKCkgPT4gZGlzcGF0Y2ggPT4ge1xyXG4gICAgZGlzcGF0Y2gobG9nb3V0KCkpXHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBVcGRhdGVVc2VyID0gKHVybCxkYXRhLGhlYWRlcnMgPSB7fSkgPT4gZGlzcGF0Y2ggPT4ge1xyXG5cclxuICAgIGF4aW9zLnB1dChgJHtwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19BUElfVVJMfSR7dXJsfWAsZGF0YSx7XHJcbiAgICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgICB9KVxyXG4gICAgICAudGhlbiggcmVzID0+IHtcclxuICAgICAgICBkaXNwYXRjaCh1cGRhdGVVc2VyKHJlcy5kYXRhKSlcclxuICAgICAgICAgU3dhbC5maXJlKHtcclxuICAgICAgICAgICB0ZXh0OiAnxo9tyZlsaXl5YXQgdcSfdXJsYSB5ZXJpbsmZIHlldGlyaWxkaScsXHJcbiAgICAgICAgICAgaWNvbjogJ3N1Y2Nlc3MnLFxyXG4gICAgICAgICAgIGNvbmZpcm1CdXR0b25UZXh0OiAnT0snLFxyXG4gICAgICAgICB9KVxyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goZXJyID0+IHtcclxuICAgICAgICBkaXNwYXRjaCh1cGRhdGVVc2VyKHtpc0Vycm9yOnRydWUsZXJyb3JzOmVyci5yZXNwb25zZS5kYXRhfSkpXHJcbiAgICAgIH0pXHJcbiAgXHJcbn1cclxuXHJcbiAgZXhwb3J0IGNvbnN0IFBheUJ5QmFsYW5jZUFjdGlvbiA9ICh1cmwsZGF0YSxoZWFkZXJzKSA9PiBkaXNwYXRjaCA9PiB7XHJcbiAgICBheGlvcy5wb3N0KGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9JHt1cmx9YCxkYXRhLHtcclxuICAgICAgaGVhZGVyczpoZWFkZXJzLFxyXG4gICAgfSkudGhlbihyZXMgPT4ge1xyXG4gICAgICBjb25zb2xlLmxvZygncmVxJyxyZXMuZGF0YS5iYWxhbmNlKSBcclxuICAgICAgICBTd2FsLmZpcmUoe1xyXG4gICAgICAgICAgdGV4dDogcmVzLmRhdGEubWVzc2FnZSxcclxuICAgICAgICAgIGljb246ICdzdWNjZXNzJyxcclxuICAgICAgICAgIGNvbmZpcm1CdXR0b25UZXh0OiAnT0snLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGRpc3BhdGNoKFBheUJ5QmFsYW5jZShyZXMuZGF0YS5iYWxhbmNlKSk7XHJcbiAgICAgICAgcm91dGVyLnB1c2goYC9zdWNjZXNzP21lc3NhZ2U9JHtyZXMuZGF0YS5tZXNzYWdlfWApO1xyXG4gICAgfSkuY2F0Y2goZXJyID0+IGNvbnNvbGUubG9nKGVycikpO1xyXG4gIH1cclxuXHJcbmV4cG9ydCBjb25zdCBJbmNyZWFzZUJhbGFuY2VBY3Rpb24gPSAoYmFsYW5jZSkgPT4gZGlzcGF0Y2ggPT4ge1xyXG4gICAgZGlzcGF0Y2goSW5jcmVhc2VCYWxhbmNlKGJhbGFuY2UpKVxyXG59XHJcblxyXG5cclxuXHJcbiIsImltcG9ydCB7IFJFSFlEUkFURSB9IGZyb20gXCJyZWR1eC1wZXJzaXN0XCI7XHJcbmltcG9ydFxyXG4gIHtcclxuICAgIElOQ1JFQVNFX0JBTEFOQ0UsIExPR0lOLFxyXG4gICAgTE9HT1VULCBQQVlfQllfQkFMQU5DRSwgUkVHSVNURVIsXHJcbiAgICBVUERBVEVfVVNFUlxyXG4gIH0gZnJvbSBcIi4vYWN0aW9uVHlwZXNcIjtcclxuXHJcbmNvbnN0IGluaXRpYWxTdGF0ZSA9IHtcclxuICB1c2VyOiB7fSxcclxuICBlcnJvck1lc3NhZ2VzOiB7fSxcclxuICBpc0xvZ2VkOiBmYWxzZSxcclxufTtcclxuXHJcbmNvbnN0IGVudHJ5UmVkdWNlciA9IChzdGF0ZSA9IGluaXRpYWxTdGF0ZSwgYWN0aW9uKSA9PiB7XHJcbiAgc3dpdGNoIChhY3Rpb24udHlwZSkge1xyXG4gICAgY2FzZSBSRUhZRFJBVEU6XHJcbiAgICAgIGJyZWFrO1xyXG4gICAgY2FzZSBMT0dJTjpcclxuICAgICAgaWYgKGFjdGlvbi5wYXlsb2FkLmlzRXJyb3IpIHtcclxuICAgICAgICBzdGF0ZSA9IHtcclxuICAgICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgICAgZXJyb3JNZXNzYWdlczogeyAuLi5hY3Rpb24ucGF5bG9hZC5lcnJvcnMgfSxcclxuICAgICAgICB9O1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHN0YXRlID0ge1xyXG4gICAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgICBlcnJvck1lc3NhZ2VzOiB7fSxcclxuICAgICAgICAgIHVzZXI6IHtcclxuICAgICAgICAgICAgLi4uYWN0aW9uLnBheWxvYWQsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgaXNMb2dlZDogdHJ1ZSxcclxuICAgICAgICB9O1xyXG4gICAgICB9XHJcblxyXG4gICAgICBicmVhaztcclxuICAgIGNhc2UgTE9HT1VUOlxyXG4gICAgICBzdGF0ZSA9IHtcclxuICAgICAgICB1c2VyOiB7fSxcclxuICAgICAgICBlcnJvck1lc3NhZ2VzOiBbXSxcclxuICAgICAgICBpc0xvZ2VkOiBmYWxzZSxcclxuICAgICAgfTtcclxuICAgICAgYnJlYWs7XHJcbiAgICBjYXNlIFJFR0lTVEVSOlxyXG4gICAgICBpZiAoYWN0aW9uLnBheWxvYWQuaXNFcnJvcikge1xyXG4gICAgICAgIHN0YXRlID0ge1xyXG4gICAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgICBlcnJvck1lc3NhZ2VzOiB7IC4uLmFjdGlvbi5wYXlsb2FkLmVycm9ycyB9LFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc3RhdGUgPSB7XHJcbiAgICAgICAgICB1c2VyOiB7IC4uLmFjdGlvbi5wYXlsb2FkIH0sXHJcbiAgICAgICAgICBlcnJvck1lc3NhZ2VzOiB7fSxcclxuICAgICAgICAgIGlzTG9nZWQ6IGZhbHNlLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH1cclxuICAgICAgYnJlYWs7XHJcbiAgICBjYXNlIFVQREFURV9VU0VSOlxyXG4gICAgICBpZiAoYWN0aW9uLnBheWxvYWQuaXNFcnJvcikge1xyXG4gICAgICAgIHN0YXRlID0ge1xyXG4gICAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgICB1c2VyOiB7XHJcbiAgICAgICAgICAgIC4uLnN0YXRlLnVzZXIsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgZXJyb3JNZXNzYWdlczogeyAuLi5hY3Rpb24ucGF5bG9hZC5lcnJvcnMgfSxcclxuICAgICAgICB9O1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHN0YXRlID0ge1xyXG4gICAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgICB1c2VyOiB7XHJcbiAgICAgICAgICAgIC4uLnN0YXRlLnVzZXIsXHJcbiAgICAgICAgICAgIHVzZXI6IHsgLi4uYWN0aW9uLnBheWxvYWQudXNlciB9LFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIGVycm9yTWVzc2FnZXM6IHt9LFxyXG4gICAgICAgIH07XHJcbiAgICAgIH1cclxuICAgICAgYnJlYWs7XHJcbiAgICBjYXNlIElOQ1JFQVNFX0JBTEFOQ0U6XHJcbiAgICAgIHN0YXRlID0ge1xyXG4gICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgIHVzZXI6IHsgXHJcbiAgICAgICAgICAuLi5zdGF0ZS51c2VyLFxyXG4gICAgICAgICAgdXNlcjogeyBcclxuICAgICAgICAgICAgLi4uc3RhdGUudXNlci51c2VyLFxyXG4gICAgICAgICAgICBiYWxhbmNlOmFjdGlvbi5wYXlsb2FkXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIGJyZWFrO1xyXG4gICAgY2FzZSBQQVlfQllfQkFMQU5DRTpcclxuICAgICAgc3RhdGUgPSB7XHJcbiAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgdXNlcjogeyBcclxuICAgICAgICAgIC4uLnN0YXRlLnVzZXIsXHJcbiAgICAgICAgICB1c2VyOiB7IFxyXG4gICAgICAgICAgICAuLi5zdGF0ZS51c2VyLnVzZXIsXHJcbiAgICAgICAgICAgIGJhbGFuY2U6YWN0aW9uLnBheWxvYWRcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgYnJlYWs7XHJcbiAgICBkZWZhdWx0OlxyXG4gICAgICBzdGF0ZSA9IHsgLi4uc3RhdGUgfTtcclxuICAgICAgYnJlYWs7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gc3RhdGU7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBlbnRyeVJlZHVjZXI7XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=