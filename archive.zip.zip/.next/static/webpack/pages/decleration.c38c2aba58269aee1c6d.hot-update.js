webpackHotUpdate_N_E("pages/decleration",{

/***/ "./pages/decleration.js":
/*!******************************!*\
  !*** ./pages/decleration.js ***!
  \******************************/
/*! exports provided: __N_SSG, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__N_SSG", function() { return __N_SSG; });
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_day_picker_lib_style_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-day-picker/lib/style.css */ "./node_modules/react-day-picker/lib/style.css");
/* harmony import */ var react_day_picker_lib_style_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_day_picker_lib_style_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-hook-form */ "./node_modules/react-hook-form/dist/index.esm.js");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-intl */ "./node_modules/react-intl/lib/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! sweetalert2 */ "./node_modules/sweetalert2/dist/sweetalert2.all.js");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_aside_menu_index__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../components/aside-menu/index */ "./components/aside-menu/index.js");
/* harmony import */ var _components_aside_aside__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../components/aside/aside */ "./components/aside/aside.js");
/* harmony import */ var _components_button_index__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../components/button/index */ "./components/button/index.js");
/* harmony import */ var _components_card_card__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../components/card/card */ "./components/card/card.js");
/* harmony import */ var _components_form_group_form_group__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../components/form-group/form-group */ "./components/form-group/form-group.js");
/* harmony import */ var _components_input_input__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../components/input/input */ "./components/input/input.js");
/* harmony import */ var _components_main_main__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../components/main/main */ "./components/main/main.js");
/* harmony import */ var _components_page_page__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../components/page/page */ "./components/page/page.js");
/* harmony import */ var _components_redirect_redirect__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../components/redirect/redirect */ "./components/redirect/redirect.js");
/* harmony import */ var _components_selectbox_selectbox__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../components/selectbox/selectbox */ "./components/selectbox/selectbox.js");



var _jsxFileName = "C:\\Users\\Home\\Desktop\\166\\166-kargo\\pages\\decleration.js",
    _s = $RefreshSig$();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }



















var telData = [{
  id: 15,
  name: 'Türkiyə'
}, {
  id: 16,
  name: 'Türkiyə'
}, {
  id: 17,
  name: 'Türkiyə'
}];
var curData = [{
  id: 'try',
  name: 'Türkiyə Lirəsi'
}, {
  id: 'azn',
  name: 'Azərbaycan Manatı'
}, {
  id: 'eur',
  name: 'Avro'
}, {
  id: 'usd',
  name: 'ABŞ dolları'
}, {
  id: 'bla',
  name: 'bla dolları'
}];

function Decleration(props) {
  _s();

  var _errors$country, _errors$track_number, _errors$shop_name, _errors$main_group, _errors$sub_category, _props$mainCategories, _errors$price, _errors$invoice, _errors$note;

  var _useIntl = Object(react_intl__WEBPACK_IMPORTED_MODULE_7__["useIntl"])(),
      f = _useIntl.formatMessage;

  if (!props.entry.isLoged) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_redirect_redirect__WEBPACK_IMPORTED_MODULE_18__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 40,
      columnNumber: 12
    }, this);
  }

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])('AA'),
      checkSerial = _useState[0],
      setCheckSerial = _useState[1];

  var _useRouter = Object(next_router__WEBPACK_IMPORTED_MODULE_3__["useRouter"])(),
      locale = _useRouter.locale;

  var _useForm = Object(react_hook_form__WEBPACK_IMPORTED_MODULE_6__["useForm"])(),
      register = _useForm.register,
      errors = _useForm.errors,
      handleSubmit = _useForm.handleSubmit,
      watch = _useForm.watch,
      setError = _useForm.setError;

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])('AA'),
      subCategories = _useState2[0],
      setSubCategories = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(null),
      fileName = _useState3[0],
      setFileName = _useState3[1];

  var handleChange = function handleChange(ev) {
    var _ev$target = ev.target,
        name = _ev$target.name,
        value = _ev$target.value;
    setUser(_objectSpread(_objectSpread({}, user), {}, Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])({}, name, value)));
  };

  var submit = function submit(data) {
    var newFormData = new FormData();

    for (var key in data) {
      if (key === 'invoice') newFormData.append(key, data[key][0]);else newFormData.append(key, data[key]);
    }

    newFormData.append('_method', 'POST');
    axios__WEBPACK_IMPORTED_MODULE_2___default.a.post("".concat("https://166api.titr.az/api/", "batches?lan=").concat(locale), newFormData, {
      headers: {
        'Content-Type': 'multipart/form-data',
        'Accepts': 'application/json',
        'Authorization': "Bearer ".concat(props.entry.user.accessToken)
      }
    }).then(function (res) {
      sweetalert2__WEBPACK_IMPORTED_MODULE_9___default.a.fire({
        title: res.message,
        icon: 'success'
      });
    })["catch"](function (err) {
      for (var _key in err.response.data.errors) {
        setError(_key, {
          message: err.response.data.errors[_key].join('\n')
        });
      }
    });
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_page_page__WEBPACK_IMPORTED_MODULE_17__["default"], {
    className: "user-profile-page bg-bg pt-lg pb-lg",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_aside_aside__WEBPACK_IMPORTED_MODULE_11__["default"], {
      className: "mr-sm",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_aside_menu_index__WEBPACK_IMPORTED_MODULE_10__["default"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 93,
        columnNumber: 15
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 92,
      columnNumber: 13
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_main_main__WEBPACK_IMPORTED_MODULE_16__["default"], {
      className: "p-none",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_13__["default"], {
        className: "bg-white p-sm br-lg",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_13__["default"].Header, {
          text: f({
            id: "decleration"
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 97,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("form", {
          onSubmit: handleSubmit(submit),
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_13__["default"].Body, {
            className: "bg-bg",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
              className: "declaration__flex",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_form_group_form_group__WEBPACK_IMPORTED_MODULE_14__["default"], {
                label: f({
                  id: "chooseone"
                }),
                bodyClass: "bg-white",
                className: "w-50 pr-xs mb-sm",
                error: (_errors$country = errors.country) === null || _errors$country === void 0 ? void 0 : _errors$country.message,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_selectbox_selectbox__WEBPACK_IMPORTED_MODULE_19__["default"], {
                  className: "bg-white w-100",
                  data: [{
                    id: 15,
                    name: f({
                      id: 'turkey'
                    })
                  }, {
                    id: 16,
                    name: f({
                      id: 'usa'
                    })
                  }, {
                    id: 17,
                    name: f({
                      id: 'ukraina'
                    })
                  }],
                  name: "country",
                  Ref: register({
                    required: {
                      value: true,
                      message: 'country type is required'
                    }
                  }) //  onChange={handleChange}

                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 104,
                  columnNumber: 19
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 101,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_form_group_form_group__WEBPACK_IMPORTED_MODULE_14__["default"], {
                label: "Track \u0130D",
                bodyClass: "bg-white",
                className: "w-50 pr-xs mb-sm",
                error: (_errors$track_number = errors.track_number) === null || _errors$track_number === void 0 ? void 0 : _errors$track_number.message,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_input_input__WEBPACK_IMPORTED_MODULE_15__["default"], {
                  type: "text",
                  name: "track_number",
                  Ref: register({
                    required: {
                      value: true,
                      message: 'track number is required'
                    }
                  }) //  onChange={handleChange}

                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 121,
                  columnNumber: 19
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 118,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_form_group_form_group__WEBPACK_IMPORTED_MODULE_14__["default"], {
                label: f({
                  id: "shopname"
                }),
                bodyClass: "bg-white",
                className: "w-50 pr-xs mb-sm",
                error: (_errors$shop_name = errors.shop_name) === null || _errors$shop_name === void 0 ? void 0 : _errors$shop_name.message,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_input_input__WEBPACK_IMPORTED_MODULE_15__["default"], {
                  type: "text",
                  name: "shop_name",
                  Ref: register({
                    required: {
                      value: true,
                      message: 'shop name is required'
                    }
                  }) //  onChange={handleChange}

                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 133,
                  columnNumber: 19
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 130,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_form_group_form_group__WEBPACK_IMPORTED_MODULE_14__["default"], {
                label: f({
                  id: "main-g"
                }),
                bodyClass: "bg-white",
                className: "w-50 pr-xs mb-sm",
                error: (_errors$main_group = errors.main_group) === null || _errors$main_group === void 0 ? void 0 : _errors$main_group.message,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_selectbox_selectbox__WEBPACK_IMPORTED_MODULE_19__["default"], {
                  className: "bg-white w-100 ",
                  data: props.mainCategories,
                  name: "main_group",
                  Ref: register({
                    required: {
                      value: true,
                      message: 'main_group type is required'
                    }
                  }),
                  onChange: function onChange(ev) {
                    setSubCategories(ev.target.value);
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 144,
                  columnNumber: 19
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 141,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_form_group_form_group__WEBPACK_IMPORTED_MODULE_14__["default"], {
                label: f({
                  id: "sub-g"
                }),
                bodyClass: "bg-white",
                className: "w-50 pr-xs mb-sm",
                error: (_errors$sub_category = errors.sub_category) === null || _errors$sub_category === void 0 ? void 0 : _errors$sub_category.message,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_selectbox_selectbox__WEBPACK_IMPORTED_MODULE_19__["default"], {
                  className: "bg-white w-100",
                  data: subCategories && ((_props$mainCategories = props.mainCategories.find(function (x) {
                    return x.id === +subCategories;
                  })) === null || _props$mainCategories === void 0 ? void 0 : _props$mainCategories.sub_categories),
                  name: "sub_category",
                  Ref: register({
                    required: {
                      value: true,
                      message: 'sub category type is required'
                    }
                  })
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 159,
                  columnNumber: 19
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 156,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_form_group_form_group__WEBPACK_IMPORTED_MODULE_14__["default"], {
                label: f({
                  id: "price-inv"
                }),
                bodyClass: "bg-white",
                className: "w-50 pr-xs mb-sm",
                error: (_errors$price = errors.price) === null || _errors$price === void 0 ? void 0 : _errors$price.message,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_input_input__WEBPACK_IMPORTED_MODULE_15__["default"], {
                  type: "number",
                  name: "price",
                  Ref: register({
                    required: {
                      value: true,
                      message: 'price is required'
                    }
                  })
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 171,
                  columnNumber: 19
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 168,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_form_group_form_group__WEBPACK_IMPORTED_MODULE_14__["default"], {
                label: f({
                  id: "upload"
                }),
                bodyClass: "bg-white",
                className: "w-50 pr-xs mb-sm",
                bodyStyle: {
                  height: '150px'
                },
                error: (_errors$invoice = errors.invoice) === null || _errors$invoice === void 0 ? void 0 : _errors$invoice.message,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
                  className: "file-uploade",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_input_input__WEBPACK_IMPORTED_MODULE_15__["default"], {
                    className: "w-100",
                    type: "file",
                    title: " ",
                    name: "invoice",
                    Ref: register({
                      required: {
                        value: true,
                        message: 'invoice is required'
                      }
                    }),
                    onChange: function onChange(e) {
                      console.log(e.target.files[0]);
                      setFileName(e.target.files[0].name);
                    }
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 188,
                    columnNumber: 19
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
                    className: "over-layer",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("img", {
                      src: "/assets/icons/upload.png"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 198,
                      columnNumber: 25
                    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("p", {
                      children: ["S\xFCr\xFCkl\u0259yib bura at\u0131n ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("br", {}, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 200,
                        columnNumber: 49
                      }, this), "v\u0259 ya ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("br", {}, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 201,
                        columnNumber: 35
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("span", {
                        children: "fayl\u0131 se\xE7in"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 202,
                        columnNumber: 29
                      }, this), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("br", {}, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 202,
                        columnNumber: 54
                      }, this), fileName && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("strong", {
                        children: fileName
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 204,
                        columnNumber: 43
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 199,
                      columnNumber: 25
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 197,
                    columnNumber: 21
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 187,
                  columnNumber: 19
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 180,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_form_group_form_group__WEBPACK_IMPORTED_MODULE_14__["default"], {
                label: f({
                  id: "note"
                }),
                bodyClass: "bg-white",
                bodyStyle: {
                  height: '150px'
                },
                className: "w-50 pr-xs mb-sm",
                error: (_errors$note = errors.note) === null || _errors$note === void 0 ? void 0 : _errors$note.message,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("textarea", {
                  className: "p-xs w-100 h-100",
                  style: {
                    outline: 'none',
                    border: 'none'
                  },
                  placeholder: "qeydiniz varsa daxil edin",
                  name: "note",
                  ref: register({
                    required: {
                      value: true,
                      message: 'note is required'
                    }
                  })
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 214,
                  columnNumber: 23
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 211,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 100,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 99,
            columnNumber: 11
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_13__["default"].Footer, {
            className: "mt-sm",
            style: {
              justifyContent: 'flex-end'
            },
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_button_index__WEBPACK_IMPORTED_MODULE_12__["default"], {
              className: "mt-sm p-xs",
              label: f({
                id: "declare-inadvance"
              })
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 223,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 222,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 98,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 96,
        columnNumber: 10
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 95,
      columnNumber: 10
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 91,
    columnNumber: 9
  }, this);
}

_s(Decleration, "9G1lJMchuZEFSxonko2+j9urR0o=", false, function () {
  return [react_intl__WEBPACK_IMPORTED_MODULE_7__["useIntl"], next_router__WEBPACK_IMPORTED_MODULE_3__["useRouter"], react_hook_form__WEBPACK_IMPORTED_MODULE_6__["useForm"]];
});

_c = Decleration;

var mapStateToProps = function mapStateToProps(state) {
  return {
    entry: state.entry
  };
};

var mapDispatchToProps = {};
var __N_SSG = true;
/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_8__["connect"])(mapStateToProps)( /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_4__["memo"])(Decleration)));

var _c;

$RefreshReg$(_c, "Decleration");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvZGVjbGVyYXRpb24uanMiXSwibmFtZXMiOlsidGVsRGF0YSIsImlkIiwibmFtZSIsImN1ckRhdGEiLCJEZWNsZXJhdGlvbiIsInByb3BzIiwidXNlSW50bCIsImYiLCJmb3JtYXRNZXNzYWdlIiwiZW50cnkiLCJpc0xvZ2VkIiwidXNlU3RhdGUiLCJjaGVja1NlcmlhbCIsInNldENoZWNrU2VyaWFsIiwidXNlUm91dGVyIiwibG9jYWxlIiwidXNlRm9ybSIsInJlZ2lzdGVyIiwiZXJyb3JzIiwiaGFuZGxlU3VibWl0Iiwid2F0Y2giLCJzZXRFcnJvciIsInN1YkNhdGVnb3JpZXMiLCJzZXRTdWJDYXRlZ29yaWVzIiwiZmlsZU5hbWUiLCJzZXRGaWxlTmFtZSIsImhhbmRsZUNoYW5nZSIsImV2IiwidGFyZ2V0IiwidmFsdWUiLCJzZXRVc2VyIiwidXNlciIsInN1Ym1pdCIsImRhdGEiLCJuZXdGb3JtRGF0YSIsIkZvcm1EYXRhIiwia2V5IiwiYXBwZW5kIiwiYXhpb3MiLCJwb3N0IiwicHJvY2VzcyIsImhlYWRlcnMiLCJhY2Nlc3NUb2tlbiIsInRoZW4iLCJyZXMiLCJTd2FsIiwiZmlyZSIsInRpdGxlIiwibWVzc2FnZSIsImljb24iLCJlcnIiLCJyZXNwb25zZSIsImpvaW4iLCJjb3VudHJ5IiwicmVxdWlyZWQiLCJ0cmFja19udW1iZXIiLCJzaG9wX25hbWUiLCJtYWluX2dyb3VwIiwibWFpbkNhdGVnb3JpZXMiLCJzdWJfY2F0ZWdvcnkiLCJmaW5kIiwieCIsInN1Yl9jYXRlZ29yaWVzIiwicHJpY2UiLCJoZWlnaHQiLCJpbnZvaWNlIiwiZSIsImNvbnNvbGUiLCJsb2ciLCJmaWxlcyIsIm5vdGUiLCJvdXRsaW5lIiwiYm9yZGVyIiwianVzdGlmeUNvbnRlbnQiLCJtYXBTdGF0ZVRvUHJvcHMiLCJzdGF0ZSIsIm1hcERpc3BhdGNoVG9Qcm9wcyIsImNvbm5lY3QiLCJtZW1vIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQSxJQUFNQSxPQUFPLEdBQUcsQ0FDZDtBQUFDQyxJQUFFLEVBQUMsRUFBSjtBQUFPQyxNQUFJLEVBQUM7QUFBWixDQURjLEVBRWQ7QUFBQ0QsSUFBRSxFQUFDLEVBQUo7QUFBT0MsTUFBSSxFQUFDO0FBQVosQ0FGYyxFQUdkO0FBQUNELElBQUUsRUFBQyxFQUFKO0FBQU9DLE1BQUksRUFBQztBQUFaLENBSGMsQ0FBaEI7QUFNQyxJQUFNQyxPQUFPLEdBQUcsQ0FDZjtBQUFDRixJQUFFLEVBQUMsS0FBSjtBQUFVQyxNQUFJLEVBQUM7QUFBZixDQURlLEVBRWY7QUFBQ0QsSUFBRSxFQUFDLEtBQUo7QUFBVUMsTUFBSSxFQUFDO0FBQWYsQ0FGZSxFQUdmO0FBQUNELElBQUUsRUFBQyxLQUFKO0FBQVVDLE1BQUksRUFBQztBQUFmLENBSGUsRUFJZjtBQUFDRCxJQUFFLEVBQUMsS0FBSjtBQUFVQyxNQUFJLEVBQUM7QUFBZixDQUplLEVBS2Y7QUFBQ0QsSUFBRSxFQUFDLEtBQUo7QUFBVUMsTUFBSSxFQUFDO0FBQWYsQ0FMZSxDQUFoQjs7QUFVRCxTQUFTRSxXQUFULENBQXFCQyxLQUFyQixFQUE0QjtBQUFBOztBQUFBOztBQUFBLGlCQUNHQywwREFBTyxFQURWO0FBQUEsTUFDSEMsQ0FERyxZQUNsQkMsYUFEa0I7O0FBRzFCLE1BQUcsQ0FBQ0gsS0FBSyxDQUFDSSxLQUFOLENBQVlDLE9BQWhCLEVBQXdCO0FBQ3RCLHdCQUFPLHFFQUFDLHNFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFBUDtBQUNEOztBQUx5QixrQkFPWUMsc0RBQVEsQ0FBQyxJQUFELENBUHBCO0FBQUEsTUFPbkJDLFdBUG1CO0FBQUEsTUFPTkMsY0FQTTs7QUFBQSxtQkFRUEMsNkRBQVMsRUFSRjtBQUFBLE1BUWxCQyxNQVJrQixjQVFsQkEsTUFSa0I7O0FBQUEsaUJBUzRCQywrREFBTyxFQVRuQztBQUFBLE1BU25CQyxRQVRtQixZQVNuQkEsUUFUbUI7QUFBQSxNQVNWQyxNQVRVLFlBU1ZBLE1BVFU7QUFBQSxNQVNIQyxZQVRHLFlBU0hBLFlBVEc7QUFBQSxNQVNVQyxLQVRWLFlBU1VBLEtBVFY7QUFBQSxNQVNnQkMsUUFUaEIsWUFTZ0JBLFFBVGhCOztBQUFBLG1CQVVnQlYsc0RBQVEsQ0FBQyxJQUFELENBVnhCO0FBQUEsTUFVbkJXLGFBVm1CO0FBQUEsTUFVSkMsZ0JBVkk7O0FBQUEsbUJBV01aLHNEQUFRLENBQUMsSUFBRCxDQVhkO0FBQUEsTUFXbkJhLFFBWG1CO0FBQUEsTUFXVEMsV0FYUzs7QUFjMUIsTUFBTUMsWUFBWSxHQUFHLFNBQWZBLFlBQWUsQ0FBQ0MsRUFBRCxFQUFRO0FBQUEscUJBQ05BLEVBQUUsQ0FBQ0MsTUFERztBQUFBLFFBQ3JCMUIsSUFEcUIsY0FDckJBLElBRHFCO0FBQUEsUUFDZjJCLEtBRGUsY0FDZkEsS0FEZTtBQUUxQkMsV0FBTyxpQ0FDRkMsSUFERSxzS0FFSjdCLElBRkksRUFFRzJCLEtBRkgsR0FBUDtBQUlGLEdBTkQ7O0FBUUEsTUFBTUcsTUFBTSxHQUFHLFNBQVRBLE1BQVMsQ0FBQ0MsSUFBRCxFQUFVO0FBRXRCLFFBQUlDLFdBQVcsR0FBRyxJQUFJQyxRQUFKLEVBQWxCOztBQUNBLFNBQUksSUFBSUMsR0FBUixJQUFlSCxJQUFmLEVBQW9CO0FBQ2xCLFVBQUdHLEdBQUcsS0FBSyxTQUFYLEVBQ0VGLFdBQVcsQ0FBQ0csTUFBWixDQUFtQkQsR0FBbkIsRUFBdUJILElBQUksQ0FBQ0csR0FBRCxDQUFKLENBQVUsQ0FBVixDQUF2QixFQURGLEtBR0FGLFdBQVcsQ0FBQ0csTUFBWixDQUFtQkQsR0FBbkIsRUFBdUJILElBQUksQ0FBQ0csR0FBRCxDQUEzQjtBQUNEOztBQUVERixlQUFXLENBQUNHLE1BQVosQ0FBbUIsU0FBbkIsRUFBNkIsTUFBN0I7QUFFQUMsZ0RBQUssQ0FBQ0MsSUFBTixXQUFjQyw2QkFBZCx5QkFBNER6QixNQUE1RCxHQUFxRW1CLFdBQXJFLEVBQWlGO0FBQy9FTyxhQUFPLEVBQUU7QUFDUix3QkFBZSxxQkFEUDtBQUVQLG1CQUFVLGtCQUZIO0FBR1AsMENBQTBCcEMsS0FBSyxDQUFDSSxLQUFOLENBQVlzQixJQUFaLENBQWlCVyxXQUEzQztBQUhPO0FBRHNFLEtBQWpGLEVBTUdDLElBTkgsQ0FNUSxVQUFBQyxHQUFHLEVBQUk7QUFDYkMsd0RBQUksQ0FBQ0MsSUFBTCxDQUFVO0FBQ1JDLGFBQUssRUFBQ0gsR0FBRyxDQUFDSSxPQURGO0FBRVJDLFlBQUksRUFBQztBQUZHLE9BQVY7QUFJRCxLQVhELFdBV1MsVUFBQUMsR0FBRyxFQUFJO0FBQ2YsV0FBSSxJQUFJZCxJQUFSLElBQWVjLEdBQUcsQ0FBQ0MsUUFBSixDQUFhbEIsSUFBYixDQUFrQmYsTUFBakMsRUFBd0M7QUFDdENHLGdCQUFRLENBQUNlLElBQUQsRUFBSztBQUFDWSxpQkFBTyxFQUFFRSxHQUFHLENBQUNDLFFBQUosQ0FBYWxCLElBQWIsQ0FBa0JmLE1BQWxCLENBQXlCa0IsSUFBekIsRUFBOEJnQixJQUE5QixDQUFtQyxJQUFuQztBQUFWLFNBQUwsQ0FBUjtBQUNEO0FBQ0QsS0FmRDtBQWdCRixHQTVCRDs7QUFnQ0Usc0JBQ0kscUVBQUMsOERBQUQ7QUFBTSxhQUFTLEVBQUMscUNBQWhCO0FBQUEsNEJBQ0kscUVBQUMsZ0VBQUQ7QUFBTyxlQUFTLEVBQUMsT0FBakI7QUFBQSw2QkFDRSxxRUFBQyxxRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURKLGVBSUMscUVBQUMsOERBQUQ7QUFBTSxlQUFTLEVBQUMsUUFBaEI7QUFBQSw2QkFDQSxxRUFBQyw4REFBRDtBQUFNLGlCQUFTLEVBQUMscUJBQWhCO0FBQUEsZ0NBQ0MscUVBQUMsOERBQUQsQ0FBTSxNQUFOO0FBQWEsY0FBSSxFQUFFN0MsQ0FBQyxDQUFDO0FBQUNOLGNBQUUsRUFBQztBQUFKLFdBQUQ7QUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERCxlQUVDO0FBQU0sa0JBQVEsRUFBRWtCLFlBQVksQ0FBQ2EsTUFBRCxDQUE1QjtBQUFBLGtDQUNBLHFFQUFDLDhEQUFELENBQU0sSUFBTjtBQUFXLHFCQUFTLEVBQUMsT0FBckI7QUFBQSxtQ0FDRTtBQUFLLHVCQUFTLEVBQUMsbUJBQWY7QUFBQSxzQ0FDSSxxRUFBQywwRUFBRDtBQUFXLHFCQUFLLEVBQUV6QixDQUFDLENBQUM7QUFBQ04sb0JBQUUsRUFBQztBQUFKLGlCQUFELENBQW5CO0FBQXVDLHlCQUFTLEVBQUMsVUFBakQ7QUFBNEQseUJBQVMsRUFBQyxrQkFBdEU7QUFDQyxxQkFBSyxxQkFBRWlCLE1BQU0sQ0FBQ21DLE9BQVQsb0RBQUUsZ0JBQWdCTCxPQUR4QjtBQUFBLHVDQUdFLHFFQUFDLHdFQUFEO0FBQVcsMkJBQVMsRUFBQyxnQkFBckI7QUFDRyxzQkFBSSxFQUFFLENBQ047QUFBQy9DLHNCQUFFLEVBQUMsRUFBSjtBQUFPQyx3QkFBSSxFQUFDSyxDQUFDLENBQUM7QUFBQ04sd0JBQUUsRUFBQztBQUFKLHFCQUFEO0FBQWIsbUJBRE0sRUFFTjtBQUFDQSxzQkFBRSxFQUFDLEVBQUo7QUFBT0Msd0JBQUksRUFBQ0ssQ0FBQyxDQUFDO0FBQUNOLHdCQUFFLEVBQUM7QUFBSixxQkFBRDtBQUFiLG1CQUZNLEVBR047QUFBQ0Esc0JBQUUsRUFBQyxFQUFKO0FBQU9DLHdCQUFJLEVBQUNLLENBQUMsQ0FBQztBQUFDTix3QkFBRSxFQUFDO0FBQUoscUJBQUQ7QUFBYixtQkFITSxDQURUO0FBTUMsc0JBQUksRUFBQyxTQU5OO0FBT0MscUJBQUcsRUFBRWdCLFFBQVEsQ0FBQztBQUNicUMsNEJBQVEsRUFBQztBQUFDekIsMkJBQUssRUFBQyxJQUFQO0FBQWFtQiw2QkFBTyxFQUFDO0FBQXJCO0FBREksbUJBQUQsQ0FQZCxDQVVFOztBQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQURKLGVBa0JJLHFFQUFDLDBFQUFEO0FBQVcscUJBQUssRUFBQyxlQUFqQjtBQUE0Qix5QkFBUyxFQUFDLFVBQXRDO0FBQWlELHlCQUFTLEVBQUMsa0JBQTNEO0FBQ0EscUJBQUssMEJBQUU5QixNQUFNLENBQUNxQyxZQUFULHlEQUFFLHFCQUFxQlAsT0FENUI7QUFBQSx1Q0FHRSxxRUFBQyxnRUFBRDtBQUFPLHNCQUFJLEVBQUMsTUFBWjtBQUFtQixzQkFBSSxFQUFDLGNBQXhCO0FBQ0cscUJBQUcsRUFBRS9CLFFBQVEsQ0FBQztBQUNicUMsNEJBQVEsRUFBQztBQUFDekIsMkJBQUssRUFBQyxJQUFQO0FBQWFtQiw2QkFBTyxFQUFDO0FBQXJCO0FBREksbUJBQUQsQ0FEaEIsQ0FJRTs7QUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFsQkosZUE4QkkscUVBQUMsMEVBQUQ7QUFBVyxxQkFBSyxFQUFFekMsQ0FBQyxDQUFDO0FBQUNOLG9CQUFFLEVBQUM7QUFBSixpQkFBRCxDQUFuQjtBQUFzQyx5QkFBUyxFQUFDLFVBQWhEO0FBQTJELHlCQUFTLEVBQUMsa0JBQXJFO0FBQ0EscUJBQUssdUJBQUVpQixNQUFNLENBQUNzQyxTQUFULHNEQUFFLGtCQUFrQlIsT0FEekI7QUFBQSx1Q0FHRSxxRUFBQyxnRUFBRDtBQUFPLHNCQUFJLEVBQUMsTUFBWjtBQUFtQixzQkFBSSxFQUFDLFdBQXhCO0FBQ0cscUJBQUcsRUFBRS9CLFFBQVEsQ0FBQztBQUNacUMsNEJBQVEsRUFBQztBQUFDekIsMkJBQUssRUFBQyxJQUFQO0FBQWFtQiw2QkFBTyxFQUFDO0FBQXJCO0FBREcsbUJBQUQsQ0FEaEIsQ0FJRTs7QUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkE5QkosZUF5Q0kscUVBQUMsMEVBQUQ7QUFBVyxxQkFBSyxFQUFFekMsQ0FBQyxDQUFDO0FBQUNOLG9CQUFFLEVBQUM7QUFBSixpQkFBRCxDQUFuQjtBQUFvQyx5QkFBUyxFQUFDLFVBQTlDO0FBQXlELHlCQUFTLEVBQUMsa0JBQW5FO0FBQ0MscUJBQUssd0JBQUVpQixNQUFNLENBQUN1QyxVQUFULHVEQUFFLG1CQUFtQlQsT0FEM0I7QUFBQSx1Q0FHRSxxRUFBQyx3RUFBRDtBQUFXLDJCQUFTLEVBQUMsaUJBQXJCO0FBQXVDLHNCQUFJLEVBQUUzQyxLQUFLLENBQUNxRCxjQUFuRDtBQUNDLHNCQUFJLEVBQUMsWUFETjtBQUVDLHFCQUFHLEVBQUV6QyxRQUFRLENBQUM7QUFDYnFDLDRCQUFRLEVBQUM7QUFBQ3pCLDJCQUFLLEVBQUMsSUFBUDtBQUFhbUIsNkJBQU8sRUFBQztBQUFyQjtBQURJLG1CQUFELENBRmQ7QUFLRywwQkFBUSxFQUFFLGtCQUFDckIsRUFBRCxFQUFRO0FBQ2hCSixvQ0FBZ0IsQ0FBQ0ksRUFBRSxDQUFDQyxNQUFILENBQVVDLEtBQVgsQ0FBaEI7QUFDRDtBQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQXpDSixlQXdESSxxRUFBQywwRUFBRDtBQUFXLHFCQUFLLEVBQUV0QixDQUFDLENBQUM7QUFBQ04sb0JBQUUsRUFBQztBQUFKLGlCQUFELENBQW5CO0FBQW1DLHlCQUFTLEVBQUMsVUFBN0M7QUFBd0QseUJBQVMsRUFBQyxrQkFBbEU7QUFDQyxxQkFBSywwQkFBRWlCLE1BQU0sQ0FBQ3lDLFlBQVQseURBQUUscUJBQXFCWCxPQUQ3QjtBQUFBLHVDQUdFLHFFQUFDLHdFQUFEO0FBQVcsMkJBQVMsRUFBQyxnQkFBckI7QUFBc0Msc0JBQUksRUFBRTFCLGFBQWEsOEJBQUlqQixLQUFLLENBQUNxRCxjQUFOLENBQXFCRSxJQUFyQixDQUEwQixVQUFBQyxDQUFDO0FBQUEsMkJBQUlBLENBQUMsQ0FBQzVELEVBQUYsS0FBUSxDQUFDcUIsYUFBYjtBQUFBLG1CQUEzQixDQUFKLDBEQUFJLHNCQUF3RHdDLGNBQTVELENBQXpEO0FBQ0Msc0JBQUksRUFBQyxjQUROO0FBRUMscUJBQUcsRUFBRTdDLFFBQVEsQ0FBQztBQUNicUMsNEJBQVEsRUFBQztBQUFDekIsMkJBQUssRUFBQyxJQUFQO0FBQWFtQiw2QkFBTyxFQUFDO0FBQXJCO0FBREksbUJBQUQ7QUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkF4REosZUFvRUkscUVBQUMsMEVBQUQ7QUFBVyxxQkFBSyxFQUFFekMsQ0FBQyxDQUFDO0FBQUNOLG9CQUFFLEVBQUM7QUFBSixpQkFBRCxDQUFuQjtBQUF1Qyx5QkFBUyxFQUFDLFVBQWpEO0FBQTRELHlCQUFTLEVBQUMsa0JBQXRFO0FBQ0EscUJBQUssbUJBQUVpQixNQUFNLENBQUM2QyxLQUFULGtEQUFFLGNBQWNmLE9BRHJCO0FBQUEsdUNBR0UscUVBQUMsZ0VBQUQ7QUFBTyxzQkFBSSxFQUFDLFFBQVo7QUFBcUIsc0JBQUksRUFBQyxPQUExQjtBQUNHLHFCQUFHLEVBQUUvQixRQUFRLENBQUM7QUFDWnFDLDRCQUFRLEVBQUM7QUFBQ3pCLDJCQUFLLEVBQUMsSUFBUDtBQUFhbUIsNkJBQU8sRUFBQztBQUFyQjtBQURHLG1CQUFEO0FBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQXBFSixlQWdGSSxxRUFBQywwRUFBRDtBQUNFLHFCQUFLLEVBQUV6QyxDQUFDLENBQUM7QUFBQ04sb0JBQUUsRUFBQztBQUFKLGlCQUFELENBRFY7QUFFRSx5QkFBUyxFQUFDLFVBRlo7QUFHRSx5QkFBUyxFQUFDLGtCQUhaO0FBSUUseUJBQVMsRUFBRTtBQUFDK0Qsd0JBQU0sRUFBQztBQUFSLGlCQUpiO0FBS0EscUJBQUsscUJBQUU5QyxNQUFNLENBQUMrQyxPQUFULG9EQUFFLGdCQUFnQmpCLE9BTHZCO0FBQUEsdUNBT0U7QUFBSywyQkFBUyxFQUFDLGNBQWY7QUFBQSwwQ0FDQSxxRUFBQyxnRUFBRDtBQUFPLDZCQUFTLEVBQUMsT0FBakI7QUFBeUIsd0JBQUksRUFBQyxNQUE5QjtBQUFxQyx5QkFBSyxFQUFDLEdBQTNDO0FBQStDLHdCQUFJLEVBQUMsU0FBcEQ7QUFDRyx1QkFBRyxFQUFFL0IsUUFBUSxDQUFDO0FBQ1pxQyw4QkFBUSxFQUFDO0FBQUN6Qiw2QkFBSyxFQUFDLElBQVA7QUFBYW1CLCtCQUFPLEVBQUM7QUFBckI7QUFERyxxQkFBRCxDQURoQjtBQUlHLDRCQUFRLEVBQUUsa0JBQUNrQixDQUFELEVBQU87QUFDZkMsNkJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFDLENBQUN0QyxNQUFGLENBQVN5QyxLQUFULENBQWUsQ0FBZixDQUFaO0FBQ0Q1QyxpQ0FBVyxDQUFDeUMsQ0FBQyxDQUFDdEMsTUFBRixDQUFTeUMsS0FBVCxDQUFlLENBQWYsRUFBa0JuRSxJQUFuQixDQUFYO0FBQ0E7QUFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQURBLGVBVUU7QUFBSyw2QkFBUyxFQUFDLFlBQWY7QUFBQSw0Q0FDSTtBQUFLLHlCQUFHLEVBQUM7QUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQURKLGVBRUk7QUFBQSx1RkFDd0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFEeEIsOEJBRVU7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFGVixlQUdJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQUhKLG9CQUc2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQUg3QixFQUtNc0IsUUFBUSxpQkFBSTtBQUFBLGtDQUFTQTtBQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBTGxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFoRkosZUErR0kscUVBQUMsMEVBQUQ7QUFBVyxxQkFBSyxFQUFFakIsQ0FBQyxDQUFDO0FBQUNOLG9CQUFFLEVBQUM7QUFBSixpQkFBRCxDQUFuQjtBQUFrQyx5QkFBUyxFQUFDLFVBQTVDO0FBQXVELHlCQUFTLEVBQUU7QUFBQytELHdCQUFNLEVBQUM7QUFBUixpQkFBbEU7QUFBb0YseUJBQVMsRUFBQyxrQkFBOUY7QUFDRyxxQkFBSyxrQkFBRTlDLE1BQU0sQ0FBQ29ELElBQVQsaURBQUUsYUFBYXRCLE9BRHZCO0FBQUEsdUNBR007QUFBVSwyQkFBUyxFQUFDLGtCQUFwQjtBQUF1Qyx1QkFBSyxFQUFFO0FBQUN1QiwyQkFBTyxFQUFDLE1BQVQ7QUFBZ0JDLDBCQUFNLEVBQUM7QUFBdkIsbUJBQTlDO0FBQThFLDZCQUFXLEVBQUMsMkJBQTFGO0FBQXNILHNCQUFJLEVBQUMsTUFBM0g7QUFDRSxxQkFBRyxFQUFFdkQsUUFBUSxDQUFDO0FBQ1pxQyw0QkFBUSxFQUFDO0FBQUN6QiwyQkFBSyxFQUFDLElBQVA7QUFBWW1CLDZCQUFPLEVBQUM7QUFBcEI7QUFERyxtQkFBRDtBQURmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQS9HSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURBLGVBNEhFLHFFQUFDLDhEQUFELENBQU0sTUFBTjtBQUFhLHFCQUFTLEVBQUMsT0FBdkI7QUFBK0IsaUJBQUssRUFBRTtBQUFDeUIsNEJBQWMsRUFBQztBQUFoQixhQUF0QztBQUFBLG1DQUNFLHFFQUFDLGlFQUFEO0FBQWlCLHVCQUFTLEVBQUMsWUFBM0I7QUFBeUMsbUJBQUssRUFBRWxFLENBQUMsQ0FBQztBQUFDTixrQkFBRSxFQUFDO0FBQUosZUFBRDtBQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkE1SEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFKRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFESjtBQTRJSDs7R0FsTVFHLFc7VUFDc0JFLGtELEVBT1ZRLHFELEVBQ21DRSx1RDs7O0tBVC9DWixXOztBQW9NVCxJQUFNc0UsZUFBZSxHQUFHLFNBQWxCQSxlQUFrQixDQUFBQyxLQUFLO0FBQUEsU0FBSztBQUNoQ2xFLFNBQUssRUFBRWtFLEtBQUssQ0FBQ2xFO0FBRG1CLEdBQUw7QUFBQSxDQUE3Qjs7QUFJQSxJQUFNbUUsa0JBQWtCLEdBQUcsRUFBM0I7O0FBaUJlQywwSEFBTyxDQUFDSCxlQUFELENBQVAsZUFBeUJJLGtEQUFJLENBQUMxRSxXQUFELENBQTdCLENBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvZGVjbGVyYXRpb24uYzM4YzJhYmE1ODI2OWFlZTFjNmQuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBheGlvcyBmcm9tICdheGlvcyc7XHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCJuZXh0L3JvdXRlclwiO1xyXG5pbXBvcnQgUmVhY3QsIHsgbWVtbywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCAncmVhY3QtZGF5LXBpY2tlci9saWIvc3R5bGUuY3NzJztcclxuaW1wb3J0IHsgdXNlRm9ybSB9IGZyb20gXCJyZWFjdC1ob29rLWZvcm1cIjtcclxuaW1wb3J0IHsgdXNlSW50bCB9IGZyb20gJ3JlYWN0LWludGwnO1xyXG5pbXBvcnQgeyBjb25uZWN0IH0gZnJvbSBcInJlYWN0LXJlZHV4XCI7XHJcbmltcG9ydCBTd2FsIGZyb20gXCJzd2VldGFsZXJ0MlwiO1xyXG5pbXBvcnQgQXNpZGVNZW51IGZyb20gXCIuLi9jb21wb25lbnRzL2FzaWRlLW1lbnUvaW5kZXhcIjtcclxuaW1wb3J0IEFzaWRlIGZyb20gJy4uL2NvbXBvbmVudHMvYXNpZGUvYXNpZGUnO1xyXG5pbXBvcnQgQnV0dG9uQ29tcG9uZW50IGZyb20gXCIuLi9jb21wb25lbnRzL2J1dHRvbi9pbmRleFwiO1xyXG5pbXBvcnQgQ2FyZCBmcm9tIFwiLi4vY29tcG9uZW50cy9jYXJkL2NhcmRcIjtcclxuaW1wb3J0IEZyb21Hcm91cCBmcm9tIFwiLi4vY29tcG9uZW50cy9mb3JtLWdyb3VwL2Zvcm0tZ3JvdXBcIjtcclxuaW1wb3J0IElucHV0IGZyb20gXCIuLi9jb21wb25lbnRzL2lucHV0L2lucHV0XCI7XHJcbmltcG9ydCBNYWluIGZyb20gJy4uL2NvbXBvbmVudHMvbWFpbi9tYWluJztcclxuaW1wb3J0IFBhZ2UgZnJvbSBcIi4uL2NvbXBvbmVudHMvcGFnZS9wYWdlXCI7XHJcbmltcG9ydCBSZWRpcmVjdCBmcm9tIFwiLi4vY29tcG9uZW50cy9yZWRpcmVjdC9yZWRpcmVjdFwiO1xyXG5pbXBvcnQgU2VsZWN0Ym94IGZyb20gXCIuLi9jb21wb25lbnRzL3NlbGVjdGJveC9zZWxlY3Rib3hcIjtcclxuXHJcbmNvbnN0IHRlbERhdGEgPSBbXHJcbiAge2lkOjE1LG5hbWU6J1TDvHJraXnJmSd9LFxyXG4gIHtpZDoxNixuYW1lOidUw7xya2l5yZknfSxcclxuICB7aWQ6MTcsbmFtZTonVMO8cmtpecmZJ31cclxuIF1cclxuXHJcbiBjb25zdCBjdXJEYXRhID0gW1xyXG4gIHtpZDondHJ5JyxuYW1lOidUw7xya2l5yZkgTGlyyZlzaSd9LFxyXG4gIHtpZDonYXpuJyxuYW1lOidBesmZcmJheWNhbiBNYW5hdMSxJ30sXHJcbiAge2lkOidldXInLG5hbWU6J0F2cm8nfSxcclxuICB7aWQ6J3VzZCcsbmFtZTonQULFniBkb2xsYXLEsSd9LFxyXG4gIHtpZDonYmxhJyxuYW1lOidibGEgZG9sbGFyxLEnfVxyXG5cclxuXHJcbiBdXHJcbiBcclxuZnVuY3Rpb24gRGVjbGVyYXRpb24ocHJvcHMpIHtcclxuICBjb25zdCB7IGZvcm1hdE1lc3NhZ2U6IGYgfSA9IHVzZUludGwoKTsgXHJcblxyXG4gIGlmKCFwcm9wcy5lbnRyeS5pc0xvZ2VkKXtcclxuICAgIHJldHVybiA8UmVkaXJlY3QvPlxyXG4gIH1cclxuXHJcbiAgY29uc3QgW2NoZWNrU2VyaWFsLCBzZXRDaGVja1NlcmlhbF0gPSB1c2VTdGF0ZSgnQUEnKTtcclxuICBjb25zdCB7IGxvY2FsZSB9ID0gdXNlUm91dGVyKCk7XHJcbiAgY29uc3Qge3JlZ2lzdGVyLGVycm9ycyxoYW5kbGVTdWJtaXQsd2F0Y2gsc2V0RXJyb3J9ID0gdXNlRm9ybSgpO1xyXG4gIGNvbnN0IFtzdWJDYXRlZ29yaWVzLCBzZXRTdWJDYXRlZ29yaWVzXSA9IHVzZVN0YXRlKCdBQScpO1xyXG4gIGNvbnN0IFtmaWxlTmFtZSwgc2V0RmlsZU5hbWVdID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZXYpID0+IHtcclxuICAgICBsZXQge25hbWUsIHZhbHVlfSA9IGV2LnRhcmdldDtcclxuICAgICBzZXRVc2VyKHtcclxuICAgICAgIC4uLnVzZXIsXHJcbiAgICAgICBbbmFtZV06IHZhbHVlXHJcbiAgICAgfSlcclxuICB9XHJcblxyXG4gIGNvbnN0IHN1Ym1pdCA9IChkYXRhKSA9PiB7XHJcbiAgICAgIFxyXG4gICAgIGxldCBuZXdGb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpO1xyXG4gICAgIGZvcihsZXQga2V5IGluIGRhdGEpe1xyXG4gICAgICAgaWYoa2V5ID09PSAnaW52b2ljZScpXHJcbiAgICAgICAgIG5ld0Zvcm1EYXRhLmFwcGVuZChrZXksZGF0YVtrZXldWzBdKTtcclxuICAgICAgIGVsc2VcclxuICAgICAgIG5ld0Zvcm1EYXRhLmFwcGVuZChrZXksZGF0YVtrZXldKTtcclxuICAgICB9XHJcblxyXG4gICAgIG5ld0Zvcm1EYXRhLmFwcGVuZCgnX21ldGhvZCcsJ1BPU1QnKVxyXG5cclxuICAgICBheGlvcy5wb3N0KGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9YmF0Y2hlcz9sYW49JHtsb2NhbGV9YCxuZXdGb3JtRGF0YSx7XHJcbiAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgJ0NvbnRlbnQtVHlwZSc6J211bHRpcGFydC9mb3JtLWRhdGEnLFxyXG4gICAgICAgICAnQWNjZXB0cyc6J2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAnQXV0aG9yaXphdGlvbic6YEJlYXJlciAke3Byb3BzLmVudHJ5LnVzZXIuYWNjZXNzVG9rZW59YFxyXG4gICAgICB9XHJcbiAgICAgfSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgU3dhbC5maXJlKHtcclxuICAgICAgICAgdGl0bGU6cmVzLm1lc3NhZ2UsXHJcbiAgICAgICAgIGljb246J3N1Y2Nlc3MnLFxyXG4gICAgICAgfSlcclxuICAgICB9KS5jYXRjaChlcnIgPT4ge1xyXG4gICAgICBmb3IobGV0IGtleSBpbiBlcnIucmVzcG9uc2UuZGF0YS5lcnJvcnMpe1xyXG4gICAgICAgIHNldEVycm9yKGtleSx7bWVzc2FnZTogZXJyLnJlc3BvbnNlLmRhdGEuZXJyb3JzW2tleV0uam9pbignXFxuJyl9KVxyXG4gICAgICB9XHJcbiAgICAgfSlcclxuICB9XHJcblxyXG5cclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxQYWdlIGNsYXNzTmFtZT0ndXNlci1wcm9maWxlLXBhZ2UgYmctYmcgcHQtbGcgcGItbGcnPlxyXG4gICAgICAgICAgICA8QXNpZGUgY2xhc3NOYW1lPSdtci1zbSc+XHJcbiAgICAgICAgICAgICAgPEFzaWRlTWVudS8+XHJcbiAgICAgICAgICAgIDwvQXNpZGU+XHJcbiAgICAgICAgIDxNYWluIGNsYXNzTmFtZT0ncC1ub25lJz5cclxuICAgICAgICAgPENhcmQgY2xhc3NOYW1lPSdiZy13aGl0ZSBwLXNtIGJyLWxnJz5cclxuICAgICAgICAgIDxDYXJkLkhlYWRlciB0ZXh0PXtmKHtpZDpcImRlY2xlcmF0aW9uXCJ9KX0vPlxyXG4gICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdChzdWJtaXQpfT5cclxuICAgICAgICAgIDxDYXJkLkJvZHkgY2xhc3NOYW1lPSdiZy1iZyc+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdkZWNsYXJhdGlvbl9fZmxleCc+XHJcbiAgICAgICAgICAgICAgICA8RnJvbUdyb3VwIGxhYmVsPXtmKHtpZDpcImNob29zZW9uZVwifSl9IGJvZHlDbGFzcz0nYmctd2hpdGUnIGNsYXNzTmFtZT0ndy01MCBwci14cyBtYi1zbSdcclxuICAgICAgICAgICAgICAgICBlcnJvcj17ZXJyb3JzLmNvdW50cnk/Lm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3Rib3ggY2xhc3NOYW1lPSdiZy13aGl0ZSB3LTEwMCcgXHJcbiAgICAgICAgICAgICAgICAgICAgIGRhdGE9e1tcclxuICAgICAgICAgICAgICAgICAgICAge2lkOjE1LG5hbWU6Zih7aWQ6J3R1cmtleSd9KX0sXHJcbiAgICAgICAgICAgICAgICAgICAgIHtpZDoxNixuYW1lOmYoe2lkOid1c2EnfSl9LFxyXG4gICAgICAgICAgICAgICAgICAgICB7aWQ6MTcsbmFtZTpmKHtpZDondWtyYWluYSd9KX1cclxuICAgICAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgICAgbmFtZT0nY291bnRyeSdcclxuICAgICAgICAgICAgICAgICAgIFJlZj17cmVnaXN0ZXIoe1xyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOnt2YWx1ZTp0cnVlLCBtZXNzYWdlOidjb3VudHJ5IHR5cGUgaXMgcmVxdWlyZWQnfSxcclxuICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L0Zyb21Hcm91cD5cclxuXHJcbiAgICAgICAgICAgICAgICA8RnJvbUdyb3VwIGxhYmVsPSdUcmFjayDEsEQnIGJvZHlDbGFzcz0nYmctd2hpdGUnIGNsYXNzTmFtZT0ndy01MCBwci14cyBtYi1zbSdcclxuICAgICAgICAgICAgICAgIGVycm9yPXtlcnJvcnMudHJhY2tfbnVtYmVyPy5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXQgdHlwZT0ndGV4dCcgbmFtZT0ndHJhY2tfbnVtYmVyJ1xyXG4gICAgICAgICAgICAgICAgICAgICBSZWY9e3JlZ2lzdGVyKHtcclxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOnt2YWx1ZTp0cnVlLCBtZXNzYWdlOid0cmFjayBudW1iZXIgaXMgcmVxdWlyZWQnfSxcclxuICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAvLyAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8L0Zyb21Hcm91cD5cclxuXHJcbiAgICAgICAgICAgICAgICA8RnJvbUdyb3VwIGxhYmVsPXtmKHtpZDpcInNob3BuYW1lXCJ9KX0gYm9keUNsYXNzPSdiZy13aGl0ZScgY2xhc3NOYW1lPSd3LTUwIHByLXhzIG1iLXNtJ1xyXG4gICAgICAgICAgICAgICAgZXJyb3I9e2Vycm9ycy5zaG9wX25hbWU/Lm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dCB0eXBlPSd0ZXh0JyBuYW1lPSdzaG9wX25hbWUnXHJcbiAgICAgICAgICAgICAgICAgICAgIFJlZj17cmVnaXN0ZXIoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOnt2YWx1ZTp0cnVlLCBtZXNzYWdlOidzaG9wIG5hbWUgaXMgcmVxdWlyZWQnfSxcclxuICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L0Zyb21Hcm91cD5cclxuXHJcbiAgICAgICAgICAgICAgICA8RnJvbUdyb3VwIGxhYmVsPXtmKHtpZDpcIm1haW4tZ1wifSl9IGJvZHlDbGFzcz0nYmctd2hpdGUnIGNsYXNzTmFtZT0ndy01MCBwci14cyBtYi1zbSdcclxuICAgICAgICAgICAgICAgICBlcnJvcj17ZXJyb3JzLm1haW5fZ3JvdXA/Lm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3Rib3ggY2xhc3NOYW1lPSdiZy13aGl0ZSB3LTEwMCAnIGRhdGE9e3Byb3BzLm1haW5DYXRlZ29yaWVzfVxyXG4gICAgICAgICAgICAgICAgICAgbmFtZT0nbWFpbl9ncm91cCdcclxuICAgICAgICAgICAgICAgICAgIFJlZj17cmVnaXN0ZXIoe1xyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOnt2YWx1ZTp0cnVlLCBtZXNzYWdlOidtYWluX2dyb3VwIHR5cGUgaXMgcmVxdWlyZWQnfSxcclxuICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXYpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICBzZXRTdWJDYXRlZ29yaWVzKGV2LnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvRnJvbUdyb3VwPlxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICA8RnJvbUdyb3VwIGxhYmVsPXtmKHtpZDpcInN1Yi1nXCJ9KX0gYm9keUNsYXNzPSdiZy13aGl0ZScgY2xhc3NOYW1lPSd3LTUwIHByLXhzIG1iLXNtJ1xyXG4gICAgICAgICAgICAgICAgIGVycm9yPXtlcnJvcnMuc3ViX2NhdGVnb3J5Py5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Ym94IGNsYXNzTmFtZT0nYmctd2hpdGUgdy0xMDAnIGRhdGE9e3N1YkNhdGVnb3JpZXMgJiYgcHJvcHMubWFpbkNhdGVnb3JpZXMuZmluZCh4ID0+IHguaWQ9PT0gK3N1YkNhdGVnb3JpZXMpPy5zdWJfY2F0ZWdvcmllc31cclxuICAgICAgICAgICAgICAgICAgIG5hbWU9J3N1Yl9jYXRlZ29yeSdcclxuICAgICAgICAgICAgICAgICAgIFJlZj17cmVnaXN0ZXIoe1xyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOnt2YWx1ZTp0cnVlLCBtZXNzYWdlOidzdWIgY2F0ZWdvcnkgdHlwZSBpcyByZXF1aXJlZCd9LFxyXG4gICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvRnJvbUdyb3VwPlxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICA8RnJvbUdyb3VwIGxhYmVsPXtmKHtpZDpcInByaWNlLWludlwifSl9IGJvZHlDbGFzcz0nYmctd2hpdGUnIGNsYXNzTmFtZT0ndy01MCBwci14cyBtYi1zbSdcclxuICAgICAgICAgICAgICAgIGVycm9yPXtlcnJvcnMucHJpY2U/Lm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dCB0eXBlPSdudW1iZXInIG5hbWU9J3ByaWNlJ1xyXG4gICAgICAgICAgICAgICAgICAgICBSZWY9e3JlZ2lzdGVyKHtcclxuICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZDp7dmFsdWU6dHJ1ZSwgbWVzc2FnZToncHJpY2UgaXMgcmVxdWlyZWQnfVxyXG4gICAgICAgICAgICAgICAgICAgICB9KX0gXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPC9Gcm9tR3JvdXA+XHJcblxyXG5cclxuICAgICAgICAgICAgICAgIDxGcm9tR3JvdXAgXHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsPXtmKHtpZDpcInVwbG9hZFwifSl9IFxyXG4gICAgICAgICAgICAgICAgICBib2R5Q2xhc3M9J2JnLXdoaXRlJyBcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPSd3LTUwIHByLXhzIG1iLXNtJ1xyXG4gICAgICAgICAgICAgICAgICBib2R5U3R5bGU9e3toZWlnaHQ6JzE1MHB4J319XHJcbiAgICAgICAgICAgICAgICBlcnJvcj17ZXJyb3JzLmludm9pY2U/Lm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdmaWxlLXVwbG9hZGUnPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXQgY2xhc3NOYW1lPSd3LTEwMCcgdHlwZT0nZmlsZScgdGl0bGU9JyAnIG5hbWU9J2ludm9pY2UnXHJcbiAgICAgICAgICAgICAgICAgICAgIFJlZj17cmVnaXN0ZXIoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOnt2YWx1ZTp0cnVlLCBtZXNzYWdlOidpbnZvaWNlIGlzIHJlcXVpcmVkJ31cclxuICAgICAgICAgICAgICAgICAgICAgfSl9IFxyXG4gICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlLnRhcmdldC5maWxlc1swXSlcclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZpbGVOYW1lKGUudGFyZ2V0LmZpbGVzWzBdLm5hbWUpXHJcbiAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J292ZXItbGF5ZXInPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz0nL2Fzc2V0cy9pY29ucy91cGxvYWQucG5nJy8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBTw7xyw7xrbMmZeWliIGJ1cmEgYXTEsW4gPGJyLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHbJmSB5YSA8YnIvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+ZmF5bMSxIHNlw6dpbjwvc3Bhbj4gPGJyLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsZU5hbWUgJiYgPHN0cm9uZz57ZmlsZU5hbWV9PC9zdHJvbmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L0Zyb21Hcm91cD5cclxuXHJcbiAgICAgICAgICAgICAgICA8RnJvbUdyb3VwIGxhYmVsPXtmKHtpZDpcIm5vdGVcIn0pfSBib2R5Q2xhc3M9J2JnLXdoaXRlJyBib2R5U3R5bGU9e3toZWlnaHQ6JzE1MHB4J319IGNsYXNzTmFtZT0ndy01MCBwci14cyBtYi1zbSdcclxuICAgICAgICAgICAgICAgICAgIGVycm9yPXtlcnJvcnMubm90ZT8ubWVzc2FnZX1cclxuICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYSBjbGFzc05hbWU9J3AteHMgdy0xMDAgaC0xMDAnIHN0eWxlPXt7b3V0bGluZTonbm9uZScsYm9yZGVyOidub25lJ319IHBsYWNlaG9sZGVyPSdxZXlkaW5peiB2YXJzYSBkYXhpbCBlZGluJyBuYW1lPSdub3RlJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZWY9e3JlZ2lzdGVyKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZDp7dmFsdWU6dHJ1ZSxtZXNzYWdlOidub3RlIGlzIHJlcXVpcmVkJ30gICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pfSBcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICA8L0Zyb21Hcm91cD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L0NhcmQuQm9keT5cclxuICAgICAgICAgICAgPENhcmQuRm9vdGVyIGNsYXNzTmFtZT0nbXQtc20nIHN0eWxlPXt7anVzdGlmeUNvbnRlbnQ6J2ZsZXgtZW5kJ319PlxyXG4gICAgICAgICAgICAgIDxCdXR0b25Db21wb25lbnQgY2xhc3NOYW1lPSdtdC1zbSBwLXhzJyAgbGFiZWw9e2Yoe2lkOlwiZGVjbGFyZS1pbmFkdmFuY2VcIn0pfS8+XHJcbiAgICAgICAgICAgIDwvQ2FyZC5Gb290ZXI+XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgICAgICA8L01haW4+XHJcbiAgICAgICAgPC9QYWdlPlxyXG4gICAgKVxyXG59XHJcblxyXG5jb25zdCBtYXBTdGF0ZVRvUHJvcHMgPSBzdGF0ZSA9PiAoe1xyXG4gIGVudHJ5OiBzdGF0ZS5lbnRyeVxyXG59KTtcclxuXHJcbmNvbnN0IG1hcERpc3BhdGNoVG9Qcm9wcyA9IHtcclxuXHJcbn1cclxuXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U3RhdGljUHJvcHMoe2xvY2FsZX0pIHtcclxuXHJcbiAgbGV0IGNhdGVnb3JpZXMgPSBhd2FpdCBheGlvcy5nZXQoYCR7cHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQVBJX1VSTH1jYXRlZ29yaWVzL21haW4/bGFuPSR7bG9jYWxlfWApO1xyXG5cclxuICByZXR1cm4ge1xyXG4gICAgcHJvcHM6IHtcclxuICAgICAgbWFpbkNhdGVnb3JpZXM6IGNhdGVnb3JpZXMuZGF0YSxcclxuICAgIH0sXHJcbiAgfVxyXG5cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgY29ubmVjdChtYXBTdGF0ZVRvUHJvcHMpKG1lbW8oRGVjbGVyYXRpb24pKVxyXG4iXSwic291cmNlUm9vdCI6IiJ9