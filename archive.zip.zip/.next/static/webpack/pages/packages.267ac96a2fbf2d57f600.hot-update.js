webpackHotUpdate_N_E("pages/packages",{

/***/ "./pages/packages.js":
/*!***************************!*\
  !*** ./pages/packages.js ***!
  \***************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/toConsumableArray */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/regenerator */ "./node_modules/next/node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-hook-form */ "./node_modules/react-hook-form/dist/index.esm.js");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-intl */ "./node_modules/react-intl/lib/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _components_aside_menu_index__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../components/aside-menu/index */ "./components/aside-menu/index.js");
/* harmony import */ var _components_aside_aside__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../components/aside/aside */ "./components/aside/aside.js");
/* harmony import */ var _components_button__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../components/button */ "./components/button/index.js");
/* harmony import */ var _components_card_card__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../components/card/card */ "./components/card/card.js");
/* harmony import */ var _components_checkbox_checkbox__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../components/checkbox/checkbox */ "./components/checkbox/checkbox.js");
/* harmony import */ var _components_form_group_form_group__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../components/form-group/form-group */ "./components/form-group/form-group.js");
/* harmony import */ var _components_input_input__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../components/input/input */ "./components/input/input.js");
/* harmony import */ var _components_main_main__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../components/main/main */ "./components/main/main.js");
/* harmony import */ var _components_package_item_package_item__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../components/package_item/package-item */ "./components/package_item/package-item.js");
/* harmony import */ var _components_page_page__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../components/page/page */ "./components/page/page.js");
/* harmony import */ var _components_redirect_redirect__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../components/redirect/redirect */ "./components/redirect/redirect.js");
/* harmony import */ var _components_tabel_tabel__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../components/tabel/tabel */ "./components/tabel/tabel.js");
/* harmony import */ var _redux_entry_entryActions__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../redux/entry/entryActions */ "./redux/entry/entryActions.js");







var _jsxFileName = "C:\\Users\\Home\\Desktop\\166\\166-kargo\\pages\\packages.js",
    _s = $RefreshSig$();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }





















function Packages(props) {
  _s();

  var _this = this,
      _errors$promocode;

  if (!props.entry.isLoged) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_redirect_redirect__WEBPACK_IMPORTED_MODULE_21__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 23,
      columnNumber: 12
    }, this);
  }

  var _useForm = Object(react_hook_form__WEBPACK_IMPORTED_MODULE_8__["useForm"])(),
      register = _useForm.register,
      handleSubmit = _useForm.handleSubmit,
      errors = _useForm.errors,
      setError = _useForm.setError;

  var _useIntl = Object(react_intl__WEBPACK_IMPORTED_MODULE_9__["useIntl"])(),
      f = _useIntl.formatMessage;

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])([]),
      packages = _useState[0],
      setPackages = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])([]),
      filteredPacks = _useState2[0],
      setFilteredPacks = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])([]),
      status = _useState3[0],
      setStatus = _useState3[1];

  var _useState4 = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])({
    packages: [],
    total: 0,
    discountTotal: 0,
    code: "",
    isAccepted: false,
    status: 0
  }),
      selectedPackages = _useState4[0],
      setSelectedPackages = _useState4[1];

  var _useRouter = Object(next_router__WEBPACK_IMPORTED_MODULE_6__["useRouter"])(),
      locale = _useRouter.locale;

  var mainCheckRef = Object(react__WEBPACK_IMPORTED_MODULE_7__["useRef"])();
  var checkRefs = Object(react__WEBPACK_IMPORTED_MODULE_7__["useRef"])([]);
  checkRefs.current = [];
  var tabRefs = Object(react__WEBPACK_IMPORTED_MODULE_7__["useRef"])([]);
  tabRefs.current = [];

  var submit = function submit(data) {
    console.log(data);
    axios__WEBPACK_IMPORTED_MODULE_5___default.a.post("".concat("https://166api.titr.az/api/", "promocode?promocode=").concat(data.promocode, "&status=").concat(selectedPackages.status), {}, {
      headers: {
        "content-type": "application/json",
        authorization: "Bearer ".concat(props.entry.user.accessToken)
      }
    }).then(function (res) {
      console.log(res.data.batches);
      setPackages(res.data.batches);
      setFilteredPacks(res.data.batches);
    })["catch"](function (err) {
      setError("promocode", {
        message: err.response.data.error
      });
    });
  };

  var PromisAll = /*#__PURE__*/function () {
    var _ref = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_4__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.mark(function _callee() {
      var batchesData, statusData;
      return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return axios__WEBPACK_IMPORTED_MODULE_5___default.a.get("".concat("https://166api.titr.az/api/", "batches?lan=").concat(locale), {
                headers: {
                  authorization: "Bearer ".concat(props.entry.user.accessToken)
                }
              });

            case 2:
              batchesData = _context.sent;
              _context.next = 5;
              return axios__WEBPACK_IMPORTED_MODULE_5___default.a.get("".concat("https://166api.titr.az/api/", "status?lan=").concat(locale), {
                headers: {
                  authorization: "Bearer ".concat(props.entry.user.accessToken)
                }
              });

            case 5:
              statusData = _context.sent;
              return _context.abrupt("return", {
                batchesData: batchesData.data,
                statusData: statusData.data
              });

            case 7:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function PromisAll() {
      return _ref.apply(this, arguments);
    };
  }();

  Object(react__WEBPACK_IMPORTED_MODULE_7__["useLayoutEffect"])(function () {
    PromisAll().then(function (res) {
      setPackages(res.batchesData);
      setFilteredPacks(res.batchesData);
      setStatus(res.statusData);
    })["catch"](function (err) {
      return console.log(err);
    });
  }, []);

  var addTabRefs = function addTabRefs(ref) {
    if (ref && !tabRefs.current.includes(ref)) {
      tabRefs.current.push(ref);
    }
  };

  var toggleTabRefs = /*#__PURE__*/function () {
    var _ref2 = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_4__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.mark(function _callee2(ev) {
      return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              tabRefs.current.forEach(function (x) {
                return x.classList.remove("pack-active");
              });
              ev.target.classList.add("pack-active");

            case 2:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2);
    }));

    return function toggleTabRefs(_x) {
      return _ref2.apply(this, arguments);
    };
  }();

  var getBatchesByStatausId = /*#__PURE__*/function () {
    var _ref3 = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_4__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.mark(function _callee3(id) {
      return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.wrap(function _callee3$(_context3) {
        while (1) {
          switch (_context3.prev = _context3.next) {
            case 0:
              axios__WEBPACK_IMPORTED_MODULE_5___default.a.get("".concat("https://166api.titr.az/api/", "batches?status=").concat(id, "&lan=").concat(locale), {
                headers: {
                  authorization: "Bearer ".concat(props.entry.user.accessToken)
                }
              }).then(function (res) {
                setPackages(res.data);
                setFilteredPacks(res.data);
              })["catch"](function (err) {
                return console.log(err);
              });

            case 1:
            case "end":
              return _context3.stop();
          }
        }
      }, _callee3);
    }));

    return function getBatchesByStatausId(_x2) {
      return _ref3.apply(this, arguments);
    };
  }();

  var tabButtonClick = function tabButtonClick(ev) {
    var id = ev.target.getAttribute("data-id");
    toggleTabRefs(ev);
    getBatchesByStatausId(id);

    if (id != 0) {
      var newPackages = packages.filter(function (x) {
        return x.status.id == id;
      });
      setFilteredPacks(Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(newPackages));
    } else {
      setFilteredPacks(Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(packages));
    }

    setSelectedPackages({
      discountTotal: 0,
      packages: [],
      total: 0,
      code: "",
      isAccepted: false,
      status: id
    });
  };

  var addCheckRefs = function addCheckRefs(ref) {
    if (ref && !checkRefs.current.includes(ref)) {
      checkRefs.current.push(ref);
    }
  };

  var checkHandler = function checkHandler(ev) {
    var _ev$target = ev.target,
        value = _ev$target.value,
        checked = _ev$target.checked;
    var price = ev.target.getAttribute("data-price");
    var dataDiscount = ev.target.getAttribute("data-discount");
    var total = 0;
    var disc = 0;
    console.log('dis', dataDiscount);

    if (checked) {
      selectedPackages.packages.push(value);

      if (dataDiscount != 0) {
        setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
          total: selectedPackages.total + parseFloat(price),
          discountTotal: selectedPackages.discountTotal + parseFloat(dataDiscount),
          packages: Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(selectedPackages.packages)
        }));
      } else {
        setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
          discountTotal: selectedPackages.discountTotal + parseFloat(price),
          total: selectedPackages.total + parseFloat(price),
          packages: Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(selectedPackages.packages)
        }));
      }
    } else {
      var newPackages = selectedPackages.packages.filter(function (x) {
        return x !== value;
      });

      if (dataDiscount != 0) {
        setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
          total: selectedPackages.total >= 0 && selectedPackages.total - parseFloat(price),
          discountTotal: selectedPackages.discountTotal >= 0 && selectedPackages.discountTotal - parseFloat(dataDiscount),
          packages: newPackages
        }));
      } else {
        setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
          discountTotal: selectedPackages.discountTotal >= 0 && selectedPackages.discountTotal - parseFloat(price),
          total: selectedPackages.total >= 0 && selectedPackages.total - parseFloat(price),
          packages: newPackages
        }));
      }
    }

    !selectedPackages.packages.some(function (x) {
      return x;
    }) ? mainCheckRef.current.checked = false : null;
  };

  var selectAll = function selectAll(e) {
    var total = 0;
    var discountTotal = 0;
    var packages = [];
    checkRefs.current.forEach(function (x) {
      x.checked = e.target.checked;

      if (e.target.checked && !packages.includes(x.value)) {
        packages.push(x.value);
        total += +x.getAttribute("data-price");
        discountTotal += +x.getAttribute("data-discount");
      } else {
        packages = packages.filter(function (p) {
          return p !== x.value;
        });
        total -= total >= 0 && +x.getAttribute("data-price");
        discountTotal -= discountTotal >= 0 && +x.getAttribute("data-discount");
      }
    });
    setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
      total: selectedPackages.total - total,
      packages: packages
    }));
  };

  var PaybyCard = function PaybyCard() {
    var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    axios__WEBPACK_IMPORTED_MODULE_5___default.a.post("".concat("https://166api.titr.az/api/", "payment"), data, {
      headers: {
        authorization: "Bearer ".concat(props.entry.user.accessToken)
      }
    }).then(function (res) {
      console.log('red', res.data.url);
      window.location.href = res.data.url;
    })["catch"](function (err) {
      return console.log(err);
    });
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_page_page__WEBPACK_IMPORTED_MODULE_20__["default"], {
    className: "bg-bg pt-lg pb-lg",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_aside_aside__WEBPACK_IMPORTED_MODULE_12__["default"], {
      className: "mr-sm",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_aside_menu_index__WEBPACK_IMPORTED_MODULE_11__["default"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 243,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 242,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_main_main__WEBPACK_IMPORTED_MODULE_18__["default"], {
      className: "bg-c p-none",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"], {
        className: "bg-bg pb-sm mgm_ss p-sm",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"].Header, {
          text: f({
            id: "active-pac"
          }),
          endElelment: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_checkbox_checkbox__WEBPACK_IMPORTED_MODULE_15__["default"], {
            text: f({
              id: "choose-all"
            }),
            Ref: function Ref(ref) {
              return mainCheckRef.current = ref;
            },
            onClick: selectAll,
            className: "bg-white border-subtitle"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 250,
            columnNumber: 15
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 247,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          "class": "ssc",
          style: {
            overflowX: "scroll"
          },
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: " pl-none",
            style: {
              display: "flex",
              marginBottom: "20px",
              width: "max-content"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
              label: "Hams\u0131 (".concat(packages.length, ")"),
              className: "mr-xs p-xs bg-bg pack-active",
              "data-id": 0,
              Ref: addTabRefs,
              onClick: tabButtonClick
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 268,
              columnNumber: 15
            }, this), status.map(function (x) {
              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                label: "".concat(x.name, " (").concat(x.count, ")"),
                className: " p-xs bg-bg ",
                "data-id": x.id,
                Ref: addTabRefs,
                onClick: tabButtonClick
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 277,
                columnNumber: 17
              }, _this);
            })]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 259,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 258,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"].Body, {
          className: "p-none",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "packages__fr",
            children: filteredPacks.filter(function (x) {
              return x.status.id !== 6;
            }).map(function (p) {
              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_package_item_package_item__WEBPACK_IMPORTED_MODULE_19__["default"], {
                checkRef: addCheckRefs,
                item: p,
                onCheck: checkHandler
              }, p.id, false, {
                fileName: _jsxFileName,
                lineNumber: 294,
                columnNumber: 19
              }, _this);
            })
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 290,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 289,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "footer__pck",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "package-total",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
              children: [selectedPackages.packages.length, " ", f({
                id: "chosed"
              })]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 305,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                display: "flex",
                justifyContent: "space-between"
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                children: [f({
                  id: "total"
                }), ":"]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 309,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                style: {
                  display: "flex",
                  flexDirection: "column"
                },
                children: selectedPackages.discountTotal > 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
                    style: {
                      textDecorationColor: "red"
                    },
                    children: [parseFloat(selectedPackages.total).toFixed(2), " AZN"]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 314,
                    columnNumber: 19
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                    children: [parseFloat(selectedPackages.discountTotal).toFixed(2), " AZN"]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 315,
                    columnNumber: 20
                  }, this)]
                }, void 0, true) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                  children: [parseFloat(selectedPackages.discountTotal).toFixed(2), " AZN"]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 317,
                  columnNumber: 23
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 310,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 308,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 304,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "package__btns",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("form", {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_form_group_form_group__WEBPACK_IMPORTED_MODULE_16__["default"], {
                bodyClass: "bg-white pl-xs",
                bodyStyle: {
                  height: "44px",
                  width: "200px"
                },
                className: "mr-xs chng__bodystyle",
                style: {
                  marginBottom: "0px"
                },
                error: (_errors$promocode = errors.promocode) === null || _errors$promocode === void 0 ? void 0 : _errors$promocode.message,
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_input_input__WEBPACK_IMPORTED_MODULE_17__["default"], {
                  placeholder: f({
                    id: "addcode"
                  }),
                  name: "promocode",
                  Ref: register({
                    required: {
                      value: true,
                      message: f({
                        id: "promo-requir"
                      })
                    }
                  }),
                  onChange: function onChange(e) {
                    return setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
                      code: e.target.value
                    }));
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 333,
                  columnNumber: 19
                }, this), selectedPackages.isAccepted ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                  className: "bg-white w-50",
                  style: {
                    textDecorationLine: "underline",
                    color: "darkblue",
                    padding: "0px 10px"
                  },
                  label: "L\u0259\u011Fv et",
                  onClick: function onClick() {
                    setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
                      isAccepted: false
                    }));
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 350,
                  columnNumber: 21
                }, this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                  disabled: !selectedPackages.code ? true : false,
                  style: {
                    padding: "0 10px"
                  },
                  className: "color-white bg-success",
                  label: f({
                    id: "confirm"
                  }),
                  type: "submit",
                  onClick: handleSubmit(submit) //  onClick={() =>{
                  //     //  setSelectedPackages({
                  //     //    ...selectedPackages,
                  //     //    isAccepted:true
                  //     //  });
                  //    }}

                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 366,
                  columnNumber: 21
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 326,
                columnNumber: 17
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 325,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
              style: {
                padding: "0 20px"
              },
              className: "color-white bg-success mr-xs desk",
              label: f({
                id: "paybycard"
              }),
              endElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                className: "color-white pl-sm",
                children: "\u2192"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 388,
                columnNumber: 29
              }, this),
              onClick: function onClick() {
                return PaybyCard({
                  price: selectedPackages.discountTotal,
                  sourcetype: 2,
                  batches: selectedPackages.packages
                });
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 384,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
              style: {
                padding: "0 10px"
              },
              className: "desk",
              label: f({
                id: "paybybalance"
              }),
              endElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                className: "color-black mr-xs pl-sm ",
                children: "\u2192"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 400,
                columnNumber: 19
              }, this),
              onClick: function onClick() {
                return props.PayByBalanceAction('payment', {
                  price: selectedPackages.discountTotal,
                  sourcetype: 3,
                  batches: selectedPackages.packages
                }, {
                  'authorization': "Bearer ".concat(props.entry.user.accessToken)
                });
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 395,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "btn__fkl",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                style: {
                  padding: "0 10px"
                },
                className: "color-white bg-success mr-xs",
                label: f({
                  id: "paybycard"
                }),
                endElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "color-white pl-sm",
                  children: "\u2192"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 418,
                  columnNumber: 21
                }, this),
                onClick: function onClick() {
                  return PaybyCard({
                    price: selectedPackages.discountTotal,
                    sourcetype: 2,
                    batches: selectedPackages.packages
                  });
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 413,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                style: {
                  padding: "0 10px"
                },
                label: f({
                  id: "paybybalance"
                }),
                endElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "color-black mr-xs pl-sm",
                  children: "\u2192"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 430,
                  columnNumber: 21
                }, this),
                onClick: function onClick() {
                  return props.PayByBalanceAction('payment', {
                    price: selectedPackages.discountTotal,
                    sourcetype: 3,
                    batches: selectedPackages.packages
                  }, {
                    'authorization': "Bearer ".concat(props.entry.user.accessToken)
                  });
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 426,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 412,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 324,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 303,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 246,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"], {
        className: "p-sm bg-white",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"].Header, {
          text: f({
            id: "order-history"
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 447,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"].Body, {
          className: "p-none overflow__package",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_tabel_tabel__WEBPACK_IMPORTED_MODULE_22__["default"], {
            th: [f({
              id: "tracking"
            }), f({
              id: "shop"
            }), f({
              id: "category"
            }), f({
              id: "amount"
            }), f({
              id: "weight"
            }), f({
              id: "delivery"
            }), f({
              id: "status"
            })],
            data: packages.map(function (x) {
              if (x.status.id == 6) {
                return {
                  track_number: x.track_number,
                  shop: x.shop,
                  category: x.category,
                  price: "".concat(x.price, " ").concat(x.currency),
                  weight: "".concat(parseFloat(x.weight).toFixed(2) || 0, " kq"),
                  delivery_price: parseFloat(x.delivery_price).toFixed(2) || 0,
                  status: "".concat(x.status.name, "\n ").concat(x.date)
                };
              }
            }) || [],
            renderBody: function renderBody(x, i) {
              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {
                children: x
              }, i++, false, {
                fileName: _jsxFileName,
                lineNumber: 476,
                columnNumber: 24
              }, _this);
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 449,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 448,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 446,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 245,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 241,
    columnNumber: 5
  }, this);
}

_s(Packages, "3E201Kyf6S2uVJ0+DS1LdJkJE1g=", false, function () {
  return [react_hook_form__WEBPACK_IMPORTED_MODULE_8__["useForm"], react_intl__WEBPACK_IMPORTED_MODULE_9__["useIntl"], next_router__WEBPACK_IMPORTED_MODULE_6__["useRouter"]];
});

_c = Packages;

var mapStateToProps = function mapStateToProps(state) {
  return {
    entry: state.entry
  };
};

var mapDispatchToProps = {
  PayByBalanceAction: _redux_entry_entryActions__WEBPACK_IMPORTED_MODULE_23__["PayByBalanceAction"]
};
/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_10__["connect"])(mapStateToProps, mapDispatchToProps)( /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_7__["memo"])(Packages)));

var _c;

$RefreshReg$(_c, "Packages");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvcGFja2FnZXMuanMiXSwibmFtZXMiOlsiUGFja2FnZXMiLCJwcm9wcyIsImVudHJ5IiwiaXNMb2dlZCIsInVzZUZvcm0iLCJyZWdpc3RlciIsImhhbmRsZVN1Ym1pdCIsImVycm9ycyIsInNldEVycm9yIiwidXNlSW50bCIsImYiLCJmb3JtYXRNZXNzYWdlIiwidXNlU3RhdGUiLCJwYWNrYWdlcyIsInNldFBhY2thZ2VzIiwiZmlsdGVyZWRQYWNrcyIsInNldEZpbHRlcmVkUGFja3MiLCJzdGF0dXMiLCJzZXRTdGF0dXMiLCJ0b3RhbCIsImRpc2NvdW50VG90YWwiLCJjb2RlIiwiaXNBY2NlcHRlZCIsInNlbGVjdGVkUGFja2FnZXMiLCJzZXRTZWxlY3RlZFBhY2thZ2VzIiwidXNlUm91dGVyIiwibG9jYWxlIiwibWFpbkNoZWNrUmVmIiwidXNlUmVmIiwiY2hlY2tSZWZzIiwiY3VycmVudCIsInRhYlJlZnMiLCJzdWJtaXQiLCJkYXRhIiwiY29uc29sZSIsImxvZyIsImF4aW9zIiwicG9zdCIsInByb2Nlc3MiLCJwcm9tb2NvZGUiLCJoZWFkZXJzIiwiYXV0aG9yaXphdGlvbiIsInVzZXIiLCJhY2Nlc3NUb2tlbiIsInRoZW4iLCJyZXMiLCJiYXRjaGVzIiwiZXJyIiwibWVzc2FnZSIsInJlc3BvbnNlIiwiZXJyb3IiLCJQcm9taXNBbGwiLCJnZXQiLCJiYXRjaGVzRGF0YSIsInN0YXR1c0RhdGEiLCJ1c2VMYXlvdXRFZmZlY3QiLCJhZGRUYWJSZWZzIiwicmVmIiwiaW5jbHVkZXMiLCJwdXNoIiwidG9nZ2xlVGFiUmVmcyIsImV2IiwiZm9yRWFjaCIsIngiLCJjbGFzc0xpc3QiLCJyZW1vdmUiLCJ0YXJnZXQiLCJhZGQiLCJnZXRCYXRjaGVzQnlTdGF0YXVzSWQiLCJpZCIsInRhYkJ1dHRvbkNsaWNrIiwiZ2V0QXR0cmlidXRlIiwibmV3UGFja2FnZXMiLCJmaWx0ZXIiLCJhZGRDaGVja1JlZnMiLCJjaGVja0hhbmRsZXIiLCJ2YWx1ZSIsImNoZWNrZWQiLCJwcmljZSIsImRhdGFEaXNjb3VudCIsImRpc2MiLCJwYXJzZUZsb2F0Iiwic29tZSIsInNlbGVjdEFsbCIsImUiLCJwIiwiUGF5YnlDYXJkIiwidXJsIiwid2luZG93IiwibG9jYXRpb24iLCJocmVmIiwib3ZlcmZsb3dYIiwiZGlzcGxheSIsIm1hcmdpbkJvdHRvbSIsIndpZHRoIiwibGVuZ3RoIiwibWFwIiwibmFtZSIsImNvdW50IiwianVzdGlmeUNvbnRlbnQiLCJmbGV4RGlyZWN0aW9uIiwidGV4dERlY29yYXRpb25Db2xvciIsInRvRml4ZWQiLCJoZWlnaHQiLCJyZXF1aXJlZCIsInRleHREZWNvcmF0aW9uTGluZSIsImNvbG9yIiwicGFkZGluZyIsInNvdXJjZXR5cGUiLCJQYXlCeUJhbGFuY2VBY3Rpb24iLCJ0cmFja19udW1iZXIiLCJzaG9wIiwiY2F0ZWdvcnkiLCJjdXJyZW5jeSIsIndlaWdodCIsImRlbGl2ZXJ5X3ByaWNlIiwiZGF0ZSIsImkiLCJtYXBTdGF0ZVRvUHJvcHMiLCJzdGF0ZSIsIm1hcERpc3BhdGNoVG9Qcm9wcyIsImNvbm5lY3QiLCJtZW1vIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxTQUFTQSxRQUFULENBQWtCQyxLQUFsQixFQUF5QjtBQUFBOztBQUFBO0FBQUE7O0FBQ3ZCLE1BQUksQ0FBQ0EsS0FBSyxDQUFDQyxLQUFOLENBQVlDLE9BQWpCLEVBQTBCO0FBQ3hCLHdCQUFPLHFFQUFDLHNFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFBUDtBQUNEOztBQUhzQixpQkFLOEJDLCtEQUFPLEVBTHJDO0FBQUEsTUFLZkMsUUFMZSxZQUtmQSxRQUxlO0FBQUEsTUFLTEMsWUFMSyxZQUtMQSxZQUxLO0FBQUEsTUFLU0MsTUFMVCxZQUtTQSxNQUxUO0FBQUEsTUFLaUJDLFFBTGpCLFlBS2lCQSxRQUxqQjs7QUFBQSxpQkFNTUMsMERBQU8sRUFOYjtBQUFBLE1BTUFDLENBTkEsWUFNZkMsYUFOZTs7QUFBQSxrQkFPU0Msc0RBQVEsQ0FBQyxFQUFELENBUGpCO0FBQUEsTUFPaEJDLFFBUGdCO0FBQUEsTUFPTkMsV0FQTTs7QUFBQSxtQkFRbUJGLHNEQUFRLENBQUMsRUFBRCxDQVIzQjtBQUFBLE1BUWhCRyxhQVJnQjtBQUFBLE1BUURDLGdCQVJDOztBQUFBLG1CQVNLSixzREFBUSxDQUFDLEVBQUQsQ0FUYjtBQUFBLE1BU2hCSyxNQVRnQjtBQUFBLE1BU1JDLFNBVFE7O0FBQUEsbUJBVXlCTixzREFBUSxDQUFDO0FBQ3ZEQyxZQUFRLEVBQUUsRUFENkM7QUFFdkRNLFNBQUssRUFBRSxDQUZnRDtBQUd2REMsaUJBQWEsRUFBQyxDQUh5QztBQUl2REMsUUFBSSxFQUFFLEVBSmlEO0FBS3ZEQyxjQUFVLEVBQUUsS0FMMkM7QUFNdkRMLFVBQU0sRUFBRTtBQU4rQyxHQUFELENBVmpDO0FBQUEsTUFVaEJNLGdCQVZnQjtBQUFBLE1BVUVDLG1CQVZGOztBQUFBLG1CQW1CSkMsNkRBQVMsRUFuQkw7QUFBQSxNQW1CZkMsTUFuQmUsY0FtQmZBLE1BbkJlOztBQW9CdkIsTUFBTUMsWUFBWSxHQUFHQyxvREFBTSxFQUEzQjtBQUNBLE1BQU1DLFNBQVMsR0FBR0Qsb0RBQU0sQ0FBQyxFQUFELENBQXhCO0FBQ0FDLFdBQVMsQ0FBQ0MsT0FBVixHQUFvQixFQUFwQjtBQUNBLE1BQU1DLE9BQU8sR0FBR0gsb0RBQU0sQ0FBQyxFQUFELENBQXRCO0FBQ0FHLFNBQU8sQ0FBQ0QsT0FBUixHQUFrQixFQUFsQjs7QUFFQSxNQUFNRSxNQUFNLEdBQUcsU0FBVEEsTUFBUyxDQUFDQyxJQUFELEVBQVU7QUFDdkJDLFdBQU8sQ0FBQ0MsR0FBUixDQUFZRixJQUFaO0FBRUFHLGdEQUFLLENBQ0ZDLElBREgsV0FFT0MsNkJBRlAsaUNBRTZETCxJQUFJLENBQUNNLFNBRmxFLHFCQUVzRmhCLGdCQUFnQixDQUFDTixNQUZ2RyxHQUdJLEVBSEosRUFJSTtBQUNFdUIsYUFBTyxFQUFFO0FBQ1Asd0JBQWdCLGtCQURUO0FBRVBDLHFCQUFhLG1CQUFZeEMsS0FBSyxDQUFDQyxLQUFOLENBQVl3QyxJQUFaLENBQWlCQyxXQUE3QjtBQUZOO0FBRFgsS0FKSixFQVdHQyxJQVhILENBV1EsVUFBQ0MsR0FBRCxFQUFTO0FBQ2JYLGFBQU8sQ0FBQ0MsR0FBUixDQUFZVSxHQUFHLENBQUNaLElBQUosQ0FBU2EsT0FBckI7QUFDQWhDLGlCQUFXLENBQUMrQixHQUFHLENBQUNaLElBQUosQ0FBU2EsT0FBVixDQUFYO0FBQ0E5QixzQkFBZ0IsQ0FBQzZCLEdBQUcsQ0FBQ1osSUFBSixDQUFTYSxPQUFWLENBQWhCO0FBQ0QsS0FmSCxXQWdCUyxVQUFDQyxHQUFELEVBQVM7QUFDZHZDLGNBQVEsQ0FBQyxXQUFELEVBQWM7QUFBRXdDLGVBQU8sRUFBRUQsR0FBRyxDQUFDRSxRQUFKLENBQWFoQixJQUFiLENBQWtCaUI7QUFBN0IsT0FBZCxDQUFSO0FBQ0QsS0FsQkg7QUFtQkQsR0F0QkQ7O0FBd0JBLE1BQU1DLFNBQVM7QUFBQSxrVUFBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUNRZiw0Q0FBSyxDQUFDZ0IsR0FBTixXQUFhZCw2QkFBYix5QkFBMkRaLE1BQTNELEdBQXFFO0FBQzNGYyx1QkFBTyxFQUFFO0FBQ1BDLCtCQUFhLG1CQUFZeEMsS0FBSyxDQUFDQyxLQUFOLENBQVl3QyxJQUFaLENBQWlCQyxXQUE3QjtBQUROO0FBRGtGLGVBQXJFLENBRFI7O0FBQUE7QUFDWlUseUJBRFk7QUFBQTtBQUFBLHFCQU1PakIsNENBQUssQ0FBQ2dCLEdBQU4sV0FBYWQsNkJBQWIsd0JBQTBEWixNQUExRCxHQUFvRTtBQUN6RmMsdUJBQU8sRUFBRTtBQUNQQywrQkFBYSxtQkFBWXhDLEtBQUssQ0FBQ0MsS0FBTixDQUFZd0MsSUFBWixDQUFpQkMsV0FBN0I7QUFETjtBQURnRixlQUFwRSxDQU5QOztBQUFBO0FBTVpXLHdCQU5ZO0FBQUEsK0NBWVQ7QUFDTEQsMkJBQVcsRUFBQ0EsV0FBVyxDQUFDcEIsSUFEbkI7QUFFTHFCLDBCQUFVLEVBQUNBLFVBQVUsQ0FBQ3JCO0FBRmpCLGVBWlM7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FBSDs7QUFBQSxvQkFBVGtCLFNBQVM7QUFBQTtBQUFBO0FBQUEsS0FBZjs7QUFpQkFJLCtEQUFlLENBQUMsWUFBTTtBQUNwQkosYUFBUyxHQUFHUCxJQUFaLENBQWlCLFVBQUFDLEdBQUcsRUFBSTtBQUN0Qi9CLGlCQUFXLENBQUMrQixHQUFHLENBQUNRLFdBQUwsQ0FBWDtBQUNBckMsc0JBQWdCLENBQUM2QixHQUFHLENBQUNRLFdBQUwsQ0FBaEI7QUFDQW5DLGVBQVMsQ0FBQzJCLEdBQUcsQ0FBQ1MsVUFBTCxDQUFUO0FBQ0QsS0FKRCxXQUlTLFVBQUFQLEdBQUc7QUFBQSxhQUFJYixPQUFPLENBQUNDLEdBQVIsQ0FBWVksR0FBWixDQUFKO0FBQUEsS0FKWjtBQU1ELEdBUGMsRUFPWixFQVBZLENBQWY7O0FBU0EsTUFBTVMsVUFBVSxHQUFHLFNBQWJBLFVBQWEsQ0FBQ0MsR0FBRCxFQUFTO0FBQzFCLFFBQUlBLEdBQUcsSUFBSSxDQUFDMUIsT0FBTyxDQUFDRCxPQUFSLENBQWdCNEIsUUFBaEIsQ0FBeUJELEdBQXpCLENBQVosRUFBMkM7QUFDekMxQixhQUFPLENBQUNELE9BQVIsQ0FBZ0I2QixJQUFoQixDQUFxQkYsR0FBckI7QUFDRDtBQUNGLEdBSkQ7O0FBTUEsTUFBTUcsYUFBYTtBQUFBLG1VQUFHLGtCQUFPQyxFQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDcEI5QixxQkFBTyxDQUFDRCxPQUFSLENBQWdCZ0MsT0FBaEIsQ0FBd0IsVUFBQ0MsQ0FBRDtBQUFBLHVCQUFPQSxDQUFDLENBQUNDLFNBQUYsQ0FBWUMsTUFBWixDQUFtQixhQUFuQixDQUFQO0FBQUEsZUFBeEI7QUFDQUosZ0JBQUUsQ0FBQ0ssTUFBSCxDQUFVRixTQUFWLENBQW9CRyxHQUFwQixDQUF3QixhQUF4Qjs7QUFGb0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FBSDs7QUFBQSxvQkFBYlAsYUFBYTtBQUFBO0FBQUE7QUFBQSxLQUFuQjs7QUFLQSxNQUFNUSxxQkFBcUI7QUFBQSxtVUFBRyxrQkFBT0MsRUFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzNCakMsMERBQUssQ0FBQ2dCLEdBQU4sV0FBYWQsNkJBQWIsNEJBQThEK0IsRUFBOUQsa0JBQXdFM0MsTUFBeEUsR0FBa0Y7QUFDakZjLHVCQUFPLEVBQUU7QUFDUEMsK0JBQWEsbUJBQVl4QyxLQUFLLENBQUNDLEtBQU4sQ0FBWXdDLElBQVosQ0FBaUJDLFdBQTdCO0FBRE47QUFEd0UsZUFBbEYsRUFJRUMsSUFKRixDQUlPLFVBQUNDLEdBQUQsRUFBUztBQUNmL0IsMkJBQVcsQ0FBQytCLEdBQUcsQ0FBQ1osSUFBTCxDQUFYO0FBQ0FqQixnQ0FBZ0IsQ0FBQzZCLEdBQUcsQ0FBQ1osSUFBTCxDQUFoQjtBQUNELGVBUEEsV0FPUSxVQUFBYyxHQUFHO0FBQUEsdUJBQUliLE9BQU8sQ0FBQ0MsR0FBUixDQUFZWSxHQUFaLENBQUo7QUFBQSxlQVBYOztBQUQyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFIOztBQUFBLG9CQUFyQnFCLHFCQUFxQjtBQUFBO0FBQUE7QUFBQSxLQUEzQjs7QUFhQSxNQUFNRSxjQUFjLEdBQUcsU0FBakJBLGNBQWlCLENBQUNULEVBQUQsRUFBUTtBQUM3QixRQUFJUSxFQUFFLEdBQUdSLEVBQUUsQ0FBQ0ssTUFBSCxDQUFVSyxZQUFWLENBQXVCLFNBQXZCLENBQVQ7QUFDQVgsaUJBQWEsQ0FBQ0MsRUFBRCxDQUFiO0FBQ0FPLHlCQUFxQixDQUFDQyxFQUFELENBQXJCOztBQUNBLFFBQUlBLEVBQUUsSUFBSSxDQUFWLEVBQWE7QUFDWCxVQUFJRyxXQUFXLEdBQUczRCxRQUFRLENBQUM0RCxNQUFULENBQWdCLFVBQUNWLENBQUQ7QUFBQSxlQUFPQSxDQUFDLENBQUM5QyxNQUFGLENBQVNvRCxFQUFULElBQWVBLEVBQXRCO0FBQUEsT0FBaEIsQ0FBbEI7QUFDQXJELHNCQUFnQixDQUFDLDhKQUFJd0QsV0FBTCxFQUFoQjtBQUNELEtBSEQsTUFHTztBQUNMeEQsc0JBQWdCLENBQUMsOEpBQUlILFFBQUwsRUFBaEI7QUFDRDs7QUFFRFcsdUJBQW1CLENBQUM7QUFDbEJKLG1CQUFhLEVBQUUsQ0FERztBQUVsQlAsY0FBUSxFQUFFLEVBRlE7QUFHbEJNLFdBQUssRUFBRSxDQUhXO0FBSWxCRSxVQUFJLEVBQUUsRUFKWTtBQUtsQkMsZ0JBQVUsRUFBRSxLQUxNO0FBTWxCTCxZQUFNLEVBQUVvRDtBQU5VLEtBQUQsQ0FBbkI7QUFRRCxHQW5CRDs7QUFxQkEsTUFBTUssWUFBWSxHQUFHLFNBQWZBLFlBQWUsQ0FBQ2pCLEdBQUQsRUFBUztBQUM1QixRQUFJQSxHQUFHLElBQUksQ0FBQzVCLFNBQVMsQ0FBQ0MsT0FBVixDQUFrQjRCLFFBQWxCLENBQTJCRCxHQUEzQixDQUFaLEVBQTZDO0FBQzNDNUIsZUFBUyxDQUFDQyxPQUFWLENBQWtCNkIsSUFBbEIsQ0FBdUJGLEdBQXZCO0FBQ0Q7QUFDRixHQUpEOztBQU1BLE1BQU1rQixZQUFZLEdBQUcsU0FBZkEsWUFBZSxDQUFDZCxFQUFELEVBQVE7QUFBQSxxQkFDRkEsRUFBRSxDQUFDSyxNQUREO0FBQUEsUUFDckJVLEtBRHFCLGNBQ3JCQSxLQURxQjtBQUFBLFFBQ2RDLE9BRGMsY0FDZEEsT0FEYztBQUUzQixRQUFJQyxLQUFLLEdBQUdqQixFQUFFLENBQUNLLE1BQUgsQ0FBVUssWUFBVixDQUF1QixZQUF2QixDQUFaO0FBQ0EsUUFBSVEsWUFBWSxHQUFHbEIsRUFBRSxDQUFDSyxNQUFILENBQVVLLFlBQVYsQ0FBdUIsZUFBdkIsQ0FBbkI7QUFDQSxRQUFJcEQsS0FBSyxHQUFDLENBQVY7QUFDQSxRQUFJNkQsSUFBSSxHQUFDLENBQVQ7QUFDQTlDLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQVosRUFBa0I0QyxZQUFsQjs7QUFDQSxRQUFJRixPQUFKLEVBQWE7QUFDWHRELHNCQUFnQixDQUFDVixRQUFqQixDQUEwQjhDLElBQTFCLENBQStCaUIsS0FBL0I7O0FBQ0EsVUFBR0csWUFBWSxJQUFFLENBQWpCLEVBQW1CO0FBQ2pCdkQsMkJBQW1CLGlDQUNkRCxnQkFEYztBQUdqQkosZUFBSyxFQUFHSSxnQkFBZ0IsQ0FBQ0osS0FBakIsR0FBdUI4RCxVQUFVLENBQUNILEtBQUQsQ0FIeEI7QUFLakIxRCx1QkFBYSxFQUFHRyxnQkFBZ0IsQ0FBQ0gsYUFBakIsR0FBK0I2RCxVQUFVLENBQUNGLFlBQUQsQ0FMeEM7QUFNakJsRSxrQkFBUSxFQUFFLDhKQUFJVSxnQkFBZ0IsQ0FBQ1YsUUFBdkI7QUFOUyxXQUFuQjtBQVNELE9BVkQsTUFVSztBQUNIVywyQkFBbUIsaUNBQ2RELGdCQURjO0FBRWpCSCx1QkFBYSxFQUFHRyxnQkFBZ0IsQ0FBQ0gsYUFBakIsR0FBK0I2RCxVQUFVLENBQUNILEtBQUQsQ0FGeEM7QUFHakIzRCxlQUFLLEVBQUdJLGdCQUFnQixDQUFDSixLQUFqQixHQUF1QjhELFVBQVUsQ0FBQ0gsS0FBRCxDQUh4QjtBQUlqQmpFLGtCQUFRLEVBQUUsOEpBQUlVLGdCQUFnQixDQUFDVixRQUF2QjtBQUpTLFdBQW5CO0FBTUQ7QUFFRixLQXJCRCxNQXFCTztBQUNMLFVBQUkyRCxXQUFXLEdBQUdqRCxnQkFBZ0IsQ0FBQ1YsUUFBakIsQ0FBMEI0RCxNQUExQixDQUFpQyxVQUFDVixDQUFEO0FBQUEsZUFBT0EsQ0FBQyxLQUFLYSxLQUFiO0FBQUEsT0FBakMsQ0FBbEI7O0FBQ0EsVUFBR0csWUFBWSxJQUFFLENBQWpCLEVBQW1CO0FBQ2pCdkQsMkJBQW1CLGlDQUVkRCxnQkFGYztBQUlqQkosZUFBSyxFQUFFSSxnQkFBZ0IsQ0FBQ0osS0FBakIsSUFBeUIsQ0FBekIsSUFBK0JJLGdCQUFnQixDQUFDSixLQUFqQixHQUF1QjhELFVBQVUsQ0FBQ0gsS0FBRCxDQUp0RDtBQU1qQjFELHVCQUFhLEVBQUVHLGdCQUFnQixDQUFDSCxhQUFqQixJQUFpQyxDQUFqQyxJQUF3Q0csZ0JBQWdCLENBQUNILGFBQWpCLEdBQStCNkQsVUFBVSxDQUFDRixZQUFELENBTi9FO0FBT2pCbEUsa0JBQVEsRUFBRTJEO0FBUE8sV0FBbkI7QUFVRCxPQVhELE1BV0s7QUFDSGhELDJCQUFtQixpQ0FDZEQsZ0JBRGM7QUFFakJILHVCQUFhLEVBQUNHLGdCQUFnQixDQUFDSCxhQUFqQixJQUFpQyxDQUFqQyxJQUF1Q0csZ0JBQWdCLENBQUNILGFBQWpCLEdBQStCNkQsVUFBVSxDQUFDSCxLQUFELENBRjdFO0FBR2pCM0QsZUFBSyxFQUFDSSxnQkFBZ0IsQ0FBQ0osS0FBakIsSUFBeUIsQ0FBekIsSUFBK0JJLGdCQUFnQixDQUFDSixLQUFqQixHQUF1QjhELFVBQVUsQ0FBQ0gsS0FBRCxDQUhyRDtBQUlqQmpFLGtCQUFRLEVBQUMyRDtBQUpRLFdBQW5CO0FBTUQ7QUFFRjs7QUFDRCxLQUFDakQsZ0JBQWdCLENBQUNWLFFBQWpCLENBQTBCcUUsSUFBMUIsQ0FBK0IsVUFBQ25CLENBQUQ7QUFBQSxhQUFPQSxDQUFQO0FBQUEsS0FBL0IsQ0FBRCxHQUNLcEMsWUFBWSxDQUFDRyxPQUFiLENBQXFCK0MsT0FBckIsR0FBK0IsS0FEcEMsR0FFSSxJQUZKO0FBR0QsR0F0REQ7O0FBd0RBLE1BQU1NLFNBQVMsR0FBRyxTQUFaQSxTQUFZLENBQUNDLENBQUQsRUFBTztBQUN2QixRQUFJakUsS0FBSyxHQUFHLENBQVo7QUFDQSxRQUFJQyxhQUFhLEdBQUcsQ0FBcEI7QUFDQSxRQUFJUCxRQUFRLEdBQUcsRUFBZjtBQUNBZ0IsYUFBUyxDQUFDQyxPQUFWLENBQWtCZ0MsT0FBbEIsQ0FBMEIsVUFBQ0MsQ0FBRCxFQUFPO0FBQy9CQSxPQUFDLENBQUNjLE9BQUYsR0FBWU8sQ0FBQyxDQUFDbEIsTUFBRixDQUFTVyxPQUFyQjs7QUFFQSxVQUFJTyxDQUFDLENBQUNsQixNQUFGLENBQVNXLE9BQVQsSUFBb0IsQ0FBQ2hFLFFBQVEsQ0FBQzZDLFFBQVQsQ0FBa0JLLENBQUMsQ0FBQ2EsS0FBcEIsQ0FBekIsRUFBcUQ7QUFDbkQvRCxnQkFBUSxDQUFDOEMsSUFBVCxDQUFjSSxDQUFDLENBQUNhLEtBQWhCO0FBQ0F6RCxhQUFLLElBQUksQ0FBQzRDLENBQUMsQ0FBQ1EsWUFBRixDQUFlLFlBQWYsQ0FBVjtBQUNBbkQscUJBQWEsSUFBSSxDQUFDMkMsQ0FBQyxDQUFDUSxZQUFGLENBQWUsZUFBZixDQUFsQjtBQUNELE9BSkQsTUFJTztBQUNMMUQsZ0JBQVEsR0FBR0EsUUFBUSxDQUFDNEQsTUFBVCxDQUFnQixVQUFDWSxDQUFEO0FBQUEsaUJBQU9BLENBQUMsS0FBS3RCLENBQUMsQ0FBQ2EsS0FBZjtBQUFBLFNBQWhCLENBQVg7QUFDQXpELGFBQUssSUFBSUEsS0FBSyxJQUFJLENBQVQsSUFBYyxDQUFDNEMsQ0FBQyxDQUFDUSxZQUFGLENBQWUsWUFBZixDQUF4QjtBQUNBbkQscUJBQWEsSUFBSUEsYUFBYSxJQUFHLENBQWhCLElBQXFCLENBQUMyQyxDQUFDLENBQUNRLFlBQUYsQ0FBZSxlQUFmLENBQXZDO0FBQ0Q7QUFDRixLQVpEO0FBY0EvQyx1QkFBbUIsaUNBQ2RELGdCQURjO0FBRWpCSixXQUFLLEVBQUVJLGdCQUFnQixDQUFDSixLQUFqQixHQUF1QkEsS0FGYjtBQUdqQk4sY0FBUSxFQUFFQTtBQUhPLE9BQW5CO0FBS0QsR0F2QkQ7O0FBeUJBLE1BQU15RSxTQUFTLEdBQUcsU0FBWkEsU0FBWSxHQUFlO0FBQUEsUUFBZHJELElBQWMsdUVBQVAsRUFBTztBQUMvQkcsZ0RBQUssQ0FBQ0MsSUFBTixXQUFjQyw2QkFBZCxjQUF1REwsSUFBdkQsRUFBNEQ7QUFDMURPLGFBQU8sRUFBQztBQUNOQyxxQkFBYSxtQkFBWXhDLEtBQUssQ0FBQ0MsS0FBTixDQUFZd0MsSUFBWixDQUFpQkMsV0FBN0I7QUFEUDtBQURrRCxLQUE1RCxFQUlHQyxJQUpILENBSVEsVUFBQUMsR0FBRyxFQUFJO0FBQ2JYLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQVosRUFBa0JVLEdBQUcsQ0FBQ1osSUFBSixDQUFTc0QsR0FBM0I7QUFDQ0MsWUFBTSxDQUFDQyxRQUFQLENBQWdCQyxJQUFoQixHQUF1QjdDLEdBQUcsQ0FBQ1osSUFBSixDQUFTc0QsR0FBaEM7QUFDRixLQVBELFdBT1MsVUFBQXhDLEdBQUc7QUFBQSxhQUFJYixPQUFPLENBQUNDLEdBQVIsQ0FBWVksR0FBWixDQUFKO0FBQUEsS0FQWjtBQVFELEdBVEQ7O0FBV0Esc0JBQ0UscUVBQUMsOERBQUQ7QUFBTSxhQUFTLEVBQUMsbUJBQWhCO0FBQUEsNEJBQ0UscUVBQUMsZ0VBQUQ7QUFBTyxlQUFTLEVBQUMsT0FBakI7QUFBQSw2QkFDRSxxRUFBQyxxRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGLGVBSUUscUVBQUMsOERBQUQ7QUFBTSxlQUFTLEVBQUMsYUFBaEI7QUFBQSw4QkFDRSxxRUFBQyw4REFBRDtBQUFNLGlCQUFTLEVBQUMseUJBQWhCO0FBQUEsZ0NBQ0UscUVBQUMsOERBQUQsQ0FBTSxNQUFOO0FBQ0UsY0FBSSxFQUFFckMsQ0FBQyxDQUFDO0FBQUUyRCxjQUFFLEVBQUU7QUFBTixXQUFELENBRFQ7QUFFRSxxQkFBVyxlQUNULHFFQUFDLHNFQUFEO0FBQ0UsZ0JBQUksRUFBRTNELENBQUMsQ0FBQztBQUFFMkQsZ0JBQUUsRUFBRTtBQUFOLGFBQUQsQ0FEVDtBQUVFLGVBQUcsRUFBRSxhQUFDWixHQUFEO0FBQUEscUJBQVU5QixZQUFZLENBQUNHLE9BQWIsR0FBdUIyQixHQUFqQztBQUFBLGFBRlA7QUFHRSxtQkFBTyxFQUFFMEIsU0FIWDtBQUlFLHFCQUFTLEVBQUM7QUFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQVlFO0FBQUssbUJBQU0sS0FBWDtBQUFpQixlQUFLLEVBQUU7QUFBRVEscUJBQVMsRUFBRTtBQUFiLFdBQXhCO0FBQUEsaUNBQ0U7QUFDRSxxQkFBUyxFQUFDLFVBRFo7QUFFRSxpQkFBSyxFQUFFO0FBQ0xDLHFCQUFPLEVBQUUsTUFESjtBQUVMQywwQkFBWSxFQUFFLE1BRlQ7QUFHTEMsbUJBQUssRUFBRTtBQUhGLGFBRlQ7QUFBQSxvQ0FTRSxxRUFBQywyREFBRDtBQUNFLG1CQUFLLHdCQUFZakYsUUFBUSxDQUFDa0YsTUFBckIsTUFEUDtBQUVFLHVCQUFTLEVBQUMsOEJBRlo7QUFHRSx5QkFBUyxDQUhYO0FBSUUsaUJBQUcsRUFBRXZDLFVBSlA7QUFLRSxxQkFBTyxFQUFFYztBQUxYO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBVEYsRUFpQklyRCxNQUFNLENBQUMrRSxHQUFQLENBQVcsVUFBQ2pDLENBQUQ7QUFBQSxrQ0FDWCxxRUFBQywyREFBRDtBQUNFLHFCQUFLLFlBQUtBLENBQUMsQ0FBQ2tDLElBQVAsZUFBZ0JsQyxDQUFDLENBQUNtQyxLQUFsQixNQURQO0FBRUUseUJBQVMsRUFBQyxjQUZaO0FBR0UsMkJBQVNuQyxDQUFDLENBQUNNLEVBSGI7QUFJRSxtQkFBRyxFQUFFYixVQUpQO0FBS0UsdUJBQU8sRUFBRWM7QUFMWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURXO0FBQUEsYUFBWCxDQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVpGLGVBMkNFLHFFQUFDLDhEQUFELENBQU0sSUFBTjtBQUFXLG1CQUFTLEVBQUMsUUFBckI7QUFBQSxpQ0FDRTtBQUFLLHFCQUFTLEVBQUMsY0FBZjtBQUFBLHNCQUNHdkQsYUFBYSxDQUNYMEQsTUFERixDQUNTLFVBQUNWLENBQUQ7QUFBQSxxQkFBT0EsQ0FBQyxDQUFDOUMsTUFBRixDQUFTb0QsRUFBVCxLQUFnQixDQUF2QjtBQUFBLGFBRFQsRUFFRTJCLEdBRkYsQ0FFTSxVQUFDWCxDQUFEO0FBQUEsa0NBQ0gscUVBQUMsOEVBQUQ7QUFFRSx3QkFBUSxFQUFFWCxZQUZaO0FBR0Usb0JBQUksRUFBRVcsQ0FIUjtBQUlFLHVCQUFPLEVBQUVWO0FBSlgsaUJBQ09VLENBQUMsQ0FBQ2hCLEVBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERztBQUFBLGFBRk47QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkEzQ0YsZUF5REU7QUFBSyxtQkFBUyxFQUFDLGFBQWY7QUFBQSxrQ0FDRTtBQUFLLHFCQUFTLEVBQUMsZUFBZjtBQUFBLG9DQUNFO0FBQUEseUJBQ0c5QyxnQkFBZ0IsQ0FBQ1YsUUFBakIsQ0FBMEJrRixNQUQ3QixPQUNzQ3JGLENBQUMsQ0FBQztBQUFFMkQsa0JBQUUsRUFBRTtBQUFOLGVBQUQsQ0FEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQURGLGVBSUU7QUFBSyxtQkFBSyxFQUFFO0FBQUV1Qix1QkFBTyxFQUFFLE1BQVg7QUFBbUJPLDhCQUFjLEVBQUU7QUFBbkMsZUFBWjtBQUFBLHNDQUNFO0FBQUEsMkJBQUl6RixDQUFDLENBQUM7QUFBRTJELG9CQUFFLEVBQUU7QUFBTixpQkFBRCxDQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFERixlQUVFO0FBQUsscUJBQUssRUFBRTtBQUFFdUIseUJBQU8sRUFBRSxNQUFYO0FBQW1CUSwrQkFBYSxFQUFFO0FBQWxDLGlCQUFaO0FBQUEsMEJBRUU3RSxnQkFBZ0IsQ0FBQ0gsYUFBakIsR0FBaUMsQ0FBakMsZ0JBQ0E7QUFBQSwwQ0FDQTtBQUFLLHlCQUFLLEVBQUU7QUFBRWlGLHlDQUFtQixFQUFFO0FBQXZCLHFCQUFaO0FBQUEsK0JBQTZDcEIsVUFBVSxDQUFDMUQsZ0JBQWdCLENBQUNKLEtBQWxCLENBQVYsQ0FBbUNtRixPQUFuQyxDQUEyQyxDQUEzQyxDQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREEsZUFFQztBQUFBLCtCQUFJckIsVUFBVSxDQUFDMUQsZ0JBQWdCLENBQUNILGFBQWxCLENBQVYsQ0FBMkNrRixPQUEzQyxDQUFtRCxDQUFuRCxDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFGRDtBQUFBLGdDQURBLGdCQUtJO0FBQUEsNkJBQUlyQixVQUFVLENBQUMxRCxnQkFBZ0IsQ0FBQ0gsYUFBbEIsQ0FBVixDQUEyQ2tGLE9BQTNDLENBQW1ELENBQW5ELENBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUE47QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGLGVBcUJFO0FBQUsscUJBQVMsRUFBQyxlQUFmO0FBQUEsb0NBQ0U7QUFBQSxxQ0FDRSxxRUFBQywwRUFBRDtBQUNFLHlCQUFTLEVBQUMsZ0JBRFo7QUFFRSx5QkFBUyxFQUFFO0FBQUVDLHdCQUFNLEVBQUUsTUFBVjtBQUFrQlQsdUJBQUssRUFBRTtBQUF6QixpQkFGYjtBQUdFLHlCQUFTLEVBQUMsdUJBSFo7QUFJRSxxQkFBSyxFQUFFO0FBQUVELDhCQUFZLEVBQUU7QUFBaEIsaUJBSlQ7QUFLRSxxQkFBSyx1QkFBRXRGLE1BQU0sQ0FBQ2dDLFNBQVQsc0RBQUUsa0JBQWtCUyxPQUwzQjtBQUFBLHdDQU9FLHFFQUFDLGdFQUFEO0FBQ0UsNkJBQVcsRUFBRXRDLENBQUMsQ0FBQztBQUFFMkQsc0JBQUUsRUFBRTtBQUFOLG1CQUFELENBRGhCO0FBRUUsc0JBQUksRUFBQyxXQUZQO0FBR0UscUJBQUcsRUFBRWhFLFFBQVEsQ0FBQztBQUNabUcsNEJBQVEsRUFBRTtBQUNSNUIsMkJBQUssRUFBRSxJQURDO0FBRVI1Qiw2QkFBTyxFQUFFdEMsQ0FBQyxDQUFDO0FBQUUyRCwwQkFBRSxFQUFFO0FBQU4sdUJBQUQ7QUFGRjtBQURFLG1CQUFELENBSGY7QUFTRSwwQkFBUSxFQUFFLGtCQUFDZSxDQUFEO0FBQUEsMkJBQ1I1RCxtQkFBbUIsaUNBQ2RELGdCQURjO0FBRWpCRiwwQkFBSSxFQUFFK0QsQ0FBQyxDQUFDbEIsTUFBRixDQUFTVTtBQUZFLHVCQURYO0FBQUE7QUFUWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQVBGLEVBdUJHckQsZ0JBQWdCLENBQUNELFVBQWpCLGdCQUNDLHFFQUFDLDJEQUFEO0FBQ0UsMkJBQVMsRUFBQyxlQURaO0FBRUUsdUJBQUssRUFBRTtBQUNMbUYsc0NBQWtCLEVBQUUsV0FEZjtBQUVMQyx5QkFBSyxFQUFFLFVBRkY7QUFHTEMsMkJBQU8sRUFBRTtBQUhKLG1CQUZUO0FBT0UsdUJBQUssRUFBQyxtQkFQUjtBQVFFLHlCQUFPLEVBQUUsbUJBQU07QUFDYm5GLHVDQUFtQixpQ0FDZEQsZ0JBRGM7QUFFakJELGdDQUFVLEVBQUU7QUFGSyx1QkFBbkI7QUFJRDtBQWJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREQsZ0JBaUJDLHFFQUFDLDJEQUFEO0FBQ0UsMEJBQVEsRUFBRSxDQUFDQyxnQkFBZ0IsQ0FBQ0YsSUFBbEIsR0FBeUIsSUFBekIsR0FBZ0MsS0FENUM7QUFFRSx1QkFBSyxFQUFFO0FBQUVzRiwyQkFBTyxFQUFFO0FBQVgsbUJBRlQ7QUFHRSwyQkFBUyxFQUFDLHdCQUhaO0FBSUUsdUJBQUssRUFBRWpHLENBQUMsQ0FBQztBQUFFMkQsc0JBQUUsRUFBRTtBQUFOLG1CQUFELENBSlY7QUFLRSxzQkFBSSxFQUFDLFFBTFA7QUFNRSx5QkFBTyxFQUFFL0QsWUFBWSxDQUFDMEIsTUFBRCxDQU52QixDQU9FO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQXhDSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQURGLGVBNERFLHFFQUFDLDJEQUFEO0FBQ0UsbUJBQUssRUFBRTtBQUFFMkUsdUJBQU8sRUFBRTtBQUFYLGVBRFQ7QUFFRSx1QkFBUyxFQUFDLG1DQUZaO0FBR0UsbUJBQUssRUFBRWpHLENBQUMsQ0FBQztBQUFFMkQsa0JBQUUsRUFBRTtBQUFOLGVBQUQsQ0FIVjtBQUlFLHdCQUFVLGVBQUU7QUFBTSx5QkFBUyxFQUFDLG1CQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFKZDtBQUtFLHFCQUFPLEVBQUk7QUFBQSx1QkFBTWlCLFNBQVMsQ0FBQztBQUN6QlIsdUJBQUssRUFBQ3ZELGdCQUFnQixDQUFDSCxhQURFO0FBRXpCd0YsNEJBQVUsRUFBQyxDQUZjO0FBR3pCOUQseUJBQU8sRUFBQ3ZCLGdCQUFnQixDQUFDVjtBQUhBLGlCQUFELENBQWY7QUFBQTtBQUxiO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBNURGLGVBdUVFLHFFQUFDLDJEQUFEO0FBQ0UsbUJBQUssRUFBRTtBQUFFOEYsdUJBQU8sRUFBRTtBQUFYLGVBRFQ7QUFFRSx1QkFBUyxFQUFDLE1BRlo7QUFHRSxtQkFBSyxFQUFFakcsQ0FBQyxDQUFDO0FBQUUyRCxrQkFBRSxFQUFFO0FBQU4sZUFBRCxDQUhWO0FBSUUsd0JBQVUsZUFDUjtBQUFNLHlCQUFTLEVBQUMsMEJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUxKO0FBT0UscUJBQU8sRUFBSTtBQUFBLHVCQUFNcEUsS0FBSyxDQUFDNEcsa0JBQU4sQ0FBeUIsU0FBekIsRUFBbUM7QUFDbEQvQix1QkFBSyxFQUFDdkQsZ0JBQWdCLENBQUNILGFBRDJCO0FBRWxEd0YsNEJBQVUsRUFBQyxDQUZ1QztBQUdsRDlELHlCQUFPLEVBQUN2QixnQkFBZ0IsQ0FBQ1Y7QUFIeUIsaUJBQW5DLEVBS2pCO0FBQ0Usb0RBQTBCWixLQUFLLENBQUNDLEtBQU4sQ0FBWXdDLElBQVosQ0FBaUJDLFdBQTNDO0FBREYsaUJBTGlCLENBQU47QUFBQTtBQVBiO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBdkVGLGVBd0ZFO0FBQUssdUJBQVMsRUFBQyxVQUFmO0FBQUEsc0NBQ0UscUVBQUMsMkRBQUQ7QUFDRSxxQkFBSyxFQUFFO0FBQUVnRSx5QkFBTyxFQUFFO0FBQVgsaUJBRFQ7QUFFRSx5QkFBUyxFQUFDLDhCQUZaO0FBR0UscUJBQUssRUFBRWpHLENBQUMsQ0FBQztBQUFFMkQsb0JBQUUsRUFBRTtBQUFOLGlCQUFELENBSFY7QUFJRSwwQkFBVSxlQUNSO0FBQU0sMkJBQVMsRUFBQyxtQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBTEo7QUFPRSx1QkFBTyxFQUFJO0FBQUEseUJBQU1pQixTQUFTLENBQUM7QUFDekJSLHlCQUFLLEVBQUN2RCxnQkFBZ0IsQ0FBQ0gsYUFERTtBQUV6QndGLDhCQUFVLEVBQUMsQ0FGYztBQUd6QjlELDJCQUFPLEVBQUN2QixnQkFBZ0IsQ0FBQ1Y7QUFIQSxtQkFBRCxDQUFmO0FBQUE7QUFQYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQURGLGVBY0UscUVBQUMsMkRBQUQ7QUFDRSxxQkFBSyxFQUFFO0FBQUU4Rix5QkFBTyxFQUFFO0FBQVgsaUJBRFQ7QUFFRSxxQkFBSyxFQUFFakcsQ0FBQyxDQUFDO0FBQUUyRCxvQkFBRSxFQUFFO0FBQU4saUJBQUQsQ0FGVjtBQUdFLDBCQUFVLGVBQ1I7QUFBTSwyQkFBUyxFQUFDLHlCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFKSjtBQU1FLHVCQUFPLEVBQUk7QUFBQSx5QkFBTXBFLEtBQUssQ0FBQzRHLGtCQUFOLENBQXlCLFNBQXpCLEVBQW1DO0FBQ2xEL0IseUJBQUssRUFBQ3ZELGdCQUFnQixDQUFDSCxhQUQyQjtBQUVsRHdGLDhCQUFVLEVBQUMsQ0FGdUM7QUFHbEQ5RCwyQkFBTyxFQUFDdkIsZ0JBQWdCLENBQUNWO0FBSHlCLG1CQUFuQyxFQUtqQjtBQUNFLHNEQUEwQlosS0FBSyxDQUFDQyxLQUFOLENBQVl3QyxJQUFaLENBQWlCQyxXQUEzQztBQURGLG1CQUxpQixDQUFOO0FBQUE7QUFOYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkF4RkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBekRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBeU1FLHFFQUFDLDhEQUFEO0FBQU0saUJBQVMsRUFBQyxlQUFoQjtBQUFBLGdDQUNFLHFFQUFDLDhEQUFELENBQU0sTUFBTjtBQUFhLGNBQUksRUFBRWpDLENBQUMsQ0FBQztBQUFFMkQsY0FBRSxFQUFFO0FBQU4sV0FBRDtBQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBRUUscUVBQUMsOERBQUQsQ0FBTSxJQUFOO0FBQVcsbUJBQVMsRUFBQywwQkFBckI7QUFBQSxpQ0FDRSxxRUFBQyxnRUFBRDtBQUNFLGNBQUUsRUFBRSxDQUNGM0QsQ0FBQyxDQUFDO0FBQUUyRCxnQkFBRSxFQUFFO0FBQU4sYUFBRCxDQURDLEVBRUYzRCxDQUFDLENBQUM7QUFBRTJELGdCQUFFLEVBQUU7QUFBTixhQUFELENBRkMsRUFHRjNELENBQUMsQ0FBQztBQUFFMkQsZ0JBQUUsRUFBRTtBQUFOLGFBQUQsQ0FIQyxFQUlGM0QsQ0FBQyxDQUFDO0FBQUUyRCxnQkFBRSxFQUFFO0FBQU4sYUFBRCxDQUpDLEVBS0YzRCxDQUFDLENBQUM7QUFBRTJELGdCQUFFLEVBQUU7QUFBTixhQUFELENBTEMsRUFNRjNELENBQUMsQ0FBQztBQUFFMkQsZ0JBQUUsRUFBRTtBQUFOLGFBQUQsQ0FOQyxFQU9GM0QsQ0FBQyxDQUFDO0FBQUUyRCxnQkFBRSxFQUFFO0FBQU4sYUFBRCxDQVBDLENBRE47QUFVRSxnQkFBSSxFQUNGeEQsUUFBUSxDQUFDbUYsR0FBVCxDQUFhLFVBQUNqQyxDQUFELEVBQU87QUFDbEIsa0JBQUlBLENBQUMsQ0FBQzlDLE1BQUYsQ0FBU29ELEVBQVQsSUFBZSxDQUFuQixFQUFzQjtBQUNwQix1QkFBTztBQUNMeUMsOEJBQVksRUFBRS9DLENBQUMsQ0FBQytDLFlBRFg7QUFFTEMsc0JBQUksRUFBRWhELENBQUMsQ0FBQ2dELElBRkg7QUFHTEMsMEJBQVEsRUFBRWpELENBQUMsQ0FBQ2lELFFBSFA7QUFJTGxDLHVCQUFLLFlBQUtmLENBQUMsQ0FBQ2UsS0FBUCxjQUFnQmYsQ0FBQyxDQUFDa0QsUUFBbEIsQ0FKQTtBQUtMQyx3QkFBTSxZQUFLakMsVUFBVSxDQUFDbEIsQ0FBQyxDQUFDbUQsTUFBSCxDQUFWLENBQXFCWixPQUFyQixDQUE2QixDQUE3QixLQUFtQyxDQUF4QyxRQUxEO0FBTUxhLGdDQUFjLEVBQ1psQyxVQUFVLENBQUNsQixDQUFDLENBQUNvRCxjQUFILENBQVYsQ0FBNkJiLE9BQTdCLENBQXFDLENBQXJDLEtBQTJDLENBUHhDO0FBUUxyRix3QkFBTSxZQUFLOEMsQ0FBQyxDQUFDOUMsTUFBRixDQUFTZ0YsSUFBZCxnQkFBd0JsQyxDQUFDLENBQUNxRCxJQUExQjtBQVJELGlCQUFQO0FBVUQ7QUFDRixhQWJELEtBYU0sRUF4QlY7QUEwQkUsc0JBQVUsRUFBRSxvQkFBQ3JELENBQUQsRUFBSXNELENBQUosRUFBVTtBQUNwQixrQ0FBTztBQUFBLDBCQUFldEQ7QUFBZixpQkFBU3NELENBQUMsRUFBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFQO0FBQ0Q7QUE1Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBek1GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBb1BEOztHQS9jUXJILFE7VUFLOENJLHVELEVBQ3hCSyxrRCxFQWFWZ0IscUQ7OztLQW5CWnpCLFE7O0FBaWRULElBQU1zSCxlQUFlLEdBQUcsU0FBbEJBLGVBQWtCLENBQUNDLEtBQUQ7QUFBQSxTQUFZO0FBQ2xDckgsU0FBSyxFQUFFcUgsS0FBSyxDQUFDckg7QUFEcUIsR0FBWjtBQUFBLENBQXhCOztBQUdBLElBQU1zSCxrQkFBa0IsR0FBSTtBQUMxQlgsb0JBQWtCLEVBQWxCQSw2RUFBa0JBO0FBRFEsQ0FBNUI7QUFJZVksMkhBQU8sQ0FBQ0gsZUFBRCxFQUFrQkUsa0JBQWxCLENBQVAsZUFBNkNFLGtEQUFJLENBQUMxSCxRQUFELENBQWpELENBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvcGFja2FnZXMuMjY3YWM5NmEyZmJmMmQ1N2Y2MDAuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcbmltcG9ydCBSZWFjdCwgeyBtZW1vLCB1c2VMYXlvdXRFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlRm9ybSB9IGZyb20gXCJyZWFjdC1ob29rLWZvcm1cIjtcclxuaW1wb3J0IHsgdXNlSW50bCB9IGZyb20gXCJyZWFjdC1pbnRsXCI7XHJcbmltcG9ydCB7IGNvbm5lY3QgfSBmcm9tIFwicmVhY3QtcmVkdXhcIjtcclxuaW1wb3J0IEFzaWRlTWVudSBmcm9tIFwiLi4vY29tcG9uZW50cy9hc2lkZS1tZW51L2luZGV4XCI7XHJcbmltcG9ydCBBc2lkZSBmcm9tIFwiLi4vY29tcG9uZW50cy9hc2lkZS9hc2lkZVwiO1xyXG5pbXBvcnQgQnV0dG9uQ29tcG9uZW50IGZyb20gXCIuLi9jb21wb25lbnRzL2J1dHRvblwiO1xyXG5pbXBvcnQgQ2FyZCBmcm9tIFwiLi4vY29tcG9uZW50cy9jYXJkL2NhcmRcIjtcclxuaW1wb3J0IENoZWNrYm94IGZyb20gXCIuLi9jb21wb25lbnRzL2NoZWNrYm94L2NoZWNrYm94XCI7XHJcbmltcG9ydCBGcm9tR3JvdXAgZnJvbSBcIi4uL2NvbXBvbmVudHMvZm9ybS1ncm91cC9mb3JtLWdyb3VwXCI7XHJcbmltcG9ydCBJbnB1dCBmcm9tIFwiLi4vY29tcG9uZW50cy9pbnB1dC9pbnB1dFwiO1xyXG5pbXBvcnQgTWFpbiBmcm9tIFwiLi4vY29tcG9uZW50cy9tYWluL21haW5cIjtcclxuaW1wb3J0IFBhY2thZ2VJdGVtIGZyb20gXCIuLi9jb21wb25lbnRzL3BhY2thZ2VfaXRlbS9wYWNrYWdlLWl0ZW1cIjtcclxuaW1wb3J0IFBhZ2UgZnJvbSBcIi4uL2NvbXBvbmVudHMvcGFnZS9wYWdlXCI7XHJcbmltcG9ydCBSZWRpcmVjdCBmcm9tIFwiLi4vY29tcG9uZW50cy9yZWRpcmVjdC9yZWRpcmVjdFwiO1xyXG5pbXBvcnQgVGFiZWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvdGFiZWwvdGFiZWxcIjtcclxuaW1wb3J0IHsgUGF5QnlCYWxhbmNlQWN0aW9uIH0gZnJvbSAnLi4vcmVkdXgvZW50cnkvZW50cnlBY3Rpb25zJztcclxuXHJcbmZ1bmN0aW9uIFBhY2thZ2VzKHByb3BzKSB7XHJcbiAgaWYgKCFwcm9wcy5lbnRyeS5pc0xvZ2VkKSB7XHJcbiAgICByZXR1cm4gPFJlZGlyZWN0IC8+O1xyXG4gIH1cclxuXHJcbiAgY29uc3QgeyByZWdpc3RlciwgaGFuZGxlU3VibWl0LCBlcnJvcnMsIHNldEVycm9yIH0gPSB1c2VGb3JtKCk7XHJcbiAgY29uc3QgeyBmb3JtYXRNZXNzYWdlOiBmIH0gPSB1c2VJbnRsKCk7XHJcbiAgY29uc3QgW3BhY2thZ2VzLCBzZXRQYWNrYWdlc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2ZpbHRlcmVkUGFja3MsIHNldEZpbHRlcmVkUGFja3NdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzdGF0dXMsIHNldFN0YXR1c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkUGFja2FnZXMsIHNldFNlbGVjdGVkUGFja2FnZXNdID0gdXNlU3RhdGUoe1xyXG4gICAgcGFja2FnZXM6IFtdLFxyXG4gICAgdG90YWw6IDAsXHJcbiAgICBkaXNjb3VudFRvdGFsOjAsXHJcbiAgICBjb2RlOiBcIlwiLFxyXG4gICAgaXNBY2NlcHRlZDogZmFsc2UsXHJcbiAgICBzdGF0dXM6IDAsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHsgbG9jYWxlIH0gPSB1c2VSb3V0ZXIoKTtcclxuICBjb25zdCBtYWluQ2hlY2tSZWYgPSB1c2VSZWYoKTtcclxuICBjb25zdCBjaGVja1JlZnMgPSB1c2VSZWYoW10pO1xyXG4gIGNoZWNrUmVmcy5jdXJyZW50ID0gW107XHJcbiAgY29uc3QgdGFiUmVmcyA9IHVzZVJlZihbXSk7XHJcbiAgdGFiUmVmcy5jdXJyZW50ID0gW107XHJcblxyXG4gIGNvbnN0IHN1Ym1pdCA9IChkYXRhKSA9PiB7XHJcbiAgICBjb25zb2xlLmxvZyhkYXRhKTtcclxuXHJcbiAgICBheGlvc1xyXG4gICAgICAucG9zdChcclxuICAgICAgICBgJHtwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19BUElfVVJMfXByb21vY29kZT9wcm9tb2NvZGU9JHtkYXRhLnByb21vY29kZX0mc3RhdHVzPSR7c2VsZWN0ZWRQYWNrYWdlcy5zdGF0dXN9YCxcclxuICAgICAgICB7fSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgIFwiY29udGVudC10eXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxyXG4gICAgICAgICAgICBhdXRob3JpemF0aW9uOiBgQmVhcmVyICR7cHJvcHMuZW50cnkudXNlci5hY2Nlc3NUb2tlbn1gLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9XHJcbiAgICAgIClcclxuICAgICAgLnRoZW4oKHJlcykgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKHJlcy5kYXRhLmJhdGNoZXMpO1xyXG4gICAgICAgIHNldFBhY2thZ2VzKHJlcy5kYXRhLmJhdGNoZXMpO1xyXG4gICAgICAgIHNldEZpbHRlcmVkUGFja3MocmVzLmRhdGEuYmF0Y2hlcyk7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyKSA9PiB7XHJcbiAgICAgICAgc2V0RXJyb3IoXCJwcm9tb2NvZGVcIiwgeyBtZXNzYWdlOiBlcnIucmVzcG9uc2UuZGF0YS5lcnJvciB9KTtcclxuICAgICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgUHJvbWlzQWxsID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgbGV0IGJhdGNoZXNEYXRhID0gYXdhaXQgYXhpb3MuZ2V0KGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9YmF0Y2hlcz9sYW49JHtsb2NhbGV9YCwge1xyXG4gICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgYXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Byb3BzLmVudHJ5LnVzZXIuYWNjZXNzVG9rZW59YCxcclxuICAgICAgfSxcclxuICAgIH0pO1xyXG4gICAgbGV0IHN0YXR1c0RhdGEgPSBhd2FpdCBheGlvcy5nZXQoYCR7cHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQVBJX1VSTH1zdGF0dXM/bGFuPSR7bG9jYWxlfWAsIHtcclxuICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgIGF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtwcm9wcy5lbnRyeS51c2VyLmFjY2Vzc1Rva2VufWAsXHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBiYXRjaGVzRGF0YTpiYXRjaGVzRGF0YS5kYXRhLFxyXG4gICAgICBzdGF0dXNEYXRhOnN0YXR1c0RhdGEuZGF0YVxyXG4gICAgfVxyXG4gIH1cclxuICB1c2VMYXlvdXRFZmZlY3QoKCkgPT4ge1xyXG4gICAgUHJvbWlzQWxsKCkudGhlbihyZXMgPT4ge1xyXG4gICAgICBzZXRQYWNrYWdlcyhyZXMuYmF0Y2hlc0RhdGEpO1xyXG4gICAgICBzZXRGaWx0ZXJlZFBhY2tzKHJlcy5iYXRjaGVzRGF0YSk7XHJcbiAgICAgIHNldFN0YXR1cyhyZXMuc3RhdHVzRGF0YSk7XHJcbiAgICB9KS5jYXRjaChlcnIgPT4gY29uc29sZS5sb2coZXJyKSlcclxuXHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBhZGRUYWJSZWZzID0gKHJlZikgPT4ge1xyXG4gICAgaWYgKHJlZiAmJiAhdGFiUmVmcy5jdXJyZW50LmluY2x1ZGVzKHJlZikpIHtcclxuICAgICAgdGFiUmVmcy5jdXJyZW50LnB1c2gocmVmKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCB0b2dnbGVUYWJSZWZzID0gYXN5bmMgKGV2KSA9PiB7XHJcbiAgICB0YWJSZWZzLmN1cnJlbnQuZm9yRWFjaCgoeCkgPT4geC5jbGFzc0xpc3QucmVtb3ZlKFwicGFjay1hY3RpdmVcIikpO1xyXG4gICAgZXYudGFyZ2V0LmNsYXNzTGlzdC5hZGQoXCJwYWNrLWFjdGl2ZVwiKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBnZXRCYXRjaGVzQnlTdGF0YXVzSWQgPSBhc3luYyAoaWQpID0+e1xyXG4gICAgIGF4aW9zLmdldChgJHtwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19BUElfVVJMfWJhdGNoZXM/c3RhdHVzPSR7aWR9Jmxhbj0ke2xvY2FsZX1gLCB7XHJcbiAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICBhdXRob3JpemF0aW9uOiBgQmVhcmVyICR7cHJvcHMuZW50cnkudXNlci5hY2Nlc3NUb2tlbn1gLFxyXG4gICAgICB9LFxyXG4gICAgfSkudGhlbigocmVzKSA9PiB7XHJcbiAgICAgIHNldFBhY2thZ2VzKHJlcy5kYXRhKTtcclxuICAgICAgc2V0RmlsdGVyZWRQYWNrcyhyZXMuZGF0YSk7XHJcbiAgICB9KS5jYXRjaChlcnIgPT4gY29uc29sZS5sb2coZXJyKSlcclxuXHJcbiAgXHJcbiAgfTtcclxuXHJcbiAgY29uc3QgdGFiQnV0dG9uQ2xpY2sgPSAoZXYpID0+IHtcclxuICAgIGxldCBpZCA9IGV2LnRhcmdldC5nZXRBdHRyaWJ1dGUoXCJkYXRhLWlkXCIpO1xyXG4gICAgdG9nZ2xlVGFiUmVmcyhldik7XHJcbiAgICBnZXRCYXRjaGVzQnlTdGF0YXVzSWQoaWQpXHJcbiAgICBpZiAoaWQgIT0gMCkge1xyXG4gICAgICBsZXQgbmV3UGFja2FnZXMgPSBwYWNrYWdlcy5maWx0ZXIoKHgpID0+IHguc3RhdHVzLmlkID09IGlkKTtcclxuICAgICAgc2V0RmlsdGVyZWRQYWNrcyhbLi4ubmV3UGFja2FnZXNdKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEZpbHRlcmVkUGFja3MoWy4uLnBhY2thZ2VzXSk7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0U2VsZWN0ZWRQYWNrYWdlcyh7XHJcbiAgICAgIGRpc2NvdW50VG90YWw6IDAsXHJcbiAgICAgIHBhY2thZ2VzOiBbXSxcclxuICAgICAgdG90YWw6IDAsXHJcbiAgICAgIGNvZGU6IFwiXCIsXHJcbiAgICAgIGlzQWNjZXB0ZWQ6IGZhbHNlLFxyXG4gICAgICBzdGF0dXM6IGlkLFxyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgYWRkQ2hlY2tSZWZzID0gKHJlZikgPT4ge1xyXG4gICAgaWYgKHJlZiAmJiAhY2hlY2tSZWZzLmN1cnJlbnQuaW5jbHVkZXMocmVmKSkge1xyXG4gICAgICBjaGVja1JlZnMuY3VycmVudC5wdXNoKHJlZik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY2hlY2tIYW5kbGVyID0gKGV2KSA9PiB7XHJcbiAgICBsZXQgeyB2YWx1ZSwgY2hlY2tlZCB9ID0gZXYudGFyZ2V0O1xyXG4gICAgbGV0IHByaWNlID0gZXYudGFyZ2V0LmdldEF0dHJpYnV0ZShcImRhdGEtcHJpY2VcIik7XHJcbiAgICBsZXQgZGF0YURpc2NvdW50ID0gZXYudGFyZ2V0LmdldEF0dHJpYnV0ZShcImRhdGEtZGlzY291bnRcIik7XHJcbiAgICBsZXQgdG90YWw9MFxyXG4gICAgbGV0IGRpc2M9MFxyXG4gICAgY29uc29sZS5sb2coJ2RpcycsZGF0YURpc2NvdW50KVxyXG4gICAgaWYgKGNoZWNrZWQpIHtcclxuICAgICAgc2VsZWN0ZWRQYWNrYWdlcy5wYWNrYWdlcy5wdXNoKHZhbHVlKTtcclxuICAgICAgaWYoZGF0YURpc2NvdW50IT0wKXtcclxuICAgICAgICBzZXRTZWxlY3RlZFBhY2thZ2VzKHtcclxuICAgICAgICAgIC4uLnNlbGVjdGVkUGFja2FnZXMsXHJcblxyXG4gICAgICAgICAgdG90YWw6IChzZWxlY3RlZFBhY2thZ2VzLnRvdGFsK3BhcnNlRmxvYXQocHJpY2UpKSxcclxuICAgICAgICAgXHJcbiAgICAgICAgICBkaXNjb3VudFRvdGFsOiAoc2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsK3BhcnNlRmxvYXQoZGF0YURpc2NvdW50KSksXHJcbiAgICAgICAgICBwYWNrYWdlczogWy4uLnNlbGVjdGVkUGFja2FnZXMucGFja2FnZXNdLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICBcclxuICAgICAgfWVsc2V7XHJcbiAgICAgICAgc2V0U2VsZWN0ZWRQYWNrYWdlcyh7XHJcbiAgICAgICAgICAuLi5zZWxlY3RlZFBhY2thZ2VzLFxyXG4gICAgICAgICAgZGlzY291bnRUb3RhbDogKHNlbGVjdGVkUGFja2FnZXMuZGlzY291bnRUb3RhbCtwYXJzZUZsb2F0KHByaWNlKSksXHJcbiAgICAgICAgICB0b3RhbDogKHNlbGVjdGVkUGFja2FnZXMudG90YWwrcGFyc2VGbG9hdChwcmljZSkpLFxyXG4gICAgICAgICAgcGFja2FnZXM6IFsuLi5zZWxlY3RlZFBhY2thZ2VzLnBhY2thZ2VzXSxcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgIFxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgbGV0IG5ld1BhY2thZ2VzID0gc2VsZWN0ZWRQYWNrYWdlcy5wYWNrYWdlcy5maWx0ZXIoKHgpID0+IHggIT09IHZhbHVlKTtcclxuICAgICAgaWYoZGF0YURpc2NvdW50IT0wKXtcclxuICAgICAgICBzZXRTZWxlY3RlZFBhY2thZ2VzKHtcclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLi4uc2VsZWN0ZWRQYWNrYWdlcyxcclxuXHJcbiAgICAgICAgICB0b3RhbDogc2VsZWN0ZWRQYWNrYWdlcy50b3RhbCA+PTAgJiYgKHNlbGVjdGVkUGFja2FnZXMudG90YWwtcGFyc2VGbG9hdChwcmljZSkpLFxyXG4gICAgICAgICBcclxuICAgICAgICAgIGRpc2NvdW50VG90YWw6IHNlbGVjdGVkUGFja2FnZXMuZGlzY291bnRUb3RhbCA+PTAgJiYgIChzZWxlY3RlZFBhY2thZ2VzLmRpc2NvdW50VG90YWwtcGFyc2VGbG9hdChkYXRhRGlzY291bnQpKSxcclxuICAgICAgICAgIHBhY2thZ2VzOiBuZXdQYWNrYWdlc1xyXG4gICAgICAgIH0pO1xyXG4gICAgICBcclxuICAgICAgfWVsc2V7XHJcbiAgICAgICAgc2V0U2VsZWN0ZWRQYWNrYWdlcyh7XHJcbiAgICAgICAgICAuLi5zZWxlY3RlZFBhY2thZ2VzLFxyXG4gICAgICAgICAgZGlzY291bnRUb3RhbDpzZWxlY3RlZFBhY2thZ2VzLmRpc2NvdW50VG90YWwgPj0wICYmIChzZWxlY3RlZFBhY2thZ2VzLmRpc2NvdW50VG90YWwtcGFyc2VGbG9hdChwcmljZSkpLFxyXG4gICAgICAgICAgdG90YWw6c2VsZWN0ZWRQYWNrYWdlcy50b3RhbCA+PTAgJiYgKHNlbGVjdGVkUGFja2FnZXMudG90YWwtcGFyc2VGbG9hdChwcmljZSkpLFxyXG4gICAgICAgICAgcGFja2FnZXM6bmV3UGFja2FnZXNcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgIFxyXG4gICAgfVxyXG4gICAgIXNlbGVjdGVkUGFja2FnZXMucGFja2FnZXMuc29tZSgoeCkgPT4geClcclxuICAgICAgPyAobWFpbkNoZWNrUmVmLmN1cnJlbnQuY2hlY2tlZCA9IGZhbHNlKVxyXG4gICAgICA6IG51bGw7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgc2VsZWN0QWxsID0gKGUpID0+IHtcclxuICAgIGxldCB0b3RhbCA9IDA7XHJcbiAgICBsZXQgZGlzY291bnRUb3RhbCA9IDA7XHJcbiAgICBsZXQgcGFja2FnZXMgPSBbXTtcclxuICAgIGNoZWNrUmVmcy5jdXJyZW50LmZvckVhY2goKHgpID0+IHtcclxuICAgICAgeC5jaGVja2VkID0gZS50YXJnZXQuY2hlY2tlZDtcclxuXHJcbiAgICAgIGlmIChlLnRhcmdldC5jaGVja2VkICYmICFwYWNrYWdlcy5pbmNsdWRlcyh4LnZhbHVlKSkge1xyXG4gICAgICAgIHBhY2thZ2VzLnB1c2goeC52YWx1ZSk7XHJcbiAgICAgICAgdG90YWwgKz0gK3guZ2V0QXR0cmlidXRlKFwiZGF0YS1wcmljZVwiKTtcclxuICAgICAgICBkaXNjb3VudFRvdGFsICs9ICt4LmdldEF0dHJpYnV0ZShcImRhdGEtZGlzY291bnRcIik7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcGFja2FnZXMgPSBwYWNrYWdlcy5maWx0ZXIoKHApID0+IHAgIT09IHgudmFsdWUpO1xyXG4gICAgICAgIHRvdGFsIC09IHRvdGFsID49IDAgJiYgK3guZ2V0QXR0cmlidXRlKFwiZGF0YS1wcmljZVwiKTtcclxuICAgICAgICBkaXNjb3VudFRvdGFsIC09IGRpc2NvdW50VG90YWwgPj0wICYmICt4LmdldEF0dHJpYnV0ZShcImRhdGEtZGlzY291bnRcIik7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIHNldFNlbGVjdGVkUGFja2FnZXMoe1xyXG4gICAgICAuLi5zZWxlY3RlZFBhY2thZ2VzLFxyXG4gICAgICB0b3RhbDogc2VsZWN0ZWRQYWNrYWdlcy50b3RhbC10b3RhbCxcclxuICAgICAgcGFja2FnZXM6IHBhY2thZ2VzLFxyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgUGF5YnlDYXJkID0gKGRhdGEgPSB7fSkgPT4ge1xyXG4gICAgYXhpb3MucG9zdChgJHtwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19BUElfVVJMfXBheW1lbnRgLGRhdGEse1xyXG4gICAgICBoZWFkZXJzOntcclxuICAgICAgICBhdXRob3JpemF0aW9uOiBgQmVhcmVyICR7cHJvcHMuZW50cnkudXNlci5hY2Nlc3NUb2tlbn1gLFxyXG4gICAgICB9XHJcbiAgICB9KS50aGVuKHJlcyA9PiB7XHJcbiAgICAgIGNvbnNvbGUubG9nKCdyZWQnLHJlcy5kYXRhLnVybCk7XHJcbiAgICAgICB3aW5kb3cubG9jYXRpb24uaHJlZiA9IHJlcy5kYXRhLnVybDtcclxuICAgIH0pLmNhdGNoKGVyciA9PiBjb25zb2xlLmxvZyhlcnIpKVxyXG4gIH1cclxuIFxyXG4gIHJldHVybiAoXHJcbiAgICA8UGFnZSBjbGFzc05hbWU9XCJiZy1iZyBwdC1sZyBwYi1sZ1wiPlxyXG4gICAgICA8QXNpZGUgY2xhc3NOYW1lPVwibXItc21cIj5cclxuICAgICAgICA8QXNpZGVNZW51IC8+XHJcbiAgICAgIDwvQXNpZGU+XHJcbiAgICAgIDxNYWluIGNsYXNzTmFtZT1cImJnLWMgcC1ub25lXCI+XHJcbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwiYmctYmcgcGItc20gbWdtX3NzIHAtc21cIj5cclxuICAgICAgICAgIDxDYXJkLkhlYWRlclxyXG4gICAgICAgICAgICB0ZXh0PXtmKHsgaWQ6IFwiYWN0aXZlLXBhY1wiIH0pfVxyXG4gICAgICAgICAgICBlbmRFbGVsbWVudD17XHJcbiAgICAgICAgICAgICAgPENoZWNrYm94XHJcbiAgICAgICAgICAgICAgICB0ZXh0PXtmKHsgaWQ6IFwiY2hvb3NlLWFsbFwiIH0pfVxyXG4gICAgICAgICAgICAgICAgUmVmPXsocmVmKSA9PiAobWFpbkNoZWNrUmVmLmN1cnJlbnQgPSByZWYpfVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17c2VsZWN0QWxsfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyLXN1YnRpdGxlXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cInNzY1wiIHN0eWxlPXt7IG92ZXJmbG93WDogXCJzY3JvbGxcIiB9fT5cclxuICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIiBwbC1ub25lXCJcclxuICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICAgICAgICAgICAgICBtYXJnaW5Cb3R0b206IFwiMjBweFwiLFxyXG4gICAgICAgICAgICAgICAgd2lkdGg6IFwibWF4LWNvbnRlbnRcIixcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcblxyXG4gICAgICAgICAgICAgIDxCdXR0b25Db21wb25lbnRcclxuICAgICAgICAgICAgICAgIGxhYmVsPXtgSGFtc8SxICgke3BhY2thZ2VzLmxlbmd0aH0pYH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1yLXhzIHAteHMgYmctYmcgcGFjay1hY3RpdmVcIlxyXG4gICAgICAgICAgICAgICAgZGF0YS1pZD17MH1cclxuICAgICAgICAgICAgICAgIFJlZj17YWRkVGFiUmVmc31cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3RhYkJ1dHRvbkNsaWNrfVxyXG4gICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICB7c3RhdHVzLm1hcCgoeCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvbkNvbXBvbmVudFxyXG4gICAgICAgICAgICAgICAgICBsYWJlbD17YCR7eC5uYW1lfSAoJHt4LmNvdW50fSlgfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCIgcC14cyBiZy1iZyBcIlxyXG4gICAgICAgICAgICAgICAgICBkYXRhLWlkPXt4LmlkfVxyXG4gICAgICAgICAgICAgICAgICBSZWY9e2FkZFRhYlJlZnN9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3RhYkJ1dHRvbkNsaWNrfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICApKX0gXHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPENhcmQuQm9keSBjbGFzc05hbWU9XCJwLW5vbmVcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYWNrYWdlc19fZnJcIj5cclxuICAgICAgICAgICAgICB7ZmlsdGVyZWRQYWNrc1xyXG4gICAgICAgICAgICAgICAgLmZpbHRlcigoeCkgPT4geC5zdGF0dXMuaWQgIT09IDYpXHJcbiAgICAgICAgICAgICAgICAubWFwKChwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxQYWNrYWdlSXRlbVxyXG4gICAgICAgICAgICAgICAgICAgIGtleT17cC5pZH1cclxuICAgICAgICAgICAgICAgICAgICBjaGVja1JlZj17YWRkQ2hlY2tSZWZzfVxyXG4gICAgICAgICAgICAgICAgICAgIGl0ZW09e3B9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGVjaz17Y2hlY2tIYW5kbGVyfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9DYXJkLkJvZHk+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvb3Rlcl9fcGNrXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGFja2FnZS10b3RhbFwiPlxyXG4gICAgICAgICAgICAgIDxzbWFsbD5cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZFBhY2thZ2VzLnBhY2thZ2VzLmxlbmd0aH0ge2YoeyBpZDogXCJjaG9zZWRcIiB9KX1cclxuICAgICAgICAgICAgICA8L3NtYWxsPlxyXG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiB9fT5cclxuICAgICAgICAgICAgICAgIDxiPntmKHsgaWQ6IFwidG90YWxcIiB9KX06PC9iPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIiB9fT5cclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsID4gMCA/IFxyXG4gICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICA8ZGVsIHN0eWxlPXt7IHRleHREZWNvcmF0aW9uQ29sb3I6IFwicmVkXCIgfX0+e3BhcnNlRmxvYXQoc2VsZWN0ZWRQYWNrYWdlcy50b3RhbCkudG9GaXhlZCgyKX0gQVpOPC9kZWw+XHJcbiAgICAgICAgICAgICAgICAgICA8Yj57cGFyc2VGbG9hdChzZWxlY3RlZFBhY2thZ2VzLmRpc2NvdW50VG90YWwpLnRvRml4ZWQoMil9IEFaTjwvYj5cclxuICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgOiAgPGI+e3BhcnNlRmxvYXQoc2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsKS50b0ZpeGVkKDIpfSBBWk48L2I+XHJcbiAgICAgICAgICAgICAgICB9ICBcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhY2thZ2VfX2J0bnNcIj5cclxuICAgICAgICAgICAgICA8Zm9ybT5cclxuICAgICAgICAgICAgICAgIDxGcm9tR3JvdXBcclxuICAgICAgICAgICAgICAgICAgYm9keUNsYXNzPVwiYmctd2hpdGUgcGwteHNcIlxyXG4gICAgICAgICAgICAgICAgICBib2R5U3R5bGU9e3sgaGVpZ2h0OiBcIjQ0cHhcIiwgd2lkdGg6IFwiMjAwcHhcIiB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtci14cyBjaG5nX19ib2R5c3R5bGVcIlxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBtYXJnaW5Cb3R0b206IFwiMHB4XCIgfX1cclxuICAgICAgICAgICAgICAgICAgZXJyb3I9e2Vycm9ycy5wcm9tb2NvZGU/Lm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtmKHsgaWQ6IFwiYWRkY29kZVwiIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwcm9tb2NvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIFJlZj17cmVnaXN0ZXIoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IGYoeyBpZDogXCJwcm9tby1yZXF1aXJcIiB9KSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRQYWNrYWdlcyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnNlbGVjdGVkUGFja2FnZXMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvZGU6IGUudGFyZ2V0LnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZFBhY2thZ2VzLmlzQWNjZXB0ZWQgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbkNvbXBvbmVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgdy01MFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZXh0RGVjb3JhdGlvbkxpbmU6IFwidW5kZXJsaW5lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcImRhcmtibHVlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IFwiMHB4IDEwcHhcIixcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkzJmcSfdiBldFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkUGFja2FnZXMoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnNlbGVjdGVkUGFja2FnZXMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaXNBY2NlcHRlZDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b25Db21wb25lbnRcclxuICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshc2VsZWN0ZWRQYWNrYWdlcy5jb2RlID8gdHJ1ZSA6IGZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgcGFkZGluZzogXCIwIDEwcHhcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY29sb3Itd2hpdGUgYmctc3VjY2Vzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbD17Zih7IGlkOiBcImNvbmZpcm1cIiB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU3VibWl0KHN1Ym1pdCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAvLyAgb25DbGljaz17KCkgPT57XHJcbiAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgLy8gIHNldFNlbGVjdGVkUGFja2FnZXMoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gICAgIC8vICAgIC4uLnNlbGVjdGVkUGFja2FnZXMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgLy8gICAgaXNBY2NlcHRlZDp0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgLy8gIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9Gcm9tR3JvdXA+XHJcbiAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDxCdXR0b25Db21wb25lbnRcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IHBhZGRpbmc6IFwiMCAyMHB4XCIgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNvbG9yLXdoaXRlIGJnLXN1Y2Nlc3MgbXIteHMgZGVza1wiXHJcbiAgICAgICAgICAgICAgICBsYWJlbD17Zih7IGlkOiBcInBheWJ5Y2FyZFwiIH0pfVxyXG4gICAgICAgICAgICAgICAgZW5kRWxlbWVudD17PHNwYW4gY2xhc3NOYW1lPVwiY29sb3Itd2hpdGUgcGwtc21cIj4mIzg1OTQ7PC9zcGFuPn1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2sgPSB7KCkgPT4gUGF5YnlDYXJkKHtcclxuICAgICAgICAgICAgICAgICAgcHJpY2U6c2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsLFxyXG4gICAgICAgICAgICAgICAgICBzb3VyY2V0eXBlOjIsXHJcbiAgICAgICAgICAgICAgICAgIGJhdGNoZXM6c2VsZWN0ZWRQYWNrYWdlcy5wYWNrYWdlc1xyXG4gICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8QnV0dG9uQ29tcG9uZW50XHJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyBwYWRkaW5nOiBcIjAgMTBweFwiIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJkZXNrXCJcclxuICAgICAgICAgICAgICAgIGxhYmVsPXtmKHsgaWQ6IFwicGF5YnliYWxhbmNlXCIgfSl9XHJcbiAgICAgICAgICAgICAgICBlbmRFbGVtZW50PXtcclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY29sb3ItYmxhY2sgbXIteHMgcGwtc20gXCI+JiM4NTk0Ozwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2sgPSB7KCkgPT4gcHJvcHMuUGF5QnlCYWxhbmNlQWN0aW9uKCdwYXltZW50Jyx7XHJcbiAgICAgICAgICAgICAgICAgIHByaWNlOnNlbGVjdGVkUGFja2FnZXMuZGlzY291bnRUb3RhbCxcclxuICAgICAgICAgICAgICAgICAgc291cmNldHlwZTozLFxyXG4gICAgICAgICAgICAgICAgICBiYXRjaGVzOnNlbGVjdGVkUGFja2FnZXMucGFja2FnZXMgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICdhdXRob3JpemF0aW9uJzpgQmVhcmVyICR7cHJvcHMuZW50cnkudXNlci5hY2Nlc3NUb2tlbn1gXHJcbiAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJ0bl9fZmtsXCI+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uQ29tcG9uZW50XHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHBhZGRpbmc6IFwiMCAxMHB4XCIgfX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY29sb3Itd2hpdGUgYmctc3VjY2VzcyBtci14c1wiXHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsPXtmKHsgaWQ6IFwicGF5YnljYXJkXCIgfSl9XHJcbiAgICAgICAgICAgICAgICAgIGVuZEVsZW1lbnQ9e1xyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNvbG9yLXdoaXRlIHBsLXNtXCI+JiM4NTk0Ozwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrID0geygpID0+IFBheWJ5Q2FyZCh7XHJcbiAgICAgICAgICAgICAgICAgICAgcHJpY2U6c2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsLFxyXG4gICAgICAgICAgICAgICAgICAgIHNvdXJjZXR5cGU6MixcclxuICAgICAgICAgICAgICAgICAgICBiYXRjaGVzOnNlbGVjdGVkUGFja2FnZXMucGFja2FnZXNcclxuICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvbkNvbXBvbmVudFxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBwYWRkaW5nOiBcIjAgMTBweFwiIH19XHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsPXtmKHsgaWQ6IFwicGF5YnliYWxhbmNlXCIgfSl9XHJcbiAgICAgICAgICAgICAgICAgIGVuZEVsZW1lbnQ9e1xyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNvbG9yLWJsYWNrIG1yLXhzIHBsLXNtXCI+JiM4NTk0Ozwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrID0geygpID0+IHByb3BzLlBheUJ5QmFsYW5jZUFjdGlvbigncGF5bWVudCcse1xyXG4gICAgICAgICAgICAgICAgICAgIHByaWNlOnNlbGVjdGVkUGFja2FnZXMuZGlzY291bnRUb3RhbCxcclxuICAgICAgICAgICAgICAgICAgICBzb3VyY2V0eXBlOjMsXHJcbiAgICAgICAgICAgICAgICAgICAgYmF0Y2hlczpzZWxlY3RlZFBhY2thZ2VzLnBhY2thZ2VzXHJcbiAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAnYXV0aG9yaXphdGlvbic6YEJlYXJlciAke3Byb3BzLmVudHJ5LnVzZXIuYWNjZXNzVG9rZW59YFxyXG4gICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9DYXJkPlxyXG5cclxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLXNtIGJnLXdoaXRlXCI+XHJcbiAgICAgICAgICA8Q2FyZC5IZWFkZXIgdGV4dD17Zih7IGlkOiBcIm9yZGVyLWhpc3RvcnlcIiB9KX0gLz5cclxuICAgICAgICAgIDxDYXJkLkJvZHkgY2xhc3NOYW1lPVwicC1ub25lIG92ZXJmbG93X19wYWNrYWdlXCI+XHJcbiAgICAgICAgICAgIDxUYWJlbFxyXG4gICAgICAgICAgICAgIHRoPXtbXHJcbiAgICAgICAgICAgICAgICBmKHsgaWQ6IFwidHJhY2tpbmdcIiB9KSxcclxuICAgICAgICAgICAgICAgIGYoeyBpZDogXCJzaG9wXCIgfSksXHJcbiAgICAgICAgICAgICAgICBmKHsgaWQ6IFwiY2F0ZWdvcnlcIiB9KSxcclxuICAgICAgICAgICAgICAgIGYoeyBpZDogXCJhbW91bnRcIiB9KSxcclxuICAgICAgICAgICAgICAgIGYoeyBpZDogXCJ3ZWlnaHRcIiB9KSxcclxuICAgICAgICAgICAgICAgIGYoeyBpZDogXCJkZWxpdmVyeVwiIH0pLFxyXG4gICAgICAgICAgICAgICAgZih7IGlkOiBcInN0YXR1c1wiIH0pLFxyXG4gICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgZGF0YT17XHJcbiAgICAgICAgICAgICAgICBwYWNrYWdlcy5tYXAoKHgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgaWYgKHguc3RhdHVzLmlkID09IDYpIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgdHJhY2tfbnVtYmVyOiB4LnRyYWNrX251bWJlcixcclxuICAgICAgICAgICAgICAgICAgICAgIHNob3A6IHguc2hvcCxcclxuICAgICAgICAgICAgICAgICAgICAgIGNhdGVnb3J5OiB4LmNhdGVnb3J5LFxyXG4gICAgICAgICAgICAgICAgICAgICAgcHJpY2U6IGAke3gucHJpY2V9ICR7eC5jdXJyZW5jeX1gLFxyXG4gICAgICAgICAgICAgICAgICAgICAgd2VpZ2h0OiBgJHtwYXJzZUZsb2F0KHgud2VpZ2h0KS50b0ZpeGVkKDIpIHx8IDB9IGtxYCxcclxuICAgICAgICAgICAgICAgICAgICAgIGRlbGl2ZXJ5X3ByaWNlOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXJzZUZsb2F0KHguZGVsaXZlcnlfcHJpY2UpLnRvRml4ZWQoMikgfHwgMCxcclxuICAgICAgICAgICAgICAgICAgICAgIHN0YXR1czogYCR7eC5zdGF0dXMubmFtZX1cXG4gJHt4LmRhdGV9YCxcclxuICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KSB8fCBbXVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICByZW5kZXJCb2R5PXsoeCwgaSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIDx0ZCBrZXk9e2krK30+e3h9PC90ZD47XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvQ2FyZC5Cb2R5PlxyXG4gICAgICAgIDwvQ2FyZD5cclxuICAgICAgPC9NYWluPlxyXG4gICAgPC9QYWdlPlxyXG4gICk7XHJcbn1cclxuXHJcbmNvbnN0IG1hcFN0YXRlVG9Qcm9wcyA9IChzdGF0ZSkgPT4gKHtcclxuICBlbnRyeTogc3RhdGUuZW50cnksXHJcbn0pO1xyXG5jb25zdCBtYXBEaXNwYXRjaFRvUHJvcHMgPSAge1xyXG4gIFBheUJ5QmFsYW5jZUFjdGlvblxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY29ubmVjdChtYXBTdGF0ZVRvUHJvcHMsIG1hcERpc3BhdGNoVG9Qcm9wcykobWVtbyhQYWNrYWdlcykpOyJdLCJzb3VyY2VSb290IjoiIn0=