webpackHotUpdate_N_E("pages/packages",{

/***/ "./components/package_item/package-item.js":
/*!*************************************************!*\
  !*** ./components/package_item/package-item.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-intl */ "./node_modules/react-intl/lib/index.js");
/* harmony import */ var _button_index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../button/index */ "./components/button/index.js");
/* harmony import */ var _checkbox_checkbox__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../checkbox/checkbox */ "./components/checkbox/checkbox.js");



var _jsxFileName = "C:\\Users\\Home\\Desktop\\166\\166-kargo\\components\\package_item\\package-item.js",
    _s = $RefreshSig$();







function PackageItem(_ref) {
  _s();

  var item = _ref.item,
      checkRef = _ref.checkRef,
      onCheck = _ref.onCheck;

  var _useIntl = Object(react_intl__WEBPACK_IMPORTED_MODULE_3__["useIntl"])(),
      f = _useIntl.formatMessage;

  var _useRouter = Object(next_router__WEBPACK_IMPORTED_MODULE_1__["useRouter"])(),
      locale = _useRouter.locale;

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "package-item mr-xs",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "package-item-header",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
        children: item.shop
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 14,
        columnNumber: 15
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h5", {
        style: {
          color: "".concat(item.status.color)
        },
        children: item.status.name
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 15
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h5", {
        style: {
          color: 'red'
        },
        children: item.pay_status
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 15
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "package-item-body",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("strong", {
              children: [f({
                id: "tracking"
              }), ":"]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 19,
              columnNumber: 26
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
              children: item.track_number
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 19,
              columnNumber: 64
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 19,
            columnNumber: 22
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("strong", {
              children: "Smart Customs ID:"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 20,
              columnNumber: 26
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
              children: item.smart_customs_id
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 20,
              columnNumber: 60
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 20,
            columnNumber: 22
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("strong", {
              children: [f({
                id: "getwhere"
              }), ":"]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 21,
              columnNumber: 26
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
              children: item.from
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 21,
              columnNumber: 64
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 21,
            columnNumber: 22
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("strong", {
              children: [f({
                id: "lastprice"
              }), ":"]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 22,
              columnNumber: 26
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
              children: [parseFloat(item.price * 0.21).toFixed(2), " AZN"]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 22,
              columnNumber: 65
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 22,
            columnNumber: 22
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("strong", {
              children: [f({
                id: "category"
              }), ":"]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 23,
              columnNumber: 26
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
              children: item.category
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 23,
              columnNumber: 64
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 23,
            columnNumber: 22
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("strong", {
              children: [f({
                id: "weight"
              }), ":"]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 24,
              columnNumber: 26
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
              children: [item.weight, " kq"]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 24,
              columnNumber: 62
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 24,
            columnNumber: 22
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("strong", {
              children: [f({
                id: "dateon"
              }), ":"]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 25,
              columnNumber: 26
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
              children: item.date
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 25,
              columnNumber: 62
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 25,
            columnNumber: 22
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 18,
          columnNumber: 18
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 17,
        columnNumber: 15
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        href: "".concat("https://166api.titr.az/storage/").concat(item.invoice),
        download: true,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_button_index__WEBPACK_IMPORTED_MODULE_4__["default"], {
          style: {
            fontSize: '10px'
          },
          className: "h-initial p-xxs w-100 bg-bg",
          label: f({
            id: "see-invoice"
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 28,
          columnNumber: 93
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 28,
        columnNumber: 15
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "package-item-footer",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "pif-amount",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
            children: f({
              id: "deliveryprice"
            })
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 31,
            columnNumber: 20
          }, this), item.customs_value_3 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
              children: [item.customs_value_3 ? parseFloat(item.customs_value_3).toFixed(2) : 0.00, " AZN"]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 35,
              columnNumber: 26
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
              style: {
                textDecorationColor: 'red'
              },
              children: [+item.delivery_price ? parseFloat(item.delivery_price).toFixed(2) : 0.00, " AZN"]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 36,
              columnNumber: 26
            }, this)]
          }, void 0, true) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
              children: [item.delivery_price ? parseFloat(+item.delivery_price).toFixed(2) : 0.00, " AZN"]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 40,
              columnNumber: 27
            }, this)
          }, void 0, false)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 30,
          columnNumber: 16
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_checkbox_checkbox__WEBPACK_IMPORTED_MODULE_5__["default"], {
          Ref: checkRef,
          onClick: onCheck,
          value: item.id,
          disabled: item.pay_status && true,
          "data-price": parseFloat(item.delivery_price).toFixed(2),
          "data-discount": parseFloat(item.customs_value_3) ? parseFloat(item.customs_value_3).toFixed(2) : 0,
          text: f({
            id: "chooseone"
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 45,
          columnNumber: 16
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 29,
        columnNumber: 15
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 13
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 11,
    columnNumber: 9
  }, this);
}

_s(PackageItem, "O5IJY/9Vtxmb/B6NsJNXuqSQp38=", false, function () {
  return [react_intl__WEBPACK_IMPORTED_MODULE_3__["useIntl"], next_router__WEBPACK_IMPORTED_MODULE_1__["useRouter"]];
});

_c = PackageItem;
/* harmony default export */ __webpack_exports__["default"] = (PackageItem);

var _c;

$RefreshReg$(_c, "PackageItem");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./pages/packages.js":
/*!***************************!*\
  !*** ./pages/packages.js ***!
  \***************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/toConsumableArray */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/regenerator */ "./node_modules/next/node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-hook-form */ "./node_modules/react-hook-form/dist/index.esm.js");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-intl */ "./node_modules/react-intl/lib/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _components_aside_menu_index__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../components/aside-menu/index */ "./components/aside-menu/index.js");
/* harmony import */ var _components_aside_aside__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../components/aside/aside */ "./components/aside/aside.js");
/* harmony import */ var _components_button__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../components/button */ "./components/button/index.js");
/* harmony import */ var _components_card_card__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../components/card/card */ "./components/card/card.js");
/* harmony import */ var _components_checkbox_checkbox__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../components/checkbox/checkbox */ "./components/checkbox/checkbox.js");
/* harmony import */ var _components_form_group_form_group__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../components/form-group/form-group */ "./components/form-group/form-group.js");
/* harmony import */ var _components_input_input__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../components/input/input */ "./components/input/input.js");
/* harmony import */ var _components_main_main__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../components/main/main */ "./components/main/main.js");
/* harmony import */ var _components_package_item_package_item__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../components/package_item/package-item */ "./components/package_item/package-item.js");
/* harmony import */ var _components_page_page__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../components/page/page */ "./components/page/page.js");
/* harmony import */ var _components_redirect_redirect__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../components/redirect/redirect */ "./components/redirect/redirect.js");
/* harmony import */ var _components_tabel_tabel__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../components/tabel/tabel */ "./components/tabel/tabel.js");
/* harmony import */ var _redux_entry_entryActions__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../redux/entry/entryActions */ "./redux/entry/entryActions.js");







var _jsxFileName = "C:\\Users\\Home\\Desktop\\166\\166-kargo\\pages\\packages.js",
    _s = $RefreshSig$();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }





















function Packages(props) {
  _s();

  var _this = this,
      _errors$promocode;

  if (!props.entry.isLoged) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_redirect_redirect__WEBPACK_IMPORTED_MODULE_21__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 23,
      columnNumber: 12
    }, this);
  }

  var _useForm = Object(react_hook_form__WEBPACK_IMPORTED_MODULE_8__["useForm"])(),
      register = _useForm.register,
      handleSubmit = _useForm.handleSubmit,
      errors = _useForm.errors,
      setError = _useForm.setError;

  var _useIntl = Object(react_intl__WEBPACK_IMPORTED_MODULE_9__["useIntl"])(),
      f = _useIntl.formatMessage;

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])([]),
      packages = _useState[0],
      setPackages = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])([]),
      filteredPacks = _useState2[0],
      setFilteredPacks = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])([]),
      status = _useState3[0],
      setStatus = _useState3[1];

  var _useState4 = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])({
    packages: [],
    total: 0,
    discountTotal: 0,
    code: "",
    isAccepted: false,
    status: 0
  }),
      selectedPackages = _useState4[0],
      setSelectedPackages = _useState4[1];

  var _useRouter = Object(next_router__WEBPACK_IMPORTED_MODULE_6__["useRouter"])(),
      locale = _useRouter.locale;

  var mainCheckRef = Object(react__WEBPACK_IMPORTED_MODULE_7__["useRef"])();
  var checkRefs = Object(react__WEBPACK_IMPORTED_MODULE_7__["useRef"])([]);
  checkRefs.current = [];
  var tabRefs = Object(react__WEBPACK_IMPORTED_MODULE_7__["useRef"])([]);
  tabRefs.current = [];

  var submit = function submit(data) {
    console.log(data);
    axios__WEBPACK_IMPORTED_MODULE_5___default.a.post("".concat("https://166api.titr.az/api/", "promocode?promocode=").concat(data.promocode, "&status=").concat(selectedPackages.status), {}, {
      headers: {
        "content-type": "application/json",
        authorization: "Bearer ".concat(props.entry.user.accessToken)
      }
    }).then(function (res) {
      console.log(res.data.batches);
      setPackages(res.data.batches);
      setFilteredPacks(res.data.batches);
    })["catch"](function (err) {
      setError("promocode", {
        message: err.response.data.error
      });
    });
  };

  var PromisAll = /*#__PURE__*/function () {
    var _ref = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_4__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.mark(function _callee() {
      var batchesData, statusData;
      return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return axios__WEBPACK_IMPORTED_MODULE_5___default.a.get("".concat("https://166api.titr.az/api/", "batches?lan=").concat(locale), {
                headers: {
                  authorization: "Bearer ".concat(props.entry.user.accessToken)
                }
              });

            case 2:
              batchesData = _context.sent;
              _context.next = 5;
              return axios__WEBPACK_IMPORTED_MODULE_5___default.a.get("".concat("https://166api.titr.az/api/", "status?lan=").concat(locale), {
                headers: {
                  authorization: "Bearer ".concat(props.entry.user.accessToken)
                }
              });

            case 5:
              statusData = _context.sent;
              return _context.abrupt("return", {
                batchesData: batchesData.data,
                statusData: statusData.data
              });

            case 7:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function PromisAll() {
      return _ref.apply(this, arguments);
    };
  }();

  Object(react__WEBPACK_IMPORTED_MODULE_7__["useLayoutEffect"])(function () {
    PromisAll().then(function (res) {
      console.log(res);
      setPackages(res.batchesData);
      setFilteredPacks(res.batchesData);
      setStatus(res.statusData);
    })["catch"](function (err) {
      return console.log(err);
    });
  }, []);

  var addTabRefs = function addTabRefs(ref) {
    if (ref && !tabRefs.current.includes(ref)) {
      tabRefs.current.push(ref);
    }
  };

  var toggleTabRefs = /*#__PURE__*/function () {
    var _ref2 = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_4__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.mark(function _callee2(ev) {
      return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              tabRefs.current.forEach(function (x) {
                return x.classList.remove("pack-active");
              });
              ev.target.classList.add("pack-active");

            case 2:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2);
    }));

    return function toggleTabRefs(_x) {
      return _ref2.apply(this, arguments);
    };
  }();

  var getBatchesByStatausId = /*#__PURE__*/function () {
    var _ref3 = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_4__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.mark(function _callee3(id) {
      return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.wrap(function _callee3$(_context3) {
        while (1) {
          switch (_context3.prev = _context3.next) {
            case 0:
              axios__WEBPACK_IMPORTED_MODULE_5___default.a.get("".concat("https://166api.titr.az/api/", "batches?status=").concat(id, "&lan=").concat(locale), {
                headers: {
                  authorization: "Bearer ".concat(props.entry.user.accessToken)
                }
              }).then(function (res) {
                setPackages(res.data);
                setFilteredPacks(res.data);
              })["catch"](function (err) {
                return console.log(err);
              });

            case 1:
            case "end":
              return _context3.stop();
          }
        }
      }, _callee3);
    }));

    return function getBatchesByStatausId(_x2) {
      return _ref3.apply(this, arguments);
    };
  }();

  var tabButtonClick = function tabButtonClick(ev) {
    var id = ev.target.getAttribute("data-id");
    toggleTabRefs(ev);
    getBatchesByStatausId(id);

    if (id != 0) {
      var newPackages = packages.filter(function (x) {
        return x.status.id == id;
      });
      setFilteredPacks(Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(newPackages));
    } else {
      setFilteredPacks(Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(packages));
    }

    setSelectedPackages({
      discountTotal: 0,
      packages: [],
      total: 0,
      code: "",
      isAccepted: false,
      status: id
    });
  };

  var addCheckRefs = function addCheckRefs(ref) {
    if (ref && !checkRefs.current.includes(ref)) {
      checkRefs.current.push(ref);
    }
  };

  var checkHandler = function checkHandler(ev) {
    var _ev$target = ev.target,
        value = _ev$target.value,
        checked = _ev$target.checked;
    var price = ev.target.getAttribute("data-price");
    var dataDiscount = ev.target.getAttribute("data-discount");
    var total = 0;
    var disc = 0;
    console.log('dis', dataDiscount);

    if (checked) {
      selectedPackages.packages.push(value);

      if (dataDiscount != 0) {
        setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
          total: selectedPackages.total + parseFloat(price),
          discountTotal: selectedPackages.discountTotal + parseFloat(dataDiscount),
          packages: Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(selectedPackages.packages)
        }));
      } else {
        setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
          discountTotal: selectedPackages.discountTotal + parseFloat(price),
          total: selectedPackages.total + parseFloat(price),
          packages: Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(selectedPackages.packages)
        }));
      }
    } else {
      var newPackages = selectedPackages.packages.filter(function (x) {
        return x !== value;
      });

      if (dataDiscount != 0) {
        setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
          total: selectedPackages.total >= 0 && selectedPackages.total - parseFloat(price),
          discountTotal: selectedPackages.discountTotal >= 0 && selectedPackages.discountTotal - parseFloat(dataDiscount),
          packages: newPackages
        }));
      } else {
        setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
          discountTotal: selectedPackages.discountTotal >= 0 && selectedPackages.discountTotal - parseFloat(price),
          total: selectedPackages.total >= 0 && selectedPackages.total - parseFloat(price),
          packages: newPackages
        }));
      }
    }

    !selectedPackages.packages.some(function (x) {
      return x;
    }) ? mainCheckRef.current.checked = false : null;
  };

  var selectAll = function selectAll(e) {
    var total = 0;
    var discountTotal = 0;
    var packages = [];
    checkRefs.current.forEach(function (x) {
      x.checked = e.target.checked;

      if (e.target.checked && !packages.includes(x.value)) {
        packages.push(x.value);
        total += +x.getAttribute("data-price");
        discountTotal += +x.getAttribute("data-discount");
      } else {
        packages = packages.filter(function (p) {
          return p !== x.value;
        });
        total -= total >= 0 && +x.getAttribute("data-price");
        discountTotal -= discountTotal >= 0 && +x.getAttribute("data-discount");
      }
    });
    setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
      total: selectedPackages.total - total,
      packages: packages
    }));
  };

  var PaybyCard = function PaybyCard() {
    var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    axios__WEBPACK_IMPORTED_MODULE_5___default.a.post("".concat("https://166api.titr.az/api/", "payment"), data, {
      headers: {
        authorization: "Bearer ".concat(props.entry.user.accessToken)
      }
    }).then(function (res) {
      console.log('red', res.data.url);
      window.location.href = res.data.url;
    })["catch"](function (err) {
      return console.log(err);
    });
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_page_page__WEBPACK_IMPORTED_MODULE_20__["default"], {
    className: "bg-bg pt-lg pb-lg",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_aside_aside__WEBPACK_IMPORTED_MODULE_12__["default"], {
      className: "mr-sm",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_aside_menu_index__WEBPACK_IMPORTED_MODULE_11__["default"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 244,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 243,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_main_main__WEBPACK_IMPORTED_MODULE_18__["default"], {
      className: "bg-c p-none",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"], {
        className: "bg-bg pb-sm mgm_ss p-sm",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"].Header, {
          text: f({
            id: "active-pac"
          }),
          endElelment: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_checkbox_checkbox__WEBPACK_IMPORTED_MODULE_15__["default"], {
            text: f({
              id: "choose-all"
            }),
            Ref: function Ref(ref) {
              return mainCheckRef.current = ref;
            },
            onClick: selectAll,
            className: "bg-white border-subtitle"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 251,
            columnNumber: 15
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 248,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          "class": "ssc",
          style: {
            overflowX: "scroll"
          },
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: " pl-none",
            style: {
              display: "flex",
              marginBottom: "20px",
              width: "max-content"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
              label: "Hams\u0131 (".concat(packages.length, ")"),
              className: "mr-xs p-sm bg-bg pack-active",
              "data-id": 0,
              Ref: addTabRefs,
              onClick: tabButtonClick
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 269,
              columnNumber: 15
            }, this), status.map(function (x) {
              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                label: "".concat(x.name, " (").concat(x.count, ")"),
                className: " p-sm bg-bg ",
                "data-id": x.id,
                Ref: addTabRefs,
                onClick: tabButtonClick
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 278,
                columnNumber: 17
              }, _this);
            })]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 260,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 259,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"].Body, {
          className: "p-none",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "packages__fr",
            children: filteredPacks.filter(function (x) {
              return x.status.id !== 6;
            }).map(function (p) {
              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_package_item_package_item__WEBPACK_IMPORTED_MODULE_19__["default"], {
                checkRef: addCheckRefs,
                item: p,
                onCheck: checkHandler
              }, p.id, false, {
                fileName: _jsxFileName,
                lineNumber: 296,
                columnNumber: 19
              }, _this);
            })
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 292,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 291,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "footer__pck",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "package-total",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
              children: [selectedPackages.packages.length, " ", f({
                id: "chosed"
              })]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 307,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                display: "flex",
                justifyContent: "space-between"
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                children: [f({
                  id: "total"
                }), ":"]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 311,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                style: {
                  display: "flex",
                  flexDirection: "column"
                },
                children: selectedPackages.discountTotal > 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
                    style: {
                      textDecorationColor: "red"
                    },
                    children: [parseFloat(selectedPackages.total).toFixed(2), " AZN"]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 316,
                    columnNumber: 19
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                    children: [parseFloat(selectedPackages.discountTotal).toFixed(2), " AZN"]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 317,
                    columnNumber: 20
                  }, this)]
                }, void 0, true) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                  children: [parseFloat(selectedPackages.discountTotal).toFixed(2), " AZN"]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 319,
                  columnNumber: 23
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 312,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 310,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 306,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "package__btns",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("form", {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_form_group_form_group__WEBPACK_IMPORTED_MODULE_16__["default"], {
                bodyClass: "bg-white pl-xs",
                bodyStyle: {
                  height: "44px",
                  width: "200px"
                },
                className: "mr-xs chng__bodystyle",
                style: {
                  marginBottom: "0px"
                },
                error: (_errors$promocode = errors.promocode) === null || _errors$promocode === void 0 ? void 0 : _errors$promocode.message,
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_input_input__WEBPACK_IMPORTED_MODULE_17__["default"], {
                  placeholder: f({
                    id: "addcode"
                  }),
                  name: "promocode",
                  Ref: register({
                    required: {
                      value: true,
                      message: f({
                        id: "promo-requir"
                      })
                    }
                  }),
                  onChange: function onChange(e) {
                    return setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
                      code: e.target.value
                    }));
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 335,
                  columnNumber: 19
                }, this), selectedPackages.isAccepted ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                  className: "bg-white w-50",
                  style: {
                    textDecorationLine: "underline",
                    color: "darkblue",
                    padding: "0px 10px"
                  },
                  label: "L\u0259\u011Fv et",
                  onClick: function onClick() {
                    setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
                      isAccepted: false
                    }));
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 352,
                  columnNumber: 21
                }, this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                  disabled: !selectedPackages.code ? true : false,
                  style: {
                    padding: "0 10px"
                  },
                  className: "color-white bg-success",
                  label: f({
                    id: "confirm"
                  }),
                  type: "submit",
                  onClick: handleSubmit(submit) //  onClick={() =>{
                  //     //  setSelectedPackages({
                  //     //    ...selectedPackages,
                  //     //    isAccepted:true
                  //     //  });
                  //    }}

                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 368,
                  columnNumber: 21
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 328,
                columnNumber: 17
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 327,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
              style: {
                padding: "0 20px"
              },
              className: "color-white bg-success mr-xs desk",
              label: f({
                id: "paybycard"
              }),
              endElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                className: "color-white pl-sm",
                children: "\u2192"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 390,
                columnNumber: 29
              }, this),
              onClick: function onClick() {
                return PaybyCard({
                  price: selectedPackages.discountTotal,
                  sourcetype: 2,
                  batches: selectedPackages.packages
                });
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 386,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
              style: {
                padding: "0 10px"
              },
              className: "desk",
              label: f({
                id: "paybybalance"
              }),
              endElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                className: "color-black mr-xs pl-sm ",
                children: "\u2192"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 402,
                columnNumber: 19
              }, this),
              onClick: function onClick() {
                return props.PayByBalanceAction('payment', {
                  price: selectedPackages.discountTotal,
                  sourcetype: 3,
                  batches: selectedPackages.packages
                }, {
                  'authorization': "Bearer ".concat(props.entry.user.accessToken)
                });
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 397,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "btn__fkl",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                style: {
                  padding: "0 10px"
                },
                className: "color-white bg-success mr-xs",
                label: f({
                  id: "paybycard"
                }),
                endElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "color-white pl-sm",
                  children: "\u2192"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 420,
                  columnNumber: 21
                }, this),
                onClick: function onClick() {
                  return PaybyCard({
                    price: selectedPackages.discountTotal,
                    sourcetype: 2,
                    batches: selectedPackages.packages
                  });
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 415,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                style: {
                  padding: "0 10px"
                },
                label: f({
                  id: "paybybalance"
                }),
                endElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "color-black mr-xs pl-sm",
                  children: "\u2192"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 432,
                  columnNumber: 21
                }, this),
                onClick: function onClick() {
                  return props.PayByBalanceAction('payment', {
                    price: selectedPackages.discountTotal,
                    sourcetype: 3,
                    batches: selectedPackages.packages
                  }, {
                    'authorization': "Bearer ".concat(props.entry.user.accessToken)
                  });
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 428,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 414,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 326,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 305,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 247,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"], {
        className: "p-sm bg-white",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"].Header, {
          text: f({
            id: "order-history"
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 449,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"].Body, {
          className: "p-none overflow__package",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_tabel_tabel__WEBPACK_IMPORTED_MODULE_22__["default"], {
            th: [f({
              id: "tracking"
            }), f({
              id: "shop"
            }), f({
              id: "category"
            }), f({
              id: "amount"
            }), f({
              id: "weight"
            }), f({
              id: "delivery"
            }), f({
              id: "status"
            })],
            data: packages.map(function (x) {
              if (x.status.id == 6) {
                return {
                  track_number: x.track_number,
                  shop: x.shop,
                  category: x.category,
                  price: "".concat(x.price, " ").concat(x.currency),
                  weight: "".concat(parseFloat(x.weight).toFixed(2) || 0, " kq"),
                  delivery_price: parseFloat(x.delivery_price).toFixed(2) || 0,
                  status: "".concat(x.status.name, "\n ").concat(x.date)
                };
              }
            }) || [],
            renderBody: function renderBody(x, i) {
              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {
                children: x
              }, i++, false, {
                fileName: _jsxFileName,
                lineNumber: 478,
                columnNumber: 24
              }, _this);
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 451,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 450,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 448,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 246,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 242,
    columnNumber: 5
  }, this);
}

_s(Packages, "3E201Kyf6S2uVJ0+DS1LdJkJE1g=", false, function () {
  return [react_hook_form__WEBPACK_IMPORTED_MODULE_8__["useForm"], react_intl__WEBPACK_IMPORTED_MODULE_9__["useIntl"], next_router__WEBPACK_IMPORTED_MODULE_6__["useRouter"]];
});

_c = Packages;

var mapStateToProps = function mapStateToProps(state) {
  return {
    entry: state.entry
  };
};

var mapDispatchToProps = {
  PayByBalanceAction: _redux_entry_entryActions__WEBPACK_IMPORTED_MODULE_23__["PayByBalanceAction"]
};
/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_10__["connect"])(mapStateToProps, mapDispatchToProps)( /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_7__["memo"])(Packages)));

var _c;

$RefreshReg$(_c, "Packages");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./redux/entry/entryActions.js":
/*!*************************************!*\
  !*** ./redux/entry/entryActions.js ***!
  \*************************************/
/*! exports provided: Login, UserRegister, LogOut, UpdateUser, PayByBalanceAction, IncreaseBalanceAction */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Login", function() { return Login; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserRegister", function() { return UserRegister; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogOut", function() { return LogOut; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UpdateUser", function() { return UpdateUser; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PayByBalanceAction", function() { return PayByBalanceAction; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IncreaseBalanceAction", function() { return IncreaseBalanceAction; });
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/regenerator */ "./node_modules/next/node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! sweetalert2 */ "./node_modules/sweetalert2/dist/sweetalert2.all.js");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./actions */ "./redux/entry/actions.js");






var Login = function Login(url, data) {
  var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return function (dispatch) {
    axios__WEBPACK_IMPORTED_MODULE_2___default.a.post("".concat("https://166api.titr.az/api/").concat(url), data, {
      headers: headers
    }).then( /*#__PURE__*/function () {
      var _ref = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(res) {
        var data;
        return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return res.data;

              case 2:
                data = _context.sent;
                dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["login"])(data));
                next_router__WEBPACK_IMPORTED_MODULE_3___default.a.push('/packages');

              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));

      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }())["catch"](function (errors) {
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["login"])({
        isError: true,
        errors: errors.response.data
      }));
    });
  };
};
var UserRegister = function UserRegister(url, data) {
  var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return function (dispatch) {
    axios__WEBPACK_IMPORTED_MODULE_2___default.a.post("".concat("https://166api.titr.az/api/").concat(url), data, {
      headers: headers
    }).then( /*#__PURE__*/function () {
      var _ref2 = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2(res) {
        var data;
        return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                sweetalert2__WEBPACK_IMPORTED_MODULE_4___default.a.fire({
                  text: 'Əməliyyat uğurla tamamlandı',
                  icon: 'success',
                  confirmButtonText: 'OK'
                }).then(function (res) {
                  if (res.isConfirmed) {
                    next_router__WEBPACK_IMPORTED_MODULE_3___default.a.push('/myaddresses');
                  }
                });
                _context2.next = 3;
                return res.data;

              case 3:
                data = _context2.sent;
                dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["register"])(data));

              case 5:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }));

      return function (_x2) {
        return _ref2.apply(this, arguments);
      };
    }())["catch"](function (err) {
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["register"])({
        isError: true,
        errors: err.response.data
      }));
    });
  };
};
var LogOut = function LogOut() {
  return function (dispatch) {
    console.log('wordek logout');
    dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["logout"])());
  };
};
var UpdateUser = function UpdateUser(url, data) {
  var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return function (dispatch) {
    axios__WEBPACK_IMPORTED_MODULE_2___default.a.put("".concat("https://166api.titr.az/api/").concat(url), data, {
      headers: headers
    }).then(function (res) {
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["updateUser"])(res.data));
      sweetalert2__WEBPACK_IMPORTED_MODULE_4___default.a.fire({
        text: 'Əməliyyat uğurla yerinə yetirildi',
        icon: 'success',
        confirmButtonText: 'OK'
      });
    })["catch"](function (err) {
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["updateUser"])({
        isError: true,
        errors: err.response.data
      }));
    });
  };
};
var PayByBalanceAction = function PayByBalanceAction(url, data, headers) {
  return function (dispatch) {
    axios__WEBPACK_IMPORTED_MODULE_2___default.a.post("".concat("https://166api.titr.az/api/").concat(url), data, {
      headers: headers
    }).then(function (res) {
      if (res.status == 'success') {
        sweetalert2__WEBPACK_IMPORTED_MODULE_4___default.a.fire({
          text: res.data.message,
          icon: 'success',
          confirmButtonText: 'OK'
        });
        dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["PayByBalance"])(data.balance));
      }
    })["catch"](function (err) {
      return console.log(err);
    });
  };
};
var IncreaseBalanceAction = function IncreaseBalanceAction(balance) {
  return function (dispatch) {
    dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["IncreaseBalance"])(balance));
  };
};

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9wYWNrYWdlX2l0ZW0vcGFja2FnZS1pdGVtLmpzIiwid2VicGFjazovL19OX0UvLi9wYWdlcy9wYWNrYWdlcy5qcyIsIndlYnBhY2s6Ly9fTl9FLy4vcmVkdXgvZW50cnkvZW50cnlBY3Rpb25zLmpzIl0sIm5hbWVzIjpbIlBhY2thZ2VJdGVtIiwiaXRlbSIsImNoZWNrUmVmIiwib25DaGVjayIsInVzZUludGwiLCJmIiwiZm9ybWF0TWVzc2FnZSIsInVzZVJvdXRlciIsImxvY2FsZSIsInNob3AiLCJjb2xvciIsInN0YXR1cyIsIm5hbWUiLCJwYXlfc3RhdHVzIiwiaWQiLCJ0cmFja19udW1iZXIiLCJzbWFydF9jdXN0b21zX2lkIiwiZnJvbSIsInBhcnNlRmxvYXQiLCJwcmljZSIsInRvRml4ZWQiLCJjYXRlZ29yeSIsIndlaWdodCIsImRhdGUiLCJwcm9jZXNzIiwiaW52b2ljZSIsImZvbnRTaXplIiwiY3VzdG9tc192YWx1ZV8zIiwidGV4dERlY29yYXRpb25Db2xvciIsImRlbGl2ZXJ5X3ByaWNlIiwiUGFja2FnZXMiLCJwcm9wcyIsImVudHJ5IiwiaXNMb2dlZCIsInVzZUZvcm0iLCJyZWdpc3RlciIsImhhbmRsZVN1Ym1pdCIsImVycm9ycyIsInNldEVycm9yIiwidXNlU3RhdGUiLCJwYWNrYWdlcyIsInNldFBhY2thZ2VzIiwiZmlsdGVyZWRQYWNrcyIsInNldEZpbHRlcmVkUGFja3MiLCJzZXRTdGF0dXMiLCJ0b3RhbCIsImRpc2NvdW50VG90YWwiLCJjb2RlIiwiaXNBY2NlcHRlZCIsInNlbGVjdGVkUGFja2FnZXMiLCJzZXRTZWxlY3RlZFBhY2thZ2VzIiwibWFpbkNoZWNrUmVmIiwidXNlUmVmIiwiY2hlY2tSZWZzIiwiY3VycmVudCIsInRhYlJlZnMiLCJzdWJtaXQiLCJkYXRhIiwiY29uc29sZSIsImxvZyIsImF4aW9zIiwicG9zdCIsInByb21vY29kZSIsImhlYWRlcnMiLCJhdXRob3JpemF0aW9uIiwidXNlciIsImFjY2Vzc1Rva2VuIiwidGhlbiIsInJlcyIsImJhdGNoZXMiLCJlcnIiLCJtZXNzYWdlIiwicmVzcG9uc2UiLCJlcnJvciIsIlByb21pc0FsbCIsImdldCIsImJhdGNoZXNEYXRhIiwic3RhdHVzRGF0YSIsInVzZUxheW91dEVmZmVjdCIsImFkZFRhYlJlZnMiLCJyZWYiLCJpbmNsdWRlcyIsInB1c2giLCJ0b2dnbGVUYWJSZWZzIiwiZXYiLCJmb3JFYWNoIiwieCIsImNsYXNzTGlzdCIsInJlbW92ZSIsInRhcmdldCIsImFkZCIsImdldEJhdGNoZXNCeVN0YXRhdXNJZCIsInRhYkJ1dHRvbkNsaWNrIiwiZ2V0QXR0cmlidXRlIiwibmV3UGFja2FnZXMiLCJmaWx0ZXIiLCJhZGRDaGVja1JlZnMiLCJjaGVja0hhbmRsZXIiLCJ2YWx1ZSIsImNoZWNrZWQiLCJkYXRhRGlzY291bnQiLCJkaXNjIiwic29tZSIsInNlbGVjdEFsbCIsImUiLCJwIiwiUGF5YnlDYXJkIiwidXJsIiwid2luZG93IiwibG9jYXRpb24iLCJocmVmIiwib3ZlcmZsb3dYIiwiZGlzcGxheSIsIm1hcmdpbkJvdHRvbSIsIndpZHRoIiwibGVuZ3RoIiwibWFwIiwiY291bnQiLCJqdXN0aWZ5Q29udGVudCIsImZsZXhEaXJlY3Rpb24iLCJoZWlnaHQiLCJyZXF1aXJlZCIsInRleHREZWNvcmF0aW9uTGluZSIsInBhZGRpbmciLCJzb3VyY2V0eXBlIiwiUGF5QnlCYWxhbmNlQWN0aW9uIiwiY3VycmVuY3kiLCJpIiwibWFwU3RhdGVUb1Byb3BzIiwic3RhdGUiLCJtYXBEaXNwYXRjaFRvUHJvcHMiLCJjb25uZWN0IiwibWVtbyIsIkxvZ2luIiwiZGlzcGF0Y2giLCJsb2dpbiIsInJvdXRlciIsImlzRXJyb3IiLCJVc2VyUmVnaXN0ZXIiLCJTd2FsIiwiZmlyZSIsInRleHQiLCJpY29uIiwiY29uZmlybUJ1dHRvblRleHQiLCJpc0NvbmZpcm1lZCIsIkxvZ091dCIsImxvZ291dCIsIlVwZGF0ZVVzZXIiLCJwdXQiLCJ1cGRhdGVVc2VyIiwiUGF5QnlCYWxhbmNlIiwiYmFsYW5jZSIsIkluY3JlYXNlQmFsYW5jZUFjdGlvbiIsIkluY3JlYXNlQmFsYW5jZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFNBQVNBLFdBQVQsT0FBOEM7QUFBQTs7QUFBQSxNQUF4QkMsSUFBd0IsUUFBeEJBLElBQXdCO0FBQUEsTUFBbkJDLFFBQW1CLFFBQW5CQSxRQUFtQjtBQUFBLE1BQVZDLE9BQVUsUUFBVkEsT0FBVTs7QUFBQSxpQkFDYkMsMERBQU8sRUFETTtBQUFBLE1BQ25CQyxDQURtQixZQUNsQ0MsYUFEa0M7O0FBQUEsbUJBRXpCQyw2REFBUyxFQUZnQjtBQUFBLE1BRW5DQyxNQUZtQyxjQUVuQ0EsTUFGbUM7O0FBRzFDLHNCQUNJO0FBQUssYUFBUyxFQUFDLG9CQUFmO0FBQUEsMkJBQ0k7QUFBSyxlQUFTLEVBQUMscUJBQWY7QUFBQSw4QkFFRTtBQUFBLGtCQUFLUCxJQUFJLENBQUNRO0FBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGLGVBR0U7QUFBSSxhQUFLLEVBQUU7QUFBQ0MsZUFBSyxZQUFJVCxJQUFJLENBQUNVLE1BQUwsQ0FBWUQsS0FBaEI7QUFBTixTQUFYO0FBQUEsa0JBQTRDVCxJQUFJLENBQUNVLE1BQUwsQ0FBWUM7QUFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUhGLGVBSUU7QUFBSSxhQUFLLEVBQUU7QUFBQ0YsZUFBSyxFQUFDO0FBQVAsU0FBWDtBQUFBLGtCQUEyQlQsSUFBSSxDQUFDWTtBQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSkYsZUFLRTtBQUFLLGlCQUFTLEVBQUMsbUJBQWY7QUFBQSwrQkFDRztBQUFBLGtDQUNJO0FBQUEsb0NBQUk7QUFBQSx5QkFBU1IsQ0FBQyxDQUFDO0FBQUNTLGtCQUFFLEVBQUM7QUFBSixlQUFELENBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUFKLGVBQTBDO0FBQUEsd0JBQVFiLElBQUksQ0FBQ2M7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREosZUFFSTtBQUFBLG9DQUFJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUFKLGVBQXNDO0FBQUEsd0JBQVFkLElBQUksQ0FBQ2U7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRkosZUFHSTtBQUFBLG9DQUFJO0FBQUEseUJBQVNYLENBQUMsQ0FBQztBQUFDUyxrQkFBRSxFQUFDO0FBQUosZUFBRCxDQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFBSixlQUEwQztBQUFBLHdCQUFRYixJQUFJLENBQUNnQjtBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFISixlQUlJO0FBQUEsb0NBQUk7QUFBQSx5QkFBU1osQ0FBQyxDQUFDO0FBQUNTLGtCQUFFLEVBQUM7QUFBSixlQUFELENBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUFKLGVBQTJDO0FBQUEseUJBQVFJLFVBQVUsQ0FBQ2pCLElBQUksQ0FBQ2tCLEtBQUwsR0FBVyxJQUFaLENBQVYsQ0FBNEJDLE9BQTVCLENBQW9DLENBQXBDLENBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSkosZUFLSTtBQUFBLG9DQUFJO0FBQUEseUJBQVNmLENBQUMsQ0FBQztBQUFDUyxrQkFBRSxFQUFDO0FBQUosZUFBRCxDQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFBSixlQUEwQztBQUFBLHdCQUFRYixJQUFJLENBQUNvQjtBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFMSixlQU1JO0FBQUEsb0NBQUk7QUFBQSx5QkFBU2hCLENBQUMsQ0FBQztBQUFDUyxrQkFBRSxFQUFDO0FBQUosZUFBRCxDQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFBSixlQUF3QztBQUFBLHlCQUFRYixJQUFJLENBQUNxQixNQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU5KLGVBT0k7QUFBQSxvQ0FBSTtBQUFBLHlCQUFTakIsQ0FBQyxDQUFDO0FBQUNTLGtCQUFFLEVBQUM7QUFBSixlQUFELENBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUFKLGVBQXdDO0FBQUEsd0JBQVFiLElBQUksQ0FBQ3NCO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FMRixlQWdCRTtBQUFHLFlBQUksWUFBS0MsaUNBQUwsU0FBNkN2QixJQUFJLENBQUN3QixPQUFsRCxDQUFQO0FBQW9FLGdCQUFRLE1BQTVFO0FBQUEsK0JBQThFLHFFQUFDLHFEQUFEO0FBQWlCLGVBQUssRUFBRTtBQUFDQyxvQkFBUSxFQUFDO0FBQVYsV0FBeEI7QUFBMkMsbUJBQVMsRUFBQyw2QkFBckQ7QUFBbUYsZUFBSyxFQUFFckIsQ0FBQyxDQUFDO0FBQUNTLGNBQUUsRUFBQztBQUFKLFdBQUQ7QUFBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBaEJGLGVBaUJFO0FBQUssaUJBQVMsRUFBQyxxQkFBZjtBQUFBLGdDQUNDO0FBQUssbUJBQVMsRUFBQyxZQUFmO0FBQUEsa0NBQ0k7QUFBQSxzQkFBT1QsQ0FBQyxDQUFDO0FBQUNTLGdCQUFFLEVBQUM7QUFBSixhQUFEO0FBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFESixFQUdRYixJQUFJLENBQUMwQixlQUFMLGdCQUNBO0FBQUEsb0NBQ0U7QUFBQSx5QkFBTzFCLElBQUksQ0FBQzBCLGVBQUwsR0FBdUJULFVBQVUsQ0FBQ2pCLElBQUksQ0FBQzBCLGVBQU4sQ0FBVixDQUFpQ1AsT0FBakMsQ0FBeUMsQ0FBekMsQ0FBdkIsR0FBcUUsSUFBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQURGLGVBRUU7QUFBSyxtQkFBSyxFQUFFO0FBQUNRLG1DQUFtQixFQUFDO0FBQXJCLGVBQVo7QUFBQSx5QkFBMkMsQ0FBQzNCLElBQUksQ0FBQzRCLGNBQU4sR0FBdUJYLFVBQVUsQ0FBQ2pCLElBQUksQ0FBQzRCLGNBQU4sQ0FBVixDQUFnQ1QsT0FBaEMsQ0FBd0MsQ0FBeEMsQ0FBdkIsR0FBb0UsSUFBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUZGO0FBQUEsMEJBREEsZ0JBTUE7QUFBQSxtQ0FDRztBQUFBLHlCQUFPbkIsSUFBSSxDQUFDNEIsY0FBTCxHQUFzQlgsVUFBVSxDQUFDLENBQUNqQixJQUFJLENBQUM0QixjQUFQLENBQVYsQ0FBaUNULE9BQWpDLENBQXlDLENBQXpDLENBQXRCLEdBQW9FLElBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURILDJCQVRSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERCxlQWdCQyxxRUFBQywwREFBRDtBQUNHLGFBQUcsRUFBRWxCLFFBRFI7QUFFRyxpQkFBTyxFQUFFQyxPQUZaO0FBR0csZUFBSyxFQUFFRixJQUFJLENBQUNhLEVBSGY7QUFJRyxrQkFBUSxFQUFFYixJQUFJLENBQUNZLFVBQUwsSUFBbUIsSUFKaEM7QUFLRyx3QkFDS0ssVUFBVSxDQUFDakIsSUFBSSxDQUFDNEIsY0FBTixDQUFWLENBQWdDVCxPQUFoQyxDQUF3QyxDQUF4QyxDQU5SO0FBUUssMkJBQ0lGLFVBQVUsQ0FBQ2pCLElBQUksQ0FBQzBCLGVBQU4sQ0FBVixHQUFtQ1QsVUFBVSxDQUFDakIsSUFBSSxDQUFDMEIsZUFBTixDQUFWLENBQWlDUCxPQUFqQyxDQUF5QyxDQUF6QyxDQUFuQyxHQUNDLENBVlY7QUFZRyxjQUFJLEVBQUVmLENBQUMsQ0FBQztBQUFDUyxjQUFFLEVBQUM7QUFBSixXQUFEO0FBWlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFoQkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFESjtBQW9ESDs7R0F2RFFkLFc7VUFDd0JJLGtELEVBQ1pHLHFEOzs7S0FGWlAsVztBQXlETUEsMEVBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQy9EQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxTQUFTOEIsUUFBVCxDQUFrQkMsS0FBbEIsRUFBeUI7QUFBQTs7QUFBQTtBQUFBOztBQUN2QixNQUFJLENBQUNBLEtBQUssQ0FBQ0MsS0FBTixDQUFZQyxPQUFqQixFQUEwQjtBQUN4Qix3QkFBTyxxRUFBQyxzRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQVA7QUFDRDs7QUFIc0IsaUJBSzhCQywrREFBTyxFQUxyQztBQUFBLE1BS2ZDLFFBTGUsWUFLZkEsUUFMZTtBQUFBLE1BS0xDLFlBTEssWUFLTEEsWUFMSztBQUFBLE1BS1NDLE1BTFQsWUFLU0EsTUFMVDtBQUFBLE1BS2lCQyxRQUxqQixZQUtpQkEsUUFMakI7O0FBQUEsaUJBTU1sQywwREFBTyxFQU5iO0FBQUEsTUFNQUMsQ0FOQSxZQU1mQyxhQU5lOztBQUFBLGtCQU9TaUMsc0RBQVEsQ0FBQyxFQUFELENBUGpCO0FBQUEsTUFPaEJDLFFBUGdCO0FBQUEsTUFPTkMsV0FQTTs7QUFBQSxtQkFRbUJGLHNEQUFRLENBQUMsRUFBRCxDQVIzQjtBQUFBLE1BUWhCRyxhQVJnQjtBQUFBLE1BUURDLGdCQVJDOztBQUFBLG1CQVNLSixzREFBUSxDQUFDLEVBQUQsQ0FUYjtBQUFBLE1BU2hCNUIsTUFUZ0I7QUFBQSxNQVNSaUMsU0FUUTs7QUFBQSxtQkFVeUJMLHNEQUFRLENBQUM7QUFDdkRDLFlBQVEsRUFBRSxFQUQ2QztBQUV2REssU0FBSyxFQUFFLENBRmdEO0FBR3ZEQyxpQkFBYSxFQUFDLENBSHlDO0FBSXZEQyxRQUFJLEVBQUUsRUFKaUQ7QUFLdkRDLGNBQVUsRUFBRSxLQUwyQztBQU12RHJDLFVBQU0sRUFBRTtBQU4rQyxHQUFELENBVmpDO0FBQUEsTUFVaEJzQyxnQkFWZ0I7QUFBQSxNQVVFQyxtQkFWRjs7QUFBQSxtQkFtQkozQyw2REFBUyxFQW5CTDtBQUFBLE1BbUJmQyxNQW5CZSxjQW1CZkEsTUFuQmU7O0FBb0J2QixNQUFNMkMsWUFBWSxHQUFHQyxvREFBTSxFQUEzQjtBQUNBLE1BQU1DLFNBQVMsR0FBR0Qsb0RBQU0sQ0FBQyxFQUFELENBQXhCO0FBQ0FDLFdBQVMsQ0FBQ0MsT0FBVixHQUFvQixFQUFwQjtBQUNBLE1BQU1DLE9BQU8sR0FBR0gsb0RBQU0sQ0FBQyxFQUFELENBQXRCO0FBQ0FHLFNBQU8sQ0FBQ0QsT0FBUixHQUFrQixFQUFsQjs7QUFFQSxNQUFNRSxNQUFNLEdBQUcsU0FBVEEsTUFBUyxDQUFDQyxJQUFELEVBQVU7QUFDdkJDLFdBQU8sQ0FBQ0MsR0FBUixDQUFZRixJQUFaO0FBRUFHLGdEQUFLLENBQ0ZDLElBREgsV0FFT3JDLDZCQUZQLGlDQUU2RGlDLElBQUksQ0FBQ0ssU0FGbEUscUJBRXNGYixnQkFBZ0IsQ0FBQ3RDLE1BRnZHLEdBR0ksRUFISixFQUlJO0FBQ0VvRCxhQUFPLEVBQUU7QUFDUCx3QkFBZ0Isa0JBRFQ7QUFFUEMscUJBQWEsbUJBQVlqQyxLQUFLLENBQUNDLEtBQU4sQ0FBWWlDLElBQVosQ0FBaUJDLFdBQTdCO0FBRk47QUFEWCxLQUpKLEVBV0dDLElBWEgsQ0FXUSxVQUFDQyxHQUFELEVBQVM7QUFDYlYsYUFBTyxDQUFDQyxHQUFSLENBQVlTLEdBQUcsQ0FBQ1gsSUFBSixDQUFTWSxPQUFyQjtBQUNBNUIsaUJBQVcsQ0FBQzJCLEdBQUcsQ0FBQ1gsSUFBSixDQUFTWSxPQUFWLENBQVg7QUFDQTFCLHNCQUFnQixDQUFDeUIsR0FBRyxDQUFDWCxJQUFKLENBQVNZLE9BQVYsQ0FBaEI7QUFDRCxLQWZILFdBZ0JTLFVBQUNDLEdBQUQsRUFBUztBQUNkaEMsY0FBUSxDQUFDLFdBQUQsRUFBYztBQUFFaUMsZUFBTyxFQUFFRCxHQUFHLENBQUNFLFFBQUosQ0FBYWYsSUFBYixDQUFrQmdCO0FBQTdCLE9BQWQsQ0FBUjtBQUNELEtBbEJIO0FBbUJELEdBdEJEOztBQXdCQSxNQUFNQyxTQUFTO0FBQUEsa1VBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFDUWQsNENBQUssQ0FBQ2UsR0FBTixXQUFhbkQsNkJBQWIseUJBQTJEaEIsTUFBM0QsR0FBcUU7QUFDM0Z1RCx1QkFBTyxFQUFFO0FBQ1BDLCtCQUFhLG1CQUFZakMsS0FBSyxDQUFDQyxLQUFOLENBQVlpQyxJQUFaLENBQWlCQyxXQUE3QjtBQUROO0FBRGtGLGVBQXJFLENBRFI7O0FBQUE7QUFDWlUseUJBRFk7QUFBQTtBQUFBLHFCQU1PaEIsNENBQUssQ0FBQ2UsR0FBTixXQUFhbkQsNkJBQWIsd0JBQTBEaEIsTUFBMUQsR0FBb0U7QUFDekZ1RCx1QkFBTyxFQUFFO0FBQ1BDLCtCQUFhLG1CQUFZakMsS0FBSyxDQUFDQyxLQUFOLENBQVlpQyxJQUFaLENBQWlCQyxXQUE3QjtBQUROO0FBRGdGLGVBQXBFLENBTlA7O0FBQUE7QUFNWlcsd0JBTlk7QUFBQSwrQ0FZVDtBQUNMRCwyQkFBVyxFQUFDQSxXQUFXLENBQUNuQixJQURuQjtBQUVMb0IsMEJBQVUsRUFBQ0EsVUFBVSxDQUFDcEI7QUFGakIsZUFaUzs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFIOztBQUFBLG9CQUFUaUIsU0FBUztBQUFBO0FBQUE7QUFBQSxLQUFmOztBQWlCQUksK0RBQWUsQ0FBQyxZQUFNO0FBQ3BCSixhQUFTLEdBQUdQLElBQVosQ0FBaUIsVUFBQUMsR0FBRyxFQUFJO0FBQ3RCVixhQUFPLENBQUNDLEdBQVIsQ0FBWVMsR0FBWjtBQUNBM0IsaUJBQVcsQ0FBQzJCLEdBQUcsQ0FBQ1EsV0FBTCxDQUFYO0FBQ0FqQyxzQkFBZ0IsQ0FBQ3lCLEdBQUcsQ0FBQ1EsV0FBTCxDQUFoQjtBQUNBaEMsZUFBUyxDQUFDd0IsR0FBRyxDQUFDUyxVQUFMLENBQVQ7QUFDRCxLQUxELFdBS1MsVUFBQVAsR0FBRztBQUFBLGFBQUlaLE9BQU8sQ0FBQ0MsR0FBUixDQUFZVyxHQUFaLENBQUo7QUFBQSxLQUxaO0FBT0QsR0FSYyxFQVFaLEVBUlksQ0FBZjs7QUFVQSxNQUFNUyxVQUFVLEdBQUcsU0FBYkEsVUFBYSxDQUFDQyxHQUFELEVBQVM7QUFDMUIsUUFBSUEsR0FBRyxJQUFJLENBQUN6QixPQUFPLENBQUNELE9BQVIsQ0FBZ0IyQixRQUFoQixDQUF5QkQsR0FBekIsQ0FBWixFQUEyQztBQUN6Q3pCLGFBQU8sQ0FBQ0QsT0FBUixDQUFnQjRCLElBQWhCLENBQXFCRixHQUFyQjtBQUNEO0FBQ0YsR0FKRDs7QUFNQSxNQUFNRyxhQUFhO0FBQUEsbVVBQUcsa0JBQU9DLEVBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNwQjdCLHFCQUFPLENBQUNELE9BQVIsQ0FBZ0IrQixPQUFoQixDQUF3QixVQUFDQyxDQUFEO0FBQUEsdUJBQU9BLENBQUMsQ0FBQ0MsU0FBRixDQUFZQyxNQUFaLENBQW1CLGFBQW5CLENBQVA7QUFBQSxlQUF4QjtBQUNBSixnQkFBRSxDQUFDSyxNQUFILENBQVVGLFNBQVYsQ0FBb0JHLEdBQXBCLENBQXdCLGFBQXhCOztBQUZvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFIOztBQUFBLG9CQUFiUCxhQUFhO0FBQUE7QUFBQTtBQUFBLEtBQW5COztBQUtBLE1BQU1RLHFCQUFxQjtBQUFBLG1VQUFHLGtCQUFPN0UsRUFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzNCOEMsMERBQUssQ0FBQ2UsR0FBTixXQUFhbkQsNkJBQWIsNEJBQThEVixFQUE5RCxrQkFBd0VOLE1BQXhFLEdBQWtGO0FBQ2pGdUQsdUJBQU8sRUFBRTtBQUNQQywrQkFBYSxtQkFBWWpDLEtBQUssQ0FBQ0MsS0FBTixDQUFZaUMsSUFBWixDQUFpQkMsV0FBN0I7QUFETjtBQUR3RSxlQUFsRixFQUlFQyxJQUpGLENBSU8sVUFBQ0MsR0FBRCxFQUFTO0FBQ2YzQiwyQkFBVyxDQUFDMkIsR0FBRyxDQUFDWCxJQUFMLENBQVg7QUFDQWQsZ0NBQWdCLENBQUN5QixHQUFHLENBQUNYLElBQUwsQ0FBaEI7QUFDRCxlQVBBLFdBT1EsVUFBQWEsR0FBRztBQUFBLHVCQUFJWixPQUFPLENBQUNDLEdBQVIsQ0FBWVcsR0FBWixDQUFKO0FBQUEsZUFQWDs7QUFEMkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FBSDs7QUFBQSxvQkFBckJxQixxQkFBcUI7QUFBQTtBQUFBO0FBQUEsS0FBM0I7O0FBYUEsTUFBTUMsY0FBYyxHQUFHLFNBQWpCQSxjQUFpQixDQUFDUixFQUFELEVBQVE7QUFDN0IsUUFBSXRFLEVBQUUsR0FBR3NFLEVBQUUsQ0FBQ0ssTUFBSCxDQUFVSSxZQUFWLENBQXVCLFNBQXZCLENBQVQ7QUFDQVYsaUJBQWEsQ0FBQ0MsRUFBRCxDQUFiO0FBQ0FPLHlCQUFxQixDQUFDN0UsRUFBRCxDQUFyQjs7QUFDQSxRQUFJQSxFQUFFLElBQUksQ0FBVixFQUFhO0FBQ1gsVUFBSWdGLFdBQVcsR0FBR3RELFFBQVEsQ0FBQ3VELE1BQVQsQ0FBZ0IsVUFBQ1QsQ0FBRDtBQUFBLGVBQU9BLENBQUMsQ0FBQzNFLE1BQUYsQ0FBU0csRUFBVCxJQUFlQSxFQUF0QjtBQUFBLE9BQWhCLENBQWxCO0FBQ0E2QixzQkFBZ0IsQ0FBQyw4SkFBSW1ELFdBQUwsRUFBaEI7QUFDRCxLQUhELE1BR087QUFDTG5ELHNCQUFnQixDQUFDLDhKQUFJSCxRQUFMLEVBQWhCO0FBQ0Q7O0FBRURVLHVCQUFtQixDQUFDO0FBQ2xCSixtQkFBYSxFQUFFLENBREc7QUFFbEJOLGNBQVEsRUFBRSxFQUZRO0FBR2xCSyxXQUFLLEVBQUUsQ0FIVztBQUlsQkUsVUFBSSxFQUFFLEVBSlk7QUFLbEJDLGdCQUFVLEVBQUUsS0FMTTtBQU1sQnJDLFlBQU0sRUFBRUc7QUFOVSxLQUFELENBQW5CO0FBUUQsR0FuQkQ7O0FBcUJBLE1BQU1rRixZQUFZLEdBQUcsU0FBZkEsWUFBZSxDQUFDaEIsR0FBRCxFQUFTO0FBQzVCLFFBQUlBLEdBQUcsSUFBSSxDQUFDM0IsU0FBUyxDQUFDQyxPQUFWLENBQWtCMkIsUUFBbEIsQ0FBMkJELEdBQTNCLENBQVosRUFBNkM7QUFDM0MzQixlQUFTLENBQUNDLE9BQVYsQ0FBa0I0QixJQUFsQixDQUF1QkYsR0FBdkI7QUFDRDtBQUNGLEdBSkQ7O0FBTUEsTUFBTWlCLFlBQVksR0FBRyxTQUFmQSxZQUFlLENBQUNiLEVBQUQsRUFBUTtBQUFBLHFCQUNGQSxFQUFFLENBQUNLLE1BREQ7QUFBQSxRQUNyQlMsS0FEcUIsY0FDckJBLEtBRHFCO0FBQUEsUUFDZEMsT0FEYyxjQUNkQSxPQURjO0FBRTNCLFFBQUloRixLQUFLLEdBQUdpRSxFQUFFLENBQUNLLE1BQUgsQ0FBVUksWUFBVixDQUF1QixZQUF2QixDQUFaO0FBQ0EsUUFBSU8sWUFBWSxHQUFHaEIsRUFBRSxDQUFDSyxNQUFILENBQVVJLFlBQVYsQ0FBdUIsZUFBdkIsQ0FBbkI7QUFDQSxRQUFJaEQsS0FBSyxHQUFDLENBQVY7QUFDQSxRQUFJd0QsSUFBSSxHQUFDLENBQVQ7QUFDQTNDLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQVosRUFBa0J5QyxZQUFsQjs7QUFDQSxRQUFJRCxPQUFKLEVBQWE7QUFDWGxELHNCQUFnQixDQUFDVCxRQUFqQixDQUEwQjBDLElBQTFCLENBQStCZ0IsS0FBL0I7O0FBQ0EsVUFBR0UsWUFBWSxJQUFFLENBQWpCLEVBQW1CO0FBQ2pCbEQsMkJBQW1CLGlDQUNkRCxnQkFEYztBQUdqQkosZUFBSyxFQUFHSSxnQkFBZ0IsQ0FBQ0osS0FBakIsR0FBdUIzQixVQUFVLENBQUNDLEtBQUQsQ0FIeEI7QUFLakIyQix1QkFBYSxFQUFHRyxnQkFBZ0IsQ0FBQ0gsYUFBakIsR0FBK0I1QixVQUFVLENBQUNrRixZQUFELENBTHhDO0FBTWpCNUQsa0JBQVEsRUFBRSw4SkFBSVMsZ0JBQWdCLENBQUNULFFBQXZCO0FBTlMsV0FBbkI7QUFTRCxPQVZELE1BVUs7QUFDSFUsMkJBQW1CLGlDQUNkRCxnQkFEYztBQUVqQkgsdUJBQWEsRUFBR0csZ0JBQWdCLENBQUNILGFBQWpCLEdBQStCNUIsVUFBVSxDQUFDQyxLQUFELENBRnhDO0FBR2pCMEIsZUFBSyxFQUFHSSxnQkFBZ0IsQ0FBQ0osS0FBakIsR0FBdUIzQixVQUFVLENBQUNDLEtBQUQsQ0FIeEI7QUFJakJxQixrQkFBUSxFQUFFLDhKQUFJUyxnQkFBZ0IsQ0FBQ1QsUUFBdkI7QUFKUyxXQUFuQjtBQU1EO0FBRUYsS0FyQkQsTUFxQk87QUFDTCxVQUFJc0QsV0FBVyxHQUFHN0MsZ0JBQWdCLENBQUNULFFBQWpCLENBQTBCdUQsTUFBMUIsQ0FBaUMsVUFBQ1QsQ0FBRDtBQUFBLGVBQU9BLENBQUMsS0FBS1ksS0FBYjtBQUFBLE9BQWpDLENBQWxCOztBQUNBLFVBQUdFLFlBQVksSUFBRSxDQUFqQixFQUFtQjtBQUNqQmxELDJCQUFtQixpQ0FFZEQsZ0JBRmM7QUFJakJKLGVBQUssRUFBRUksZ0JBQWdCLENBQUNKLEtBQWpCLElBQXlCLENBQXpCLElBQStCSSxnQkFBZ0IsQ0FBQ0osS0FBakIsR0FBdUIzQixVQUFVLENBQUNDLEtBQUQsQ0FKdEQ7QUFNakIyQix1QkFBYSxFQUFFRyxnQkFBZ0IsQ0FBQ0gsYUFBakIsSUFBaUMsQ0FBakMsSUFBd0NHLGdCQUFnQixDQUFDSCxhQUFqQixHQUErQjVCLFVBQVUsQ0FBQ2tGLFlBQUQsQ0FOL0U7QUFPakI1RCxrQkFBUSxFQUFFc0Q7QUFQTyxXQUFuQjtBQVVELE9BWEQsTUFXSztBQUNINUMsMkJBQW1CLGlDQUNkRCxnQkFEYztBQUVqQkgsdUJBQWEsRUFBQ0csZ0JBQWdCLENBQUNILGFBQWpCLElBQWlDLENBQWpDLElBQXVDRyxnQkFBZ0IsQ0FBQ0gsYUFBakIsR0FBK0I1QixVQUFVLENBQUNDLEtBQUQsQ0FGN0U7QUFHakIwQixlQUFLLEVBQUNJLGdCQUFnQixDQUFDSixLQUFqQixJQUF5QixDQUF6QixJQUErQkksZ0JBQWdCLENBQUNKLEtBQWpCLEdBQXVCM0IsVUFBVSxDQUFDQyxLQUFELENBSHJEO0FBSWpCcUIsa0JBQVEsRUFBQ3NEO0FBSlEsV0FBbkI7QUFNRDtBQUVGOztBQUNELEtBQUM3QyxnQkFBZ0IsQ0FBQ1QsUUFBakIsQ0FBMEI4RCxJQUExQixDQUErQixVQUFDaEIsQ0FBRDtBQUFBLGFBQU9BLENBQVA7QUFBQSxLQUEvQixDQUFELEdBQ0tuQyxZQUFZLENBQUNHLE9BQWIsQ0FBcUI2QyxPQUFyQixHQUErQixLQURwQyxHQUVJLElBRko7QUFHRCxHQXRERDs7QUF3REEsTUFBTUksU0FBUyxHQUFHLFNBQVpBLFNBQVksQ0FBQ0MsQ0FBRCxFQUFPO0FBQ3ZCLFFBQUkzRCxLQUFLLEdBQUcsQ0FBWjtBQUNBLFFBQUlDLGFBQWEsR0FBRyxDQUFwQjtBQUNBLFFBQUlOLFFBQVEsR0FBRyxFQUFmO0FBQ0FhLGFBQVMsQ0FBQ0MsT0FBVixDQUFrQitCLE9BQWxCLENBQTBCLFVBQUNDLENBQUQsRUFBTztBQUMvQkEsT0FBQyxDQUFDYSxPQUFGLEdBQVlLLENBQUMsQ0FBQ2YsTUFBRixDQUFTVSxPQUFyQjs7QUFFQSxVQUFJSyxDQUFDLENBQUNmLE1BQUYsQ0FBU1UsT0FBVCxJQUFvQixDQUFDM0QsUUFBUSxDQUFDeUMsUUFBVCxDQUFrQkssQ0FBQyxDQUFDWSxLQUFwQixDQUF6QixFQUFxRDtBQUNuRDFELGdCQUFRLENBQUMwQyxJQUFULENBQWNJLENBQUMsQ0FBQ1ksS0FBaEI7QUFDQXJELGFBQUssSUFBSSxDQUFDeUMsQ0FBQyxDQUFDTyxZQUFGLENBQWUsWUFBZixDQUFWO0FBQ0EvQyxxQkFBYSxJQUFJLENBQUN3QyxDQUFDLENBQUNPLFlBQUYsQ0FBZSxlQUFmLENBQWxCO0FBQ0QsT0FKRCxNQUlPO0FBQ0xyRCxnQkFBUSxHQUFHQSxRQUFRLENBQUN1RCxNQUFULENBQWdCLFVBQUNVLENBQUQ7QUFBQSxpQkFBT0EsQ0FBQyxLQUFLbkIsQ0FBQyxDQUFDWSxLQUFmO0FBQUEsU0FBaEIsQ0FBWDtBQUNBckQsYUFBSyxJQUFJQSxLQUFLLElBQUksQ0FBVCxJQUFjLENBQUN5QyxDQUFDLENBQUNPLFlBQUYsQ0FBZSxZQUFmLENBQXhCO0FBQ0EvQyxxQkFBYSxJQUFJQSxhQUFhLElBQUcsQ0FBaEIsSUFBcUIsQ0FBQ3dDLENBQUMsQ0FBQ08sWUFBRixDQUFlLGVBQWYsQ0FBdkM7QUFDRDtBQUNGLEtBWkQ7QUFjQTNDLHVCQUFtQixpQ0FDZEQsZ0JBRGM7QUFFakJKLFdBQUssRUFBRUksZ0JBQWdCLENBQUNKLEtBQWpCLEdBQXVCQSxLQUZiO0FBR2pCTCxjQUFRLEVBQUVBO0FBSE8sT0FBbkI7QUFLRCxHQXZCRDs7QUF5QkEsTUFBTWtFLFNBQVMsR0FBRyxTQUFaQSxTQUFZLEdBQWU7QUFBQSxRQUFkakQsSUFBYyx1RUFBUCxFQUFPO0FBQy9CRyxnREFBSyxDQUFDQyxJQUFOLFdBQWNyQyw2QkFBZCxjQUF1RGlDLElBQXZELEVBQTREO0FBQzFETSxhQUFPLEVBQUM7QUFDTkMscUJBQWEsbUJBQVlqQyxLQUFLLENBQUNDLEtBQU4sQ0FBWWlDLElBQVosQ0FBaUJDLFdBQTdCO0FBRFA7QUFEa0QsS0FBNUQsRUFJR0MsSUFKSCxDQUlRLFVBQUFDLEdBQUcsRUFBSTtBQUNiVixhQUFPLENBQUNDLEdBQVIsQ0FBWSxLQUFaLEVBQWtCUyxHQUFHLENBQUNYLElBQUosQ0FBU2tELEdBQTNCO0FBQ0NDLFlBQU0sQ0FBQ0MsUUFBUCxDQUFnQkMsSUFBaEIsR0FBdUIxQyxHQUFHLENBQUNYLElBQUosQ0FBU2tELEdBQWhDO0FBQ0YsS0FQRCxXQU9TLFVBQUFyQyxHQUFHO0FBQUEsYUFBSVosT0FBTyxDQUFDQyxHQUFSLENBQVlXLEdBQVosQ0FBSjtBQUFBLEtBUFo7QUFRRCxHQVREOztBQVdBLHNCQUNFLHFFQUFDLDhEQUFEO0FBQU0sYUFBUyxFQUFDLG1CQUFoQjtBQUFBLDRCQUNFLHFFQUFDLGdFQUFEO0FBQU8sZUFBUyxFQUFDLE9BQWpCO0FBQUEsNkJBQ0UscUVBQUMscUVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQUlFLHFFQUFDLDhEQUFEO0FBQU0sZUFBUyxFQUFDLGFBQWhCO0FBQUEsOEJBQ0UscUVBQUMsOERBQUQ7QUFBTSxpQkFBUyxFQUFDLHlCQUFoQjtBQUFBLGdDQUNFLHFFQUFDLDhEQUFELENBQU0sTUFBTjtBQUNFLGNBQUksRUFBRWpFLENBQUMsQ0FBQztBQUFFUyxjQUFFLEVBQUU7QUFBTixXQUFELENBRFQ7QUFFRSxxQkFBVyxlQUNULHFFQUFDLHNFQUFEO0FBQ0UsZ0JBQUksRUFBRVQsQ0FBQyxDQUFDO0FBQUVTLGdCQUFFLEVBQUU7QUFBTixhQUFELENBRFQ7QUFFRSxlQUFHLEVBQUUsYUFBQ2tFLEdBQUQ7QUFBQSxxQkFBVTdCLFlBQVksQ0FBQ0csT0FBYixHQUF1QjBCLEdBQWpDO0FBQUEsYUFGUDtBQUdFLG1CQUFPLEVBQUV1QixTQUhYO0FBSUUscUJBQVMsRUFBQztBQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFISjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBWUU7QUFBSyxtQkFBTSxLQUFYO0FBQWlCLGVBQUssRUFBRTtBQUFFUSxxQkFBUyxFQUFFO0FBQWIsV0FBeEI7QUFBQSxpQ0FDRTtBQUNFLHFCQUFTLEVBQUMsVUFEWjtBQUVFLGlCQUFLLEVBQUU7QUFDTEMscUJBQU8sRUFBRSxNQURKO0FBRUxDLDBCQUFZLEVBQUUsTUFGVDtBQUdMQyxtQkFBSyxFQUFFO0FBSEYsYUFGVDtBQUFBLG9DQVNFLHFFQUFDLDJEQUFEO0FBQ0UsbUJBQUssd0JBQVkxRSxRQUFRLENBQUMyRSxNQUFyQixNQURQO0FBRUUsdUJBQVMsRUFBQyw4QkFGWjtBQUdFLHlCQUFTLENBSFg7QUFJRSxpQkFBRyxFQUFFcEMsVUFKUDtBQUtFLHFCQUFPLEVBQUVhO0FBTFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFURixFQWlCSWpGLE1BQU0sQ0FBQ3lHLEdBQVAsQ0FBVyxVQUFDOUIsQ0FBRDtBQUFBLGtDQUNYLHFFQUFDLDJEQUFEO0FBQ0UscUJBQUssWUFBS0EsQ0FBQyxDQUFDMUUsSUFBUCxlQUFnQjBFLENBQUMsQ0FBQytCLEtBQWxCLE1BRFA7QUFHRSx5QkFBUyxFQUFDLGNBSFo7QUFJRSwyQkFBUy9CLENBQUMsQ0FBQ3hFLEVBSmI7QUFLRSxtQkFBRyxFQUFFaUUsVUFMUDtBQU1FLHVCQUFPLEVBQUVhO0FBTlg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFEVztBQUFBLGFBQVgsQ0FqQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFaRixlQTRDRSxxRUFBQyw4REFBRCxDQUFNLElBQU47QUFBVyxtQkFBUyxFQUFDLFFBQXJCO0FBQUEsaUNBQ0U7QUFBSyxxQkFBUyxFQUFDLGNBQWY7QUFBQSxzQkFDR2xELGFBQWEsQ0FDWHFELE1BREYsQ0FDUyxVQUFDVCxDQUFEO0FBQUEscUJBQU9BLENBQUMsQ0FBQzNFLE1BQUYsQ0FBU0csRUFBVCxLQUFnQixDQUF2QjtBQUFBLGFBRFQsRUFFRXNHLEdBRkYsQ0FFTSxVQUFDWCxDQUFEO0FBQUEsa0NBQ0gscUVBQUMsOEVBQUQ7QUFFRSx3QkFBUSxFQUFFVCxZQUZaO0FBR0Usb0JBQUksRUFBRVMsQ0FIUjtBQUlFLHVCQUFPLEVBQUVSO0FBSlgsaUJBQ09RLENBQUMsQ0FBQzNGLEVBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERztBQUFBLGFBRk47QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkE1Q0YsZUEwREU7QUFBSyxtQkFBUyxFQUFDLGFBQWY7QUFBQSxrQ0FDRTtBQUFLLHFCQUFTLEVBQUMsZUFBZjtBQUFBLG9DQUNFO0FBQUEseUJBQ0dtQyxnQkFBZ0IsQ0FBQ1QsUUFBakIsQ0FBMEIyRSxNQUQ3QixPQUNzQzlHLENBQUMsQ0FBQztBQUFFUyxrQkFBRSxFQUFFO0FBQU4sZUFBRCxDQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBREYsZUFJRTtBQUFLLG1CQUFLLEVBQUU7QUFBRWtHLHVCQUFPLEVBQUUsTUFBWDtBQUFtQk0sOEJBQWMsRUFBRTtBQUFuQyxlQUFaO0FBQUEsc0NBQ0U7QUFBQSwyQkFBSWpILENBQUMsQ0FBQztBQUFFUyxvQkFBRSxFQUFFO0FBQU4saUJBQUQsQ0FBTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBREYsZUFFRTtBQUFLLHFCQUFLLEVBQUU7QUFBRWtHLHlCQUFPLEVBQUUsTUFBWDtBQUFtQk8sK0JBQWEsRUFBRTtBQUFsQyxpQkFBWjtBQUFBLDBCQUVFdEUsZ0JBQWdCLENBQUNILGFBQWpCLEdBQWlDLENBQWpDLGdCQUNBO0FBQUEsMENBQ0E7QUFBSyx5QkFBSyxFQUFFO0FBQUVsQix5Q0FBbUIsRUFBRTtBQUF2QixxQkFBWjtBQUFBLCtCQUE2Q1YsVUFBVSxDQUFDK0IsZ0JBQWdCLENBQUNKLEtBQWxCLENBQVYsQ0FBbUN6QixPQUFuQyxDQUEyQyxDQUEzQyxDQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREEsZUFFQztBQUFBLCtCQUFJRixVQUFVLENBQUMrQixnQkFBZ0IsQ0FBQ0gsYUFBbEIsQ0FBVixDQUEyQzFCLE9BQTNDLENBQW1ELENBQW5ELENBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUZEO0FBQUEsZ0NBREEsZ0JBS0k7QUFBQSw2QkFBSUYsVUFBVSxDQUFDK0IsZ0JBQWdCLENBQUNILGFBQWxCLENBQVYsQ0FBMkMxQixPQUEzQyxDQUFtRCxDQUFuRCxDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVBOO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERixlQXFCRTtBQUFLLHFCQUFTLEVBQUMsZUFBZjtBQUFBLG9DQUNFO0FBQUEscUNBQ0UscUVBQUMsMEVBQUQ7QUFDRSx5QkFBUyxFQUFDLGdCQURaO0FBRUUseUJBQVMsRUFBRTtBQUFFb0csd0JBQU0sRUFBRSxNQUFWO0FBQWtCTix1QkFBSyxFQUFFO0FBQXpCLGlCQUZiO0FBR0UseUJBQVMsRUFBQyx1QkFIWjtBQUlFLHFCQUFLLEVBQUU7QUFBRUQsOEJBQVksRUFBRTtBQUFoQixpQkFKVDtBQUtFLHFCQUFLLHVCQUFFNUUsTUFBTSxDQUFDeUIsU0FBVCxzREFBRSxrQkFBa0JTLE9BTDNCO0FBQUEsd0NBT0UscUVBQUMsZ0VBQUQ7QUFDRSw2QkFBVyxFQUFFbEUsQ0FBQyxDQUFDO0FBQUVTLHNCQUFFLEVBQUU7QUFBTixtQkFBRCxDQURoQjtBQUVFLHNCQUFJLEVBQUMsV0FGUDtBQUdFLHFCQUFHLEVBQUVxQixRQUFRLENBQUM7QUFDWnNGLDRCQUFRLEVBQUU7QUFDUnZCLDJCQUFLLEVBQUUsSUFEQztBQUVSM0IsNkJBQU8sRUFBRWxFLENBQUMsQ0FBQztBQUFFUywwQkFBRSxFQUFFO0FBQU4sdUJBQUQ7QUFGRjtBQURFLG1CQUFELENBSGY7QUFTRSwwQkFBUSxFQUFFLGtCQUFDMEYsQ0FBRDtBQUFBLDJCQUNSdEQsbUJBQW1CLGlDQUNkRCxnQkFEYztBQUVqQkYsMEJBQUksRUFBRXlELENBQUMsQ0FBQ2YsTUFBRixDQUFTUztBQUZFLHVCQURYO0FBQUE7QUFUWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQVBGLEVBdUJHakQsZ0JBQWdCLENBQUNELFVBQWpCLGdCQUNDLHFFQUFDLDJEQUFEO0FBQ0UsMkJBQVMsRUFBQyxlQURaO0FBRUUsdUJBQUssRUFBRTtBQUNMMEUsc0NBQWtCLEVBQUUsV0FEZjtBQUVMaEgseUJBQUssRUFBRSxVQUZGO0FBR0xpSCwyQkFBTyxFQUFFO0FBSEosbUJBRlQ7QUFPRSx1QkFBSyxFQUFDLG1CQVBSO0FBUUUseUJBQU8sRUFBRSxtQkFBTTtBQUNiekUsdUNBQW1CLGlDQUNkRCxnQkFEYztBQUVqQkQsZ0NBQVUsRUFBRTtBQUZLLHVCQUFuQjtBQUlEO0FBYkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFERCxnQkFpQkMscUVBQUMsMkRBQUQ7QUFDRSwwQkFBUSxFQUFFLENBQUNDLGdCQUFnQixDQUFDRixJQUFsQixHQUF5QixJQUF6QixHQUFnQyxLQUQ1QztBQUVFLHVCQUFLLEVBQUU7QUFBRTRFLDJCQUFPLEVBQUU7QUFBWCxtQkFGVDtBQUdFLDJCQUFTLEVBQUMsd0JBSFo7QUFJRSx1QkFBSyxFQUFFdEgsQ0FBQyxDQUFDO0FBQUVTLHNCQUFFLEVBQUU7QUFBTixtQkFBRCxDQUpWO0FBS0Usc0JBQUksRUFBQyxRQUxQO0FBTUUseUJBQU8sRUFBRXNCLFlBQVksQ0FBQ29CLE1BQUQsQ0FOdkIsQ0FPRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkF4Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFERixlQTRERSxxRUFBQywyREFBRDtBQUNFLG1CQUFLLEVBQUU7QUFBRW1FLHVCQUFPLEVBQUU7QUFBWCxlQURUO0FBRUUsdUJBQVMsRUFBQyxtQ0FGWjtBQUdFLG1CQUFLLEVBQUV0SCxDQUFDLENBQUM7QUFBRVMsa0JBQUUsRUFBRTtBQUFOLGVBQUQsQ0FIVjtBQUlFLHdCQUFVLGVBQUU7QUFBTSx5QkFBUyxFQUFDLG1CQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFKZDtBQUtFLHFCQUFPLEVBQUk7QUFBQSx1QkFBTTRGLFNBQVMsQ0FBQztBQUN6QnZGLHVCQUFLLEVBQUM4QixnQkFBZ0IsQ0FBQ0gsYUFERTtBQUV6QjhFLDRCQUFVLEVBQUMsQ0FGYztBQUd6QnZELHlCQUFPLEVBQUNwQixnQkFBZ0IsQ0FBQ1Q7QUFIQSxpQkFBRCxDQUFmO0FBQUE7QUFMYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQTVERixlQXVFRSxxRUFBQywyREFBRDtBQUNFLG1CQUFLLEVBQUU7QUFBRW1GLHVCQUFPLEVBQUU7QUFBWCxlQURUO0FBRUUsdUJBQVMsRUFBQyxNQUZaO0FBR0UsbUJBQUssRUFBRXRILENBQUMsQ0FBQztBQUFFUyxrQkFBRSxFQUFFO0FBQU4sZUFBRCxDQUhWO0FBSUUsd0JBQVUsZUFDUjtBQUFNLHlCQUFTLEVBQUMsMEJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUxKO0FBT0UscUJBQU8sRUFBSTtBQUFBLHVCQUFNaUIsS0FBSyxDQUFDOEYsa0JBQU4sQ0FBeUIsU0FBekIsRUFBbUM7QUFDbEQxRyx1QkFBSyxFQUFDOEIsZ0JBQWdCLENBQUNILGFBRDJCO0FBRWxEOEUsNEJBQVUsRUFBQyxDQUZ1QztBQUdsRHZELHlCQUFPLEVBQUNwQixnQkFBZ0IsQ0FBQ1Q7QUFIeUIsaUJBQW5DLEVBS2pCO0FBQ0Usb0RBQTBCVCxLQUFLLENBQUNDLEtBQU4sQ0FBWWlDLElBQVosQ0FBaUJDLFdBQTNDO0FBREYsaUJBTGlCLENBQU47QUFBQTtBQVBiO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBdkVGLGVBd0ZFO0FBQUssdUJBQVMsRUFBQyxVQUFmO0FBQUEsc0NBQ0UscUVBQUMsMkRBQUQ7QUFDRSxxQkFBSyxFQUFFO0FBQUV5RCx5QkFBTyxFQUFFO0FBQVgsaUJBRFQ7QUFFRSx5QkFBUyxFQUFDLDhCQUZaO0FBR0UscUJBQUssRUFBRXRILENBQUMsQ0FBQztBQUFFUyxvQkFBRSxFQUFFO0FBQU4saUJBQUQsQ0FIVjtBQUlFLDBCQUFVLGVBQ1I7QUFBTSwyQkFBUyxFQUFDLG1CQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFMSjtBQU9FLHVCQUFPLEVBQUk7QUFBQSx5QkFBTTRGLFNBQVMsQ0FBQztBQUN6QnZGLHlCQUFLLEVBQUM4QixnQkFBZ0IsQ0FBQ0gsYUFERTtBQUV6QjhFLDhCQUFVLEVBQUMsQ0FGYztBQUd6QnZELDJCQUFPLEVBQUNwQixnQkFBZ0IsQ0FBQ1Q7QUFIQSxtQkFBRCxDQUFmO0FBQUE7QUFQYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQURGLGVBY0UscUVBQUMsMkRBQUQ7QUFDRSxxQkFBSyxFQUFFO0FBQUVtRix5QkFBTyxFQUFFO0FBQVgsaUJBRFQ7QUFFRSxxQkFBSyxFQUFFdEgsQ0FBQyxDQUFDO0FBQUVTLG9CQUFFLEVBQUU7QUFBTixpQkFBRCxDQUZWO0FBR0UsMEJBQVUsZUFDUjtBQUFNLDJCQUFTLEVBQUMseUJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUpKO0FBTUUsdUJBQU8sRUFBSTtBQUFBLHlCQUFNaUIsS0FBSyxDQUFDOEYsa0JBQU4sQ0FBeUIsU0FBekIsRUFBbUM7QUFDbEQxRyx5QkFBSyxFQUFDOEIsZ0JBQWdCLENBQUNILGFBRDJCO0FBRWxEOEUsOEJBQVUsRUFBQyxDQUZ1QztBQUdsRHZELDJCQUFPLEVBQUNwQixnQkFBZ0IsQ0FBQ1Q7QUFIeUIsbUJBQW5DLEVBS2pCO0FBQ0Usc0RBQTBCVCxLQUFLLENBQUNDLEtBQU4sQ0FBWWlDLElBQVosQ0FBaUJDLFdBQTNDO0FBREYsbUJBTGlCLENBQU47QUFBQTtBQU5iO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQXhGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkExREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUEwTUUscUVBQUMsOERBQUQ7QUFBTSxpQkFBUyxFQUFDLGVBQWhCO0FBQUEsZ0NBQ0UscUVBQUMsOERBQUQsQ0FBTSxNQUFOO0FBQWEsY0FBSSxFQUFFN0QsQ0FBQyxDQUFDO0FBQUVTLGNBQUUsRUFBRTtBQUFOLFdBQUQ7QUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQUVFLHFFQUFDLDhEQUFELENBQU0sSUFBTjtBQUFXLG1CQUFTLEVBQUMsMEJBQXJCO0FBQUEsaUNBQ0UscUVBQUMsZ0VBQUQ7QUFDRSxjQUFFLEVBQUUsQ0FDRlQsQ0FBQyxDQUFDO0FBQUVTLGdCQUFFLEVBQUU7QUFBTixhQUFELENBREMsRUFFRlQsQ0FBQyxDQUFDO0FBQUVTLGdCQUFFLEVBQUU7QUFBTixhQUFELENBRkMsRUFHRlQsQ0FBQyxDQUFDO0FBQUVTLGdCQUFFLEVBQUU7QUFBTixhQUFELENBSEMsRUFJRlQsQ0FBQyxDQUFDO0FBQUVTLGdCQUFFLEVBQUU7QUFBTixhQUFELENBSkMsRUFLRlQsQ0FBQyxDQUFDO0FBQUVTLGdCQUFFLEVBQUU7QUFBTixhQUFELENBTEMsRUFNRlQsQ0FBQyxDQUFDO0FBQUVTLGdCQUFFLEVBQUU7QUFBTixhQUFELENBTkMsRUFPRlQsQ0FBQyxDQUFDO0FBQUVTLGdCQUFFLEVBQUU7QUFBTixhQUFELENBUEMsQ0FETjtBQVVFLGdCQUFJLEVBQ0YwQixRQUFRLENBQUM0RSxHQUFULENBQWEsVUFBQzlCLENBQUQsRUFBTztBQUNsQixrQkFBSUEsQ0FBQyxDQUFDM0UsTUFBRixDQUFTRyxFQUFULElBQWUsQ0FBbkIsRUFBc0I7QUFDcEIsdUJBQU87QUFDTEMsOEJBQVksRUFBRXVFLENBQUMsQ0FBQ3ZFLFlBRFg7QUFFTE4sc0JBQUksRUFBRTZFLENBQUMsQ0FBQzdFLElBRkg7QUFHTFksMEJBQVEsRUFBRWlFLENBQUMsQ0FBQ2pFLFFBSFA7QUFJTEYsdUJBQUssWUFBS21FLENBQUMsQ0FBQ25FLEtBQVAsY0FBZ0JtRSxDQUFDLENBQUN3QyxRQUFsQixDQUpBO0FBS0x4Ryx3QkFBTSxZQUFLSixVQUFVLENBQUNvRSxDQUFDLENBQUNoRSxNQUFILENBQVYsQ0FBcUJGLE9BQXJCLENBQTZCLENBQTdCLEtBQW1DLENBQXhDLFFBTEQ7QUFNTFMsZ0NBQWMsRUFDWlgsVUFBVSxDQUFDb0UsQ0FBQyxDQUFDekQsY0FBSCxDQUFWLENBQTZCVCxPQUE3QixDQUFxQyxDQUFyQyxLQUEyQyxDQVB4QztBQVFMVCx3QkFBTSxZQUFLMkUsQ0FBQyxDQUFDM0UsTUFBRixDQUFTQyxJQUFkLGdCQUF3QjBFLENBQUMsQ0FBQy9ELElBQTFCO0FBUkQsaUJBQVA7QUFVRDtBQUNGLGFBYkQsS0FhTSxFQXhCVjtBQTBCRSxzQkFBVSxFQUFFLG9CQUFDK0QsQ0FBRCxFQUFJeUMsQ0FBSixFQUFVO0FBQ3BCLGtDQUFPO0FBQUEsMEJBQWV6QztBQUFmLGlCQUFTeUMsQ0FBQyxFQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQVA7QUFDRDtBQTVCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0ExTUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFxUEQ7O0dBamRRakcsUTtVQUs4Q0ksdUQsRUFDeEI5QixrRCxFQWFWRyxxRDs7O0tBbkJadUIsUTs7QUFtZFQsSUFBTWtHLGVBQWUsR0FBRyxTQUFsQkEsZUFBa0IsQ0FBQ0MsS0FBRDtBQUFBLFNBQVk7QUFDbENqRyxTQUFLLEVBQUVpRyxLQUFLLENBQUNqRztBQURxQixHQUFaO0FBQUEsQ0FBeEI7O0FBR0EsSUFBTWtHLGtCQUFrQixHQUFJO0FBQzFCTCxvQkFBa0IsRUFBbEJBLDZFQUFrQkE7QUFEUSxDQUE1QjtBQUllTSwySEFBTyxDQUFDSCxlQUFELEVBQWtCRSxrQkFBbEIsQ0FBUCxlQUE2Q0Usa0RBQUksQ0FBQ3RHLFFBQUQsQ0FBakQsQ0FBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM3ZUE7QUFDQTtBQUNBO0FBQ0E7QUFFTyxJQUFNdUcsS0FBSyxHQUFHLFNBQVJBLEtBQVEsQ0FBQzFCLEdBQUQsRUFBS2xELElBQUw7QUFBQSxNQUFVTSxPQUFWLHVFQUFvQixFQUFwQjtBQUFBLFNBQTJCLFVBQUF1RSxRQUFRLEVBQUk7QUFDeEQxRSxnREFBSyxDQUFDQyxJQUFOLFdBQWNyQyw2QkFBZCxTQUFnRG1GLEdBQWhELEdBQXNEbEQsSUFBdEQsRUFBMkQ7QUFDdkRNLGFBQU8sRUFBQ0E7QUFEK0MsS0FBM0QsRUFHR0ksSUFISDtBQUFBLG9VQUdRLGlCQUFNQyxHQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQ2FBLEdBQUcsQ0FBQ1gsSUFEakI7O0FBQUE7QUFDQUEsb0JBREE7QUFFSjZFLHdCQUFRLENBQUNDLHNEQUFLLENBQUM5RSxJQUFELENBQU4sQ0FBUjtBQUNBK0Usa0VBQU0sQ0FBQ3RELElBQVAsQ0FBWSxXQUFaOztBQUhJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BSFI7O0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBT1csVUFBQTdDLE1BQU0sRUFBSTtBQUNqQmlHLGNBQVEsQ0FBQ0Msc0RBQUssQ0FBQztBQUFDRSxlQUFPLEVBQUMsSUFBVDtBQUFjcEcsY0FBTSxFQUFDQSxNQUFNLENBQUNtQyxRQUFQLENBQWdCZjtBQUFyQyxPQUFELENBQU4sQ0FBUjtBQUNELEtBVEg7QUFVSCxHQVhvQjtBQUFBLENBQWQ7QUFjQSxJQUFNaUYsWUFBWSxHQUFHLFNBQWZBLFlBQWUsQ0FBQy9CLEdBQUQsRUFBS2xELElBQUw7QUFBQSxNQUFVTSxPQUFWLHVFQUFvQixFQUFwQjtBQUFBLFNBQTJCLFVBQUF1RSxRQUFRLEVBQUk7QUFDakUxRSxnREFBSyxDQUFDQyxJQUFOLFdBQWNyQyw2QkFBZCxTQUFnRG1GLEdBQWhELEdBQXNEbEQsSUFBdEQsRUFBMkQ7QUFDdkRNLGFBQU8sRUFBQ0E7QUFEK0MsS0FBM0QsRUFHR0ksSUFISDtBQUFBLHFVQUdRLGtCQUFNQyxHQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNKdUUsa0VBQUksQ0FBQ0MsSUFBTCxDQUFVO0FBQ1JDLHNCQUFJLEVBQUUsNkJBREU7QUFFUkMsc0JBQUksRUFBRSxTQUZFO0FBR1JDLG1DQUFpQixFQUFFO0FBSFgsaUJBQVYsRUFJRzVFLElBSkgsQ0FJUSxVQUFBQyxHQUFHLEVBQUk7QUFDYixzQkFBR0EsR0FBRyxDQUFDNEUsV0FBUCxFQUFtQjtBQUNqQlIsc0VBQU0sQ0FBQ3RELElBQVAsQ0FBWSxjQUFaO0FBQ0Q7QUFDRixpQkFSRDtBQURJO0FBQUEsdUJBVWFkLEdBQUcsQ0FBQ1gsSUFWakI7O0FBQUE7QUFVQUEsb0JBVkE7QUFXSjZFLHdCQUFRLENBQUNuRyx5REFBUSxDQUFDc0IsSUFBRCxDQUFULENBQVI7O0FBWEk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FIUjs7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFlVyxVQUFBYSxHQUFHLEVBQUk7QUFDZGdFLGNBQVEsQ0FBQ25HLHlEQUFRLENBQUM7QUFBQ3NHLGVBQU8sRUFBQyxJQUFUO0FBQWNwRyxjQUFNLEVBQUNpQyxHQUFHLENBQUNFLFFBQUosQ0FBYWY7QUFBbEMsT0FBRCxDQUFULENBQVI7QUFDRCxLQWpCSDtBQWtCRCxHQW5CMkI7QUFBQSxDQUFyQjtBQXFCQSxJQUFNd0YsTUFBTSxHQUFHLFNBQVRBLE1BQVM7QUFBQSxTQUFNLFVBQUFYLFFBQVEsRUFBSTtBQUNyQzVFLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLGVBQVo7QUFDQzJFLFlBQVEsQ0FBQ1ksdURBQU0sRUFBUCxDQUFSO0FBQ0gsR0FIcUI7QUFBQSxDQUFmO0FBS0EsSUFBTUMsVUFBVSxHQUFHLFNBQWJBLFVBQWEsQ0FBQ3hDLEdBQUQsRUFBS2xELElBQUw7QUFBQSxNQUFVTSxPQUFWLHVFQUFvQixFQUFwQjtBQUFBLFNBQTJCLFVBQUF1RSxRQUFRLEVBQUk7QUFFN0QxRSxnREFBSyxDQUFDd0YsR0FBTixXQUFhNUgsNkJBQWIsU0FBK0NtRixHQUEvQyxHQUFxRGxELElBQXJELEVBQTBEO0FBQ3RETSxhQUFPLEVBQUVBO0FBRDZDLEtBQTFELEVBR0dJLElBSEgsQ0FHUyxVQUFBQyxHQUFHLEVBQUk7QUFDWmtFLGNBQVEsQ0FBQ2UsMkRBQVUsQ0FBQ2pGLEdBQUcsQ0FBQ1gsSUFBTCxDQUFYLENBQVI7QUFDQ2tGLHdEQUFJLENBQUNDLElBQUwsQ0FBVTtBQUNSQyxZQUFJLEVBQUUsbUNBREU7QUFFUkMsWUFBSSxFQUFFLFNBRkU7QUFHUkMseUJBQWlCLEVBQUU7QUFIWCxPQUFWO0FBS0YsS0FWSCxXQVdTLFVBQUF6RSxHQUFHLEVBQUk7QUFDWmdFLGNBQVEsQ0FBQ2UsMkRBQVUsQ0FBQztBQUFDWixlQUFPLEVBQUMsSUFBVDtBQUFjcEcsY0FBTSxFQUFDaUMsR0FBRyxDQUFDRSxRQUFKLENBQWFmO0FBQWxDLE9BQUQsQ0FBWCxDQUFSO0FBQ0QsS0FiSDtBQWVILEdBakJ5QjtBQUFBLENBQW5CO0FBbUJFLElBQU1vRSxrQkFBa0IsR0FBRyxTQUFyQkEsa0JBQXFCLENBQUNsQixHQUFELEVBQUtsRCxJQUFMLEVBQVVNLE9BQVY7QUFBQSxTQUFzQixVQUFBdUUsUUFBUSxFQUFJO0FBQ2xFMUUsZ0RBQUssQ0FBQ0MsSUFBTixXQUFjckMsNkJBQWQsU0FBZ0RtRixHQUFoRCxHQUFzRGxELElBQXRELEVBQTJEO0FBQ3pETSxhQUFPLEVBQUNBO0FBRGlELEtBQTNELEVBRUdJLElBRkgsQ0FFUSxVQUFBQyxHQUFHLEVBQUk7QUFDYixVQUFHQSxHQUFHLENBQUN6RCxNQUFKLElBQWMsU0FBakIsRUFBMkI7QUFDekJnSSwwREFBSSxDQUFDQyxJQUFMLENBQVU7QUFDUkMsY0FBSSxFQUFFekUsR0FBRyxDQUFDWCxJQUFKLENBQVNjLE9BRFA7QUFFUnVFLGNBQUksRUFBRSxTQUZFO0FBR1JDLDJCQUFpQixFQUFFO0FBSFgsU0FBVjtBQUtBVCxnQkFBUSxDQUFDZ0IsNkRBQVksQ0FBQzdGLElBQUksQ0FBQzhGLE9BQU4sQ0FBYixDQUFSO0FBQ0Q7QUFDRixLQVhELFdBV1MsVUFBQWpGLEdBQUc7QUFBQSxhQUFJWixPQUFPLENBQUNDLEdBQVIsQ0FBWVcsR0FBWixDQUFKO0FBQUEsS0FYWjtBQVlELEdBYmlDO0FBQUEsQ0FBM0I7QUFlRixJQUFNa0YscUJBQXFCLEdBQUcsU0FBeEJBLHFCQUF3QixDQUFDRCxPQUFEO0FBQUEsU0FBYSxVQUFBakIsUUFBUSxFQUFJO0FBQzFEQSxZQUFRLENBQUNtQixnRUFBZSxDQUFDRixPQUFELENBQWhCLENBQVI7QUFDSCxHQUZvQztBQUFBLENBQTlCIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL3BhY2thZ2VzLjliNmFmYTVhMzBhMThlNmMxMWE4LmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdXNlSW50bCB9IGZyb20gJ3JlYWN0LWludGwnO1xyXG5pbXBvcnQgQnV0dG9uQ29tcG9uZW50IGZyb20gXCIuLi9idXR0b24vaW5kZXhcIjtcclxuaW1wb3J0IENoZWNrYm94IGZyb20gXCIuLi9jaGVja2JveC9jaGVja2JveFwiO1xyXG5cclxuZnVuY3Rpb24gUGFja2FnZUl0ZW0oe2l0ZW0sY2hlY2tSZWYsb25DaGVja30pIHtcclxuICAgIGNvbnN0IHsgZm9ybWF0TWVzc2FnZTogZiB9ID0gdXNlSW50bCgpO1xyXG4gICAgY29uc3Qge2xvY2FsZX0gPSB1c2VSb3V0ZXIoKVxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT0ncGFja2FnZS1pdGVtIG1yLXhzJz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J3BhY2thZ2UtaXRlbS1oZWFkZXInPlxyXG4gICAgICAgICAgICAgIHsvKiA8aW1nIHN0eWxlPXt7bWFyZ2luTGVmdDonLTEwcHgnfX0gc3JjPScuL2Fzc2V0cy9pbWFnZXMvYTAyLnN2ZycvPiAqL31cclxuICAgICAgICAgICAgICA8aDE+e2l0ZW0uc2hvcH08L2gxPlxyXG4gICAgICAgICAgICAgIDxoNSBzdHlsZT17e2NvbG9yOmAke2l0ZW0uc3RhdHVzLmNvbG9yfWB9fT57aXRlbS5zdGF0dXMubmFtZX08L2g1PlxyXG4gICAgICAgICAgICAgIDxoNSBzdHlsZT17e2NvbG9yOidyZWQnfX0+e2l0ZW0ucGF5X3N0YXR1c308L2g1PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdwYWNrYWdlLWl0ZW0tYm9keSc+XHJcbiAgICAgICAgICAgICAgICAgPHVsPlxyXG4gICAgICAgICAgICAgICAgICAgICA8bGk+PHN0cm9uZz57Zih7aWQ6XCJ0cmFja2luZ1wifSl9Ojwvc3Ryb25nPjxzbWFsbD57aXRlbS50cmFja19udW1iZXJ9PC9zbWFsbD48L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgICA8bGk+PHN0cm9uZz5TbWFydCBDdXN0b21zIElEOjwvc3Ryb25nPjxzbWFsbD57aXRlbS5zbWFydF9jdXN0b21zX2lkfTwvc21hbGw+PC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgPGxpPjxzdHJvbmc+e2Yoe2lkOlwiZ2V0d2hlcmVcIn0pfTo8L3N0cm9uZz48c21hbGw+e2l0ZW0uZnJvbX08L3NtYWxsPjwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgIDxsaT48c3Ryb25nPntmKHtpZDpcImxhc3RwcmljZVwifSl9Ojwvc3Ryb25nPjxzbWFsbD57cGFyc2VGbG9hdChpdGVtLnByaWNlKjAuMjEpLnRvRml4ZWQoMil9IEFaTjwvc21hbGw+PC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgPGxpPjxzdHJvbmc+e2Yoe2lkOlwiY2F0ZWdvcnlcIn0pfTo8L3N0cm9uZz48c21hbGw+e2l0ZW0uY2F0ZWdvcnl9PC9zbWFsbD48L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgICA8bGk+PHN0cm9uZz57Zih7aWQ6XCJ3ZWlnaHRcIn0pfTo8L3N0cm9uZz48c21hbGw+e2l0ZW0ud2VpZ2h0fSBrcTwvc21hbGw+PC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgPGxpPjxzdHJvbmc+e2Yoe2lkOlwiZGF0ZW9uXCJ9KX06PC9zdHJvbmc+PHNtYWxsPntpdGVtLmRhdGV9PC9zbWFsbD48L2xpPlxyXG4gICAgICAgICAgICAgICAgIDwvdWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGEgaHJlZj17YCR7cHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQVBJX0lNQUdFX1VSTH0ke2l0ZW0uaW52b2ljZX1gfSBkb3dubG9hZCA+PEJ1dHRvbkNvbXBvbmVudCBzdHlsZT17e2ZvbnRTaXplOicxMHB4J319IGNsYXNzTmFtZT0naC1pbml0aWFsIHAteHhzIHctMTAwIGJnLWJnJyBsYWJlbD17Zih7aWQ6XCJzZWUtaW52b2ljZVwifSl9Lz48L2E+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J3BhY2thZ2UtaXRlbS1mb290ZXInPlxyXG4gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0ncGlmLWFtb3VudCc+XHJcbiAgICAgICAgICAgICAgICAgICA8c3Bhbj57Zih7aWQ6XCJkZWxpdmVyeXByaWNlXCJ9KX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5jdXN0b21zX3ZhbHVlXzMgPyBcclxuICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2l0ZW0uY3VzdG9tc192YWx1ZV8zID8gcGFyc2VGbG9hdChpdGVtLmN1c3RvbXNfdmFsdWVfMykudG9GaXhlZCgyKSA6IDAuMDB9IEFaTjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgIDxkZWwgc3R5bGU9e3t0ZXh0RGVjb3JhdGlvbkNvbG9yOidyZWQnfX0gPnsraXRlbS5kZWxpdmVyeV9wcmljZSA/IHBhcnNlRmxvYXQoaXRlbS5kZWxpdmVyeV9wcmljZSkudG9GaXhlZCgyKSA6IDAuMDB9IEFaTjwvZGVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgIDpcclxuICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntpdGVtLmRlbGl2ZXJ5X3ByaWNlID8gcGFyc2VGbG9hdCgraXRlbS5kZWxpdmVyeV9wcmljZSkudG9GaXhlZCgyKSA6IDAuMDB9IEFaTjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgPENoZWNrYm94IFxyXG4gICAgICAgICAgICAgICAgICBSZWY9e2NoZWNrUmVmfSBcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17b25DaGVja30gXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtpdGVtLmlkfVxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXRlbS5wYXlfc3RhdHVzICYmIHRydWV9IFxyXG4gICAgICAgICAgICAgICAgICBkYXRhLXByaWNlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICBwYXJzZUZsb2F0KGl0ZW0uZGVsaXZlcnlfcHJpY2UpLnRvRml4ZWQoMikgIFxyXG4gICAgICAgICAgICAgICAgICAgIH0gXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YS1kaXNjb3VudD17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhcnNlRmxvYXQoaXRlbS5jdXN0b21zX3ZhbHVlXzMpID8gcGFyc2VGbG9hdChpdGVtLmN1c3RvbXNfdmFsdWVfMykudG9GaXhlZCgyKSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgOjBcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIHRleHQ9e2Yoe2lkOlwiY2hvb3Nlb25lXCJ9KX0vPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgUGFja2FnZUl0ZW1cclxuIiwiaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IFJlYWN0LCB7IG1lbW8sIHVzZUxheW91dEVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VGb3JtIH0gZnJvbSBcInJlYWN0LWhvb2stZm9ybVwiO1xyXG5pbXBvcnQgeyB1c2VJbnRsIH0gZnJvbSBcInJlYWN0LWludGxcIjtcclxuaW1wb3J0IHsgY29ubmVjdCB9IGZyb20gXCJyZWFjdC1yZWR1eFwiO1xyXG5pbXBvcnQgQXNpZGVNZW51IGZyb20gXCIuLi9jb21wb25lbnRzL2FzaWRlLW1lbnUvaW5kZXhcIjtcclxuaW1wb3J0IEFzaWRlIGZyb20gXCIuLi9jb21wb25lbnRzL2FzaWRlL2FzaWRlXCI7XHJcbmltcG9ydCBCdXR0b25Db21wb25lbnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvYnV0dG9uXCI7XHJcbmltcG9ydCBDYXJkIGZyb20gXCIuLi9jb21wb25lbnRzL2NhcmQvY2FyZFwiO1xyXG5pbXBvcnQgQ2hlY2tib3ggZnJvbSBcIi4uL2NvbXBvbmVudHMvY2hlY2tib3gvY2hlY2tib3hcIjtcclxuaW1wb3J0IEZyb21Hcm91cCBmcm9tIFwiLi4vY29tcG9uZW50cy9mb3JtLWdyb3VwL2Zvcm0tZ3JvdXBcIjtcclxuaW1wb3J0IElucHV0IGZyb20gXCIuLi9jb21wb25lbnRzL2lucHV0L2lucHV0XCI7XHJcbmltcG9ydCBNYWluIGZyb20gXCIuLi9jb21wb25lbnRzL21haW4vbWFpblwiO1xyXG5pbXBvcnQgUGFja2FnZUl0ZW0gZnJvbSBcIi4uL2NvbXBvbmVudHMvcGFja2FnZV9pdGVtL3BhY2thZ2UtaXRlbVwiO1xyXG5pbXBvcnQgUGFnZSBmcm9tIFwiLi4vY29tcG9uZW50cy9wYWdlL3BhZ2VcIjtcclxuaW1wb3J0IFJlZGlyZWN0IGZyb20gXCIuLi9jb21wb25lbnRzL3JlZGlyZWN0L3JlZGlyZWN0XCI7XHJcbmltcG9ydCBUYWJlbCBmcm9tIFwiLi4vY29tcG9uZW50cy90YWJlbC90YWJlbFwiO1xyXG5pbXBvcnQgeyBQYXlCeUJhbGFuY2VBY3Rpb24gfSBmcm9tICcuLi9yZWR1eC9lbnRyeS9lbnRyeUFjdGlvbnMnO1xyXG5cclxuZnVuY3Rpb24gUGFja2FnZXMocHJvcHMpIHtcclxuICBpZiAoIXByb3BzLmVudHJ5LmlzTG9nZWQpIHtcclxuICAgIHJldHVybiA8UmVkaXJlY3QgLz47XHJcbiAgfVxyXG5cclxuICBjb25zdCB7IHJlZ2lzdGVyLCBoYW5kbGVTdWJtaXQsIGVycm9ycywgc2V0RXJyb3IgfSA9IHVzZUZvcm0oKTtcclxuICBjb25zdCB7IGZvcm1hdE1lc3NhZ2U6IGYgfSA9IHVzZUludGwoKTtcclxuICBjb25zdCBbcGFja2FnZXMsIHNldFBhY2thZ2VzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZmlsdGVyZWRQYWNrcywgc2V0RmlsdGVyZWRQYWNrc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3N0YXR1cywgc2V0U3RhdHVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VsZWN0ZWRQYWNrYWdlcywgc2V0U2VsZWN0ZWRQYWNrYWdlc10gPSB1c2VTdGF0ZSh7XHJcbiAgICBwYWNrYWdlczogW10sXHJcbiAgICB0b3RhbDogMCxcclxuICAgIGRpc2NvdW50VG90YWw6MCxcclxuICAgIGNvZGU6IFwiXCIsXHJcbiAgICBpc0FjY2VwdGVkOiBmYWxzZSxcclxuICAgIHN0YXR1czogMCxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgeyBsb2NhbGUgfSA9IHVzZVJvdXRlcigpO1xyXG4gIGNvbnN0IG1haW5DaGVja1JlZiA9IHVzZVJlZigpO1xyXG4gIGNvbnN0IGNoZWNrUmVmcyA9IHVzZVJlZihbXSk7XHJcbiAgY2hlY2tSZWZzLmN1cnJlbnQgPSBbXTtcclxuICBjb25zdCB0YWJSZWZzID0gdXNlUmVmKFtdKTtcclxuICB0YWJSZWZzLmN1cnJlbnQgPSBbXTtcclxuXHJcbiAgY29uc3Qgc3VibWl0ID0gKGRhdGEpID0+IHtcclxuICAgIGNvbnNvbGUubG9nKGRhdGEpO1xyXG5cclxuICAgIGF4aW9zXHJcbiAgICAgIC5wb3N0KFxyXG4gICAgICAgIGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9cHJvbW9jb2RlP3Byb21vY29kZT0ke2RhdGEucHJvbW9jb2RlfSZzdGF0dXM9JHtzZWxlY3RlZFBhY2thZ2VzLnN0YXR1c31gLFxyXG4gICAgICAgIHt9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgXCJjb250ZW50LXR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbiAgICAgICAgICAgIGF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtwcm9wcy5lbnRyeS51c2VyLmFjY2Vzc1Rva2VufWAsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gICAgICAudGhlbigocmVzKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2cocmVzLmRhdGEuYmF0Y2hlcyk7XHJcbiAgICAgICAgc2V0UGFja2FnZXMocmVzLmRhdGEuYmF0Y2hlcyk7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRQYWNrcyhyZXMuZGF0YS5iYXRjaGVzKTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnIpID0+IHtcclxuICAgICAgICBzZXRFcnJvcihcInByb21vY29kZVwiLCB7IG1lc3NhZ2U6IGVyci5yZXNwb25zZS5kYXRhLmVycm9yIH0pO1xyXG4gICAgICB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBQcm9taXNBbGwgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBsZXQgYmF0Y2hlc0RhdGEgPSBhd2FpdCBheGlvcy5nZXQoYCR7cHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQVBJX1VSTH1iYXRjaGVzP2xhbj0ke2xvY2FsZX1gLCB7XHJcbiAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICBhdXRob3JpemF0aW9uOiBgQmVhcmVyICR7cHJvcHMuZW50cnkudXNlci5hY2Nlc3NUb2tlbn1gLFxyXG4gICAgICB9LFxyXG4gICAgfSk7XHJcbiAgICBsZXQgc3RhdHVzRGF0YSA9IGF3YWl0IGF4aW9zLmdldChgJHtwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19BUElfVVJMfXN0YXR1cz9sYW49JHtsb2NhbGV9YCwge1xyXG4gICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgYXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Byb3BzLmVudHJ5LnVzZXIuYWNjZXNzVG9rZW59YCxcclxuICAgICAgfSxcclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIGJhdGNoZXNEYXRhOmJhdGNoZXNEYXRhLmRhdGEsXHJcbiAgICAgIHN0YXR1c0RhdGE6c3RhdHVzRGF0YS5kYXRhXHJcbiAgICB9XHJcbiAgfVxyXG4gIHVzZUxheW91dEVmZmVjdCgoKSA9PiB7XHJcbiAgICBQcm9taXNBbGwoKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgIGNvbnNvbGUubG9nKHJlcyk7XHJcbiAgICAgIHNldFBhY2thZ2VzKHJlcy5iYXRjaGVzRGF0YSk7XHJcbiAgICAgIHNldEZpbHRlcmVkUGFja3MocmVzLmJhdGNoZXNEYXRhKTtcclxuICAgICAgc2V0U3RhdHVzKHJlcy5zdGF0dXNEYXRhKTtcclxuICAgIH0pLmNhdGNoKGVyciA9PiBjb25zb2xlLmxvZyhlcnIpKVxyXG5cclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IGFkZFRhYlJlZnMgPSAocmVmKSA9PiB7XHJcbiAgICBpZiAocmVmICYmICF0YWJSZWZzLmN1cnJlbnQuaW5jbHVkZXMocmVmKSkge1xyXG4gICAgICB0YWJSZWZzLmN1cnJlbnQucHVzaChyZWYpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHRvZ2dsZVRhYlJlZnMgPSBhc3luYyAoZXYpID0+IHtcclxuICAgIHRhYlJlZnMuY3VycmVudC5mb3JFYWNoKCh4KSA9PiB4LmNsYXNzTGlzdC5yZW1vdmUoXCJwYWNrLWFjdGl2ZVwiKSk7XHJcbiAgICBldi50YXJnZXQuY2xhc3NMaXN0LmFkZChcInBhY2stYWN0aXZlXCIpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdldEJhdGNoZXNCeVN0YXRhdXNJZCA9IGFzeW5jIChpZCkgPT57XHJcbiAgICAgYXhpb3MuZ2V0KGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9YmF0Y2hlcz9zdGF0dXM9JHtpZH0mbGFuPSR7bG9jYWxlfWAsIHtcclxuICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgIGF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtwcm9wcy5lbnRyeS51c2VyLmFjY2Vzc1Rva2VufWAsXHJcbiAgICAgIH0sXHJcbiAgICB9KS50aGVuKChyZXMpID0+IHtcclxuICAgICAgc2V0UGFja2FnZXMocmVzLmRhdGEpO1xyXG4gICAgICBzZXRGaWx0ZXJlZFBhY2tzKHJlcy5kYXRhKTtcclxuICAgIH0pLmNhdGNoKGVyciA9PiBjb25zb2xlLmxvZyhlcnIpKVxyXG5cclxuICBcclxuICB9O1xyXG5cclxuICBjb25zdCB0YWJCdXR0b25DbGljayA9IChldikgPT4ge1xyXG4gICAgbGV0IGlkID0gZXYudGFyZ2V0LmdldEF0dHJpYnV0ZShcImRhdGEtaWRcIik7XHJcbiAgICB0b2dnbGVUYWJSZWZzKGV2KTtcclxuICAgIGdldEJhdGNoZXNCeVN0YXRhdXNJZChpZClcclxuICAgIGlmIChpZCAhPSAwKSB7XHJcbiAgICAgIGxldCBuZXdQYWNrYWdlcyA9IHBhY2thZ2VzLmZpbHRlcigoeCkgPT4geC5zdGF0dXMuaWQgPT0gaWQpO1xyXG4gICAgICBzZXRGaWx0ZXJlZFBhY2tzKFsuLi5uZXdQYWNrYWdlc10pO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0RmlsdGVyZWRQYWNrcyhbLi4ucGFja2FnZXNdKTtcclxuICAgIH1cclxuXHJcbiAgICBzZXRTZWxlY3RlZFBhY2thZ2VzKHtcclxuICAgICAgZGlzY291bnRUb3RhbDogMCxcclxuICAgICAgcGFja2FnZXM6IFtdLFxyXG4gICAgICB0b3RhbDogMCxcclxuICAgICAgY29kZTogXCJcIixcclxuICAgICAgaXNBY2NlcHRlZDogZmFsc2UsXHJcbiAgICAgIHN0YXR1czogaWQsXHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBhZGRDaGVja1JlZnMgPSAocmVmKSA9PiB7XHJcbiAgICBpZiAocmVmICYmICFjaGVja1JlZnMuY3VycmVudC5pbmNsdWRlcyhyZWYpKSB7XHJcbiAgICAgIGNoZWNrUmVmcy5jdXJyZW50LnB1c2gocmVmKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBjaGVja0hhbmRsZXIgPSAoZXYpID0+IHtcclxuICAgIGxldCB7IHZhbHVlLCBjaGVja2VkIH0gPSBldi50YXJnZXQ7XHJcbiAgICBsZXQgcHJpY2UgPSBldi50YXJnZXQuZ2V0QXR0cmlidXRlKFwiZGF0YS1wcmljZVwiKTtcclxuICAgIGxldCBkYXRhRGlzY291bnQgPSBldi50YXJnZXQuZ2V0QXR0cmlidXRlKFwiZGF0YS1kaXNjb3VudFwiKTtcclxuICAgIGxldCB0b3RhbD0wXHJcbiAgICBsZXQgZGlzYz0wXHJcbiAgICBjb25zb2xlLmxvZygnZGlzJyxkYXRhRGlzY291bnQpXHJcbiAgICBpZiAoY2hlY2tlZCkge1xyXG4gICAgICBzZWxlY3RlZFBhY2thZ2VzLnBhY2thZ2VzLnB1c2godmFsdWUpO1xyXG4gICAgICBpZihkYXRhRGlzY291bnQhPTApe1xyXG4gICAgICAgIHNldFNlbGVjdGVkUGFja2FnZXMoe1xyXG4gICAgICAgICAgLi4uc2VsZWN0ZWRQYWNrYWdlcyxcclxuXHJcbiAgICAgICAgICB0b3RhbDogKHNlbGVjdGVkUGFja2FnZXMudG90YWwrcGFyc2VGbG9hdChwcmljZSkpLFxyXG4gICAgICAgICBcclxuICAgICAgICAgIGRpc2NvdW50VG90YWw6IChzZWxlY3RlZFBhY2thZ2VzLmRpc2NvdW50VG90YWwrcGFyc2VGbG9hdChkYXRhRGlzY291bnQpKSxcclxuICAgICAgICAgIHBhY2thZ2VzOiBbLi4uc2VsZWN0ZWRQYWNrYWdlcy5wYWNrYWdlc10sXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIFxyXG4gICAgICB9ZWxzZXtcclxuICAgICAgICBzZXRTZWxlY3RlZFBhY2thZ2VzKHtcclxuICAgICAgICAgIC4uLnNlbGVjdGVkUGFja2FnZXMsXHJcbiAgICAgICAgICBkaXNjb3VudFRvdGFsOiAoc2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsK3BhcnNlRmxvYXQocHJpY2UpKSxcclxuICAgICAgICAgIHRvdGFsOiAoc2VsZWN0ZWRQYWNrYWdlcy50b3RhbCtwYXJzZUZsb2F0KHByaWNlKSksXHJcbiAgICAgICAgICBwYWNrYWdlczogWy4uLnNlbGVjdGVkUGFja2FnZXMucGFja2FnZXNdLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICAgXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBsZXQgbmV3UGFja2FnZXMgPSBzZWxlY3RlZFBhY2thZ2VzLnBhY2thZ2VzLmZpbHRlcigoeCkgPT4geCAhPT0gdmFsdWUpO1xyXG4gICAgICBpZihkYXRhRGlzY291bnQhPTApe1xyXG4gICAgICAgIHNldFNlbGVjdGVkUGFja2FnZXMoe1xyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuLi5zZWxlY3RlZFBhY2thZ2VzLFxyXG5cclxuICAgICAgICAgIHRvdGFsOiBzZWxlY3RlZFBhY2thZ2VzLnRvdGFsID49MCAmJiAoc2VsZWN0ZWRQYWNrYWdlcy50b3RhbC1wYXJzZUZsb2F0KHByaWNlKSksXHJcbiAgICAgICAgIFxyXG4gICAgICAgICAgZGlzY291bnRUb3RhbDogc2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsID49MCAmJiAgKHNlbGVjdGVkUGFja2FnZXMuZGlzY291bnRUb3RhbC1wYXJzZUZsb2F0KGRhdGFEaXNjb3VudCkpLFxyXG4gICAgICAgICAgcGFja2FnZXM6IG5ld1BhY2thZ2VzXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIFxyXG4gICAgICB9ZWxzZXtcclxuICAgICAgICBzZXRTZWxlY3RlZFBhY2thZ2VzKHtcclxuICAgICAgICAgIC4uLnNlbGVjdGVkUGFja2FnZXMsXHJcbiAgICAgICAgICBkaXNjb3VudFRvdGFsOnNlbGVjdGVkUGFja2FnZXMuZGlzY291bnRUb3RhbCA+PTAgJiYgKHNlbGVjdGVkUGFja2FnZXMuZGlzY291bnRUb3RhbC1wYXJzZUZsb2F0KHByaWNlKSksXHJcbiAgICAgICAgICB0b3RhbDpzZWxlY3RlZFBhY2thZ2VzLnRvdGFsID49MCAmJiAoc2VsZWN0ZWRQYWNrYWdlcy50b3RhbC1wYXJzZUZsb2F0KHByaWNlKSksXHJcbiAgICAgICAgICBwYWNrYWdlczpuZXdQYWNrYWdlc1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICAgXHJcbiAgICB9XHJcbiAgICAhc2VsZWN0ZWRQYWNrYWdlcy5wYWNrYWdlcy5zb21lKCh4KSA9PiB4KVxyXG4gICAgICA/IChtYWluQ2hlY2tSZWYuY3VycmVudC5jaGVja2VkID0gZmFsc2UpXHJcbiAgICAgIDogbnVsbDtcclxuICB9O1xyXG5cclxuICBjb25zdCBzZWxlY3RBbGwgPSAoZSkgPT4ge1xyXG4gICAgbGV0IHRvdGFsID0gMDtcclxuICAgIGxldCBkaXNjb3VudFRvdGFsID0gMDtcclxuICAgIGxldCBwYWNrYWdlcyA9IFtdO1xyXG4gICAgY2hlY2tSZWZzLmN1cnJlbnQuZm9yRWFjaCgoeCkgPT4ge1xyXG4gICAgICB4LmNoZWNrZWQgPSBlLnRhcmdldC5jaGVja2VkO1xyXG5cclxuICAgICAgaWYgKGUudGFyZ2V0LmNoZWNrZWQgJiYgIXBhY2thZ2VzLmluY2x1ZGVzKHgudmFsdWUpKSB7XHJcbiAgICAgICAgcGFja2FnZXMucHVzaCh4LnZhbHVlKTtcclxuICAgICAgICB0b3RhbCArPSAreC5nZXRBdHRyaWJ1dGUoXCJkYXRhLXByaWNlXCIpO1xyXG4gICAgICAgIGRpc2NvdW50VG90YWwgKz0gK3guZ2V0QXR0cmlidXRlKFwiZGF0YS1kaXNjb3VudFwiKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBwYWNrYWdlcyA9IHBhY2thZ2VzLmZpbHRlcigocCkgPT4gcCAhPT0geC52YWx1ZSk7XHJcbiAgICAgICAgdG90YWwgLT0gdG90YWwgPj0gMCAmJiAreC5nZXRBdHRyaWJ1dGUoXCJkYXRhLXByaWNlXCIpO1xyXG4gICAgICAgIGRpc2NvdW50VG90YWwgLT0gZGlzY291bnRUb3RhbCA+PTAgJiYgK3guZ2V0QXR0cmlidXRlKFwiZGF0YS1kaXNjb3VudFwiKTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgc2V0U2VsZWN0ZWRQYWNrYWdlcyh7XHJcbiAgICAgIC4uLnNlbGVjdGVkUGFja2FnZXMsXHJcbiAgICAgIHRvdGFsOiBzZWxlY3RlZFBhY2thZ2VzLnRvdGFsLXRvdGFsLFxyXG4gICAgICBwYWNrYWdlczogcGFja2FnZXMsXHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBQYXlieUNhcmQgPSAoZGF0YSA9IHt9KSA9PiB7XHJcbiAgICBheGlvcy5wb3N0KGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9cGF5bWVudGAsZGF0YSx7XHJcbiAgICAgIGhlYWRlcnM6e1xyXG4gICAgICAgIGF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtwcm9wcy5lbnRyeS51c2VyLmFjY2Vzc1Rva2VufWAsXHJcbiAgICAgIH1cclxuICAgIH0pLnRoZW4ocmVzID0+IHtcclxuICAgICAgY29uc29sZS5sb2coJ3JlZCcscmVzLmRhdGEudXJsKTtcclxuICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gcmVzLmRhdGEudXJsO1xyXG4gICAgfSkuY2F0Y2goZXJyID0+IGNvbnNvbGUubG9nKGVycikpXHJcbiAgfVxyXG4gXHJcbiAgcmV0dXJuIChcclxuICAgIDxQYWdlIGNsYXNzTmFtZT1cImJnLWJnIHB0LWxnIHBiLWxnXCI+XHJcbiAgICAgIDxBc2lkZSBjbGFzc05hbWU9XCJtci1zbVwiPlxyXG4gICAgICAgIDxBc2lkZU1lbnUgLz5cclxuICAgICAgPC9Bc2lkZT5cclxuICAgICAgPE1haW4gY2xhc3NOYW1lPVwiYmctYyBwLW5vbmVcIj5cclxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJiZy1iZyBwYi1zbSBtZ21fc3MgcC1zbVwiPlxyXG4gICAgICAgICAgPENhcmQuSGVhZGVyXHJcbiAgICAgICAgICAgIHRleHQ9e2YoeyBpZDogXCJhY3RpdmUtcGFjXCIgfSl9XHJcbiAgICAgICAgICAgIGVuZEVsZWxtZW50PXtcclxuICAgICAgICAgICAgICA8Q2hlY2tib3hcclxuICAgICAgICAgICAgICAgIHRleHQ9e2YoeyBpZDogXCJjaG9vc2UtYWxsXCIgfSl9XHJcbiAgICAgICAgICAgICAgICBSZWY9eyhyZWYpID0+IChtYWluQ2hlY2tSZWYuY3VycmVudCA9IHJlZil9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtzZWxlY3RBbGx9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXItc3VidGl0bGVcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwic3NjXCIgc3R5bGU9e3sgb3ZlcmZsb3dYOiBcInNjcm9sbFwiIH19PlxyXG4gICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiIHBsLW5vbmVcIlxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcclxuICAgICAgICAgICAgICAgIG1hcmdpbkJvdHRvbTogXCIyMHB4XCIsXHJcbiAgICAgICAgICAgICAgICB3aWR0aDogXCJtYXgtY29udGVudFwiLFxyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgID5cclxuXHJcbiAgICAgICAgICAgICAgPEJ1dHRvbkNvbXBvbmVudFxyXG4gICAgICAgICAgICAgICAgbGFiZWw9e2BIYW1zxLEgKCR7cGFja2FnZXMubGVuZ3RofSlgfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXIteHMgcC1zbSBiZy1iZyBwYWNrLWFjdGl2ZVwiXHJcbiAgICAgICAgICAgICAgICBkYXRhLWlkPXswfVxyXG4gICAgICAgICAgICAgICAgUmVmPXthZGRUYWJSZWZzfVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17dGFiQnV0dG9uQ2xpY2t9XHJcbiAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgIHtzdGF0dXMubWFwKCh4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uQ29tcG9uZW50XHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsPXtgJHt4Lm5hbWV9ICgke3guY291bnR9KWB9XHJcbiAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIiBwLXNtIGJnLWJnIFwiXHJcbiAgICAgICAgICAgICAgICAgIGRhdGEtaWQ9e3guaWR9XHJcbiAgICAgICAgICAgICAgICAgIFJlZj17YWRkVGFiUmVmc31cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17dGFiQnV0dG9uQ2xpY2t9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICkpfSBcclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8Q2FyZC5Cb2R5IGNsYXNzTmFtZT1cInAtbm9uZVwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhY2thZ2VzX19mclwiPlxyXG4gICAgICAgICAgICAgIHtmaWx0ZXJlZFBhY2tzXHJcbiAgICAgICAgICAgICAgICAuZmlsdGVyKCh4KSA9PiB4LnN0YXR1cy5pZCAhPT0gNilcclxuICAgICAgICAgICAgICAgIC5tYXAoKHApID0+IChcclxuICAgICAgICAgICAgICAgICAgPFBhY2thZ2VJdGVtXHJcbiAgICAgICAgICAgICAgICAgICAga2V5PXtwLmlkfVxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrUmVmPXthZGRDaGVja1JlZnN9XHJcbiAgICAgICAgICAgICAgICAgICAgaXRlbT17cH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoZWNrPXtjaGVja0hhbmRsZXJ9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L0NhcmQuQm9keT5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9vdGVyX19wY2tcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYWNrYWdlLXRvdGFsXCI+XHJcbiAgICAgICAgICAgICAgPHNtYWxsPlxyXG4gICAgICAgICAgICAgICAge3NlbGVjdGVkUGFja2FnZXMucGFja2FnZXMubGVuZ3RofSB7Zih7IGlkOiBcImNob3NlZFwiIH0pfVxyXG4gICAgICAgICAgICAgIDwvc21hbGw+XHJcbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiIH19PlxyXG4gICAgICAgICAgICAgICAgPGI+e2YoeyBpZDogXCJ0b3RhbFwiIH0pfTo8L2I+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiIH19PlxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICBzZWxlY3RlZFBhY2thZ2VzLmRpc2NvdW50VG90YWwgPiAwID8gXHJcbiAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgIDxkZWwgc3R5bGU9e3sgdGV4dERlY29yYXRpb25Db2xvcjogXCJyZWRcIiB9fT57cGFyc2VGbG9hdChzZWxlY3RlZFBhY2thZ2VzLnRvdGFsKS50b0ZpeGVkKDIpfSBBWk48L2RlbD5cclxuICAgICAgICAgICAgICAgICAgIDxiPntwYXJzZUZsb2F0KHNlbGVjdGVkUGFja2FnZXMuZGlzY291bnRUb3RhbCkudG9GaXhlZCgyKX0gQVpOPC9iPlxyXG4gICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICA6ICA8Yj57cGFyc2VGbG9hdChzZWxlY3RlZFBhY2thZ2VzLmRpc2NvdW50VG90YWwpLnRvRml4ZWQoMil9IEFaTjwvYj5cclxuICAgICAgICAgICAgICAgIH0gIFxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGFja2FnZV9fYnRuc1wiPlxyXG4gICAgICAgICAgICAgIDxmb3JtPlxyXG4gICAgICAgICAgICAgICAgPEZyb21Hcm91cFxyXG4gICAgICAgICAgICAgICAgICBib2R5Q2xhc3M9XCJiZy13aGl0ZSBwbC14c1wiXHJcbiAgICAgICAgICAgICAgICAgIGJvZHlTdHlsZT17eyBoZWlnaHQ6IFwiNDRweFwiLCB3aWR0aDogXCIyMDBweFwiIH19XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1yLXhzIGNobmdfX2JvZHlzdHlsZVwiXHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogXCIwcHhcIiB9fVxyXG4gICAgICAgICAgICAgICAgICBlcnJvcj17ZXJyb3JzLnByb21vY29kZT8ubWVzc2FnZX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e2YoeyBpZDogXCJhZGRjb2RlXCIgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInByb21vY29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgUmVmPXtyZWdpc3Rlcih7XHJcbiAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZDoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogZih7IGlkOiBcInByb21vLXJlcXVpclwiIH0pLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFBhY2thZ2VzKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uc2VsZWN0ZWRQYWNrYWdlcyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29kZTogZS50YXJnZXQudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge3NlbGVjdGVkUGFja2FnZXMuaXNBY2NlcHRlZCA/IChcclxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uQ29tcG9uZW50XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSB3LTUwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRleHREZWNvcmF0aW9uTGluZTogXCJ1bmRlcmxpbmVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwiZGFya2JsdWVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogXCIwcHggMTBweFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiTMmZxJ92IGV0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRQYWNrYWdlcyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uc2VsZWN0ZWRQYWNrYWdlcyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpc0FjY2VwdGVkOiBmYWxzZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbkNvbXBvbmVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFzZWxlY3RlZFBhY2thZ2VzLmNvZGUgPyB0cnVlIDogZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBwYWRkaW5nOiBcIjAgMTBweFwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjb2xvci13aGl0ZSBiZy1zdWNjZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPXtmKHsgaWQ6IFwiY29uZmlybVwiIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTdWJtaXQoc3VibWl0KX1cclxuICAgICAgICAgICAgICAgICAgICAgIC8vICBvbkNsaWNrPXsoKSA9PntcclxuICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAvLyAgc2V0U2VsZWN0ZWRQYWNrYWdlcyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgLy8gICAgLi4uc2VsZWN0ZWRQYWNrYWdlcyxcclxuICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAvLyAgICBpc0FjY2VwdGVkOnRydWVcclxuICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAvLyAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAvLyAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L0Zyb21Hcm91cD5cclxuICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgPEJ1dHRvbkNvbXBvbmVudFxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgcGFkZGluZzogXCIwIDIwcHhcIiB9fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY29sb3Itd2hpdGUgYmctc3VjY2VzcyBtci14cyBkZXNrXCJcclxuICAgICAgICAgICAgICAgIGxhYmVsPXtmKHsgaWQ6IFwicGF5YnljYXJkXCIgfSl9XHJcbiAgICAgICAgICAgICAgICBlbmRFbGVtZW50PXs8c3BhbiBjbGFzc05hbWU9XCJjb2xvci13aGl0ZSBwbC1zbVwiPiYjODU5NDs8L3NwYW4+fVxyXG4gICAgICAgICAgICAgICAgb25DbGljayA9IHsoKSA9PiBQYXlieUNhcmQoe1xyXG4gICAgICAgICAgICAgICAgICBwcmljZTpzZWxlY3RlZFBhY2thZ2VzLmRpc2NvdW50VG90YWwsXHJcbiAgICAgICAgICAgICAgICAgIHNvdXJjZXR5cGU6MixcclxuICAgICAgICAgICAgICAgICAgYmF0Y2hlczpzZWxlY3RlZFBhY2thZ2VzLnBhY2thZ2VzXHJcbiAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxCdXR0b25Db21wb25lbnRcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IHBhZGRpbmc6IFwiMCAxMHB4XCIgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImRlc2tcIlxyXG4gICAgICAgICAgICAgICAgbGFiZWw9e2YoeyBpZDogXCJwYXlieWJhbGFuY2VcIiB9KX1cclxuICAgICAgICAgICAgICAgIGVuZEVsZW1lbnQ9e1xyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjb2xvci1ibGFjayBtci14cyBwbC1zbSBcIj4mIzg1OTQ7PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgb25DbGljayA9IHsoKSA9PiBwcm9wcy5QYXlCeUJhbGFuY2VBY3Rpb24oJ3BheW1lbnQnLHtcclxuICAgICAgICAgICAgICAgICAgcHJpY2U6c2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsLFxyXG4gICAgICAgICAgICAgICAgICBzb3VyY2V0eXBlOjMsXHJcbiAgICAgICAgICAgICAgICAgIGJhdGNoZXM6c2VsZWN0ZWRQYWNrYWdlcy5wYWNrYWdlcyAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgJ2F1dGhvcml6YXRpb24nOmBCZWFyZXIgJHtwcm9wcy5lbnRyeS51c2VyLmFjY2Vzc1Rva2VufWBcclxuICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYnRuX19ma2xcIj5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25Db21wb25lbnRcclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgcGFkZGluZzogXCIwIDEwcHhcIiB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjb2xvci13aGl0ZSBiZy1zdWNjZXNzIG1yLXhzXCJcclxuICAgICAgICAgICAgICAgICAgbGFiZWw9e2YoeyBpZDogXCJwYXlieWNhcmRcIiB9KX1cclxuICAgICAgICAgICAgICAgICAgZW5kRWxlbWVudD17XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY29sb3Itd2hpdGUgcGwtc21cIj4mIzg1OTQ7PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2sgPSB7KCkgPT4gUGF5YnlDYXJkKHtcclxuICAgICAgICAgICAgICAgICAgICBwcmljZTpzZWxlY3RlZFBhY2thZ2VzLmRpc2NvdW50VG90YWwsXHJcbiAgICAgICAgICAgICAgICAgICAgc291cmNldHlwZToyLFxyXG4gICAgICAgICAgICAgICAgICAgIGJhdGNoZXM6c2VsZWN0ZWRQYWNrYWdlcy5wYWNrYWdlc1xyXG4gICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uQ29tcG9uZW50XHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHBhZGRpbmc6IFwiMCAxMHB4XCIgfX1cclxuICAgICAgICAgICAgICAgICAgbGFiZWw9e2YoeyBpZDogXCJwYXlieWJhbGFuY2VcIiB9KX1cclxuICAgICAgICAgICAgICAgICAgZW5kRWxlbWVudD17XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY29sb3ItYmxhY2sgbXIteHMgcGwtc21cIj4mIzg1OTQ7PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2sgPSB7KCkgPT4gcHJvcHMuUGF5QnlCYWxhbmNlQWN0aW9uKCdwYXltZW50Jyx7XHJcbiAgICAgICAgICAgICAgICAgICAgcHJpY2U6c2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsLFxyXG4gICAgICAgICAgICAgICAgICAgIHNvdXJjZXR5cGU6MyxcclxuICAgICAgICAgICAgICAgICAgICBiYXRjaGVzOnNlbGVjdGVkUGFja2FnZXMucGFja2FnZXNcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICdhdXRob3JpemF0aW9uJzpgQmVhcmVyICR7cHJvcHMuZW50cnkudXNlci5hY2Nlc3NUb2tlbn1gXHJcbiAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L0NhcmQ+XHJcblxyXG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInAtc20gYmctd2hpdGVcIj5cclxuICAgICAgICAgIDxDYXJkLkhlYWRlciB0ZXh0PXtmKHsgaWQ6IFwib3JkZXItaGlzdG9yeVwiIH0pfSAvPlxyXG4gICAgICAgICAgPENhcmQuQm9keSBjbGFzc05hbWU9XCJwLW5vbmUgb3ZlcmZsb3dfX3BhY2thZ2VcIj5cclxuICAgICAgICAgICAgPFRhYmVsXHJcbiAgICAgICAgICAgICAgdGg9e1tcclxuICAgICAgICAgICAgICAgIGYoeyBpZDogXCJ0cmFja2luZ1wiIH0pLFxyXG4gICAgICAgICAgICAgICAgZih7IGlkOiBcInNob3BcIiB9KSxcclxuICAgICAgICAgICAgICAgIGYoeyBpZDogXCJjYXRlZ29yeVwiIH0pLFxyXG4gICAgICAgICAgICAgICAgZih7IGlkOiBcImFtb3VudFwiIH0pLFxyXG4gICAgICAgICAgICAgICAgZih7IGlkOiBcIndlaWdodFwiIH0pLFxyXG4gICAgICAgICAgICAgICAgZih7IGlkOiBcImRlbGl2ZXJ5XCIgfSksXHJcbiAgICAgICAgICAgICAgICBmKHsgaWQ6IFwic3RhdHVzXCIgfSksXHJcbiAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICBkYXRhPXtcclxuICAgICAgICAgICAgICAgIHBhY2thZ2VzLm1hcCgoeCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBpZiAoeC5zdGF0dXMuaWQgPT0gNikge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICB0cmFja19udW1iZXI6IHgudHJhY2tfbnVtYmVyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvcDogeC5zaG9wLFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2F0ZWdvcnk6IHguY2F0ZWdvcnksXHJcbiAgICAgICAgICAgICAgICAgICAgICBwcmljZTogYCR7eC5wcmljZX0gJHt4LmN1cnJlbmN5fWAsXHJcbiAgICAgICAgICAgICAgICAgICAgICB3ZWlnaHQ6IGAke3BhcnNlRmxvYXQoeC53ZWlnaHQpLnRvRml4ZWQoMikgfHwgMH0ga3FgLFxyXG4gICAgICAgICAgICAgICAgICAgICAgZGVsaXZlcnlfcHJpY2U6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhcnNlRmxvYXQoeC5kZWxpdmVyeV9wcmljZSkudG9GaXhlZCgyKSB8fCAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiBgJHt4LnN0YXR1cy5uYW1lfVxcbiAke3guZGF0ZX1gLFxyXG4gICAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pIHx8IFtdXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIHJlbmRlckJvZHk9eyh4LCBpKSA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gPHRkIGtleT17aSsrfT57eH08L3RkPjtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9DYXJkLkJvZHk+XHJcbiAgICAgICAgPC9DYXJkPlxyXG4gICAgICA8L01haW4+XHJcbiAgICA8L1BhZ2U+XHJcbiAgKTtcclxufVxyXG5cclxuY29uc3QgbWFwU3RhdGVUb1Byb3BzID0gKHN0YXRlKSA9PiAoe1xyXG4gIGVudHJ5OiBzdGF0ZS5lbnRyeSxcclxufSk7XHJcbmNvbnN0IG1hcERpc3BhdGNoVG9Qcm9wcyA9ICB7XHJcbiAgUGF5QnlCYWxhbmNlQWN0aW9uXHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBjb25uZWN0KG1hcFN0YXRlVG9Qcm9wcywgbWFwRGlzcGF0Y2hUb1Byb3BzKShtZW1vKFBhY2thZ2VzKSk7XHJcbiIsIlxyXG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCByb3V0ZXIgZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcbmltcG9ydCBTd2FsIGZyb20gXCJzd2VldGFsZXJ0MlwiO1xyXG5pbXBvcnQgeyBJbmNyZWFzZUJhbGFuY2UsIGxvZ2luLCBsb2dvdXQsIFBheUJ5QmFsYW5jZSwgcmVnaXN0ZXIsIHVwZGF0ZVVzZXIgfSBmcm9tIFwiLi9hY3Rpb25zXCI7XHJcblxyXG5leHBvcnQgY29uc3QgTG9naW4gPSAodXJsLGRhdGEsaGVhZGVycyA9IHt9KSA9PiBkaXNwYXRjaCA9PiB7XHJcbiAgICBheGlvcy5wb3N0KGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9JHt1cmx9YCxkYXRhLHtcclxuICAgICAgICBoZWFkZXJzOmhlYWRlcnMsXHJcbiAgICAgIH0pXHJcbiAgICAgIC50aGVuKGFzeW5jIHJlcyA9PiB7XHJcbiAgICAgICAgbGV0IGRhdGEgPSBhd2FpdCByZXMuZGF0YTtcclxuICAgICAgICBkaXNwYXRjaChsb2dpbihkYXRhKSlcclxuICAgICAgICByb3V0ZXIucHVzaCgnL3BhY2thZ2VzJylcclxuICAgICAgfSkuY2F0Y2goZXJyb3JzID0+IHtcclxuICAgICAgICBkaXNwYXRjaChsb2dpbih7aXNFcnJvcjp0cnVlLGVycm9yczplcnJvcnMucmVzcG9uc2UuZGF0YX0pKVxyXG4gICAgICB9KVxyXG59XHJcblxyXG5cclxuZXhwb3J0IGNvbnN0IFVzZXJSZWdpc3RlciA9ICh1cmwsZGF0YSxoZWFkZXJzID0ge30pID0+IGRpc3BhdGNoID0+IHtcclxuICBheGlvcy5wb3N0KGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9JHt1cmx9YCxkYXRhLHtcclxuICAgICAgaGVhZGVyczpoZWFkZXJzLFxyXG4gICAgfSlcclxuICAgIC50aGVuKGFzeW5jIHJlcyA9PiB7XHJcbiAgICAgIFN3YWwuZmlyZSh7XHJcbiAgICAgICAgdGV4dDogJ8aPbcmZbGl5eWF0IHXEn3VybGEgdGFtYW1sYW5kxLEnLFxyXG4gICAgICAgIGljb246ICdzdWNjZXNzJyxcclxuICAgICAgICBjb25maXJtQnV0dG9uVGV4dDogJ09LJyxcclxuICAgICAgfSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgIGlmKHJlcy5pc0NvbmZpcm1lZCl7XHJcbiAgICAgICAgICByb3V0ZXIucHVzaCgnL215YWRkcmVzc2VzJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgICBsZXQgZGF0YSA9IGF3YWl0IHJlcy5kYXRhO1xyXG4gICAgICBkaXNwYXRjaChyZWdpc3RlcihkYXRhKSlcclxuICAgIH0pLmNhdGNoKGVyciA9PiB7XHJcbiAgICAgIGRpc3BhdGNoKHJlZ2lzdGVyKHtpc0Vycm9yOnRydWUsZXJyb3JzOmVyci5yZXNwb25zZS5kYXRhfSkpXHJcbiAgICB9KVxyXG59XHJcblxyXG5leHBvcnQgY29uc3QgTG9nT3V0ID0gKCkgPT4gZGlzcGF0Y2ggPT4ge1xyXG4gICBjb25zb2xlLmxvZygnd29yZGVrIGxvZ291dCcpXHJcbiAgICBkaXNwYXRjaChsb2dvdXQoKSlcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IFVwZGF0ZVVzZXIgPSAodXJsLGRhdGEsaGVhZGVycyA9IHt9KSA9PiBkaXNwYXRjaCA9PiB7XHJcblxyXG4gICAgYXhpb3MucHV0KGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9JHt1cmx9YCxkYXRhLHtcclxuICAgICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICAgIH0pXHJcbiAgICAgIC50aGVuKCByZXMgPT4ge1xyXG4gICAgICAgIGRpc3BhdGNoKHVwZGF0ZVVzZXIocmVzLmRhdGEpKVxyXG4gICAgICAgICBTd2FsLmZpcmUoe1xyXG4gICAgICAgICAgIHRleHQ6ICfGj23JmWxpeXlhdCB1xJ91cmxhIHllcmluyZkgeWV0aXJpbGRpJyxcclxuICAgICAgICAgICBpY29uOiAnc3VjY2VzcycsXHJcbiAgICAgICAgICAgY29uZmlybUJ1dHRvblRleHQ6ICdPSycsXHJcbiAgICAgICAgIH0pXHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaChlcnIgPT4ge1xyXG4gICAgICAgIGRpc3BhdGNoKHVwZGF0ZVVzZXIoe2lzRXJyb3I6dHJ1ZSxlcnJvcnM6ZXJyLnJlc3BvbnNlLmRhdGF9KSlcclxuICAgICAgfSlcclxuICBcclxufVxyXG5cclxuICBleHBvcnQgY29uc3QgUGF5QnlCYWxhbmNlQWN0aW9uID0gKHVybCxkYXRhLGhlYWRlcnMpID0+IGRpc3BhdGNoID0+IHtcclxuICAgIGF4aW9zLnBvc3QoYCR7cHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQVBJX1VSTH0ke3VybH1gLGRhdGEse1xyXG4gICAgICBoZWFkZXJzOmhlYWRlcnMsXHJcbiAgICB9KS50aGVuKHJlcyA9PiB7XHJcbiAgICAgIGlmKHJlcy5zdGF0dXMgPT0gJ3N1Y2Nlc3MnKXsgXHJcbiAgICAgICAgU3dhbC5maXJlKHtcclxuICAgICAgICAgIHRleHQ6IHJlcy5kYXRhLm1lc3NhZ2UsXHJcbiAgICAgICAgICBpY29uOiAnc3VjY2VzcycsXHJcbiAgICAgICAgICBjb25maXJtQnV0dG9uVGV4dDogJ09LJyxcclxuICAgICAgICB9KTtcclxuICAgICAgICBkaXNwYXRjaChQYXlCeUJhbGFuY2UoZGF0YS5iYWxhbmNlKSlcclxuICAgICAgfVxyXG4gICAgfSkuY2F0Y2goZXJyID0+IGNvbnNvbGUubG9nKGVycikpO1xyXG4gIH1cclxuXHJcbmV4cG9ydCBjb25zdCBJbmNyZWFzZUJhbGFuY2VBY3Rpb24gPSAoYmFsYW5jZSkgPT4gZGlzcGF0Y2ggPT4ge1xyXG4gICAgZGlzcGF0Y2goSW5jcmVhc2VCYWxhbmNlKGJhbGFuY2UpKVxyXG59XHJcblxyXG5cclxuXHJcbiJdLCJzb3VyY2VSb290IjoiIn0=