webpackHotUpdate_N_E("pages/packages",{

/***/ "./pages/packages.js":
/*!***************************!*\
  !*** ./pages/packages.js ***!
  \***************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/toConsumableArray */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/regenerator */ "./node_modules/next/node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-hook-form */ "./node_modules/react-hook-form/dist/index.esm.js");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-intl */ "./node_modules/react-intl/lib/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _components_aside_menu_index__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../components/aside-menu/index */ "./components/aside-menu/index.js");
/* harmony import */ var _components_aside_aside__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../components/aside/aside */ "./components/aside/aside.js");
/* harmony import */ var _components_button__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../components/button */ "./components/button/index.js");
/* harmony import */ var _components_card_card__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../components/card/card */ "./components/card/card.js");
/* harmony import */ var _components_checkbox_checkbox__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../components/checkbox/checkbox */ "./components/checkbox/checkbox.js");
/* harmony import */ var _components_form_group_form_group__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../components/form-group/form-group */ "./components/form-group/form-group.js");
/* harmony import */ var _components_input_input__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../components/input/input */ "./components/input/input.js");
/* harmony import */ var _components_main_main__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../components/main/main */ "./components/main/main.js");
/* harmony import */ var _components_package_item_package_item__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../components/package_item/package-item */ "./components/package_item/package-item.js");
/* harmony import */ var _components_page_page__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../components/page/page */ "./components/page/page.js");
/* harmony import */ var _components_redirect_redirect__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../components/redirect/redirect */ "./components/redirect/redirect.js");
/* harmony import */ var _components_tabel_tabel__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../components/tabel/tabel */ "./components/tabel/tabel.js");
/* harmony import */ var _redux_entry_entryActions__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../redux/entry/entryActions */ "./redux/entry/entryActions.js");







var _jsxFileName = "C:\\Users\\Home\\Desktop\\166\\166-kargo\\pages\\packages.js",
    _s = $RefreshSig$();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }





















function Packages(props) {
  _s();

  var _this = this,
      _errors$promocode;

  if (!props.entry.isLoged) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_redirect_redirect__WEBPACK_IMPORTED_MODULE_21__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 23,
      columnNumber: 12
    }, this);
  }

  var _useForm = Object(react_hook_form__WEBPACK_IMPORTED_MODULE_8__["useForm"])(),
      register = _useForm.register,
      handleSubmit = _useForm.handleSubmit,
      errors = _useForm.errors,
      setError = _useForm.setError;

  var _useIntl = Object(react_intl__WEBPACK_IMPORTED_MODULE_9__["useIntl"])(),
      f = _useIntl.formatMessage;

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])([]),
      packages = _useState[0],
      setPackages = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])([]),
      filteredPacks = _useState2[0],
      setFilteredPacks = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])([]),
      status = _useState3[0],
      setStatus = _useState3[1];

  var _useState4 = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])({
    packages: [],
    total: 0,
    discountTotal: 0,
    code: "",
    isAccepted: false,
    status: 0
  }),
      selectedPackages = _useState4[0],
      setSelectedPackages = _useState4[1];

  var _useRouter = Object(next_router__WEBPACK_IMPORTED_MODULE_6__["useRouter"])(),
      locale = _useRouter.locale;

  var mainCheckRef = Object(react__WEBPACK_IMPORTED_MODULE_7__["useRef"])();
  var checkRefs = Object(react__WEBPACK_IMPORTED_MODULE_7__["useRef"])([]);
  checkRefs.current = [];
  var tabRefs = Object(react__WEBPACK_IMPORTED_MODULE_7__["useRef"])([]);
  tabRefs.current = [];

  var submit = function submit(data) {
    console.log(data);
    axios__WEBPACK_IMPORTED_MODULE_5___default.a.post("".concat("https://166api.titr.az/api/", "promocode?promocode=").concat(data.promocode, "&status=").concat(selectedPackages.status), {}, {
      headers: {
        "content-type": "application/json",
        authorization: "Bearer ".concat(props.entry.user.accessToken)
      }
    }).then(function (res) {
      console.log(res.data.batches);
      setPackages(res.data.batches);
      setFilteredPacks(res.data.batches);
    })["catch"](function (err) {
      setError("promocode", {
        message: err.response.data.error
      });
    });
  };

  Object(react__WEBPACK_IMPORTED_MODULE_7__["useLayoutEffect"])(function () {
    // axios.get(`${process.env.NEXT_PUBLIC_API_URL}batches?lan=${locale}`, {
    //     headers: {
    //       authorization: `Bearer ${props.entry.user.accessToken}`,
    //     },
    //   })
    //   .then((res) => {
    //     setPackages(res.data);
    //     setFilteredPacks(res.data);
    //   })
    //   .catch((err) => console.log(err));
    Promise.all([axios__WEBPACK_IMPORTED_MODULE_5___default.a.get("".concat("https://166api.titr.az/api/", "batches?lan=").concat(locale), {
      headers: {
        authorization: "Bearer ".concat(props.entry.user.accessToken)
      }
    }), axios__WEBPACK_IMPORTED_MODULE_5___default.a.get("".concat("https://166api.titr.az/api/", "status?lan=").concat(locale), {
      headers: {
        authorization: "Bearer ".concat(props.entry.user.accessToken)
      }
    })]).then(function (res) {
      console.log(res.data);
      setPackages(res[0].data);
      setFilteredPacks(res[0].data);
      setStatus(res[1].data);
    })["catch"](function (err) {
      return console.log(err);
    });
  }, []);

  var addTabRefs = function addTabRefs(ref) {
    if (ref && !tabRefs.current.includes(ref)) {
      tabRefs.current.push(ref);
    }
  };

  var toggleTabRefs = /*#__PURE__*/function () {
    var _ref = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_4__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.mark(function _callee(ev) {
      return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              tabRefs.current.forEach(function (x) {
                return x.classList.remove("pack-active");
              });
              ev.target.classList.add("pack-active");

            case 2:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function toggleTabRefs(_x) {
      return _ref.apply(this, arguments);
    };
  }();

  var tabButtonClick = function tabButtonClick(ev) {
    toggleTabRefs(ev);
    var id = ev.target.getAttribute("data-id");

    if (id != 0) {
      var newPackages = packages.filter(function (x) {
        return x.status.id == id;
      });
      setFilteredPacks(Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(newPackages));
    } else {
      setFilteredPacks(Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(packages));
    }

    setSelectedPackages({
      discountTotal: 0,
      packages: [],
      total: 0,
      code: "",
      isAccepted: false,
      status: id
    });
  };

  var addCheckRefs = function addCheckRefs(ref) {
    if (ref && !checkRefs.current.includes(ref)) {
      checkRefs.current.push(ref);
    }
  };

  var checkHandler = function checkHandler(ev) {
    var _ev$target = ev.target,
        value = _ev$target.value,
        checked = _ev$target.checked;
    var price = ev.target.getAttribute("data-price");
    var dataDiscount = ev.target.getAttribute("data-discount");
    var total = 0;
    var disc = 0;
    console.log('dis', dataDiscount);

    if (checked) {
      selectedPackages.packages.push(value);

      if (dataDiscount != 0) {
        setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
          total: selectedPackages.total + parseFloat(price),
          discountTotal: selectedPackages.discountTotal + parseFloat(dataDiscount),
          packages: Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(selectedPackages.packages)
        }));
      } else {
        setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
          discountTotal: selectedPackages.discountTotal + parseFloat(price),
          total: selectedPackages.total + parseFloat(price),
          packages: Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(selectedPackages.packages)
        }));
      }
    } else {
      var newPackages = selectedPackages.packages.filter(function (x) {
        return x !== value;
      });

      if (dataDiscount != 0) {
        setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
          total: selectedPackages.total >= 0 && selectedPackages.total - parseFloat(price),
          discountTotal: selectedPackages.discountTotal >= 0 && selectedPackages.discountTotal - parseFloat(dataDiscount),
          packages: newPackages
        }));
      } else {
        setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
          discountTotal: selectedPackages.discountTotal >= 0 && selectedPackages.discountTotal - parseFloat(price),
          total: selectedPackages.total >= 0 && selectedPackages.total - parseFloat(price),
          packages: newPackages
        }));
      }
    }

    !selectedPackages.packages.some(function (x) {
      return x;
    }) ? mainCheckRef.current.checked = false : null;
  };

  var selectAll = function selectAll(e) {
    var total = 0;
    var discountTotal = 0;
    var packages = [];
    checkRefs.current.forEach(function (x) {
      x.checked = e.target.checked;

      if (e.target.checked && !packages.includes(x.value)) {
        packages.push(x.value);
        total += +x.getAttribute("data-price");
        discountTotal += +x.getAttribute("data-discount");
      } else {
        packages = packages.filter(function (p) {
          return p !== x.value;
        });
        total -= total >= 0 && +x.getAttribute("data-price");
        discountTotal -= discountTotal >= 0 && +x.getAttribute("data-discount");
      }
    });
    setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
      total: selectedPackages.total - total,
      packages: packages
    }));
  };

  var PaybyCard = function PaybyCard() {
    var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    axios__WEBPACK_IMPORTED_MODULE_5___default.a.post("".concat("https://166api.titr.az/api/", "payment"), data, {
      headers: {
        authorization: "Bearer ".concat(props.entry.user.accessToken)
      }
    }).then(function (res) {
      console.log('red', res.data.url); // window.location.href = res.data.url;
    })["catch"](function (err) {
      return console.log(err);
    });
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_page_page__WEBPACK_IMPORTED_MODULE_20__["default"], {
    className: "bg-bg pt-lg pb-lg",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_aside_aside__WEBPACK_IMPORTED_MODULE_12__["default"], {
      className: "mr-sm",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_aside_menu_index__WEBPACK_IMPORTED_MODULE_11__["default"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 236,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 235,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_main_main__WEBPACK_IMPORTED_MODULE_18__["default"], {
      className: "bg-c p-none",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"], {
        className: "bg-bg pb-sm mgm_ss p-sm",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"].Header, {
          text: f({
            id: "active-pac"
          }),
          endElelment: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_checkbox_checkbox__WEBPACK_IMPORTED_MODULE_15__["default"], {
            text: f({
              id: "choose-all"
            }),
            Ref: function Ref(ref) {
              return mainCheckRef.current = ref;
            },
            onClick: selectAll,
            className: "bg-white border-subtitle"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 243,
            columnNumber: 15
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 240,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          "class": "ssc",
          style: {
            overflowX: "scroll"
          },
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: " pl-none",
            style: {
              display: "flex",
              marginBottom: "20px",
              width: "max-content"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
              label: "Hams\u0131 (".concat(packages.length, ")"),
              className: "mr-xs p-sm bg-bg pack-active",
              "data-id": 0,
              Ref: addTabRefs,
              onClick: tabButtonClick
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 261,
              columnNumber: 15
            }, this), status.map(function (x) {
              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                label: "".concat(x.name, " (").concat(packages.filter(function (x) {
                  return x.status.id == 3;
                }).length, ")"),
                className: " mr-xs p-sm bg-bg ",
                "data-id": x.id,
                Ref: addTabRefs,
                onClick: tabButtonClick
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 270,
                columnNumber: 17
              }, _this);
            })]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 252,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 251,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"].Body, {
          className: "p-none",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "packages__fr",
            children: filteredPacks.filter(function (x) {
              return x.status.id !== 6;
            }).map(function (p) {
              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_package_item_package_item__WEBPACK_IMPORTED_MODULE_19__["default"], {
                checkRef: addCheckRefs,
                item: p,
                onCheck: checkHandler
              }, p.id, false, {
                fileName: _jsxFileName,
                lineNumber: 290,
                columnNumber: 19
              }, _this);
            })
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 286,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 285,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "footer__pck",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "package-total",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
              children: [selectedPackages.packages.length, " ", f({
                id: "chosed"
              })]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 301,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                display: "flex",
                justifyContent: "space-between"
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                children: [f({
                  id: "total"
                }), ":"]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 305,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                style: {
                  display: "flex",
                  flexDirection: "column"
                },
                children: selectedPackages.discountTotal > 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
                    style: {
                      textDecorationColor: "red"
                    },
                    children: [parseFloat(selectedPackages.total).toFixed(2), " AZN"]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 310,
                    columnNumber: 19
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                    children: [parseFloat(selectedPackages.discountTotal).toFixed(2), " AZN"]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 311,
                    columnNumber: 20
                  }, this)]
                }, void 0, true) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                  children: [parseFloat(selectedPackages.discountTotal).toFixed(2), " AZN"]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 313,
                  columnNumber: 23
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 306,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 304,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 300,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "package__btns",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("form", {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_form_group_form_group__WEBPACK_IMPORTED_MODULE_16__["default"], {
                bodyClass: "bg-white pl-xs",
                bodyStyle: {
                  height: "44px",
                  width: "200px"
                },
                className: "mr-xs chng__bodystyle",
                style: {
                  marginBottom: "0px"
                },
                error: (_errors$promocode = errors.promocode) === null || _errors$promocode === void 0 ? void 0 : _errors$promocode.message,
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_input_input__WEBPACK_IMPORTED_MODULE_17__["default"], {
                  placeholder: f({
                    id: "addcode"
                  }),
                  name: "promocode",
                  Ref: register({
                    required: {
                      value: true,
                      message: f({
                        id: "promo-requir"
                      })
                    }
                  }),
                  onChange: function onChange(e) {
                    return setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
                      code: e.target.value
                    }));
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 329,
                  columnNumber: 19
                }, this), selectedPackages.isAccepted ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                  className: "bg-white w-50",
                  style: {
                    textDecorationLine: "underline",
                    color: "darkblue",
                    padding: "0px 10px"
                  },
                  label: "L\u0259\u011Fv et",
                  onClick: function onClick() {
                    setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
                      isAccepted: false
                    }));
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 346,
                  columnNumber: 21
                }, this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                  disabled: !selectedPackages.code ? true : false,
                  style: {
                    padding: "0 10px"
                  },
                  className: "color-white bg-success",
                  label: f({
                    id: "confirm"
                  }),
                  type: "submit",
                  onClick: handleSubmit(submit) //  onClick={() =>{
                  //     //  setSelectedPackages({
                  //     //    ...selectedPackages,
                  //     //    isAccepted:true
                  //     //  });
                  //    }}

                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 362,
                  columnNumber: 21
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 322,
                columnNumber: 17
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 321,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
              style: {
                padding: "0 20px"
              },
              className: "color-white bg-success mr-xs desk",
              label: f({
                id: "paybycard"
              }),
              endElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                className: "color-white pl-sm",
                children: "\u2192"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 384,
                columnNumber: 29
              }, this),
              onClick: function onClick() {
                return PaybyCard({
                  price: selectedPackages.discountTotal,
                  sourcetype: 2
                });
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 380,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
              style: {
                padding: "0 10px"
              },
              className: "desk",
              label: f({
                id: "paybybalance"
              }),
              endElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                className: "color-black mr-xs pl-sm ",
                children: "\u2192"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 395,
                columnNumber: 19
              }, this),
              onClick: function onClick() {
                return props.PayByBalanceAction('payment', {
                  price: selectedPackages.discountTotal,
                  sourcetype: 3
                }, {
                  'authorization': "Bearer ".concat(props.entry.user.accessToken)
                });
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 390,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "btn__fkl",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                style: {
                  padding: "0 10px"
                },
                className: "color-white bg-success mr-xs",
                label: f({
                  id: "paybycard"
                }),
                endElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "color-white pl-sm",
                  children: "\u2192"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 413,
                  columnNumber: 21
                }, this),
                onClick: function onClick() {
                  return PaybyCard({
                    price: selectedPackages.discountTotal,
                    sourcetype: 2
                  });
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 408,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                style: {
                  padding: "0 10px"
                },
                label: f({
                  id: "paybybalance"
                }),
                endElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "color-black mr-xs pl-sm",
                  children: "\u2192"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 424,
                  columnNumber: 21
                }, this),
                onClick: function onClick() {
                  return props.PayByBalanceAction('payment', {
                    price: selectedPackages.discountTotal,
                    sourcetype: 3
                  }, {
                    'authorization': "Bearer ".concat(props.entry.user.accessToken)
                  });
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 420,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 407,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 320,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 299,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 239,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"], {
        className: "p-sm bg-white",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"].Header, {
          text: f({
            id: "order-history"
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 440,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"].Body, {
          className: "p-none overflow__package",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_tabel_tabel__WEBPACK_IMPORTED_MODULE_22__["default"], {
            th: [f({
              id: "tracking"
            }), f({
              id: "shop"
            }), f({
              id: "category"
            }), f({
              id: "amount"
            }), f({
              id: "weight"
            }), f({
              id: "delivery"
            }), f({
              id: "status"
            })],
            data: packages.map(function (x) {
              if (x.status.id == 6) {
                return {
                  track_number: x.track_number,
                  shop: x.shop,
                  category: x.category,
                  price: "".concat(x.price, " ").concat(x.currency),
                  weight: "".concat(parseFloat(x.weight).toFixed(2) || 0, " kq"),
                  delivery_price: parseFloat(x.delivery_price).toFixed(2) || 0,
                  status: "".concat(x.status.name, "\n ").concat(x.date)
                };
              }
            }) || [],
            renderBody: function renderBody(x, i) {
              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {
                children: x
              }, i++, false, {
                fileName: _jsxFileName,
                lineNumber: 469,
                columnNumber: 24
              }, _this);
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 442,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 441,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 439,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 238,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 234,
    columnNumber: 5
  }, this);
}

_s(Packages, "3E201Kyf6S2uVJ0+DS1LdJkJE1g=", false, function () {
  return [react_hook_form__WEBPACK_IMPORTED_MODULE_8__["useForm"], react_intl__WEBPACK_IMPORTED_MODULE_9__["useIntl"], next_router__WEBPACK_IMPORTED_MODULE_6__["useRouter"]];
});

_c = Packages;

var mapStateToProps = function mapStateToProps(state) {
  return {
    entry: state.entry
  };
};

var mapDispatchToProps = {
  PayByBalanceAction: _redux_entry_entryActions__WEBPACK_IMPORTED_MODULE_23__["PayByBalanceAction"]
};
/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_10__["connect"])(mapStateToProps, mapDispatchToProps)( /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_7__["memo"])(Packages)));

var _c;

$RefreshReg$(_c, "Packages");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvcGFja2FnZXMuanMiXSwibmFtZXMiOlsiUGFja2FnZXMiLCJwcm9wcyIsImVudHJ5IiwiaXNMb2dlZCIsInVzZUZvcm0iLCJyZWdpc3RlciIsImhhbmRsZVN1Ym1pdCIsImVycm9ycyIsInNldEVycm9yIiwidXNlSW50bCIsImYiLCJmb3JtYXRNZXNzYWdlIiwidXNlU3RhdGUiLCJwYWNrYWdlcyIsInNldFBhY2thZ2VzIiwiZmlsdGVyZWRQYWNrcyIsInNldEZpbHRlcmVkUGFja3MiLCJzdGF0dXMiLCJzZXRTdGF0dXMiLCJ0b3RhbCIsImRpc2NvdW50VG90YWwiLCJjb2RlIiwiaXNBY2NlcHRlZCIsInNlbGVjdGVkUGFja2FnZXMiLCJzZXRTZWxlY3RlZFBhY2thZ2VzIiwidXNlUm91dGVyIiwibG9jYWxlIiwibWFpbkNoZWNrUmVmIiwidXNlUmVmIiwiY2hlY2tSZWZzIiwiY3VycmVudCIsInRhYlJlZnMiLCJzdWJtaXQiLCJkYXRhIiwiY29uc29sZSIsImxvZyIsImF4aW9zIiwicG9zdCIsInByb2Nlc3MiLCJwcm9tb2NvZGUiLCJoZWFkZXJzIiwiYXV0aG9yaXphdGlvbiIsInVzZXIiLCJhY2Nlc3NUb2tlbiIsInRoZW4iLCJyZXMiLCJiYXRjaGVzIiwiZXJyIiwibWVzc2FnZSIsInJlc3BvbnNlIiwiZXJyb3IiLCJ1c2VMYXlvdXRFZmZlY3QiLCJQcm9taXNlIiwiYWxsIiwiZ2V0IiwiYWRkVGFiUmVmcyIsInJlZiIsImluY2x1ZGVzIiwicHVzaCIsInRvZ2dsZVRhYlJlZnMiLCJldiIsImZvckVhY2giLCJ4IiwiY2xhc3NMaXN0IiwicmVtb3ZlIiwidGFyZ2V0IiwiYWRkIiwidGFiQnV0dG9uQ2xpY2siLCJpZCIsImdldEF0dHJpYnV0ZSIsIm5ld1BhY2thZ2VzIiwiZmlsdGVyIiwiYWRkQ2hlY2tSZWZzIiwiY2hlY2tIYW5kbGVyIiwidmFsdWUiLCJjaGVja2VkIiwicHJpY2UiLCJkYXRhRGlzY291bnQiLCJkaXNjIiwicGFyc2VGbG9hdCIsInNvbWUiLCJzZWxlY3RBbGwiLCJlIiwicCIsIlBheWJ5Q2FyZCIsInVybCIsIm92ZXJmbG93WCIsImRpc3BsYXkiLCJtYXJnaW5Cb3R0b20iLCJ3aWR0aCIsImxlbmd0aCIsIm1hcCIsIm5hbWUiLCJqdXN0aWZ5Q29udGVudCIsImZsZXhEaXJlY3Rpb24iLCJ0ZXh0RGVjb3JhdGlvbkNvbG9yIiwidG9GaXhlZCIsImhlaWdodCIsInJlcXVpcmVkIiwidGV4dERlY29yYXRpb25MaW5lIiwiY29sb3IiLCJwYWRkaW5nIiwic291cmNldHlwZSIsIlBheUJ5QmFsYW5jZUFjdGlvbiIsInRyYWNrX251bWJlciIsInNob3AiLCJjYXRlZ29yeSIsImN1cnJlbmN5Iiwid2VpZ2h0IiwiZGVsaXZlcnlfcHJpY2UiLCJkYXRlIiwiaSIsIm1hcFN0YXRlVG9Qcm9wcyIsInN0YXRlIiwibWFwRGlzcGF0Y2hUb1Byb3BzIiwiY29ubmVjdCIsIm1lbW8iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFNBQVNBLFFBQVQsQ0FBa0JDLEtBQWxCLEVBQXlCO0FBQUE7O0FBQUE7QUFBQTs7QUFDdkIsTUFBSSxDQUFDQSxLQUFLLENBQUNDLEtBQU4sQ0FBWUMsT0FBakIsRUFBMEI7QUFDeEIsd0JBQU8scUVBQUMsc0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUFQO0FBQ0Q7O0FBSHNCLGlCQUs4QkMsK0RBQU8sRUFMckM7QUFBQSxNQUtmQyxRQUxlLFlBS2ZBLFFBTGU7QUFBQSxNQUtMQyxZQUxLLFlBS0xBLFlBTEs7QUFBQSxNQUtTQyxNQUxULFlBS1NBLE1BTFQ7QUFBQSxNQUtpQkMsUUFMakIsWUFLaUJBLFFBTGpCOztBQUFBLGlCQU1NQywwREFBTyxFQU5iO0FBQUEsTUFNQUMsQ0FOQSxZQU1mQyxhQU5lOztBQUFBLGtCQU9TQyxzREFBUSxDQUFDLEVBQUQsQ0FQakI7QUFBQSxNQU9oQkMsUUFQZ0I7QUFBQSxNQU9OQyxXQVBNOztBQUFBLG1CQVFtQkYsc0RBQVEsQ0FBQyxFQUFELENBUjNCO0FBQUEsTUFRaEJHLGFBUmdCO0FBQUEsTUFRREMsZ0JBUkM7O0FBQUEsbUJBU0tKLHNEQUFRLENBQUMsRUFBRCxDQVRiO0FBQUEsTUFTaEJLLE1BVGdCO0FBQUEsTUFTUkMsU0FUUTs7QUFBQSxtQkFVeUJOLHNEQUFRLENBQUM7QUFDdkRDLFlBQVEsRUFBRSxFQUQ2QztBQUV2RE0sU0FBSyxFQUFFLENBRmdEO0FBR3ZEQyxpQkFBYSxFQUFDLENBSHlDO0FBSXZEQyxRQUFJLEVBQUUsRUFKaUQ7QUFLdkRDLGNBQVUsRUFBRSxLQUwyQztBQU12REwsVUFBTSxFQUFFO0FBTitDLEdBQUQsQ0FWakM7QUFBQSxNQVVoQk0sZ0JBVmdCO0FBQUEsTUFVRUMsbUJBVkY7O0FBQUEsbUJBbUJKQyw2REFBUyxFQW5CTDtBQUFBLE1BbUJmQyxNQW5CZSxjQW1CZkEsTUFuQmU7O0FBb0J2QixNQUFNQyxZQUFZLEdBQUdDLG9EQUFNLEVBQTNCO0FBQ0EsTUFBTUMsU0FBUyxHQUFHRCxvREFBTSxDQUFDLEVBQUQsQ0FBeEI7QUFDQUMsV0FBUyxDQUFDQyxPQUFWLEdBQW9CLEVBQXBCO0FBQ0EsTUFBTUMsT0FBTyxHQUFHSCxvREFBTSxDQUFDLEVBQUQsQ0FBdEI7QUFDQUcsU0FBTyxDQUFDRCxPQUFSLEdBQWtCLEVBQWxCOztBQUVBLE1BQU1FLE1BQU0sR0FBRyxTQUFUQSxNQUFTLENBQUNDLElBQUQsRUFBVTtBQUN2QkMsV0FBTyxDQUFDQyxHQUFSLENBQVlGLElBQVo7QUFFQUcsZ0RBQUssQ0FDRkMsSUFESCxXQUVPQyw2QkFGUCxpQ0FFNkRMLElBQUksQ0FBQ00sU0FGbEUscUJBRXNGaEIsZ0JBQWdCLENBQUNOLE1BRnZHLEdBR0ksRUFISixFQUlJO0FBQ0V1QixhQUFPLEVBQUU7QUFDUCx3QkFBZ0Isa0JBRFQ7QUFFUEMscUJBQWEsbUJBQVl4QyxLQUFLLENBQUNDLEtBQU4sQ0FBWXdDLElBQVosQ0FBaUJDLFdBQTdCO0FBRk47QUFEWCxLQUpKLEVBV0dDLElBWEgsQ0FXUSxVQUFDQyxHQUFELEVBQVM7QUFDYlgsYUFBTyxDQUFDQyxHQUFSLENBQVlVLEdBQUcsQ0FBQ1osSUFBSixDQUFTYSxPQUFyQjtBQUNBaEMsaUJBQVcsQ0FBQytCLEdBQUcsQ0FBQ1osSUFBSixDQUFTYSxPQUFWLENBQVg7QUFDQTlCLHNCQUFnQixDQUFDNkIsR0FBRyxDQUFDWixJQUFKLENBQVNhLE9BQVYsQ0FBaEI7QUFDRCxLQWZILFdBZ0JTLFVBQUNDLEdBQUQsRUFBUztBQUNkdkMsY0FBUSxDQUFDLFdBQUQsRUFBYztBQUFFd0MsZUFBTyxFQUFFRCxHQUFHLENBQUNFLFFBQUosQ0FBYWhCLElBQWIsQ0FBa0JpQjtBQUE3QixPQUFkLENBQVI7QUFDRCxLQWxCSDtBQW1CRCxHQXRCRDs7QUF3QkFDLCtEQUFlLENBQUMsWUFBTTtBQUNwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQyxXQUFPLENBQUNDLEdBQVIsQ0FBWSxDQUNWakIsNENBQUssQ0FBQ2tCLEdBQU4sV0FBYWhCLDZCQUFiLHlCQUEyRFosTUFBM0QsR0FBcUU7QUFDbkVjLGFBQU8sRUFBRTtBQUNQQyxxQkFBYSxtQkFBWXhDLEtBQUssQ0FBQ0MsS0FBTixDQUFZd0MsSUFBWixDQUFpQkMsV0FBN0I7QUFETjtBQUQwRCxLQUFyRSxDQURVLEVBTVZQLDRDQUFLLENBQUNrQixHQUFOLFdBQWFoQiw2QkFBYix3QkFBMERaLE1BQTFELEdBQW9FO0FBQ2xFYyxhQUFPLEVBQUU7QUFDUEMscUJBQWEsbUJBQVl4QyxLQUFLLENBQUNDLEtBQU4sQ0FBWXdDLElBQVosQ0FBaUJDLFdBQTdCO0FBRE47QUFEeUQsS0FBcEUsQ0FOVSxDQUFaLEVBWUdDLElBWkgsQ0FZUSxVQUFDQyxHQUFELEVBQVM7QUFDYlgsYUFBTyxDQUFDQyxHQUFSLENBQVlVLEdBQUcsQ0FBQ1osSUFBaEI7QUFDQW5CLGlCQUFXLENBQUMrQixHQUFHLENBQUMsQ0FBRCxDQUFILENBQU9aLElBQVIsQ0FBWDtBQUNBakIsc0JBQWdCLENBQUM2QixHQUFHLENBQUMsQ0FBRCxDQUFILENBQU9aLElBQVIsQ0FBaEI7QUFDQWYsZUFBUyxDQUFDMkIsR0FBRyxDQUFDLENBQUQsQ0FBSCxDQUFPWixJQUFSLENBQVQ7QUFDRCxLQWpCSCxXQWtCUyxVQUFDYyxHQUFEO0FBQUEsYUFBU2IsT0FBTyxDQUFDQyxHQUFSLENBQVlZLEdBQVosQ0FBVDtBQUFBLEtBbEJUO0FBbUJELEdBL0JjLEVBK0JaLEVBL0JZLENBQWY7O0FBaUNBLE1BQU1RLFVBQVUsR0FBRyxTQUFiQSxVQUFhLENBQUNDLEdBQUQsRUFBUztBQUMxQixRQUFJQSxHQUFHLElBQUksQ0FBQ3pCLE9BQU8sQ0FBQ0QsT0FBUixDQUFnQjJCLFFBQWhCLENBQXlCRCxHQUF6QixDQUFaLEVBQTJDO0FBQ3pDekIsYUFBTyxDQUFDRCxPQUFSLENBQWdCNEIsSUFBaEIsQ0FBcUJGLEdBQXJCO0FBQ0Q7QUFDRixHQUpEOztBQU1BLE1BQU1HLGFBQWE7QUFBQSxrVUFBRyxpQkFBT0MsRUFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3BCN0IscUJBQU8sQ0FBQ0QsT0FBUixDQUFnQitCLE9BQWhCLENBQXdCLFVBQUNDLENBQUQ7QUFBQSx1QkFBT0EsQ0FBQyxDQUFDQyxTQUFGLENBQVlDLE1BQVosQ0FBbUIsYUFBbkIsQ0FBUDtBQUFBLGVBQXhCO0FBQ0FKLGdCQUFFLENBQUNLLE1BQUgsQ0FBVUYsU0FBVixDQUFvQkcsR0FBcEIsQ0FBd0IsYUFBeEI7O0FBRm9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQUg7O0FBQUEsb0JBQWJQLGFBQWE7QUFBQTtBQUFBO0FBQUEsS0FBbkI7O0FBS0EsTUFBTVEsY0FBYyxHQUFHLFNBQWpCQSxjQUFpQixDQUFDUCxFQUFELEVBQVE7QUFDN0JELGlCQUFhLENBQUNDLEVBQUQsQ0FBYjtBQUNBLFFBQUlRLEVBQUUsR0FBR1IsRUFBRSxDQUFDSyxNQUFILENBQVVJLFlBQVYsQ0FBdUIsU0FBdkIsQ0FBVDs7QUFDQSxRQUFJRCxFQUFFLElBQUksQ0FBVixFQUFhO0FBQ1gsVUFBSUUsV0FBVyxHQUFHekQsUUFBUSxDQUFDMEQsTUFBVCxDQUFnQixVQUFDVCxDQUFEO0FBQUEsZUFBT0EsQ0FBQyxDQUFDN0MsTUFBRixDQUFTbUQsRUFBVCxJQUFlQSxFQUF0QjtBQUFBLE9BQWhCLENBQWxCO0FBQ0FwRCxzQkFBZ0IsQ0FBQyw4SkFBSXNELFdBQUwsRUFBaEI7QUFDRCxLQUhELE1BR087QUFDTHRELHNCQUFnQixDQUFDLDhKQUFJSCxRQUFMLEVBQWhCO0FBQ0Q7O0FBRURXLHVCQUFtQixDQUFDO0FBQ2xCSixtQkFBYSxFQUFFLENBREc7QUFFbEJQLGNBQVEsRUFBRSxFQUZRO0FBR2xCTSxXQUFLLEVBQUUsQ0FIVztBQUlsQkUsVUFBSSxFQUFFLEVBSlk7QUFLbEJDLGdCQUFVLEVBQUUsS0FMTTtBQU1sQkwsWUFBTSxFQUFFbUQ7QUFOVSxLQUFELENBQW5CO0FBUUQsR0FsQkQ7O0FBb0JBLE1BQU1JLFlBQVksR0FBRyxTQUFmQSxZQUFlLENBQUNoQixHQUFELEVBQVM7QUFDNUIsUUFBSUEsR0FBRyxJQUFJLENBQUMzQixTQUFTLENBQUNDLE9BQVYsQ0FBa0IyQixRQUFsQixDQUEyQkQsR0FBM0IsQ0FBWixFQUE2QztBQUMzQzNCLGVBQVMsQ0FBQ0MsT0FBVixDQUFrQjRCLElBQWxCLENBQXVCRixHQUF2QjtBQUNEO0FBQ0YsR0FKRDs7QUFNQSxNQUFNaUIsWUFBWSxHQUFHLFNBQWZBLFlBQWUsQ0FBQ2IsRUFBRCxFQUFRO0FBQUEscUJBQ0ZBLEVBQUUsQ0FBQ0ssTUFERDtBQUFBLFFBQ3JCUyxLQURxQixjQUNyQkEsS0FEcUI7QUFBQSxRQUNkQyxPQURjLGNBQ2RBLE9BRGM7QUFFM0IsUUFBSUMsS0FBSyxHQUFHaEIsRUFBRSxDQUFDSyxNQUFILENBQVVJLFlBQVYsQ0FBdUIsWUFBdkIsQ0FBWjtBQUNBLFFBQUlRLFlBQVksR0FBR2pCLEVBQUUsQ0FBQ0ssTUFBSCxDQUFVSSxZQUFWLENBQXVCLGVBQXZCLENBQW5CO0FBQ0EsUUFBSWxELEtBQUssR0FBQyxDQUFWO0FBQ0EsUUFBSTJELElBQUksR0FBQyxDQUFUO0FBQ0E1QyxXQUFPLENBQUNDLEdBQVIsQ0FBWSxLQUFaLEVBQWtCMEMsWUFBbEI7O0FBQ0EsUUFBSUYsT0FBSixFQUFhO0FBQ1hwRCxzQkFBZ0IsQ0FBQ1YsUUFBakIsQ0FBMEI2QyxJQUExQixDQUErQmdCLEtBQS9COztBQUNBLFVBQUdHLFlBQVksSUFBRSxDQUFqQixFQUFtQjtBQUNqQnJELDJCQUFtQixpQ0FDZEQsZ0JBRGM7QUFHakJKLGVBQUssRUFBR0ksZ0JBQWdCLENBQUNKLEtBQWpCLEdBQXVCNEQsVUFBVSxDQUFDSCxLQUFELENBSHhCO0FBS2pCeEQsdUJBQWEsRUFBR0csZ0JBQWdCLENBQUNILGFBQWpCLEdBQStCMkQsVUFBVSxDQUFDRixZQUFELENBTHhDO0FBTWpCaEUsa0JBQVEsRUFBRSw4SkFBSVUsZ0JBQWdCLENBQUNWLFFBQXZCO0FBTlMsV0FBbkI7QUFTRCxPQVZELE1BVUs7QUFDSFcsMkJBQW1CLGlDQUNkRCxnQkFEYztBQUVqQkgsdUJBQWEsRUFBR0csZ0JBQWdCLENBQUNILGFBQWpCLEdBQStCMkQsVUFBVSxDQUFDSCxLQUFELENBRnhDO0FBR2pCekQsZUFBSyxFQUFHSSxnQkFBZ0IsQ0FBQ0osS0FBakIsR0FBdUI0RCxVQUFVLENBQUNILEtBQUQsQ0FIeEI7QUFJakIvRCxrQkFBUSxFQUFFLDhKQUFJVSxnQkFBZ0IsQ0FBQ1YsUUFBdkI7QUFKUyxXQUFuQjtBQU1EO0FBRUYsS0FyQkQsTUFxQk87QUFDTCxVQUFJeUQsV0FBVyxHQUFHL0MsZ0JBQWdCLENBQUNWLFFBQWpCLENBQTBCMEQsTUFBMUIsQ0FBaUMsVUFBQ1QsQ0FBRDtBQUFBLGVBQU9BLENBQUMsS0FBS1ksS0FBYjtBQUFBLE9BQWpDLENBQWxCOztBQUNBLFVBQUdHLFlBQVksSUFBRSxDQUFqQixFQUFtQjtBQUNqQnJELDJCQUFtQixpQ0FFZEQsZ0JBRmM7QUFJakJKLGVBQUssRUFBRUksZ0JBQWdCLENBQUNKLEtBQWpCLElBQXlCLENBQXpCLElBQStCSSxnQkFBZ0IsQ0FBQ0osS0FBakIsR0FBdUI0RCxVQUFVLENBQUNILEtBQUQsQ0FKdEQ7QUFNakJ4RCx1QkFBYSxFQUFFRyxnQkFBZ0IsQ0FBQ0gsYUFBakIsSUFBaUMsQ0FBakMsSUFBd0NHLGdCQUFnQixDQUFDSCxhQUFqQixHQUErQjJELFVBQVUsQ0FBQ0YsWUFBRCxDQU4vRTtBQU9qQmhFLGtCQUFRLEVBQUV5RDtBQVBPLFdBQW5CO0FBVUQsT0FYRCxNQVdLO0FBQ0g5QywyQkFBbUIsaUNBQ2RELGdCQURjO0FBRWpCSCx1QkFBYSxFQUFDRyxnQkFBZ0IsQ0FBQ0gsYUFBakIsSUFBaUMsQ0FBakMsSUFBdUNHLGdCQUFnQixDQUFDSCxhQUFqQixHQUErQjJELFVBQVUsQ0FBQ0gsS0FBRCxDQUY3RTtBQUdqQnpELGVBQUssRUFBQ0ksZ0JBQWdCLENBQUNKLEtBQWpCLElBQXlCLENBQXpCLElBQStCSSxnQkFBZ0IsQ0FBQ0osS0FBakIsR0FBdUI0RCxVQUFVLENBQUNILEtBQUQsQ0FIckQ7QUFJakIvRCxrQkFBUSxFQUFDeUQ7QUFKUSxXQUFuQjtBQU1EO0FBRUY7O0FBQ0QsS0FBQy9DLGdCQUFnQixDQUFDVixRQUFqQixDQUEwQm1FLElBQTFCLENBQStCLFVBQUNsQixDQUFEO0FBQUEsYUFBT0EsQ0FBUDtBQUFBLEtBQS9CLENBQUQsR0FDS25DLFlBQVksQ0FBQ0csT0FBYixDQUFxQjZDLE9BQXJCLEdBQStCLEtBRHBDLEdBRUksSUFGSjtBQUdELEdBdEREOztBQXdEQSxNQUFNTSxTQUFTLEdBQUcsU0FBWkEsU0FBWSxDQUFDQyxDQUFELEVBQU87QUFDdkIsUUFBSS9ELEtBQUssR0FBRyxDQUFaO0FBQ0EsUUFBSUMsYUFBYSxHQUFHLENBQXBCO0FBQ0EsUUFBSVAsUUFBUSxHQUFHLEVBQWY7QUFDQWdCLGFBQVMsQ0FBQ0MsT0FBVixDQUFrQitCLE9BQWxCLENBQTBCLFVBQUNDLENBQUQsRUFBTztBQUMvQkEsT0FBQyxDQUFDYSxPQUFGLEdBQVlPLENBQUMsQ0FBQ2pCLE1BQUYsQ0FBU1UsT0FBckI7O0FBRUEsVUFBSU8sQ0FBQyxDQUFDakIsTUFBRixDQUFTVSxPQUFULElBQW9CLENBQUM5RCxRQUFRLENBQUM0QyxRQUFULENBQWtCSyxDQUFDLENBQUNZLEtBQXBCLENBQXpCLEVBQXFEO0FBQ25EN0QsZ0JBQVEsQ0FBQzZDLElBQVQsQ0FBY0ksQ0FBQyxDQUFDWSxLQUFoQjtBQUNBdkQsYUFBSyxJQUFJLENBQUMyQyxDQUFDLENBQUNPLFlBQUYsQ0FBZSxZQUFmLENBQVY7QUFDQWpELHFCQUFhLElBQUksQ0FBQzBDLENBQUMsQ0FBQ08sWUFBRixDQUFlLGVBQWYsQ0FBbEI7QUFDRCxPQUpELE1BSU87QUFDTHhELGdCQUFRLEdBQUdBLFFBQVEsQ0FBQzBELE1BQVQsQ0FBZ0IsVUFBQ1ksQ0FBRDtBQUFBLGlCQUFPQSxDQUFDLEtBQUtyQixDQUFDLENBQUNZLEtBQWY7QUFBQSxTQUFoQixDQUFYO0FBQ0F2RCxhQUFLLElBQUlBLEtBQUssSUFBSSxDQUFULElBQWMsQ0FBQzJDLENBQUMsQ0FBQ08sWUFBRixDQUFlLFlBQWYsQ0FBeEI7QUFDQWpELHFCQUFhLElBQUlBLGFBQWEsSUFBRyxDQUFoQixJQUFxQixDQUFDMEMsQ0FBQyxDQUFDTyxZQUFGLENBQWUsZUFBZixDQUF2QztBQUNEO0FBQ0YsS0FaRDtBQWNBN0MsdUJBQW1CLGlDQUNkRCxnQkFEYztBQUVqQkosV0FBSyxFQUFFSSxnQkFBZ0IsQ0FBQ0osS0FBakIsR0FBdUJBLEtBRmI7QUFHakJOLGNBQVEsRUFBRUE7QUFITyxPQUFuQjtBQUtELEdBdkJEOztBQXlCQSxNQUFNdUUsU0FBUyxHQUFHLFNBQVpBLFNBQVksR0FBZTtBQUFBLFFBQWRuRCxJQUFjLHVFQUFQLEVBQU87QUFDL0JHLGdEQUFLLENBQUNDLElBQU4sV0FBY0MsNkJBQWQsY0FBdURMLElBQXZELEVBQTREO0FBQzFETyxhQUFPLEVBQUM7QUFDTkMscUJBQWEsbUJBQVl4QyxLQUFLLENBQUNDLEtBQU4sQ0FBWXdDLElBQVosQ0FBaUJDLFdBQTdCO0FBRFA7QUFEa0QsS0FBNUQsRUFJR0MsSUFKSCxDQUlRLFVBQUFDLEdBQUcsRUFBSTtBQUNiWCxhQUFPLENBQUNDLEdBQVIsQ0FBWSxLQUFaLEVBQWtCVSxHQUFHLENBQUNaLElBQUosQ0FBU29ELEdBQTNCLEVBRGEsQ0FFYjtBQUNELEtBUEQsV0FPUyxVQUFBdEMsR0FBRztBQUFBLGFBQUliLE9BQU8sQ0FBQ0MsR0FBUixDQUFZWSxHQUFaLENBQUo7QUFBQSxLQVBaO0FBUUQsR0FURDs7QUFXQSxzQkFDRSxxRUFBQyw4REFBRDtBQUFNLGFBQVMsRUFBQyxtQkFBaEI7QUFBQSw0QkFDRSxxRUFBQyxnRUFBRDtBQUFPLGVBQVMsRUFBQyxPQUFqQjtBQUFBLDZCQUNFLHFFQUFDLHFFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFJRSxxRUFBQyw4REFBRDtBQUFNLGVBQVMsRUFBQyxhQUFoQjtBQUFBLDhCQUNFLHFFQUFDLDhEQUFEO0FBQU0saUJBQVMsRUFBQyx5QkFBaEI7QUFBQSxnQ0FDRSxxRUFBQyw4REFBRCxDQUFNLE1BQU47QUFDRSxjQUFJLEVBQUVyQyxDQUFDLENBQUM7QUFBRTBELGNBQUUsRUFBRTtBQUFOLFdBQUQsQ0FEVDtBQUVFLHFCQUFXLGVBQ1QscUVBQUMsc0VBQUQ7QUFDRSxnQkFBSSxFQUFFMUQsQ0FBQyxDQUFDO0FBQUUwRCxnQkFBRSxFQUFFO0FBQU4sYUFBRCxDQURUO0FBRUUsZUFBRyxFQUFFLGFBQUNaLEdBQUQ7QUFBQSxxQkFBVTdCLFlBQVksQ0FBQ0csT0FBYixHQUF1QjBCLEdBQWpDO0FBQUEsYUFGUDtBQUdFLG1CQUFPLEVBQUV5QixTQUhYO0FBSUUscUJBQVMsRUFBQztBQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFISjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBWUU7QUFBSyxtQkFBTSxLQUFYO0FBQWlCLGVBQUssRUFBRTtBQUFFSyxxQkFBUyxFQUFFO0FBQWIsV0FBeEI7QUFBQSxpQ0FDRTtBQUNFLHFCQUFTLEVBQUMsVUFEWjtBQUVFLGlCQUFLLEVBQUU7QUFDTEMscUJBQU8sRUFBRSxNQURKO0FBRUxDLDBCQUFZLEVBQUUsTUFGVDtBQUdMQyxtQkFBSyxFQUFFO0FBSEYsYUFGVDtBQUFBLG9DQVNFLHFFQUFDLDJEQUFEO0FBQ0UsbUJBQUssd0JBQVk1RSxRQUFRLENBQUM2RSxNQUFyQixNQURQO0FBRUUsdUJBQVMsRUFBQyw4QkFGWjtBQUdFLHlCQUFTLENBSFg7QUFJRSxpQkFBRyxFQUFFbkMsVUFKUDtBQUtFLHFCQUFPLEVBQUVZO0FBTFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFURixFQWlCSWxELE1BQU0sQ0FBQzBFLEdBQVAsQ0FBVyxVQUFDN0IsQ0FBRDtBQUFBLGtDQUNYLHFFQUFDLDJEQUFEO0FBQ0UscUJBQUssWUFBS0EsQ0FBQyxDQUFDOEIsSUFBUCxlQUNIL0UsUUFBUSxDQUFDMEQsTUFBVCxDQUFnQixVQUFDVCxDQUFEO0FBQUEseUJBQU9BLENBQUMsQ0FBQzdDLE1BQUYsQ0FBU21ELEVBQVQsSUFBZSxDQUF0QjtBQUFBLGlCQUFoQixFQUF5Q3NCLE1BRHRDLE1BRFA7QUFLRSx5QkFBUyxFQUFDLG9CQUxaO0FBTUUsMkJBQVM1QixDQUFDLENBQUNNLEVBTmI7QUFPRSxtQkFBRyxFQUFFYixVQVBQO0FBUUUsdUJBQU8sRUFBRVk7QUFSWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURXO0FBQUEsYUFBWCxDQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVpGLGVBOENFLHFFQUFDLDhEQUFELENBQU0sSUFBTjtBQUFXLG1CQUFTLEVBQUMsUUFBckI7QUFBQSxpQ0FDRTtBQUFLLHFCQUFTLEVBQUMsY0FBZjtBQUFBLHNCQUNHcEQsYUFBYSxDQUNYd0QsTUFERixDQUNTLFVBQUNULENBQUQ7QUFBQSxxQkFBT0EsQ0FBQyxDQUFDN0MsTUFBRixDQUFTbUQsRUFBVCxLQUFnQixDQUF2QjtBQUFBLGFBRFQsRUFFRXVCLEdBRkYsQ0FFTSxVQUFDUixDQUFEO0FBQUEsa0NBQ0gscUVBQUMsOEVBQUQ7QUFFRSx3QkFBUSxFQUFFWCxZQUZaO0FBR0Usb0JBQUksRUFBRVcsQ0FIUjtBQUlFLHVCQUFPLEVBQUVWO0FBSlgsaUJBQ09VLENBQUMsQ0FBQ2YsRUFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURHO0FBQUEsYUFGTjtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQTlDRixlQTRERTtBQUFLLG1CQUFTLEVBQUMsYUFBZjtBQUFBLGtDQUNFO0FBQUsscUJBQVMsRUFBQyxlQUFmO0FBQUEsb0NBQ0U7QUFBQSx5QkFDRzdDLGdCQUFnQixDQUFDVixRQUFqQixDQUEwQjZFLE1BRDdCLE9BQ3NDaEYsQ0FBQyxDQUFDO0FBQUUwRCxrQkFBRSxFQUFFO0FBQU4sZUFBRCxDQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBREYsZUFJRTtBQUFLLG1CQUFLLEVBQUU7QUFBRW1CLHVCQUFPLEVBQUUsTUFBWDtBQUFtQk0sOEJBQWMsRUFBRTtBQUFuQyxlQUFaO0FBQUEsc0NBQ0U7QUFBQSwyQkFBSW5GLENBQUMsQ0FBQztBQUFFMEQsb0JBQUUsRUFBRTtBQUFOLGlCQUFELENBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQURGLGVBRUU7QUFBSyxxQkFBSyxFQUFFO0FBQUVtQix5QkFBTyxFQUFFLE1BQVg7QUFBbUJPLCtCQUFhLEVBQUU7QUFBbEMsaUJBQVo7QUFBQSwwQkFFRXZFLGdCQUFnQixDQUFDSCxhQUFqQixHQUFpQyxDQUFqQyxnQkFDQTtBQUFBLDBDQUNBO0FBQUsseUJBQUssRUFBRTtBQUFFMkUseUNBQW1CLEVBQUU7QUFBdkIscUJBQVo7QUFBQSwrQkFBNkNoQixVQUFVLENBQUN4RCxnQkFBZ0IsQ0FBQ0osS0FBbEIsQ0FBVixDQUFtQzZFLE9BQW5DLENBQTJDLENBQTNDLENBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFEQSxlQUVDO0FBQUEsK0JBQUlqQixVQUFVLENBQUN4RCxnQkFBZ0IsQ0FBQ0gsYUFBbEIsQ0FBVixDQUEyQzRFLE9BQTNDLENBQW1ELENBQW5ELENBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUZEO0FBQUEsZ0NBREEsZ0JBS0k7QUFBQSw2QkFBSWpCLFVBQVUsQ0FBQ3hELGdCQUFnQixDQUFDSCxhQUFsQixDQUFWLENBQTJDNEUsT0FBM0MsQ0FBbUQsQ0FBbkQsQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFQTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREYsZUFxQkU7QUFBSyxxQkFBUyxFQUFDLGVBQWY7QUFBQSxvQ0FDRTtBQUFBLHFDQUNFLHFFQUFDLDBFQUFEO0FBQ0UseUJBQVMsRUFBQyxnQkFEWjtBQUVFLHlCQUFTLEVBQUU7QUFBRUMsd0JBQU0sRUFBRSxNQUFWO0FBQWtCUix1QkFBSyxFQUFFO0FBQXpCLGlCQUZiO0FBR0UseUJBQVMsRUFBQyx1QkFIWjtBQUlFLHFCQUFLLEVBQUU7QUFBRUQsOEJBQVksRUFBRTtBQUFoQixpQkFKVDtBQUtFLHFCQUFLLHVCQUFFakYsTUFBTSxDQUFDZ0MsU0FBVCxzREFBRSxrQkFBa0JTLE9BTDNCO0FBQUEsd0NBT0UscUVBQUMsZ0VBQUQ7QUFDRSw2QkFBVyxFQUFFdEMsQ0FBQyxDQUFDO0FBQUUwRCxzQkFBRSxFQUFFO0FBQU4sbUJBQUQsQ0FEaEI7QUFFRSxzQkFBSSxFQUFDLFdBRlA7QUFHRSxxQkFBRyxFQUFFL0QsUUFBUSxDQUFDO0FBQ1o2Riw0QkFBUSxFQUFFO0FBQ1J4QiwyQkFBSyxFQUFFLElBREM7QUFFUjFCLDZCQUFPLEVBQUV0QyxDQUFDLENBQUM7QUFBRTBELDBCQUFFLEVBQUU7QUFBTix1QkFBRDtBQUZGO0FBREUsbUJBQUQsQ0FIZjtBQVNFLDBCQUFRLEVBQUUsa0JBQUNjLENBQUQ7QUFBQSwyQkFDUjFELG1CQUFtQixpQ0FDZEQsZ0JBRGM7QUFFakJGLDBCQUFJLEVBQUU2RCxDQUFDLENBQUNqQixNQUFGLENBQVNTO0FBRkUsdUJBRFg7QUFBQTtBQVRaO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBUEYsRUF1QkduRCxnQkFBZ0IsQ0FBQ0QsVUFBakIsZ0JBQ0MscUVBQUMsMkRBQUQ7QUFDRSwyQkFBUyxFQUFDLGVBRFo7QUFFRSx1QkFBSyxFQUFFO0FBQ0w2RSxzQ0FBa0IsRUFBRSxXQURmO0FBRUxDLHlCQUFLLEVBQUUsVUFGRjtBQUdMQywyQkFBTyxFQUFFO0FBSEosbUJBRlQ7QUFPRSx1QkFBSyxFQUFDLG1CQVBSO0FBUUUseUJBQU8sRUFBRSxtQkFBTTtBQUNiN0UsdUNBQW1CLGlDQUNkRCxnQkFEYztBQUVqQkQsZ0NBQVUsRUFBRTtBQUZLLHVCQUFuQjtBQUlEO0FBYkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFERCxnQkFpQkMscUVBQUMsMkRBQUQ7QUFDRSwwQkFBUSxFQUFFLENBQUNDLGdCQUFnQixDQUFDRixJQUFsQixHQUF5QixJQUF6QixHQUFnQyxLQUQ1QztBQUVFLHVCQUFLLEVBQUU7QUFBRWdGLDJCQUFPLEVBQUU7QUFBWCxtQkFGVDtBQUdFLDJCQUFTLEVBQUMsd0JBSFo7QUFJRSx1QkFBSyxFQUFFM0YsQ0FBQyxDQUFDO0FBQUUwRCxzQkFBRSxFQUFFO0FBQU4sbUJBQUQsQ0FKVjtBQUtFLHNCQUFJLEVBQUMsUUFMUDtBQU1FLHlCQUFPLEVBQUU5RCxZQUFZLENBQUMwQixNQUFELENBTnZCLENBT0U7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBeENKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBREYsZUE0REUscUVBQUMsMkRBQUQ7QUFDRSxtQkFBSyxFQUFFO0FBQUVxRSx1QkFBTyxFQUFFO0FBQVgsZUFEVDtBQUVFLHVCQUFTLEVBQUMsbUNBRlo7QUFHRSxtQkFBSyxFQUFFM0YsQ0FBQyxDQUFDO0FBQUUwRCxrQkFBRSxFQUFFO0FBQU4sZUFBRCxDQUhWO0FBSUUsd0JBQVUsZUFBRTtBQUFNLHlCQUFTLEVBQUMsbUJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUpkO0FBS0UscUJBQU8sRUFBSTtBQUFBLHVCQUFNZ0IsU0FBUyxDQUFDO0FBQ3pCUix1QkFBSyxFQUFDckQsZ0JBQWdCLENBQUNILGFBREU7QUFFekJrRiw0QkFBVSxFQUFDO0FBRmMsaUJBQUQsQ0FBZjtBQUFBO0FBTGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkE1REYsZUFzRUUscUVBQUMsMkRBQUQ7QUFDRSxtQkFBSyxFQUFFO0FBQUVELHVCQUFPLEVBQUU7QUFBWCxlQURUO0FBRUUsdUJBQVMsRUFBQyxNQUZaO0FBR0UsbUJBQUssRUFBRTNGLENBQUMsQ0FBQztBQUFFMEQsa0JBQUUsRUFBRTtBQUFOLGVBQUQsQ0FIVjtBQUlFLHdCQUFVLGVBQ1I7QUFBTSx5QkFBUyxFQUFDLDBCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFMSjtBQU9FLHFCQUFPLEVBQUk7QUFBQSx1QkFBTW5FLEtBQUssQ0FBQ3NHLGtCQUFOLENBQXlCLFNBQXpCLEVBQW1DO0FBQ2xEM0IsdUJBQUssRUFBQ3JELGdCQUFnQixDQUFDSCxhQUQyQjtBQUVsRGtGLDRCQUFVLEVBQUM7QUFGdUMsaUJBQW5DLEVBS2pCO0FBQ0Usb0RBQTBCckcsS0FBSyxDQUFDQyxLQUFOLENBQVl3QyxJQUFaLENBQWlCQyxXQUEzQztBQURGLGlCQUxpQixDQUFOO0FBQUE7QUFQYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQXRFRixlQXVGRTtBQUFLLHVCQUFTLEVBQUMsVUFBZjtBQUFBLHNDQUNFLHFFQUFDLDJEQUFEO0FBQ0UscUJBQUssRUFBRTtBQUFFMEQseUJBQU8sRUFBRTtBQUFYLGlCQURUO0FBRUUseUJBQVMsRUFBQyw4QkFGWjtBQUdFLHFCQUFLLEVBQUUzRixDQUFDLENBQUM7QUFBRTBELG9CQUFFLEVBQUU7QUFBTixpQkFBRCxDQUhWO0FBSUUsMEJBQVUsZUFDUjtBQUFNLDJCQUFTLEVBQUMsbUJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUxKO0FBT0UsdUJBQU8sRUFBSTtBQUFBLHlCQUFNZ0IsU0FBUyxDQUFDO0FBQ3pCUix5QkFBSyxFQUFDckQsZ0JBQWdCLENBQUNILGFBREU7QUFFekJrRiw4QkFBVSxFQUFDO0FBRmMsbUJBQUQsQ0FBZjtBQUFBO0FBUGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFERixlQWFFLHFFQUFDLDJEQUFEO0FBQ0UscUJBQUssRUFBRTtBQUFFRCx5QkFBTyxFQUFFO0FBQVgsaUJBRFQ7QUFFRSxxQkFBSyxFQUFFM0YsQ0FBQyxDQUFDO0FBQUUwRCxvQkFBRSxFQUFFO0FBQU4saUJBQUQsQ0FGVjtBQUdFLDBCQUFVLGVBQ1I7QUFBTSwyQkFBUyxFQUFDLHlCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFKSjtBQU1FLHVCQUFPLEVBQUk7QUFBQSx5QkFBTW5FLEtBQUssQ0FBQ3NHLGtCQUFOLENBQXlCLFNBQXpCLEVBQW1DO0FBQ2xEM0IseUJBQUssRUFBQ3JELGdCQUFnQixDQUFDSCxhQUQyQjtBQUVsRGtGLDhCQUFVLEVBQUM7QUFGdUMsbUJBQW5DLEVBSWpCO0FBQ0Usc0RBQTBCckcsS0FBSyxDQUFDQyxLQUFOLENBQVl3QyxJQUFaLENBQWlCQyxXQUEzQztBQURGLG1CQUppQixDQUFOO0FBQUE7QUFOYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkF2RkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBNURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBeU1FLHFFQUFDLDhEQUFEO0FBQU0saUJBQVMsRUFBQyxlQUFoQjtBQUFBLGdDQUNFLHFFQUFDLDhEQUFELENBQU0sTUFBTjtBQUFhLGNBQUksRUFBRWpDLENBQUMsQ0FBQztBQUFFMEQsY0FBRSxFQUFFO0FBQU4sV0FBRDtBQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBRUUscUVBQUMsOERBQUQsQ0FBTSxJQUFOO0FBQVcsbUJBQVMsRUFBQywwQkFBckI7QUFBQSxpQ0FDRSxxRUFBQyxnRUFBRDtBQUNFLGNBQUUsRUFBRSxDQUNGMUQsQ0FBQyxDQUFDO0FBQUUwRCxnQkFBRSxFQUFFO0FBQU4sYUFBRCxDQURDLEVBRUYxRCxDQUFDLENBQUM7QUFBRTBELGdCQUFFLEVBQUU7QUFBTixhQUFELENBRkMsRUFHRjFELENBQUMsQ0FBQztBQUFFMEQsZ0JBQUUsRUFBRTtBQUFOLGFBQUQsQ0FIQyxFQUlGMUQsQ0FBQyxDQUFDO0FBQUUwRCxnQkFBRSxFQUFFO0FBQU4sYUFBRCxDQUpDLEVBS0YxRCxDQUFDLENBQUM7QUFBRTBELGdCQUFFLEVBQUU7QUFBTixhQUFELENBTEMsRUFNRjFELENBQUMsQ0FBQztBQUFFMEQsZ0JBQUUsRUFBRTtBQUFOLGFBQUQsQ0FOQyxFQU9GMUQsQ0FBQyxDQUFDO0FBQUUwRCxnQkFBRSxFQUFFO0FBQU4sYUFBRCxDQVBDLENBRE47QUFVRSxnQkFBSSxFQUNGdkQsUUFBUSxDQUFDOEUsR0FBVCxDQUFhLFVBQUM3QixDQUFELEVBQU87QUFDbEIsa0JBQUlBLENBQUMsQ0FBQzdDLE1BQUYsQ0FBU21ELEVBQVQsSUFBZSxDQUFuQixFQUFzQjtBQUNwQix1QkFBTztBQUNMb0MsOEJBQVksRUFBRTFDLENBQUMsQ0FBQzBDLFlBRFg7QUFFTEMsc0JBQUksRUFBRTNDLENBQUMsQ0FBQzJDLElBRkg7QUFHTEMsMEJBQVEsRUFBRTVDLENBQUMsQ0FBQzRDLFFBSFA7QUFJTDlCLHVCQUFLLFlBQUtkLENBQUMsQ0FBQ2MsS0FBUCxjQUFnQmQsQ0FBQyxDQUFDNkMsUUFBbEIsQ0FKQTtBQUtMQyx3QkFBTSxZQUFLN0IsVUFBVSxDQUFDakIsQ0FBQyxDQUFDOEMsTUFBSCxDQUFWLENBQXFCWixPQUFyQixDQUE2QixDQUE3QixLQUFtQyxDQUF4QyxRQUxEO0FBTUxhLGdDQUFjLEVBQ1o5QixVQUFVLENBQUNqQixDQUFDLENBQUMrQyxjQUFILENBQVYsQ0FBNkJiLE9BQTdCLENBQXFDLENBQXJDLEtBQTJDLENBUHhDO0FBUUwvRSx3QkFBTSxZQUFLNkMsQ0FBQyxDQUFDN0MsTUFBRixDQUFTMkUsSUFBZCxnQkFBd0I5QixDQUFDLENBQUNnRCxJQUExQjtBQVJELGlCQUFQO0FBVUQ7QUFDRixhQWJELEtBYU0sRUF4QlY7QUEwQkUsc0JBQVUsRUFBRSxvQkFBQ2hELENBQUQsRUFBSWlELENBQUosRUFBVTtBQUNwQixrQ0FBTztBQUFBLDBCQUFlakQ7QUFBZixpQkFBU2lELENBQUMsRUFBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFQO0FBQ0Q7QUE1Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBek1GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBb1BEOztHQXhjUS9HLFE7VUFLOENJLHVELEVBQ3hCSyxrRCxFQWFWZ0IscUQ7OztLQW5CWnpCLFE7O0FBMGNULElBQU1nSCxlQUFlLEdBQUcsU0FBbEJBLGVBQWtCLENBQUNDLEtBQUQ7QUFBQSxTQUFZO0FBQ2xDL0csU0FBSyxFQUFFK0csS0FBSyxDQUFDL0c7QUFEcUIsR0FBWjtBQUFBLENBQXhCOztBQUdBLElBQU1nSCxrQkFBa0IsR0FBSTtBQUMxQlgsb0JBQWtCLEVBQWxCQSw2RUFBa0JBO0FBRFEsQ0FBNUI7QUFJZVksMkhBQU8sQ0FBQ0gsZUFBRCxFQUFrQkUsa0JBQWxCLENBQVAsZUFBNkNFLGtEQUFJLENBQUNwSCxRQUFELENBQWpELENBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvcGFja2FnZXMuYmU3YTYyNzNhMmZhNTU5MGI4M2MuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcbmltcG9ydCBSZWFjdCwgeyBtZW1vLCB1c2VMYXlvdXRFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlRm9ybSB9IGZyb20gXCJyZWFjdC1ob29rLWZvcm1cIjtcclxuaW1wb3J0IHsgdXNlSW50bCB9IGZyb20gXCJyZWFjdC1pbnRsXCI7XHJcbmltcG9ydCB7IGNvbm5lY3QgfSBmcm9tIFwicmVhY3QtcmVkdXhcIjtcclxuaW1wb3J0IEFzaWRlTWVudSBmcm9tIFwiLi4vY29tcG9uZW50cy9hc2lkZS1tZW51L2luZGV4XCI7XHJcbmltcG9ydCBBc2lkZSBmcm9tIFwiLi4vY29tcG9uZW50cy9hc2lkZS9hc2lkZVwiO1xyXG5pbXBvcnQgQnV0dG9uQ29tcG9uZW50IGZyb20gXCIuLi9jb21wb25lbnRzL2J1dHRvblwiO1xyXG5pbXBvcnQgQ2FyZCBmcm9tIFwiLi4vY29tcG9uZW50cy9jYXJkL2NhcmRcIjtcclxuaW1wb3J0IENoZWNrYm94IGZyb20gXCIuLi9jb21wb25lbnRzL2NoZWNrYm94L2NoZWNrYm94XCI7XHJcbmltcG9ydCBGcm9tR3JvdXAgZnJvbSBcIi4uL2NvbXBvbmVudHMvZm9ybS1ncm91cC9mb3JtLWdyb3VwXCI7XHJcbmltcG9ydCBJbnB1dCBmcm9tIFwiLi4vY29tcG9uZW50cy9pbnB1dC9pbnB1dFwiO1xyXG5pbXBvcnQgTWFpbiBmcm9tIFwiLi4vY29tcG9uZW50cy9tYWluL21haW5cIjtcclxuaW1wb3J0IFBhY2thZ2VJdGVtIGZyb20gXCIuLi9jb21wb25lbnRzL3BhY2thZ2VfaXRlbS9wYWNrYWdlLWl0ZW1cIjtcclxuaW1wb3J0IFBhZ2UgZnJvbSBcIi4uL2NvbXBvbmVudHMvcGFnZS9wYWdlXCI7XHJcbmltcG9ydCBSZWRpcmVjdCBmcm9tIFwiLi4vY29tcG9uZW50cy9yZWRpcmVjdC9yZWRpcmVjdFwiO1xyXG5pbXBvcnQgVGFiZWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvdGFiZWwvdGFiZWxcIjtcclxuaW1wb3J0IHsgUGF5QnlCYWxhbmNlQWN0aW9uIH0gZnJvbSAnLi4vcmVkdXgvZW50cnkvZW50cnlBY3Rpb25zJ1xyXG5cclxuZnVuY3Rpb24gUGFja2FnZXMocHJvcHMpIHtcclxuICBpZiAoIXByb3BzLmVudHJ5LmlzTG9nZWQpIHtcclxuICAgIHJldHVybiA8UmVkaXJlY3QgLz47XHJcbiAgfVxyXG5cclxuICBjb25zdCB7IHJlZ2lzdGVyLCBoYW5kbGVTdWJtaXQsIGVycm9ycywgc2V0RXJyb3IgfSA9IHVzZUZvcm0oKTtcclxuICBjb25zdCB7IGZvcm1hdE1lc3NhZ2U6IGYgfSA9IHVzZUludGwoKTtcclxuICBjb25zdCBbcGFja2FnZXMsIHNldFBhY2thZ2VzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZmlsdGVyZWRQYWNrcywgc2V0RmlsdGVyZWRQYWNrc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3N0YXR1cywgc2V0U3RhdHVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VsZWN0ZWRQYWNrYWdlcywgc2V0U2VsZWN0ZWRQYWNrYWdlc10gPSB1c2VTdGF0ZSh7XHJcbiAgICBwYWNrYWdlczogW10sXHJcbiAgICB0b3RhbDogMCxcclxuICAgIGRpc2NvdW50VG90YWw6MCxcclxuICAgIGNvZGU6IFwiXCIsXHJcbiAgICBpc0FjY2VwdGVkOiBmYWxzZSxcclxuICAgIHN0YXR1czogMCxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgeyBsb2NhbGUgfSA9IHVzZVJvdXRlcigpO1xyXG4gIGNvbnN0IG1haW5DaGVja1JlZiA9IHVzZVJlZigpO1xyXG4gIGNvbnN0IGNoZWNrUmVmcyA9IHVzZVJlZihbXSk7XHJcbiAgY2hlY2tSZWZzLmN1cnJlbnQgPSBbXTtcclxuICBjb25zdCB0YWJSZWZzID0gdXNlUmVmKFtdKTtcclxuICB0YWJSZWZzLmN1cnJlbnQgPSBbXTtcclxuXHJcbiAgY29uc3Qgc3VibWl0ID0gKGRhdGEpID0+IHtcclxuICAgIGNvbnNvbGUubG9nKGRhdGEpO1xyXG5cclxuICAgIGF4aW9zXHJcbiAgICAgIC5wb3N0KFxyXG4gICAgICAgIGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9cHJvbW9jb2RlP3Byb21vY29kZT0ke2RhdGEucHJvbW9jb2RlfSZzdGF0dXM9JHtzZWxlY3RlZFBhY2thZ2VzLnN0YXR1c31gLFxyXG4gICAgICAgIHt9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgXCJjb250ZW50LXR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbiAgICAgICAgICAgIGF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtwcm9wcy5lbnRyeS51c2VyLmFjY2Vzc1Rva2VufWAsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gICAgICAudGhlbigocmVzKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2cocmVzLmRhdGEuYmF0Y2hlcyk7XHJcbiAgICAgICAgc2V0UGFja2FnZXMocmVzLmRhdGEuYmF0Y2hlcyk7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRQYWNrcyhyZXMuZGF0YS5iYXRjaGVzKTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnIpID0+IHtcclxuICAgICAgICBzZXRFcnJvcihcInByb21vY29kZVwiLCB7IG1lc3NhZ2U6IGVyci5yZXNwb25zZS5kYXRhLmVycm9yIH0pO1xyXG4gICAgICB9KTtcclxuICB9O1xyXG5cclxuICB1c2VMYXlvdXRFZmZlY3QoKCkgPT4ge1xyXG4gICAgLy8gYXhpb3MuZ2V0KGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9YmF0Y2hlcz9sYW49JHtsb2NhbGV9YCwge1xyXG4gICAgLy8gICAgIGhlYWRlcnM6IHtcclxuICAgIC8vICAgICAgIGF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtwcm9wcy5lbnRyeS51c2VyLmFjY2Vzc1Rva2VufWAsXHJcbiAgICAvLyAgICAgfSxcclxuICAgIC8vICAgfSlcclxuICAgIC8vICAgLnRoZW4oKHJlcykgPT4ge1xyXG4gICAgLy8gICAgIHNldFBhY2thZ2VzKHJlcy5kYXRhKTtcclxuICAgIC8vICAgICBzZXRGaWx0ZXJlZFBhY2tzKHJlcy5kYXRhKTtcclxuICAgIC8vICAgfSlcclxuICAgIC8vICAgLmNhdGNoKChlcnIpID0+IGNvbnNvbGUubG9nKGVycikpO1xyXG5cclxuICAgIFByb21pc2UuYWxsKFtcclxuICAgICAgYXhpb3MuZ2V0KGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9YmF0Y2hlcz9sYW49JHtsb2NhbGV9YCwge1xyXG4gICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgIGF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtwcm9wcy5lbnRyeS51c2VyLmFjY2Vzc1Rva2VufWAsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSksXHJcbiAgICAgIGF4aW9zLmdldChgJHtwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19BUElfVVJMfXN0YXR1cz9sYW49JHtsb2NhbGV9YCwge1xyXG4gICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgIGF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtwcm9wcy5lbnRyeS51c2VyLmFjY2Vzc1Rva2VufWAsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSksXHJcbiAgICBdKVxyXG4gICAgICAudGhlbigocmVzKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2cocmVzLmRhdGEpO1xyXG4gICAgICAgIHNldFBhY2thZ2VzKHJlc1swXS5kYXRhKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZFBhY2tzKHJlc1swXS5kYXRhKTtcclxuICAgICAgICBzZXRTdGF0dXMocmVzWzFdLmRhdGEpO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycikgPT4gY29uc29sZS5sb2coZXJyKSk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBhZGRUYWJSZWZzID0gKHJlZikgPT4ge1xyXG4gICAgaWYgKHJlZiAmJiAhdGFiUmVmcy5jdXJyZW50LmluY2x1ZGVzKHJlZikpIHtcclxuICAgICAgdGFiUmVmcy5jdXJyZW50LnB1c2gocmVmKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCB0b2dnbGVUYWJSZWZzID0gYXN5bmMgKGV2KSA9PiB7XHJcbiAgICB0YWJSZWZzLmN1cnJlbnQuZm9yRWFjaCgoeCkgPT4geC5jbGFzc0xpc3QucmVtb3ZlKFwicGFjay1hY3RpdmVcIikpO1xyXG4gICAgZXYudGFyZ2V0LmNsYXNzTGlzdC5hZGQoXCJwYWNrLWFjdGl2ZVwiKTtcclxuICB9O1xyXG5cclxuICBjb25zdCB0YWJCdXR0b25DbGljayA9IChldikgPT4ge1xyXG4gICAgdG9nZ2xlVGFiUmVmcyhldik7XHJcbiAgICBsZXQgaWQgPSBldi50YXJnZXQuZ2V0QXR0cmlidXRlKFwiZGF0YS1pZFwiKTtcclxuICAgIGlmIChpZCAhPSAwKSB7XHJcbiAgICAgIGxldCBuZXdQYWNrYWdlcyA9IHBhY2thZ2VzLmZpbHRlcigoeCkgPT4geC5zdGF0dXMuaWQgPT0gaWQpO1xyXG4gICAgICBzZXRGaWx0ZXJlZFBhY2tzKFsuLi5uZXdQYWNrYWdlc10pO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0RmlsdGVyZWRQYWNrcyhbLi4ucGFja2FnZXNdKTtcclxuICAgIH1cclxuXHJcbiAgICBzZXRTZWxlY3RlZFBhY2thZ2VzKHtcclxuICAgICAgZGlzY291bnRUb3RhbDogMCxcclxuICAgICAgcGFja2FnZXM6IFtdLFxyXG4gICAgICB0b3RhbDogMCxcclxuICAgICAgY29kZTogXCJcIixcclxuICAgICAgaXNBY2NlcHRlZDogZmFsc2UsXHJcbiAgICAgIHN0YXR1czogaWQsXHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBhZGRDaGVja1JlZnMgPSAocmVmKSA9PiB7XHJcbiAgICBpZiAocmVmICYmICFjaGVja1JlZnMuY3VycmVudC5pbmNsdWRlcyhyZWYpKSB7XHJcbiAgICAgIGNoZWNrUmVmcy5jdXJyZW50LnB1c2gocmVmKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBjaGVja0hhbmRsZXIgPSAoZXYpID0+IHtcclxuICAgIGxldCB7IHZhbHVlLCBjaGVja2VkIH0gPSBldi50YXJnZXQ7XHJcbiAgICBsZXQgcHJpY2UgPSBldi50YXJnZXQuZ2V0QXR0cmlidXRlKFwiZGF0YS1wcmljZVwiKTtcclxuICAgIGxldCBkYXRhRGlzY291bnQgPSBldi50YXJnZXQuZ2V0QXR0cmlidXRlKFwiZGF0YS1kaXNjb3VudFwiKTtcclxuICAgIGxldCB0b3RhbD0wXHJcbiAgICBsZXQgZGlzYz0wXHJcbiAgICBjb25zb2xlLmxvZygnZGlzJyxkYXRhRGlzY291bnQpXHJcbiAgICBpZiAoY2hlY2tlZCkge1xyXG4gICAgICBzZWxlY3RlZFBhY2thZ2VzLnBhY2thZ2VzLnB1c2godmFsdWUpO1xyXG4gICAgICBpZihkYXRhRGlzY291bnQhPTApe1xyXG4gICAgICAgIHNldFNlbGVjdGVkUGFja2FnZXMoe1xyXG4gICAgICAgICAgLi4uc2VsZWN0ZWRQYWNrYWdlcyxcclxuXHJcbiAgICAgICAgICB0b3RhbDogKHNlbGVjdGVkUGFja2FnZXMudG90YWwrcGFyc2VGbG9hdChwcmljZSkpLFxyXG4gICAgICAgICBcclxuICAgICAgICAgIGRpc2NvdW50VG90YWw6IChzZWxlY3RlZFBhY2thZ2VzLmRpc2NvdW50VG90YWwrcGFyc2VGbG9hdChkYXRhRGlzY291bnQpKSxcclxuICAgICAgICAgIHBhY2thZ2VzOiBbLi4uc2VsZWN0ZWRQYWNrYWdlcy5wYWNrYWdlc10sXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIFxyXG4gICAgICB9ZWxzZXtcclxuICAgICAgICBzZXRTZWxlY3RlZFBhY2thZ2VzKHtcclxuICAgICAgICAgIC4uLnNlbGVjdGVkUGFja2FnZXMsXHJcbiAgICAgICAgICBkaXNjb3VudFRvdGFsOiAoc2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsK3BhcnNlRmxvYXQocHJpY2UpKSxcclxuICAgICAgICAgIHRvdGFsOiAoc2VsZWN0ZWRQYWNrYWdlcy50b3RhbCtwYXJzZUZsb2F0KHByaWNlKSksXHJcbiAgICAgICAgICBwYWNrYWdlczogWy4uLnNlbGVjdGVkUGFja2FnZXMucGFja2FnZXNdLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICAgXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBsZXQgbmV3UGFja2FnZXMgPSBzZWxlY3RlZFBhY2thZ2VzLnBhY2thZ2VzLmZpbHRlcigoeCkgPT4geCAhPT0gdmFsdWUpO1xyXG4gICAgICBpZihkYXRhRGlzY291bnQhPTApe1xyXG4gICAgICAgIHNldFNlbGVjdGVkUGFja2FnZXMoe1xyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuLi5zZWxlY3RlZFBhY2thZ2VzLFxyXG5cclxuICAgICAgICAgIHRvdGFsOiBzZWxlY3RlZFBhY2thZ2VzLnRvdGFsID49MCAmJiAoc2VsZWN0ZWRQYWNrYWdlcy50b3RhbC1wYXJzZUZsb2F0KHByaWNlKSksXHJcbiAgICAgICAgIFxyXG4gICAgICAgICAgZGlzY291bnRUb3RhbDogc2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsID49MCAmJiAgKHNlbGVjdGVkUGFja2FnZXMuZGlzY291bnRUb3RhbC1wYXJzZUZsb2F0KGRhdGFEaXNjb3VudCkpLFxyXG4gICAgICAgICAgcGFja2FnZXM6IG5ld1BhY2thZ2VzXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIFxyXG4gICAgICB9ZWxzZXtcclxuICAgICAgICBzZXRTZWxlY3RlZFBhY2thZ2VzKHtcclxuICAgICAgICAgIC4uLnNlbGVjdGVkUGFja2FnZXMsXHJcbiAgICAgICAgICBkaXNjb3VudFRvdGFsOnNlbGVjdGVkUGFja2FnZXMuZGlzY291bnRUb3RhbCA+PTAgJiYgKHNlbGVjdGVkUGFja2FnZXMuZGlzY291bnRUb3RhbC1wYXJzZUZsb2F0KHByaWNlKSksXHJcbiAgICAgICAgICB0b3RhbDpzZWxlY3RlZFBhY2thZ2VzLnRvdGFsID49MCAmJiAoc2VsZWN0ZWRQYWNrYWdlcy50b3RhbC1wYXJzZUZsb2F0KHByaWNlKSksXHJcbiAgICAgICAgICBwYWNrYWdlczpuZXdQYWNrYWdlc1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICAgXHJcbiAgICB9XHJcbiAgICAhc2VsZWN0ZWRQYWNrYWdlcy5wYWNrYWdlcy5zb21lKCh4KSA9PiB4KVxyXG4gICAgICA/IChtYWluQ2hlY2tSZWYuY3VycmVudC5jaGVja2VkID0gZmFsc2UpXHJcbiAgICAgIDogbnVsbDtcclxuICB9O1xyXG5cclxuICBjb25zdCBzZWxlY3RBbGwgPSAoZSkgPT4ge1xyXG4gICAgbGV0IHRvdGFsID0gMDtcclxuICAgIGxldCBkaXNjb3VudFRvdGFsID0gMDtcclxuICAgIGxldCBwYWNrYWdlcyA9IFtdO1xyXG4gICAgY2hlY2tSZWZzLmN1cnJlbnQuZm9yRWFjaCgoeCkgPT4ge1xyXG4gICAgICB4LmNoZWNrZWQgPSBlLnRhcmdldC5jaGVja2VkO1xyXG5cclxuICAgICAgaWYgKGUudGFyZ2V0LmNoZWNrZWQgJiYgIXBhY2thZ2VzLmluY2x1ZGVzKHgudmFsdWUpKSB7XHJcbiAgICAgICAgcGFja2FnZXMucHVzaCh4LnZhbHVlKTtcclxuICAgICAgICB0b3RhbCArPSAreC5nZXRBdHRyaWJ1dGUoXCJkYXRhLXByaWNlXCIpO1xyXG4gICAgICAgIGRpc2NvdW50VG90YWwgKz0gK3guZ2V0QXR0cmlidXRlKFwiZGF0YS1kaXNjb3VudFwiKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBwYWNrYWdlcyA9IHBhY2thZ2VzLmZpbHRlcigocCkgPT4gcCAhPT0geC52YWx1ZSk7XHJcbiAgICAgICAgdG90YWwgLT0gdG90YWwgPj0gMCAmJiAreC5nZXRBdHRyaWJ1dGUoXCJkYXRhLXByaWNlXCIpO1xyXG4gICAgICAgIGRpc2NvdW50VG90YWwgLT0gZGlzY291bnRUb3RhbCA+PTAgJiYgK3guZ2V0QXR0cmlidXRlKFwiZGF0YS1kaXNjb3VudFwiKTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgc2V0U2VsZWN0ZWRQYWNrYWdlcyh7XHJcbiAgICAgIC4uLnNlbGVjdGVkUGFja2FnZXMsXHJcbiAgICAgIHRvdGFsOiBzZWxlY3RlZFBhY2thZ2VzLnRvdGFsLXRvdGFsLFxyXG4gICAgICBwYWNrYWdlczogcGFja2FnZXMsXHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBQYXlieUNhcmQgPSAoZGF0YSA9IHt9KSA9PiB7XHJcbiAgICBheGlvcy5wb3N0KGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9cGF5bWVudGAsZGF0YSx7XHJcbiAgICAgIGhlYWRlcnM6e1xyXG4gICAgICAgIGF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtwcm9wcy5lbnRyeS51c2VyLmFjY2Vzc1Rva2VufWAsXHJcbiAgICAgIH1cclxuICAgIH0pLnRoZW4ocmVzID0+IHtcclxuICAgICAgY29uc29sZS5sb2coJ3JlZCcscmVzLmRhdGEudXJsKTtcclxuICAgICAgLy8gd2luZG93LmxvY2F0aW9uLmhyZWYgPSByZXMuZGF0YS51cmw7XHJcbiAgICB9KS5jYXRjaChlcnIgPT4gY29uc29sZS5sb2coZXJyKSlcclxuICB9XHJcbiBcclxuICByZXR1cm4gKFxyXG4gICAgPFBhZ2UgY2xhc3NOYW1lPVwiYmctYmcgcHQtbGcgcGItbGdcIj5cclxuICAgICAgPEFzaWRlIGNsYXNzTmFtZT1cIm1yLXNtXCI+XHJcbiAgICAgICAgPEFzaWRlTWVudSAvPlxyXG4gICAgICA8L0FzaWRlPlxyXG4gICAgICA8TWFpbiBjbGFzc05hbWU9XCJiZy1jIHAtbm9uZVwiPlxyXG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cImJnLWJnIHBiLXNtIG1nbV9zcyBwLXNtXCI+XHJcbiAgICAgICAgICA8Q2FyZC5IZWFkZXJcclxuICAgICAgICAgICAgdGV4dD17Zih7IGlkOiBcImFjdGl2ZS1wYWNcIiB9KX1cclxuICAgICAgICAgICAgZW5kRWxlbG1lbnQ9e1xyXG4gICAgICAgICAgICAgIDxDaGVja2JveFxyXG4gICAgICAgICAgICAgICAgdGV4dD17Zih7IGlkOiBcImNob29zZS1hbGxcIiB9KX1cclxuICAgICAgICAgICAgICAgIFJlZj17KHJlZikgPT4gKG1haW5DaGVja1JlZi5jdXJyZW50ID0gcmVmKX1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3NlbGVjdEFsbH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlci1zdWJ0aXRsZVwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJzc2NcIiBzdHlsZT17eyBvdmVyZmxvd1g6IFwic2Nyb2xsXCIgfX0+XHJcbiAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCIgcGwtbm9uZVwiXHJcbiAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxyXG4gICAgICAgICAgICAgICAgbWFyZ2luQm90dG9tOiBcIjIwcHhcIixcclxuICAgICAgICAgICAgICAgIHdpZHRoOiBcIm1heC1jb250ZW50XCIsXHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgPlxyXG5cclxuICAgICAgICAgICAgICA8QnV0dG9uQ29tcG9uZW50XHJcbiAgICAgICAgICAgICAgICBsYWJlbD17YEhhbXPEsSAoJHtwYWNrYWdlcy5sZW5ndGh9KWB9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtci14cyBwLXNtIGJnLWJnIHBhY2stYWN0aXZlXCJcclxuICAgICAgICAgICAgICAgIGRhdGEtaWQ9ezB9XHJcbiAgICAgICAgICAgICAgICBSZWY9e2FkZFRhYlJlZnN9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXt0YWJCdXR0b25DbGlja31cclxuICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAge3N0YXR1cy5tYXAoKHgpID0+IChcclxuICAgICAgICAgICAgICAgIDxCdXR0b25Db21wb25lbnRcclxuICAgICAgICAgICAgICAgICAgbGFiZWw9e2Ake3gubmFtZX0gKCR7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFja2FnZXMuZmlsdGVyKCh4KSA9PiB4LnN0YXR1cy5pZCA9PSAzKS5sZW5ndGhcclxuICAgICAgICAgICAgICAgICAgfSlgfVxyXG4gICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCIgbXIteHMgcC1zbSBiZy1iZyBcIlxyXG4gICAgICAgICAgICAgICAgICBkYXRhLWlkPXt4LmlkfVxyXG4gICAgICAgICAgICAgICAgICBSZWY9e2FkZFRhYlJlZnN9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3RhYkJ1dHRvbkNsaWNrfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICApKX0gXHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPENhcmQuQm9keSBjbGFzc05hbWU9XCJwLW5vbmVcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYWNrYWdlc19fZnJcIj5cclxuICAgICAgICAgICAgICB7ZmlsdGVyZWRQYWNrc1xyXG4gICAgICAgICAgICAgICAgLmZpbHRlcigoeCkgPT4geC5zdGF0dXMuaWQgIT09IDYpXHJcbiAgICAgICAgICAgICAgICAubWFwKChwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxQYWNrYWdlSXRlbVxyXG4gICAgICAgICAgICAgICAgICAgIGtleT17cC5pZH1cclxuICAgICAgICAgICAgICAgICAgICBjaGVja1JlZj17YWRkQ2hlY2tSZWZzfVxyXG4gICAgICAgICAgICAgICAgICAgIGl0ZW09e3B9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGVjaz17Y2hlY2tIYW5kbGVyfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9DYXJkLkJvZHk+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvb3Rlcl9fcGNrXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGFja2FnZS10b3RhbFwiPlxyXG4gICAgICAgICAgICAgIDxzbWFsbD5cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZFBhY2thZ2VzLnBhY2thZ2VzLmxlbmd0aH0ge2YoeyBpZDogXCJjaG9zZWRcIiB9KX1cclxuICAgICAgICAgICAgICA8L3NtYWxsPlxyXG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiB9fT5cclxuICAgICAgICAgICAgICAgIDxiPntmKHsgaWQ6IFwidG90YWxcIiB9KX06PC9iPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIiB9fT5cclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsID4gMCA/IFxyXG4gICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICA8ZGVsIHN0eWxlPXt7IHRleHREZWNvcmF0aW9uQ29sb3I6IFwicmVkXCIgfX0+e3BhcnNlRmxvYXQoc2VsZWN0ZWRQYWNrYWdlcy50b3RhbCkudG9GaXhlZCgyKX0gQVpOPC9kZWw+XHJcbiAgICAgICAgICAgICAgICAgICA8Yj57cGFyc2VGbG9hdChzZWxlY3RlZFBhY2thZ2VzLmRpc2NvdW50VG90YWwpLnRvRml4ZWQoMil9IEFaTjwvYj5cclxuICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgOiAgPGI+e3BhcnNlRmxvYXQoc2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsKS50b0ZpeGVkKDIpfSBBWk48L2I+XHJcbiAgICAgICAgICAgICAgICB9ICBcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhY2thZ2VfX2J0bnNcIj5cclxuICAgICAgICAgICAgICA8Zm9ybT5cclxuICAgICAgICAgICAgICAgIDxGcm9tR3JvdXBcclxuICAgICAgICAgICAgICAgICAgYm9keUNsYXNzPVwiYmctd2hpdGUgcGwteHNcIlxyXG4gICAgICAgICAgICAgICAgICBib2R5U3R5bGU9e3sgaGVpZ2h0OiBcIjQ0cHhcIiwgd2lkdGg6IFwiMjAwcHhcIiB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtci14cyBjaG5nX19ib2R5c3R5bGVcIlxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBtYXJnaW5Cb3R0b206IFwiMHB4XCIgfX1cclxuICAgICAgICAgICAgICAgICAgZXJyb3I9e2Vycm9ycy5wcm9tb2NvZGU/Lm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtmKHsgaWQ6IFwiYWRkY29kZVwiIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwcm9tb2NvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIFJlZj17cmVnaXN0ZXIoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IGYoeyBpZDogXCJwcm9tby1yZXF1aXJcIiB9KSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRQYWNrYWdlcyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnNlbGVjdGVkUGFja2FnZXMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvZGU6IGUudGFyZ2V0LnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZFBhY2thZ2VzLmlzQWNjZXB0ZWQgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbkNvbXBvbmVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgdy01MFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZXh0RGVjb3JhdGlvbkxpbmU6IFwidW5kZXJsaW5lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcImRhcmtibHVlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IFwiMHB4IDEwcHhcIixcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkzJmcSfdiBldFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkUGFja2FnZXMoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnNlbGVjdGVkUGFja2FnZXMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaXNBY2NlcHRlZDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b25Db21wb25lbnRcclxuICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshc2VsZWN0ZWRQYWNrYWdlcy5jb2RlID8gdHJ1ZSA6IGZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgcGFkZGluZzogXCIwIDEwcHhcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY29sb3Itd2hpdGUgYmctc3VjY2Vzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbD17Zih7IGlkOiBcImNvbmZpcm1cIiB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU3VibWl0KHN1Ym1pdCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAvLyAgb25DbGljaz17KCkgPT57XHJcbiAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgLy8gIHNldFNlbGVjdGVkUGFja2FnZXMoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gICAgIC8vICAgIC4uLnNlbGVjdGVkUGFja2FnZXMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgLy8gICAgaXNBY2NlcHRlZDp0cnVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgLy8gIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9Gcm9tR3JvdXA+XHJcbiAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDxCdXR0b25Db21wb25lbnRcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IHBhZGRpbmc6IFwiMCAyMHB4XCIgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNvbG9yLXdoaXRlIGJnLXN1Y2Nlc3MgbXIteHMgZGVza1wiXHJcbiAgICAgICAgICAgICAgICBsYWJlbD17Zih7IGlkOiBcInBheWJ5Y2FyZFwiIH0pfVxyXG4gICAgICAgICAgICAgICAgZW5kRWxlbWVudD17PHNwYW4gY2xhc3NOYW1lPVwiY29sb3Itd2hpdGUgcGwtc21cIj4mIzg1OTQ7PC9zcGFuPn1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2sgPSB7KCkgPT4gUGF5YnlDYXJkKHtcclxuICAgICAgICAgICAgICAgICAgcHJpY2U6c2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsLFxyXG4gICAgICAgICAgICAgICAgICBzb3VyY2V0eXBlOjJcclxuICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvbkNvbXBvbmVudFxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgcGFkZGluZzogXCIwIDEwcHhcIiB9fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZGVza1wiXHJcbiAgICAgICAgICAgICAgICBsYWJlbD17Zih7IGlkOiBcInBheWJ5YmFsYW5jZVwiIH0pfVxyXG4gICAgICAgICAgICAgICAgZW5kRWxlbWVudD17XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNvbG9yLWJsYWNrIG1yLXhzIHBsLXNtIFwiPiYjODU5NDs8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrID0geygpID0+IHByb3BzLlBheUJ5QmFsYW5jZUFjdGlvbigncGF5bWVudCcse1xyXG4gICAgICAgICAgICAgICAgICBwcmljZTpzZWxlY3RlZFBhY2thZ2VzLmRpc2NvdW50VG90YWwsXHJcbiAgICAgICAgICAgICAgICAgIHNvdXJjZXR5cGU6MyxcclxuICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAnYXV0aG9yaXphdGlvbic6YEJlYXJlciAke3Byb3BzLmVudHJ5LnVzZXIuYWNjZXNzVG9rZW59YFxyXG4gICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJidG5fX2ZrbFwiPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvbkNvbXBvbmVudFxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBwYWRkaW5nOiBcIjAgMTBweFwiIH19XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNvbG9yLXdoaXRlIGJnLXN1Y2Nlc3MgbXIteHNcIlxyXG4gICAgICAgICAgICAgICAgICBsYWJlbD17Zih7IGlkOiBcInBheWJ5Y2FyZFwiIH0pfVxyXG4gICAgICAgICAgICAgICAgICBlbmRFbGVtZW50PXtcclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjb2xvci13aGl0ZSBwbC1zbVwiPiYjODU5NDs8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgb25DbGljayA9IHsoKSA9PiBQYXlieUNhcmQoe1xyXG4gICAgICAgICAgICAgICAgICAgIHByaWNlOnNlbGVjdGVkUGFja2FnZXMuZGlzY291bnRUb3RhbCxcclxuICAgICAgICAgICAgICAgICAgICBzb3VyY2V0eXBlOjJcclxuICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvbkNvbXBvbmVudFxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBwYWRkaW5nOiBcIjAgMTBweFwiIH19XHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsPXtmKHsgaWQ6IFwicGF5YnliYWxhbmNlXCIgfSl9XHJcbiAgICAgICAgICAgICAgICAgIGVuZEVsZW1lbnQ9e1xyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNvbG9yLWJsYWNrIG1yLXhzIHBsLXNtXCI+JiM4NTk0Ozwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrID0geygpID0+IHByb3BzLlBheUJ5QmFsYW5jZUFjdGlvbigncGF5bWVudCcse1xyXG4gICAgICAgICAgICAgICAgICAgIHByaWNlOnNlbGVjdGVkUGFja2FnZXMuZGlzY291bnRUb3RhbCxcclxuICAgICAgICAgICAgICAgICAgICBzb3VyY2V0eXBlOjMsXHJcbiAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAnYXV0aG9yaXphdGlvbic6YEJlYXJlciAke3Byb3BzLmVudHJ5LnVzZXIuYWNjZXNzVG9rZW59YFxyXG4gICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9DYXJkPlxyXG5cclxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLXNtIGJnLXdoaXRlXCI+XHJcbiAgICAgICAgICA8Q2FyZC5IZWFkZXIgdGV4dD17Zih7IGlkOiBcIm9yZGVyLWhpc3RvcnlcIiB9KX0gLz5cclxuICAgICAgICAgIDxDYXJkLkJvZHkgY2xhc3NOYW1lPVwicC1ub25lIG92ZXJmbG93X19wYWNrYWdlXCI+XHJcbiAgICAgICAgICAgIDxUYWJlbFxyXG4gICAgICAgICAgICAgIHRoPXtbXHJcbiAgICAgICAgICAgICAgICBmKHsgaWQ6IFwidHJhY2tpbmdcIiB9KSxcclxuICAgICAgICAgICAgICAgIGYoeyBpZDogXCJzaG9wXCIgfSksXHJcbiAgICAgICAgICAgICAgICBmKHsgaWQ6IFwiY2F0ZWdvcnlcIiB9KSxcclxuICAgICAgICAgICAgICAgIGYoeyBpZDogXCJhbW91bnRcIiB9KSxcclxuICAgICAgICAgICAgICAgIGYoeyBpZDogXCJ3ZWlnaHRcIiB9KSxcclxuICAgICAgICAgICAgICAgIGYoeyBpZDogXCJkZWxpdmVyeVwiIH0pLFxyXG4gICAgICAgICAgICAgICAgZih7IGlkOiBcInN0YXR1c1wiIH0pLFxyXG4gICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgZGF0YT17XHJcbiAgICAgICAgICAgICAgICBwYWNrYWdlcy5tYXAoKHgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgaWYgKHguc3RhdHVzLmlkID09IDYpIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgdHJhY2tfbnVtYmVyOiB4LnRyYWNrX251bWJlcixcclxuICAgICAgICAgICAgICAgICAgICAgIHNob3A6IHguc2hvcCxcclxuICAgICAgICAgICAgICAgICAgICAgIGNhdGVnb3J5OiB4LmNhdGVnb3J5LFxyXG4gICAgICAgICAgICAgICAgICAgICAgcHJpY2U6IGAke3gucHJpY2V9ICR7eC5jdXJyZW5jeX1gLFxyXG4gICAgICAgICAgICAgICAgICAgICAgd2VpZ2h0OiBgJHtwYXJzZUZsb2F0KHgud2VpZ2h0KS50b0ZpeGVkKDIpIHx8IDB9IGtxYCxcclxuICAgICAgICAgICAgICAgICAgICAgIGRlbGl2ZXJ5X3ByaWNlOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXJzZUZsb2F0KHguZGVsaXZlcnlfcHJpY2UpLnRvRml4ZWQoMikgfHwgMCxcclxuICAgICAgICAgICAgICAgICAgICAgIHN0YXR1czogYCR7eC5zdGF0dXMubmFtZX1cXG4gJHt4LmRhdGV9YCxcclxuICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KSB8fCBbXVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICByZW5kZXJCb2R5PXsoeCwgaSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIDx0ZCBrZXk9e2krK30+e3h9PC90ZD47XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvQ2FyZC5Cb2R5PlxyXG4gICAgICAgIDwvQ2FyZD5cclxuICAgICAgPC9NYWluPlxyXG4gICAgPC9QYWdlPlxyXG4gICk7XHJcbn1cclxuXHJcbmNvbnN0IG1hcFN0YXRlVG9Qcm9wcyA9IChzdGF0ZSkgPT4gKHtcclxuICBlbnRyeTogc3RhdGUuZW50cnksXHJcbn0pO1xyXG5jb25zdCBtYXBEaXNwYXRjaFRvUHJvcHMgPSAge1xyXG4gIFBheUJ5QmFsYW5jZUFjdGlvblxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY29ubmVjdChtYXBTdGF0ZVRvUHJvcHMsIG1hcERpc3BhdGNoVG9Qcm9wcykobWVtbyhQYWNrYWdlcykpO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9