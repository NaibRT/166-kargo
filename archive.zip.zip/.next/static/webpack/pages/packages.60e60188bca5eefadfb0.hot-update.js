webpackHotUpdate_N_E("pages/packages",{

/***/ "./pages/packages.js":
/*!***************************!*\
  !*** ./pages/packages.js ***!
  \***************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/toConsumableArray */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/regenerator */ "./node_modules/next/node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-hook-form */ "./node_modules/react-hook-form/dist/index.esm.js");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-intl */ "./node_modules/react-intl/lib/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _components_aside_menu_index__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../components/aside-menu/index */ "./components/aside-menu/index.js");
/* harmony import */ var _components_aside_aside__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../components/aside/aside */ "./components/aside/aside.js");
/* harmony import */ var _components_button__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../components/button */ "./components/button/index.js");
/* harmony import */ var _components_card_card__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../components/card/card */ "./components/card/card.js");
/* harmony import */ var _components_checkbox_checkbox__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../components/checkbox/checkbox */ "./components/checkbox/checkbox.js");
/* harmony import */ var _components_form_group_form_group__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../components/form-group/form-group */ "./components/form-group/form-group.js");
/* harmony import */ var _components_input_input__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../components/input/input */ "./components/input/input.js");
/* harmony import */ var _components_main_main__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../components/main/main */ "./components/main/main.js");
/* harmony import */ var _components_package_item_package_item__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../components/package_item/package-item */ "./components/package_item/package-item.js");
/* harmony import */ var _components_page_page__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../components/page/page */ "./components/page/page.js");
/* harmony import */ var _components_redirect_redirect__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../components/redirect/redirect */ "./components/redirect/redirect.js");
/* harmony import */ var _components_tabel_tabel__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../components/tabel/tabel */ "./components/tabel/tabel.js");
/* harmony import */ var _redux_entry_entryActions__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../redux/entry/entryActions */ "./redux/entry/entryActions.js");







var _jsxFileName = "C:\\Users\\Home\\Desktop\\166\\166-kargo\\pages\\packages.js",
    _s = $RefreshSig$();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }





















function Packages(props) {
  _s();

  var _this = this,
      _errors$promocode;

  if (!props.entry.isLoged) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_redirect_redirect__WEBPACK_IMPORTED_MODULE_21__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 23,
      columnNumber: 12
    }, this);
  }

  var _useForm = Object(react_hook_form__WEBPACK_IMPORTED_MODULE_8__["useForm"])(),
      register = _useForm.register,
      handleSubmit = _useForm.handleSubmit,
      errors = _useForm.errors,
      setError = _useForm.setError;

  var _useIntl = Object(react_intl__WEBPACK_IMPORTED_MODULE_9__["useIntl"])(),
      f = _useIntl.formatMessage;

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])([]),
      packages = _useState[0],
      setPackages = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])([]),
      filteredPacks = _useState2[0],
      setFilteredPacks = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])([]),
      status = _useState3[0],
      setStatus = _useState3[1];

  var _useState4 = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])({
    packages: [],
    total: 0,
    discountTotal: 0,
    code: "",
    isAccepted: false,
    status: 0
  }),
      selectedPackages = _useState4[0],
      setSelectedPackages = _useState4[1];

  var _useRouter = Object(next_router__WEBPACK_IMPORTED_MODULE_6__["useRouter"])(),
      locale = _useRouter.locale;

  var mainCheckRef = Object(react__WEBPACK_IMPORTED_MODULE_7__["useRef"])();
  var checkRefs = Object(react__WEBPACK_IMPORTED_MODULE_7__["useRef"])([]);
  checkRefs.current = [];
  var tabRefs = Object(react__WEBPACK_IMPORTED_MODULE_7__["useRef"])([]);
  tabRefs.current = [];

  var submit = function submit(data) {
    console.log(data);
    axios__WEBPACK_IMPORTED_MODULE_5___default.a.post("".concat("https://166api.titr.az/api/", "promocode?promocode=").concat(data.promocode, "&status=").concat(selectedPackages.status), {}, {
      headers: {
        "content-type": "application/json",
        authorization: "Bearer ".concat(props.entry.user.accessToken)
      }
    }).then(function (res) {
      console.log(res.data.batches);
      setPackages(res.data.batches);
      setFilteredPacks(res.data.batches);
    })["catch"](function (err) {
      setError("promocode", {
        message: err.response.data.error
      });
    });
  };

  var PromisAll = /*#__PURE__*/function () {
    var _ref = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_4__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.mark(function _callee() {
      var batchesData, statusData;
      return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return axios__WEBPACK_IMPORTED_MODULE_5___default.a.get("".concat("https://166api.titr.az/api/", "batches?lan=").concat(locale), {
                headers: {
                  authorization: "Bearer ".concat(props.entry.user.accessToken)
                }
              });

            case 2:
              batchesData = _context.sent;
              _context.next = 5;
              return axios__WEBPACK_IMPORTED_MODULE_5___default.a.get("".concat("https://166api.titr.az/api/", "status?lan=").concat(locale), {
                headers: {
                  authorization: "Bearer ".concat(props.entry.user.accessToken)
                }
              });

            case 5:
              statusData = _context.sent;
              return _context.abrupt("return", {
                batchesData: batchesData.data,
                statusData: statusData.data
              });

            case 7:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function PromisAll() {
      return _ref.apply(this, arguments);
    };
  }();

  Object(react__WEBPACK_IMPORTED_MODULE_7__["useLayoutEffect"])(function () {
    PromisAll().then(function (res) {
      setPackages(res.batchesData);
      setFilteredPacks(res.batchesData);
      setStatus(res.statusData);
    })["catch"](function (err) {
      return console.log(err);
    });
  }, []);

  var addTabRefs = function addTabRefs(ref) {
    if (ref && !tabRefs.current.includes(ref)) {
      tabRefs.current.push(ref);
    }
  };

  var toggleTabRefs = /*#__PURE__*/function () {
    var _ref2 = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_4__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.mark(function _callee2(ev) {
      return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              tabRefs.current.forEach(function (x) {
                return x.classList.remove("pack-active");
              });
              ev.target.classList.add("pack-active");

            case 2:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2);
    }));

    return function toggleTabRefs(_x) {
      return _ref2.apply(this, arguments);
    };
  }();

  var getBatchesByStatausId = /*#__PURE__*/function () {
    var _ref3 = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_4__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.mark(function _callee3(id) {
      return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.wrap(function _callee3$(_context3) {
        while (1) {
          switch (_context3.prev = _context3.next) {
            case 0:
              axios__WEBPACK_IMPORTED_MODULE_5___default.a.get("".concat("https://166api.titr.az/api/", "batches?status=").concat(id, "&lan=").concat(locale), {
                headers: {
                  authorization: "Bearer ".concat(props.entry.user.accessToken)
                }
              }).then(function (res) {
                setPackages(res.data);
                setFilteredPacks(res.data);
              })["catch"](function (err) {
                return console.log(err);
              });

            case 1:
            case "end":
              return _context3.stop();
          }
        }
      }, _callee3);
    }));

    return function getBatchesByStatausId(_x2) {
      return _ref3.apply(this, arguments);
    };
  }();

  var tabButtonClick = function tabButtonClick(ev) {
    var id = ev.target.getAttribute("data-id");
    toggleTabRefs(ev);
    getBatchesByStatausId(id);

    if (id != 0) {
      var newPackages = packages.filter(function (x) {
        return x.status.id == id;
      });
      setFilteredPacks(Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(newPackages));
    } else {
      setFilteredPacks(Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(packages));
    }

    setSelectedPackages({
      discountTotal: 0,
      packages: [],
      total: 0,
      code: "",
      isAccepted: false,
      status: id
    });
  };

  var addCheckRefs = function addCheckRefs(ref) {
    if (ref && !checkRefs.current.includes(ref)) {
      checkRefs.current.push(ref);
    }
  };

  var checkHandler = function checkHandler(ev) {
    var _ev$target = ev.target,
        value = _ev$target.value,
        checked = _ev$target.checked;
    var price = ev.target.getAttribute("data-price");
    var dataDiscount = ev.target.getAttribute("data-discount");
    var total = 0;
    var disc = 0;
    console.log('dis', dataDiscount);

    if (checked) {
      selectedPackages.packages.push(value);

      if (dataDiscount != 0) {
        setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
          total: selectedPackages.total + parseFloat(price),
          discountTotal: selectedPackages.discountTotal + parseFloat(dataDiscount),
          packages: Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(selectedPackages.packages)
        }));
      } else {
        setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
          discountTotal: selectedPackages.discountTotal + parseFloat(price),
          total: selectedPackages.total + parseFloat(price),
          packages: Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(selectedPackages.packages)
        }));
      }
    } else {
      var newPackages = selectedPackages.packages.filter(function (x) {
        return x !== value;
      });

      if (dataDiscount != 0) {
        setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
          total: selectedPackages.total >= 0 && selectedPackages.total - parseFloat(price),
          discountTotal: selectedPackages.discountTotal >= 0 && selectedPackages.discountTotal - parseFloat(dataDiscount),
          packages: newPackages
        }));
      } else {
        setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
          discountTotal: selectedPackages.discountTotal >= 0 && selectedPackages.discountTotal - parseFloat(price),
          total: selectedPackages.total >= 0 && selectedPackages.total - parseFloat(price),
          packages: newPackages
        }));
      }
    }

    !selectedPackages.packages.some(function (x) {
      return x;
    }) ? mainCheckRef.current.checked = false : null;
  };

  var selectAll = function selectAll(e) {
    var total = 0;
    var discountTotal = 0;
    var packages = [];
    checkRefs.current.forEach(function (x) {
      x.checked = e.target.checked;

      if (e.target.checked && !packages.includes(x.value)) {
        packages.push(x.value);
        total += +x.getAttribute("data-price");
        discountTotal += +x.getAttribute("data-discount");
      } else {
        packages = packages.filter(function (p) {
          return p !== x.value;
        });
        total -= total >= 0 && +x.getAttribute("data-price");
        discountTotal -= discountTotal >= 0 && +x.getAttribute("data-discount");
      }
    });
    setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
      total: selectedPackages.total - total,
      packages: packages
    }));
  };

  var PaybyCard = function PaybyCard() {
    var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    axios__WEBPACK_IMPORTED_MODULE_5___default.a.post("".concat("https://166api.titr.az/api/", "payment"), data, {
      headers: {
        authorization: "Bearer ".concat(props.entry.user.accessToken)
      }
    }).then(function (res) {
      console.log('red', res.data.url);
      window.location.href = res.data.url;
    })["catch"](function (err) {
      return console.log(err);
    });
  };

  var PaybyBalance = function PaybyBalance() {
    if (props.entry.user.user.balance >= 0) {
      props.PayByBalanceAction('payment', {
        price: selectedPackages.discountTotal,
        sourcetype: 3,
        batches: selectedPackages.packages
      }, {
        'authorization': "Bearer ".concat(props.entry.user.accessToken)
      });
    } else {
      Swal.fire({
        text: 'Balansda kifayət qədər məbləğ yoxdur',
        icon: 'info',
        confirmButtonText: 'OK'
      });
    }
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_page_page__WEBPACK_IMPORTED_MODULE_20__["default"], {
    className: "bg-bg pt-lg pb-lg",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_aside_aside__WEBPACK_IMPORTED_MODULE_12__["default"], {
      className: "mr-sm",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_aside_menu_index__WEBPACK_IMPORTED_MODULE_11__["default"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 263,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 262,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_main_main__WEBPACK_IMPORTED_MODULE_18__["default"], {
      className: "bg-c p-none",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"], {
        className: "bg-bg pb-sm mgm_ss p-sm",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"].Header, {
          text: f({
            id: "active-pac"
          }),
          endElelment: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_checkbox_checkbox__WEBPACK_IMPORTED_MODULE_15__["default"], {
            text: f({
              id: "choose-all"
            }),
            Ref: function Ref(ref) {
              return mainCheckRef.current = ref;
            },
            onClick: selectAll,
            className: "bg-white border-subtitle"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 270,
            columnNumber: 15
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 267,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          "class": "ssc",
          style: {
            overflowX: "scroll"
          },
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: " pl-none",
            style: {
              display: "flex",
              marginBottom: "20px",
              width: "max-content"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
              label: "Hams\u0131 (".concat(packages.length, ")"),
              className: "mr-xs p-xs bg-bg pack-active",
              "data-id": 0,
              Ref: addTabRefs,
              onClick: tabButtonClick
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 288,
              columnNumber: 15
            }, this), status.map(function (x) {
              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                label: "".concat(x.name, " (").concat(x.count, ")"),
                className: " p-xs bg-bg ",
                "data-id": x.id,
                Ref: addTabRefs,
                onClick: tabButtonClick
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 297,
                columnNumber: 17
              }, _this);
            })]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 279,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 278,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"].Body, {
          className: "p-none",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "packages__fr",
            children: filteredPacks.filter(function (x) {
              return x.status.id !== 6;
            }).map(function (p) {
              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_package_item_package_item__WEBPACK_IMPORTED_MODULE_19__["default"], {
                checkRef: addCheckRefs,
                item: p,
                onCheck: checkHandler
              }, p.id, false, {
                fileName: _jsxFileName,
                lineNumber: 314,
                columnNumber: 19
              }, _this);
            })
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 310,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 309,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "footer__pck",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "package-total",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
              children: [selectedPackages.packages.length, " ", f({
                id: "chosed"
              })]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 325,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                display: "flex",
                justifyContent: "space-between"
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                children: [f({
                  id: "total"
                }), ":"]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 329,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                style: {
                  display: "flex",
                  flexDirection: "column"
                },
                children: selectedPackages.discountTotal > 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
                    style: {
                      textDecorationColor: "red"
                    },
                    children: [parseFloat(selectedPackages.total).toFixed(2), " AZN"]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 334,
                    columnNumber: 19
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                    children: [parseFloat(selectedPackages.discountTotal).toFixed(2), " AZN"]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 335,
                    columnNumber: 20
                  }, this)]
                }, void 0, true) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                  children: [parseFloat(selectedPackages.discountTotal).toFixed(2), " AZN"]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 337,
                  columnNumber: 23
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 330,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 328,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 324,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "package__btns",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("form", {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_form_group_form_group__WEBPACK_IMPORTED_MODULE_16__["default"], {
                bodyClass: "bg-white pl-xs",
                bodyStyle: {
                  height: "44px",
                  width: "200px"
                },
                className: "mr-xs chng__bodystyle",
                style: {
                  marginBottom: "0px"
                },
                error: (_errors$promocode = errors.promocode) === null || _errors$promocode === void 0 ? void 0 : _errors$promocode.message,
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_input_input__WEBPACK_IMPORTED_MODULE_17__["default"], {
                  placeholder: f({
                    id: "addcode"
                  }),
                  name: "promocode",
                  Ref: register({
                    required: {
                      value: true,
                      message: f({
                        id: "promo-requir"
                      })
                    }
                  }),
                  onChange: function onChange(e) {
                    return setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
                      code: e.target.value
                    }));
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 353,
                  columnNumber: 19
                }, this), selectedPackages.isAccepted ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                  className: "bg-white w-50",
                  style: {
                    textDecorationLine: "underline",
                    color: "darkblue",
                    padding: "0px 10px"
                  },
                  label: "L\u0259\u011Fv et",
                  onClick: function onClick() {
                    setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
                      isAccepted: false
                    }));
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 370,
                  columnNumber: 21
                }, this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                  disabled: !selectedPackages.code ? true : false,
                  style: {
                    padding: "0 10px"
                  },
                  className: "color-white bg-success",
                  label: f({
                    id: "confirm"
                  }),
                  type: "submit",
                  onClick: handleSubmit(submit) //  onClick={() =>{
                  //     //  setSelectedPackages({
                  //     //    ...selectedPackages,
                  //     //    isAccepted:true
                  //     //  });
                  //    }}

                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 386,
                  columnNumber: 21
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 346,
                columnNumber: 17
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 345,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
              style: {
                padding: "0 20px"
              },
              className: "color-white bg-success mr-xs desk",
              label: f({
                id: "paybycard"
              }),
              endElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                className: "color-white pl-sm",
                children: "\u2192"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 408,
                columnNumber: 29
              }, this),
              onClick: function onClick() {
                return PaybyCard({
                  price: selectedPackages.discountTotal,
                  sourcetype: 2,
                  batches: selectedPackages.packages
                });
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 404,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
              style: {
                padding: "0 10px"
              },
              className: "desk",
              label: f({
                id: "paybybalance"
              }),
              endElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                className: "color-black mr-xs pl-sm ",
                children: "\u2192"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 420,
                columnNumber: 19
              }, this),
              onClick: PaybyBalance
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 415,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "btn__fkl",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                style: {
                  padding: "0 10px"
                },
                className: "color-white bg-success mr-xs",
                label: f({
                  id: "paybycard"
                }),
                endElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "color-white pl-sm",
                  children: "\u2192"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 431,
                  columnNumber: 21
                }, this),
                onClick: function onClick() {
                  return PaybyCard({
                    price: selectedPackages.discountTotal,
                    sourcetype: 2,
                    batches: selectedPackages.packages
                  });
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 426,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                style: {
                  padding: "0 10px"
                },
                label: f({
                  id: "paybybalance"
                }),
                endElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "color-black mr-xs pl-sm",
                  children: "\u2192"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 443,
                  columnNumber: 21
                }, this),
                onClick: PaybyBalance
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 439,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 425,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 344,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 323,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 266,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"], {
        className: "p-sm bg-white",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"].Header, {
          text: f({
            id: "order-history"
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 453,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"].Body, {
          className: "p-none overflow__package",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_tabel_tabel__WEBPACK_IMPORTED_MODULE_22__["default"], {
            th: [f({
              id: "tracking"
            }), f({
              id: "shop"
            }), f({
              id: "category"
            }), f({
              id: "amount"
            }), f({
              id: "weight"
            }), f({
              id: "delivery"
            }), f({
              id: "status"
            })],
            data: packages.map(function (x) {
              if (x.status.id == 6) {
                return {
                  track_number: x.track_number,
                  shop: x.shop,
                  category: x.category,
                  price: "".concat(x.price, " ").concat(x.currency),
                  weight: "".concat(parseFloat(x.weight).toFixed(2) || 0, " kq"),
                  delivery_price: parseFloat(x.delivery_price).toFixed(2) || 0,
                  status: "".concat(x.status.name, "\n ").concat(x.date)
                };
              }
            }) || [],
            renderBody: function renderBody(x, i) {
              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {
                children: x
              }, i++, false, {
                fileName: _jsxFileName,
                lineNumber: 482,
                columnNumber: 24
              }, _this);
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 455,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 454,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 452,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 265,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 261,
    columnNumber: 5
  }, this);
}

_s(Packages, "3E201Kyf6S2uVJ0+DS1LdJkJE1g=", false, function () {
  return [react_hook_form__WEBPACK_IMPORTED_MODULE_8__["useForm"], react_intl__WEBPACK_IMPORTED_MODULE_9__["useIntl"], next_router__WEBPACK_IMPORTED_MODULE_6__["useRouter"]];
});

_c = Packages;

var mapStateToProps = function mapStateToProps(state) {
  return {
    entry: state.entry
  };
};

var mapDispatchToProps = {
  PayByBalanceAction: _redux_entry_entryActions__WEBPACK_IMPORTED_MODULE_23__["PayByBalanceAction"]
};
/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_10__["connect"])(mapStateToProps, mapDispatchToProps)( /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_7__["memo"])(Packages)));

var _c;

$RefreshReg$(_c, "Packages");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./redux/entry/entryActions.js":
/*!*************************************!*\
  !*** ./redux/entry/entryActions.js ***!
  \*************************************/
/*! exports provided: Login, UserRegister, LogOut, UpdateUser, PayByBalanceAction, IncreaseBalanceAction */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Login", function() { return Login; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserRegister", function() { return UserRegister; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogOut", function() { return LogOut; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UpdateUser", function() { return UpdateUser; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PayByBalanceAction", function() { return PayByBalanceAction; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IncreaseBalanceAction", function() { return IncreaseBalanceAction; });
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/regenerator */ "./node_modules/next/node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! sweetalert2 */ "./node_modules/sweetalert2/dist/sweetalert2.all.js");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./actions */ "./redux/entry/actions.js");






var Login = function Login(url, data) {
  var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return function (dispatch) {
    axios__WEBPACK_IMPORTED_MODULE_2___default.a.post("".concat("https://166api.titr.az/api/").concat(url), data, {
      headers: headers
    }).then( /*#__PURE__*/function () {
      var _ref = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(res) {
        var data;
        return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return res.data;

              case 2:
                data = _context.sent;
                dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["login"])(data));
                next_router__WEBPACK_IMPORTED_MODULE_3___default.a.push('/packages');

              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));

      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }())["catch"](function (errors) {
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["login"])({
        isError: true,
        errors: errors.response.data
      }));
    });
  };
};
var UserRegister = function UserRegister(url, data) {
  var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return function (dispatch) {
    axios__WEBPACK_IMPORTED_MODULE_2___default.a.post("".concat("https://166api.titr.az/api/").concat(url), data, {
      headers: headers
    }).then( /*#__PURE__*/function () {
      var _ref2 = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2(res) {
        var data;
        return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                sweetalert2__WEBPACK_IMPORTED_MODULE_4___default.a.fire({
                  text: 'Əməliyyat uğurla tamamlandı',
                  icon: 'success',
                  confirmButtonText: 'OK'
                }).then(function (res) {
                  if (res.isConfirmed) {
                    next_router__WEBPACK_IMPORTED_MODULE_3___default.a.push('/myaddresses');
                  }
                });
                _context2.next = 3;
                return res.data;

              case 3:
                data = _context2.sent;
                dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["register"])(data));

              case 5:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }));

      return function (_x2) {
        return _ref2.apply(this, arguments);
      };
    }())["catch"](function (err) {
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["register"])({
        isError: true,
        errors: err.response.data
      }));
    });
  };
};
var LogOut = function LogOut() {
  return function (dispatch) {
    dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["logout"])());
  };
};
var UpdateUser = function UpdateUser(url, data) {
  var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return function (dispatch) {
    axios__WEBPACK_IMPORTED_MODULE_2___default.a.put("".concat("https://166api.titr.az/api/").concat(url), data, {
      headers: headers
    }).then(function (res) {
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["updateUser"])(res.data));
      sweetalert2__WEBPACK_IMPORTED_MODULE_4___default.a.fire({
        text: 'Əməliyyat uğurla yerinə yetirildi',
        icon: 'success',
        confirmButtonText: 'OK'
      });
    })["catch"](function (err) {
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["updateUser"])({
        isError: true,
        errors: err.response.data
      }));
    });
  };
};
var PayByBalanceAction = function PayByBalanceAction(url, data, headers) {
  return function (dispatch) {
    axios__WEBPACK_IMPORTED_MODULE_2___default.a.post("".concat("https://166api.titr.az/api/").concat(url), data, {
      headers: headers
    }).then(function (res) {
      console.log('req', res.data.balance);
      sweetalert2__WEBPACK_IMPORTED_MODULE_4___default.a.fire({
        text: res.data.message,
        icon: 'success',
        confirmButtonText: 'OK'
      });
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["PayByBalance"])(res.data.balance));
      next_router__WEBPACK_IMPORTED_MODULE_3___default.a.push("/success?message=".concat(res.data.message));
    })["catch"](function (err) {
      return console.log(err);
    });
  };
};
var IncreaseBalanceAction = function IncreaseBalanceAction(balance) {
  return function (dispatch) {
    dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["IncreaseBalance"])(balance));
  };
};

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvcGFja2FnZXMuanMiLCJ3ZWJwYWNrOi8vX05fRS8uL3JlZHV4L2VudHJ5L2VudHJ5QWN0aW9ucy5qcyJdLCJuYW1lcyI6WyJQYWNrYWdlcyIsInByb3BzIiwiZW50cnkiLCJpc0xvZ2VkIiwidXNlRm9ybSIsInJlZ2lzdGVyIiwiaGFuZGxlU3VibWl0IiwiZXJyb3JzIiwic2V0RXJyb3IiLCJ1c2VJbnRsIiwiZiIsImZvcm1hdE1lc3NhZ2UiLCJ1c2VTdGF0ZSIsInBhY2thZ2VzIiwic2V0UGFja2FnZXMiLCJmaWx0ZXJlZFBhY2tzIiwic2V0RmlsdGVyZWRQYWNrcyIsInN0YXR1cyIsInNldFN0YXR1cyIsInRvdGFsIiwiZGlzY291bnRUb3RhbCIsImNvZGUiLCJpc0FjY2VwdGVkIiwic2VsZWN0ZWRQYWNrYWdlcyIsInNldFNlbGVjdGVkUGFja2FnZXMiLCJ1c2VSb3V0ZXIiLCJsb2NhbGUiLCJtYWluQ2hlY2tSZWYiLCJ1c2VSZWYiLCJjaGVja1JlZnMiLCJjdXJyZW50IiwidGFiUmVmcyIsInN1Ym1pdCIsImRhdGEiLCJjb25zb2xlIiwibG9nIiwiYXhpb3MiLCJwb3N0IiwicHJvY2VzcyIsInByb21vY29kZSIsImhlYWRlcnMiLCJhdXRob3JpemF0aW9uIiwidXNlciIsImFjY2Vzc1Rva2VuIiwidGhlbiIsInJlcyIsImJhdGNoZXMiLCJlcnIiLCJtZXNzYWdlIiwicmVzcG9uc2UiLCJlcnJvciIsIlByb21pc0FsbCIsImdldCIsImJhdGNoZXNEYXRhIiwic3RhdHVzRGF0YSIsInVzZUxheW91dEVmZmVjdCIsImFkZFRhYlJlZnMiLCJyZWYiLCJpbmNsdWRlcyIsInB1c2giLCJ0b2dnbGVUYWJSZWZzIiwiZXYiLCJmb3JFYWNoIiwieCIsImNsYXNzTGlzdCIsInJlbW92ZSIsInRhcmdldCIsImFkZCIsImdldEJhdGNoZXNCeVN0YXRhdXNJZCIsImlkIiwidGFiQnV0dG9uQ2xpY2siLCJnZXRBdHRyaWJ1dGUiLCJuZXdQYWNrYWdlcyIsImZpbHRlciIsImFkZENoZWNrUmVmcyIsImNoZWNrSGFuZGxlciIsInZhbHVlIiwiY2hlY2tlZCIsInByaWNlIiwiZGF0YURpc2NvdW50IiwiZGlzYyIsInBhcnNlRmxvYXQiLCJzb21lIiwic2VsZWN0QWxsIiwiZSIsInAiLCJQYXlieUNhcmQiLCJ1cmwiLCJ3aW5kb3ciLCJsb2NhdGlvbiIsImhyZWYiLCJQYXlieUJhbGFuY2UiLCJiYWxhbmNlIiwiUGF5QnlCYWxhbmNlQWN0aW9uIiwic291cmNldHlwZSIsIlN3YWwiLCJmaXJlIiwidGV4dCIsImljb24iLCJjb25maXJtQnV0dG9uVGV4dCIsIm92ZXJmbG93WCIsImRpc3BsYXkiLCJtYXJnaW5Cb3R0b20iLCJ3aWR0aCIsImxlbmd0aCIsIm1hcCIsIm5hbWUiLCJjb3VudCIsImp1c3RpZnlDb250ZW50IiwiZmxleERpcmVjdGlvbiIsInRleHREZWNvcmF0aW9uQ29sb3IiLCJ0b0ZpeGVkIiwiaGVpZ2h0IiwicmVxdWlyZWQiLCJ0ZXh0RGVjb3JhdGlvbkxpbmUiLCJjb2xvciIsInBhZGRpbmciLCJ0cmFja19udW1iZXIiLCJzaG9wIiwiY2F0ZWdvcnkiLCJjdXJyZW5jeSIsIndlaWdodCIsImRlbGl2ZXJ5X3ByaWNlIiwiZGF0ZSIsImkiLCJtYXBTdGF0ZVRvUHJvcHMiLCJzdGF0ZSIsIm1hcERpc3BhdGNoVG9Qcm9wcyIsImNvbm5lY3QiLCJtZW1vIiwiTG9naW4iLCJkaXNwYXRjaCIsImxvZ2luIiwicm91dGVyIiwiaXNFcnJvciIsIlVzZXJSZWdpc3RlciIsImlzQ29uZmlybWVkIiwiTG9nT3V0IiwibG9nb3V0IiwiVXBkYXRlVXNlciIsInB1dCIsInVwZGF0ZVVzZXIiLCJQYXlCeUJhbGFuY2UiLCJJbmNyZWFzZUJhbGFuY2VBY3Rpb24iLCJJbmNyZWFzZUJhbGFuY2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFNBQVNBLFFBQVQsQ0FBa0JDLEtBQWxCLEVBQXlCO0FBQUE7O0FBQUE7QUFBQTs7QUFDdkIsTUFBSSxDQUFDQSxLQUFLLENBQUNDLEtBQU4sQ0FBWUMsT0FBakIsRUFBMEI7QUFDeEIsd0JBQU8scUVBQUMsc0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUFQO0FBQ0Q7O0FBSHNCLGlCQUs4QkMsK0RBQU8sRUFMckM7QUFBQSxNQUtmQyxRQUxlLFlBS2ZBLFFBTGU7QUFBQSxNQUtMQyxZQUxLLFlBS0xBLFlBTEs7QUFBQSxNQUtTQyxNQUxULFlBS1NBLE1BTFQ7QUFBQSxNQUtpQkMsUUFMakIsWUFLaUJBLFFBTGpCOztBQUFBLGlCQU1NQywwREFBTyxFQU5iO0FBQUEsTUFNQUMsQ0FOQSxZQU1mQyxhQU5lOztBQUFBLGtCQU9TQyxzREFBUSxDQUFDLEVBQUQsQ0FQakI7QUFBQSxNQU9oQkMsUUFQZ0I7QUFBQSxNQU9OQyxXQVBNOztBQUFBLG1CQVFtQkYsc0RBQVEsQ0FBQyxFQUFELENBUjNCO0FBQUEsTUFRaEJHLGFBUmdCO0FBQUEsTUFRREMsZ0JBUkM7O0FBQUEsbUJBU0tKLHNEQUFRLENBQUMsRUFBRCxDQVRiO0FBQUEsTUFTaEJLLE1BVGdCO0FBQUEsTUFTUkMsU0FUUTs7QUFBQSxtQkFVeUJOLHNEQUFRLENBQUM7QUFDdkRDLFlBQVEsRUFBRSxFQUQ2QztBQUV2RE0sU0FBSyxFQUFFLENBRmdEO0FBR3ZEQyxpQkFBYSxFQUFDLENBSHlDO0FBSXZEQyxRQUFJLEVBQUUsRUFKaUQ7QUFLdkRDLGNBQVUsRUFBRSxLQUwyQztBQU12REwsVUFBTSxFQUFFO0FBTitDLEdBQUQsQ0FWakM7QUFBQSxNQVVoQk0sZ0JBVmdCO0FBQUEsTUFVRUMsbUJBVkY7O0FBQUEsbUJBbUJKQyw2REFBUyxFQW5CTDtBQUFBLE1BbUJmQyxNQW5CZSxjQW1CZkEsTUFuQmU7O0FBb0J2QixNQUFNQyxZQUFZLEdBQUdDLG9EQUFNLEVBQTNCO0FBQ0EsTUFBTUMsU0FBUyxHQUFHRCxvREFBTSxDQUFDLEVBQUQsQ0FBeEI7QUFDQUMsV0FBUyxDQUFDQyxPQUFWLEdBQW9CLEVBQXBCO0FBQ0EsTUFBTUMsT0FBTyxHQUFHSCxvREFBTSxDQUFDLEVBQUQsQ0FBdEI7QUFDQUcsU0FBTyxDQUFDRCxPQUFSLEdBQWtCLEVBQWxCOztBQUVBLE1BQU1FLE1BQU0sR0FBRyxTQUFUQSxNQUFTLENBQUNDLElBQUQsRUFBVTtBQUN2QkMsV0FBTyxDQUFDQyxHQUFSLENBQVlGLElBQVo7QUFFQUcsZ0RBQUssQ0FDRkMsSUFESCxXQUVPQyw2QkFGUCxpQ0FFNkRMLElBQUksQ0FBQ00sU0FGbEUscUJBRXNGaEIsZ0JBQWdCLENBQUNOLE1BRnZHLEdBR0ksRUFISixFQUlJO0FBQ0V1QixhQUFPLEVBQUU7QUFDUCx3QkFBZ0Isa0JBRFQ7QUFFUEMscUJBQWEsbUJBQVl4QyxLQUFLLENBQUNDLEtBQU4sQ0FBWXdDLElBQVosQ0FBaUJDLFdBQTdCO0FBRk47QUFEWCxLQUpKLEVBV0dDLElBWEgsQ0FXUSxVQUFDQyxHQUFELEVBQVM7QUFDYlgsYUFBTyxDQUFDQyxHQUFSLENBQVlVLEdBQUcsQ0FBQ1osSUFBSixDQUFTYSxPQUFyQjtBQUNBaEMsaUJBQVcsQ0FBQytCLEdBQUcsQ0FBQ1osSUFBSixDQUFTYSxPQUFWLENBQVg7QUFDQTlCLHNCQUFnQixDQUFDNkIsR0FBRyxDQUFDWixJQUFKLENBQVNhLE9BQVYsQ0FBaEI7QUFDRCxLQWZILFdBZ0JTLFVBQUNDLEdBQUQsRUFBUztBQUNkdkMsY0FBUSxDQUFDLFdBQUQsRUFBYztBQUFFd0MsZUFBTyxFQUFFRCxHQUFHLENBQUNFLFFBQUosQ0FBYWhCLElBQWIsQ0FBa0JpQjtBQUE3QixPQUFkLENBQVI7QUFDRCxLQWxCSDtBQW1CRCxHQXRCRDs7QUF3QkEsTUFBTUMsU0FBUztBQUFBLGtVQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQ1FmLDRDQUFLLENBQUNnQixHQUFOLFdBQWFkLDZCQUFiLHlCQUEyRFosTUFBM0QsR0FBcUU7QUFDM0ZjLHVCQUFPLEVBQUU7QUFDUEMsK0JBQWEsbUJBQVl4QyxLQUFLLENBQUNDLEtBQU4sQ0FBWXdDLElBQVosQ0FBaUJDLFdBQTdCO0FBRE47QUFEa0YsZUFBckUsQ0FEUjs7QUFBQTtBQUNaVSx5QkFEWTtBQUFBO0FBQUEscUJBTU9qQiw0Q0FBSyxDQUFDZ0IsR0FBTixXQUFhZCw2QkFBYix3QkFBMERaLE1BQTFELEdBQW9FO0FBQ3pGYyx1QkFBTyxFQUFFO0FBQ1BDLCtCQUFhLG1CQUFZeEMsS0FBSyxDQUFDQyxLQUFOLENBQVl3QyxJQUFaLENBQWlCQyxXQUE3QjtBQUROO0FBRGdGLGVBQXBFLENBTlA7O0FBQUE7QUFNWlcsd0JBTlk7QUFBQSwrQ0FZVDtBQUNMRCwyQkFBVyxFQUFDQSxXQUFXLENBQUNwQixJQURuQjtBQUVMcUIsMEJBQVUsRUFBQ0EsVUFBVSxDQUFDckI7QUFGakIsZUFaUzs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFIOztBQUFBLG9CQUFUa0IsU0FBUztBQUFBO0FBQUE7QUFBQSxLQUFmOztBQWlCQUksK0RBQWUsQ0FBQyxZQUFNO0FBQ3BCSixhQUFTLEdBQUdQLElBQVosQ0FBaUIsVUFBQUMsR0FBRyxFQUFJO0FBQ3RCL0IsaUJBQVcsQ0FBQytCLEdBQUcsQ0FBQ1EsV0FBTCxDQUFYO0FBQ0FyQyxzQkFBZ0IsQ0FBQzZCLEdBQUcsQ0FBQ1EsV0FBTCxDQUFoQjtBQUNBbkMsZUFBUyxDQUFDMkIsR0FBRyxDQUFDUyxVQUFMLENBQVQ7QUFDRCxLQUpELFdBSVMsVUFBQVAsR0FBRztBQUFBLGFBQUliLE9BQU8sQ0FBQ0MsR0FBUixDQUFZWSxHQUFaLENBQUo7QUFBQSxLQUpaO0FBTUQsR0FQYyxFQU9aLEVBUFksQ0FBZjs7QUFTQSxNQUFNUyxVQUFVLEdBQUcsU0FBYkEsVUFBYSxDQUFDQyxHQUFELEVBQVM7QUFDMUIsUUFBSUEsR0FBRyxJQUFJLENBQUMxQixPQUFPLENBQUNELE9BQVIsQ0FBZ0I0QixRQUFoQixDQUF5QkQsR0FBekIsQ0FBWixFQUEyQztBQUN6QzFCLGFBQU8sQ0FBQ0QsT0FBUixDQUFnQjZCLElBQWhCLENBQXFCRixHQUFyQjtBQUNEO0FBQ0YsR0FKRDs7QUFNQSxNQUFNRyxhQUFhO0FBQUEsbVVBQUcsa0JBQU9DLEVBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNwQjlCLHFCQUFPLENBQUNELE9BQVIsQ0FBZ0JnQyxPQUFoQixDQUF3QixVQUFDQyxDQUFEO0FBQUEsdUJBQU9BLENBQUMsQ0FBQ0MsU0FBRixDQUFZQyxNQUFaLENBQW1CLGFBQW5CLENBQVA7QUFBQSxlQUF4QjtBQUNBSixnQkFBRSxDQUFDSyxNQUFILENBQVVGLFNBQVYsQ0FBb0JHLEdBQXBCLENBQXdCLGFBQXhCOztBQUZvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFIOztBQUFBLG9CQUFiUCxhQUFhO0FBQUE7QUFBQTtBQUFBLEtBQW5COztBQUtBLE1BQU1RLHFCQUFxQjtBQUFBLG1VQUFHLGtCQUFPQyxFQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDM0JqQywwREFBSyxDQUFDZ0IsR0FBTixXQUFhZCw2QkFBYiw0QkFBOEQrQixFQUE5RCxrQkFBd0UzQyxNQUF4RSxHQUFrRjtBQUNqRmMsdUJBQU8sRUFBRTtBQUNQQywrQkFBYSxtQkFBWXhDLEtBQUssQ0FBQ0MsS0FBTixDQUFZd0MsSUFBWixDQUFpQkMsV0FBN0I7QUFETjtBQUR3RSxlQUFsRixFQUlFQyxJQUpGLENBSU8sVUFBQ0MsR0FBRCxFQUFTO0FBQ2YvQiwyQkFBVyxDQUFDK0IsR0FBRyxDQUFDWixJQUFMLENBQVg7QUFDQWpCLGdDQUFnQixDQUFDNkIsR0FBRyxDQUFDWixJQUFMLENBQWhCO0FBQ0QsZUFQQSxXQU9RLFVBQUFjLEdBQUc7QUFBQSx1QkFBSWIsT0FBTyxDQUFDQyxHQUFSLENBQVlZLEdBQVosQ0FBSjtBQUFBLGVBUFg7O0FBRDJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQUg7O0FBQUEsb0JBQXJCcUIscUJBQXFCO0FBQUE7QUFBQTtBQUFBLEtBQTNCOztBQWFBLE1BQU1FLGNBQWMsR0FBRyxTQUFqQkEsY0FBaUIsQ0FBQ1QsRUFBRCxFQUFRO0FBQzdCLFFBQUlRLEVBQUUsR0FBR1IsRUFBRSxDQUFDSyxNQUFILENBQVVLLFlBQVYsQ0FBdUIsU0FBdkIsQ0FBVDtBQUNBWCxpQkFBYSxDQUFDQyxFQUFELENBQWI7QUFDQU8seUJBQXFCLENBQUNDLEVBQUQsQ0FBckI7O0FBQ0EsUUFBSUEsRUFBRSxJQUFJLENBQVYsRUFBYTtBQUNYLFVBQUlHLFdBQVcsR0FBRzNELFFBQVEsQ0FBQzRELE1BQVQsQ0FBZ0IsVUFBQ1YsQ0FBRDtBQUFBLGVBQU9BLENBQUMsQ0FBQzlDLE1BQUYsQ0FBU29ELEVBQVQsSUFBZUEsRUFBdEI7QUFBQSxPQUFoQixDQUFsQjtBQUNBckQsc0JBQWdCLENBQUMsOEpBQUl3RCxXQUFMLEVBQWhCO0FBQ0QsS0FIRCxNQUdPO0FBQ0x4RCxzQkFBZ0IsQ0FBQyw4SkFBSUgsUUFBTCxFQUFoQjtBQUNEOztBQUVEVyx1QkFBbUIsQ0FBQztBQUNsQkosbUJBQWEsRUFBRSxDQURHO0FBRWxCUCxjQUFRLEVBQUUsRUFGUTtBQUdsQk0sV0FBSyxFQUFFLENBSFc7QUFJbEJFLFVBQUksRUFBRSxFQUpZO0FBS2xCQyxnQkFBVSxFQUFFLEtBTE07QUFNbEJMLFlBQU0sRUFBRW9EO0FBTlUsS0FBRCxDQUFuQjtBQVFELEdBbkJEOztBQXFCQSxNQUFNSyxZQUFZLEdBQUcsU0FBZkEsWUFBZSxDQUFDakIsR0FBRCxFQUFTO0FBQzVCLFFBQUlBLEdBQUcsSUFBSSxDQUFDNUIsU0FBUyxDQUFDQyxPQUFWLENBQWtCNEIsUUFBbEIsQ0FBMkJELEdBQTNCLENBQVosRUFBNkM7QUFDM0M1QixlQUFTLENBQUNDLE9BQVYsQ0FBa0I2QixJQUFsQixDQUF1QkYsR0FBdkI7QUFDRDtBQUNGLEdBSkQ7O0FBTUEsTUFBTWtCLFlBQVksR0FBRyxTQUFmQSxZQUFlLENBQUNkLEVBQUQsRUFBUTtBQUFBLHFCQUNGQSxFQUFFLENBQUNLLE1BREQ7QUFBQSxRQUNyQlUsS0FEcUIsY0FDckJBLEtBRHFCO0FBQUEsUUFDZEMsT0FEYyxjQUNkQSxPQURjO0FBRTNCLFFBQUlDLEtBQUssR0FBR2pCLEVBQUUsQ0FBQ0ssTUFBSCxDQUFVSyxZQUFWLENBQXVCLFlBQXZCLENBQVo7QUFDQSxRQUFJUSxZQUFZLEdBQUdsQixFQUFFLENBQUNLLE1BQUgsQ0FBVUssWUFBVixDQUF1QixlQUF2QixDQUFuQjtBQUNBLFFBQUlwRCxLQUFLLEdBQUMsQ0FBVjtBQUNBLFFBQUk2RCxJQUFJLEdBQUMsQ0FBVDtBQUNBOUMsV0FBTyxDQUFDQyxHQUFSLENBQVksS0FBWixFQUFrQjRDLFlBQWxCOztBQUNBLFFBQUlGLE9BQUosRUFBYTtBQUNYdEQsc0JBQWdCLENBQUNWLFFBQWpCLENBQTBCOEMsSUFBMUIsQ0FBK0JpQixLQUEvQjs7QUFDQSxVQUFHRyxZQUFZLElBQUUsQ0FBakIsRUFBbUI7QUFDakJ2RCwyQkFBbUIsaUNBQ2RELGdCQURjO0FBR2pCSixlQUFLLEVBQUdJLGdCQUFnQixDQUFDSixLQUFqQixHQUF1QjhELFVBQVUsQ0FBQ0gsS0FBRCxDQUh4QjtBQUtqQjFELHVCQUFhLEVBQUdHLGdCQUFnQixDQUFDSCxhQUFqQixHQUErQjZELFVBQVUsQ0FBQ0YsWUFBRCxDQUx4QztBQU1qQmxFLGtCQUFRLEVBQUUsOEpBQUlVLGdCQUFnQixDQUFDVixRQUF2QjtBQU5TLFdBQW5CO0FBU0QsT0FWRCxNQVVLO0FBQ0hXLDJCQUFtQixpQ0FDZEQsZ0JBRGM7QUFFakJILHVCQUFhLEVBQUdHLGdCQUFnQixDQUFDSCxhQUFqQixHQUErQjZELFVBQVUsQ0FBQ0gsS0FBRCxDQUZ4QztBQUdqQjNELGVBQUssRUFBR0ksZ0JBQWdCLENBQUNKLEtBQWpCLEdBQXVCOEQsVUFBVSxDQUFDSCxLQUFELENBSHhCO0FBSWpCakUsa0JBQVEsRUFBRSw4SkFBSVUsZ0JBQWdCLENBQUNWLFFBQXZCO0FBSlMsV0FBbkI7QUFNRDtBQUVGLEtBckJELE1BcUJPO0FBQ0wsVUFBSTJELFdBQVcsR0FBR2pELGdCQUFnQixDQUFDVixRQUFqQixDQUEwQjRELE1BQTFCLENBQWlDLFVBQUNWLENBQUQ7QUFBQSxlQUFPQSxDQUFDLEtBQUthLEtBQWI7QUFBQSxPQUFqQyxDQUFsQjs7QUFDQSxVQUFHRyxZQUFZLElBQUUsQ0FBakIsRUFBbUI7QUFDakJ2RCwyQkFBbUIsaUNBRWRELGdCQUZjO0FBSWpCSixlQUFLLEVBQUVJLGdCQUFnQixDQUFDSixLQUFqQixJQUF5QixDQUF6QixJQUErQkksZ0JBQWdCLENBQUNKLEtBQWpCLEdBQXVCOEQsVUFBVSxDQUFDSCxLQUFELENBSnREO0FBTWpCMUQsdUJBQWEsRUFBRUcsZ0JBQWdCLENBQUNILGFBQWpCLElBQWlDLENBQWpDLElBQXdDRyxnQkFBZ0IsQ0FBQ0gsYUFBakIsR0FBK0I2RCxVQUFVLENBQUNGLFlBQUQsQ0FOL0U7QUFPakJsRSxrQkFBUSxFQUFFMkQ7QUFQTyxXQUFuQjtBQVVELE9BWEQsTUFXSztBQUNIaEQsMkJBQW1CLGlDQUNkRCxnQkFEYztBQUVqQkgsdUJBQWEsRUFBQ0csZ0JBQWdCLENBQUNILGFBQWpCLElBQWlDLENBQWpDLElBQXVDRyxnQkFBZ0IsQ0FBQ0gsYUFBakIsR0FBK0I2RCxVQUFVLENBQUNILEtBQUQsQ0FGN0U7QUFHakIzRCxlQUFLLEVBQUNJLGdCQUFnQixDQUFDSixLQUFqQixJQUF5QixDQUF6QixJQUErQkksZ0JBQWdCLENBQUNKLEtBQWpCLEdBQXVCOEQsVUFBVSxDQUFDSCxLQUFELENBSHJEO0FBSWpCakUsa0JBQVEsRUFBQzJEO0FBSlEsV0FBbkI7QUFNRDtBQUVGOztBQUNELEtBQUNqRCxnQkFBZ0IsQ0FBQ1YsUUFBakIsQ0FBMEJxRSxJQUExQixDQUErQixVQUFDbkIsQ0FBRDtBQUFBLGFBQU9BLENBQVA7QUFBQSxLQUEvQixDQUFELEdBQ0twQyxZQUFZLENBQUNHLE9BQWIsQ0FBcUIrQyxPQUFyQixHQUErQixLQURwQyxHQUVJLElBRko7QUFHRCxHQXRERDs7QUF3REEsTUFBTU0sU0FBUyxHQUFHLFNBQVpBLFNBQVksQ0FBQ0MsQ0FBRCxFQUFPO0FBQ3ZCLFFBQUlqRSxLQUFLLEdBQUcsQ0FBWjtBQUNBLFFBQUlDLGFBQWEsR0FBRyxDQUFwQjtBQUNBLFFBQUlQLFFBQVEsR0FBRyxFQUFmO0FBQ0FnQixhQUFTLENBQUNDLE9BQVYsQ0FBa0JnQyxPQUFsQixDQUEwQixVQUFDQyxDQUFELEVBQU87QUFDL0JBLE9BQUMsQ0FBQ2MsT0FBRixHQUFZTyxDQUFDLENBQUNsQixNQUFGLENBQVNXLE9BQXJCOztBQUVBLFVBQUlPLENBQUMsQ0FBQ2xCLE1BQUYsQ0FBU1csT0FBVCxJQUFvQixDQUFDaEUsUUFBUSxDQUFDNkMsUUFBVCxDQUFrQkssQ0FBQyxDQUFDYSxLQUFwQixDQUF6QixFQUFxRDtBQUNuRC9ELGdCQUFRLENBQUM4QyxJQUFULENBQWNJLENBQUMsQ0FBQ2EsS0FBaEI7QUFDQXpELGFBQUssSUFBSSxDQUFDNEMsQ0FBQyxDQUFDUSxZQUFGLENBQWUsWUFBZixDQUFWO0FBQ0FuRCxxQkFBYSxJQUFJLENBQUMyQyxDQUFDLENBQUNRLFlBQUYsQ0FBZSxlQUFmLENBQWxCO0FBQ0QsT0FKRCxNQUlPO0FBQ0wxRCxnQkFBUSxHQUFHQSxRQUFRLENBQUM0RCxNQUFULENBQWdCLFVBQUNZLENBQUQ7QUFBQSxpQkFBT0EsQ0FBQyxLQUFLdEIsQ0FBQyxDQUFDYSxLQUFmO0FBQUEsU0FBaEIsQ0FBWDtBQUNBekQsYUFBSyxJQUFJQSxLQUFLLElBQUksQ0FBVCxJQUFjLENBQUM0QyxDQUFDLENBQUNRLFlBQUYsQ0FBZSxZQUFmLENBQXhCO0FBQ0FuRCxxQkFBYSxJQUFJQSxhQUFhLElBQUcsQ0FBaEIsSUFBcUIsQ0FBQzJDLENBQUMsQ0FBQ1EsWUFBRixDQUFlLGVBQWYsQ0FBdkM7QUFDRDtBQUNGLEtBWkQ7QUFjQS9DLHVCQUFtQixpQ0FDZEQsZ0JBRGM7QUFFakJKLFdBQUssRUFBRUksZ0JBQWdCLENBQUNKLEtBQWpCLEdBQXVCQSxLQUZiO0FBR2pCTixjQUFRLEVBQUVBO0FBSE8sT0FBbkI7QUFLRCxHQXZCRDs7QUF5QkEsTUFBTXlFLFNBQVMsR0FBRyxTQUFaQSxTQUFZLEdBQWU7QUFBQSxRQUFkckQsSUFBYyx1RUFBUCxFQUFPO0FBQy9CRyxnREFBSyxDQUFDQyxJQUFOLFdBQWNDLDZCQUFkLGNBQXVETCxJQUF2RCxFQUE0RDtBQUMxRE8sYUFBTyxFQUFDO0FBQ05DLHFCQUFhLG1CQUFZeEMsS0FBSyxDQUFDQyxLQUFOLENBQVl3QyxJQUFaLENBQWlCQyxXQUE3QjtBQURQO0FBRGtELEtBQTVELEVBSUdDLElBSkgsQ0FJUSxVQUFBQyxHQUFHLEVBQUk7QUFDYlgsYUFBTyxDQUFDQyxHQUFSLENBQVksS0FBWixFQUFrQlUsR0FBRyxDQUFDWixJQUFKLENBQVNzRCxHQUEzQjtBQUNDQyxZQUFNLENBQUNDLFFBQVAsQ0FBZ0JDLElBQWhCLEdBQXVCN0MsR0FBRyxDQUFDWixJQUFKLENBQVNzRCxHQUFoQztBQUNGLEtBUEQsV0FPUyxVQUFBeEMsR0FBRztBQUFBLGFBQUliLE9BQU8sQ0FBQ0MsR0FBUixDQUFZWSxHQUFaLENBQUo7QUFBQSxLQVBaO0FBUUQsR0FURDs7QUFXQSxNQUFNNEMsWUFBWSxHQUFHLFNBQWZBLFlBQWUsR0FBTTtBQUN6QixRQUFHMUYsS0FBSyxDQUFDQyxLQUFOLENBQVl3QyxJQUFaLENBQWlCQSxJQUFqQixDQUFzQmtELE9BQXRCLElBQWlDLENBQXBDLEVBQXNDO0FBQ3BDM0YsV0FBSyxDQUFDNEYsa0JBQU4sQ0FBeUIsU0FBekIsRUFBbUM7QUFDakNmLGFBQUssRUFBQ3ZELGdCQUFnQixDQUFDSCxhQURVO0FBRWpDMEUsa0JBQVUsRUFBQyxDQUZzQjtBQUdqQ2hELGVBQU8sRUFBQ3ZCLGdCQUFnQixDQUFDVjtBQUhRLE9BQW5DLEVBS0E7QUFDRSwwQ0FBMEJaLEtBQUssQ0FBQ0MsS0FBTixDQUFZd0MsSUFBWixDQUFpQkMsV0FBM0M7QUFERixPQUxBO0FBUUQsS0FURCxNQVNLO0FBQ0hvRCxVQUFJLENBQUNDLElBQUwsQ0FBVTtBQUNSQyxZQUFJLEVBQUUsc0NBREU7QUFFUkMsWUFBSSxFQUFFLE1BRkU7QUFHUkMseUJBQWlCLEVBQUU7QUFIWCxPQUFWO0FBS0Q7QUFFRixHQWxCRDs7QUFvQkEsc0JBQ0UscUVBQUMsOERBQUQ7QUFBTSxhQUFTLEVBQUMsbUJBQWhCO0FBQUEsNEJBQ0UscUVBQUMsZ0VBQUQ7QUFBTyxlQUFTLEVBQUMsT0FBakI7QUFBQSw2QkFDRSxxRUFBQyxxRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGLGVBSUUscUVBQUMsOERBQUQ7QUFBTSxlQUFTLEVBQUMsYUFBaEI7QUFBQSw4QkFDRSxxRUFBQyw4REFBRDtBQUFNLGlCQUFTLEVBQUMseUJBQWhCO0FBQUEsZ0NBQ0UscUVBQUMsOERBQUQsQ0FBTSxNQUFOO0FBQ0UsY0FBSSxFQUFFekYsQ0FBQyxDQUFDO0FBQUUyRCxjQUFFLEVBQUU7QUFBTixXQUFELENBRFQ7QUFFRSxxQkFBVyxlQUNULHFFQUFDLHNFQUFEO0FBQ0UsZ0JBQUksRUFBRTNELENBQUMsQ0FBQztBQUFFMkQsZ0JBQUUsRUFBRTtBQUFOLGFBQUQsQ0FEVDtBQUVFLGVBQUcsRUFBRSxhQUFDWixHQUFEO0FBQUEscUJBQVU5QixZQUFZLENBQUNHLE9BQWIsR0FBdUIyQixHQUFqQztBQUFBLGFBRlA7QUFHRSxtQkFBTyxFQUFFMEIsU0FIWDtBQUlFLHFCQUFTLEVBQUM7QUFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQVlFO0FBQUssbUJBQU0sS0FBWDtBQUFpQixlQUFLLEVBQUU7QUFBRWlCLHFCQUFTLEVBQUU7QUFBYixXQUF4QjtBQUFBLGlDQUNFO0FBQ0UscUJBQVMsRUFBQyxVQURaO0FBRUUsaUJBQUssRUFBRTtBQUNMQyxxQkFBTyxFQUFFLE1BREo7QUFFTEMsMEJBQVksRUFBRSxNQUZUO0FBR0xDLG1CQUFLLEVBQUU7QUFIRixhQUZUO0FBQUEsb0NBU0UscUVBQUMsMkRBQUQ7QUFDRSxtQkFBSyx3QkFBWTFGLFFBQVEsQ0FBQzJGLE1BQXJCLE1BRFA7QUFFRSx1QkFBUyxFQUFDLDhCQUZaO0FBR0UseUJBQVMsQ0FIWDtBQUlFLGlCQUFHLEVBQUVoRCxVQUpQO0FBS0UscUJBQU8sRUFBRWM7QUFMWDtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVRGLEVBaUJJckQsTUFBTSxDQUFDd0YsR0FBUCxDQUFXLFVBQUMxQyxDQUFEO0FBQUEsa0NBQ1gscUVBQUMsMkRBQUQ7QUFDRSxxQkFBSyxZQUFLQSxDQUFDLENBQUMyQyxJQUFQLGVBQWdCM0MsQ0FBQyxDQUFDNEMsS0FBbEIsTUFEUDtBQUVFLHlCQUFTLEVBQUMsY0FGWjtBQUdFLDJCQUFTNUMsQ0FBQyxDQUFDTSxFQUhiO0FBSUUsbUJBQUcsRUFBRWIsVUFKUDtBQUtFLHVCQUFPLEVBQUVjO0FBTFg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFEVztBQUFBLGFBQVgsQ0FqQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFaRixlQTJDRSxxRUFBQyw4REFBRCxDQUFNLElBQU47QUFBVyxtQkFBUyxFQUFDLFFBQXJCO0FBQUEsaUNBQ0U7QUFBSyxxQkFBUyxFQUFDLGNBQWY7QUFBQSxzQkFDR3ZELGFBQWEsQ0FDWDBELE1BREYsQ0FDUyxVQUFDVixDQUFEO0FBQUEscUJBQU9BLENBQUMsQ0FBQzlDLE1BQUYsQ0FBU29ELEVBQVQsS0FBZ0IsQ0FBdkI7QUFBQSxhQURULEVBRUVvQyxHQUZGLENBRU0sVUFBQ3BCLENBQUQ7QUFBQSxrQ0FDSCxxRUFBQyw4RUFBRDtBQUVFLHdCQUFRLEVBQUVYLFlBRlo7QUFHRSxvQkFBSSxFQUFFVyxDQUhSO0FBSUUsdUJBQU8sRUFBRVY7QUFKWCxpQkFDT1UsQ0FBQyxDQUFDaEIsRUFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURHO0FBQUEsYUFGTjtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQTNDRixlQXlERTtBQUFLLG1CQUFTLEVBQUMsYUFBZjtBQUFBLGtDQUNFO0FBQUsscUJBQVMsRUFBQyxlQUFmO0FBQUEsb0NBQ0U7QUFBQSx5QkFDRzlDLGdCQUFnQixDQUFDVixRQUFqQixDQUEwQjJGLE1BRDdCLE9BQ3NDOUYsQ0FBQyxDQUFDO0FBQUUyRCxrQkFBRSxFQUFFO0FBQU4sZUFBRCxDQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBREYsZUFJRTtBQUFLLG1CQUFLLEVBQUU7QUFBRWdDLHVCQUFPLEVBQUUsTUFBWDtBQUFtQk8sOEJBQWMsRUFBRTtBQUFuQyxlQUFaO0FBQUEsc0NBQ0U7QUFBQSwyQkFBSWxHLENBQUMsQ0FBQztBQUFFMkQsb0JBQUUsRUFBRTtBQUFOLGlCQUFELENBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQURGLGVBRUU7QUFBSyxxQkFBSyxFQUFFO0FBQUVnQyx5QkFBTyxFQUFFLE1BQVg7QUFBbUJRLCtCQUFhLEVBQUU7QUFBbEMsaUJBQVo7QUFBQSwwQkFFRXRGLGdCQUFnQixDQUFDSCxhQUFqQixHQUFpQyxDQUFqQyxnQkFDQTtBQUFBLDBDQUNBO0FBQUsseUJBQUssRUFBRTtBQUFFMEYseUNBQW1CLEVBQUU7QUFBdkIscUJBQVo7QUFBQSwrQkFBNkM3QixVQUFVLENBQUMxRCxnQkFBZ0IsQ0FBQ0osS0FBbEIsQ0FBVixDQUFtQzRGLE9BQW5DLENBQTJDLENBQTNDLENBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFEQSxlQUVDO0FBQUEsK0JBQUk5QixVQUFVLENBQUMxRCxnQkFBZ0IsQ0FBQ0gsYUFBbEIsQ0FBVixDQUEyQzJGLE9BQTNDLENBQW1ELENBQW5ELENBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUZEO0FBQUEsZ0NBREEsZ0JBS0k7QUFBQSw2QkFBSTlCLFVBQVUsQ0FBQzFELGdCQUFnQixDQUFDSCxhQUFsQixDQUFWLENBQTJDMkYsT0FBM0MsQ0FBbUQsQ0FBbkQsQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFQTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREYsZUFxQkU7QUFBSyxxQkFBUyxFQUFDLGVBQWY7QUFBQSxvQ0FDRTtBQUFBLHFDQUNFLHFFQUFDLDBFQUFEO0FBQ0UseUJBQVMsRUFBQyxnQkFEWjtBQUVFLHlCQUFTLEVBQUU7QUFBRUMsd0JBQU0sRUFBRSxNQUFWO0FBQWtCVCx1QkFBSyxFQUFFO0FBQXpCLGlCQUZiO0FBR0UseUJBQVMsRUFBQyx1QkFIWjtBQUlFLHFCQUFLLEVBQUU7QUFBRUQsOEJBQVksRUFBRTtBQUFoQixpQkFKVDtBQUtFLHFCQUFLLHVCQUFFL0YsTUFBTSxDQUFDZ0MsU0FBVCxzREFBRSxrQkFBa0JTLE9BTDNCO0FBQUEsd0NBT0UscUVBQUMsZ0VBQUQ7QUFDRSw2QkFBVyxFQUFFdEMsQ0FBQyxDQUFDO0FBQUUyRCxzQkFBRSxFQUFFO0FBQU4sbUJBQUQsQ0FEaEI7QUFFRSxzQkFBSSxFQUFDLFdBRlA7QUFHRSxxQkFBRyxFQUFFaEUsUUFBUSxDQUFDO0FBQ1o0Ryw0QkFBUSxFQUFFO0FBQ1JyQywyQkFBSyxFQUFFLElBREM7QUFFUjVCLDZCQUFPLEVBQUV0QyxDQUFDLENBQUM7QUFBRTJELDBCQUFFLEVBQUU7QUFBTix1QkFBRDtBQUZGO0FBREUsbUJBQUQsQ0FIZjtBQVNFLDBCQUFRLEVBQUUsa0JBQUNlLENBQUQ7QUFBQSwyQkFDUjVELG1CQUFtQixpQ0FDZEQsZ0JBRGM7QUFFakJGLDBCQUFJLEVBQUUrRCxDQUFDLENBQUNsQixNQUFGLENBQVNVO0FBRkUsdUJBRFg7QUFBQTtBQVRaO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBUEYsRUF1QkdyRCxnQkFBZ0IsQ0FBQ0QsVUFBakIsZ0JBQ0MscUVBQUMsMkRBQUQ7QUFDRSwyQkFBUyxFQUFDLGVBRFo7QUFFRSx1QkFBSyxFQUFFO0FBQ0w0RixzQ0FBa0IsRUFBRSxXQURmO0FBRUxDLHlCQUFLLEVBQUUsVUFGRjtBQUdMQywyQkFBTyxFQUFFO0FBSEosbUJBRlQ7QUFPRSx1QkFBSyxFQUFDLG1CQVBSO0FBUUUseUJBQU8sRUFBRSxtQkFBTTtBQUNiNUYsdUNBQW1CLGlDQUNkRCxnQkFEYztBQUVqQkQsZ0NBQVUsRUFBRTtBQUZLLHVCQUFuQjtBQUlEO0FBYkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFERCxnQkFpQkMscUVBQUMsMkRBQUQ7QUFDRSwwQkFBUSxFQUFFLENBQUNDLGdCQUFnQixDQUFDRixJQUFsQixHQUF5QixJQUF6QixHQUFnQyxLQUQ1QztBQUVFLHVCQUFLLEVBQUU7QUFBRStGLDJCQUFPLEVBQUU7QUFBWCxtQkFGVDtBQUdFLDJCQUFTLEVBQUMsd0JBSFo7QUFJRSx1QkFBSyxFQUFFMUcsQ0FBQyxDQUFDO0FBQUUyRCxzQkFBRSxFQUFFO0FBQU4sbUJBQUQsQ0FKVjtBQUtFLHNCQUFJLEVBQUMsUUFMUDtBQU1FLHlCQUFPLEVBQUUvRCxZQUFZLENBQUMwQixNQUFELENBTnZCLENBT0U7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBeENKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBREYsZUE0REUscUVBQUMsMkRBQUQ7QUFDRSxtQkFBSyxFQUFFO0FBQUVvRix1QkFBTyxFQUFFO0FBQVgsZUFEVDtBQUVFLHVCQUFTLEVBQUMsbUNBRlo7QUFHRSxtQkFBSyxFQUFFMUcsQ0FBQyxDQUFDO0FBQUUyRCxrQkFBRSxFQUFFO0FBQU4sZUFBRCxDQUhWO0FBSUUsd0JBQVUsZUFBRTtBQUFNLHlCQUFTLEVBQUMsbUJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUpkO0FBS0UscUJBQU8sRUFBSTtBQUFBLHVCQUFNaUIsU0FBUyxDQUFDO0FBQ3pCUix1QkFBSyxFQUFDdkQsZ0JBQWdCLENBQUNILGFBREU7QUFFekIwRSw0QkFBVSxFQUFDLENBRmM7QUFHekJoRCx5QkFBTyxFQUFDdkIsZ0JBQWdCLENBQUNWO0FBSEEsaUJBQUQsQ0FBZjtBQUFBO0FBTGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkE1REYsZUF1RUUscUVBQUMsMkRBQUQ7QUFDRSxtQkFBSyxFQUFFO0FBQUV1Ryx1QkFBTyxFQUFFO0FBQVgsZUFEVDtBQUVFLHVCQUFTLEVBQUMsTUFGWjtBQUdFLG1CQUFLLEVBQUUxRyxDQUFDLENBQUM7QUFBRTJELGtCQUFFLEVBQUU7QUFBTixlQUFELENBSFY7QUFJRSx3QkFBVSxlQUNSO0FBQU0seUJBQVMsRUFBQywwQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBTEo7QUFPRSxxQkFBTyxFQUFJc0I7QUFQYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQXZFRixlQWlGRTtBQUFLLHVCQUFTLEVBQUMsVUFBZjtBQUFBLHNDQUNFLHFFQUFDLDJEQUFEO0FBQ0UscUJBQUssRUFBRTtBQUFFeUIseUJBQU8sRUFBRTtBQUFYLGlCQURUO0FBRUUseUJBQVMsRUFBQyw4QkFGWjtBQUdFLHFCQUFLLEVBQUUxRyxDQUFDLENBQUM7QUFBRTJELG9CQUFFLEVBQUU7QUFBTixpQkFBRCxDQUhWO0FBSUUsMEJBQVUsZUFDUjtBQUFNLDJCQUFTLEVBQUMsbUJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUxKO0FBT0UsdUJBQU8sRUFBSTtBQUFBLHlCQUFNaUIsU0FBUyxDQUFDO0FBQ3pCUix5QkFBSyxFQUFDdkQsZ0JBQWdCLENBQUNILGFBREU7QUFFekIwRSw4QkFBVSxFQUFDLENBRmM7QUFHekJoRCwyQkFBTyxFQUFDdkIsZ0JBQWdCLENBQUNWO0FBSEEsbUJBQUQsQ0FBZjtBQUFBO0FBUGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFERixlQWNFLHFFQUFDLDJEQUFEO0FBQ0UscUJBQUssRUFBRTtBQUFFdUcseUJBQU8sRUFBRTtBQUFYLGlCQURUO0FBRUUscUJBQUssRUFBRTFHLENBQUMsQ0FBQztBQUFFMkQsb0JBQUUsRUFBRTtBQUFOLGlCQUFELENBRlY7QUFHRSwwQkFBVSxlQUNSO0FBQU0sMkJBQVMsRUFBQyx5QkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBSko7QUFNRSx1QkFBTyxFQUFJc0I7QUFOYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFqRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBekRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBMkxFLHFFQUFDLDhEQUFEO0FBQU0saUJBQVMsRUFBQyxlQUFoQjtBQUFBLGdDQUNFLHFFQUFDLDhEQUFELENBQU0sTUFBTjtBQUFhLGNBQUksRUFBRWpGLENBQUMsQ0FBQztBQUFFMkQsY0FBRSxFQUFFO0FBQU4sV0FBRDtBQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBRUUscUVBQUMsOERBQUQsQ0FBTSxJQUFOO0FBQVcsbUJBQVMsRUFBQywwQkFBckI7QUFBQSxpQ0FDRSxxRUFBQyxnRUFBRDtBQUNFLGNBQUUsRUFBRSxDQUNGM0QsQ0FBQyxDQUFDO0FBQUUyRCxnQkFBRSxFQUFFO0FBQU4sYUFBRCxDQURDLEVBRUYzRCxDQUFDLENBQUM7QUFBRTJELGdCQUFFLEVBQUU7QUFBTixhQUFELENBRkMsRUFHRjNELENBQUMsQ0FBQztBQUFFMkQsZ0JBQUUsRUFBRTtBQUFOLGFBQUQsQ0FIQyxFQUlGM0QsQ0FBQyxDQUFDO0FBQUUyRCxnQkFBRSxFQUFFO0FBQU4sYUFBRCxDQUpDLEVBS0YzRCxDQUFDLENBQUM7QUFBRTJELGdCQUFFLEVBQUU7QUFBTixhQUFELENBTEMsRUFNRjNELENBQUMsQ0FBQztBQUFFMkQsZ0JBQUUsRUFBRTtBQUFOLGFBQUQsQ0FOQyxFQU9GM0QsQ0FBQyxDQUFDO0FBQUUyRCxnQkFBRSxFQUFFO0FBQU4sYUFBRCxDQVBDLENBRE47QUFVRSxnQkFBSSxFQUNGeEQsUUFBUSxDQUFDNEYsR0FBVCxDQUFhLFVBQUMxQyxDQUFELEVBQU87QUFDbEIsa0JBQUlBLENBQUMsQ0FBQzlDLE1BQUYsQ0FBU29ELEVBQVQsSUFBZSxDQUFuQixFQUFzQjtBQUNwQix1QkFBTztBQUNMZ0QsOEJBQVksRUFBRXRELENBQUMsQ0FBQ3NELFlBRFg7QUFFTEMsc0JBQUksRUFBRXZELENBQUMsQ0FBQ3VELElBRkg7QUFHTEMsMEJBQVEsRUFBRXhELENBQUMsQ0FBQ3dELFFBSFA7QUFJTHpDLHVCQUFLLFlBQUtmLENBQUMsQ0FBQ2UsS0FBUCxjQUFnQmYsQ0FBQyxDQUFDeUQsUUFBbEIsQ0FKQTtBQUtMQyx3QkFBTSxZQUFLeEMsVUFBVSxDQUFDbEIsQ0FBQyxDQUFDMEQsTUFBSCxDQUFWLENBQXFCVixPQUFyQixDQUE2QixDQUE3QixLQUFtQyxDQUF4QyxRQUxEO0FBTUxXLGdDQUFjLEVBQ1p6QyxVQUFVLENBQUNsQixDQUFDLENBQUMyRCxjQUFILENBQVYsQ0FBNkJYLE9BQTdCLENBQXFDLENBQXJDLEtBQTJDLENBUHhDO0FBUUw5Rix3QkFBTSxZQUFLOEMsQ0FBQyxDQUFDOUMsTUFBRixDQUFTeUYsSUFBZCxnQkFBd0IzQyxDQUFDLENBQUM0RCxJQUExQjtBQVJELGlCQUFQO0FBVUQ7QUFDRixhQWJELEtBYU0sRUF4QlY7QUEwQkUsc0JBQVUsRUFBRSxvQkFBQzVELENBQUQsRUFBSTZELENBQUosRUFBVTtBQUNwQixrQ0FBTztBQUFBLDBCQUFlN0Q7QUFBZixpQkFBUzZELENBQUMsRUFBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFQO0FBQ0Q7QUE1Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBM0xGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBc09EOztHQXJkUTVILFE7VUFLOENJLHVELEVBQ3hCSyxrRCxFQWFWZ0IscUQ7OztLQW5CWnpCLFE7O0FBdWRULElBQU02SCxlQUFlLEdBQUcsU0FBbEJBLGVBQWtCLENBQUNDLEtBQUQ7QUFBQSxTQUFZO0FBQ2xDNUgsU0FBSyxFQUFFNEgsS0FBSyxDQUFDNUg7QUFEcUIsR0FBWjtBQUFBLENBQXhCOztBQUdBLElBQU02SCxrQkFBa0IsR0FBSTtBQUMxQmxDLG9CQUFrQixFQUFsQkEsNkVBQWtCQTtBQURRLENBQTVCO0FBSWVtQywySEFBTyxDQUFDSCxlQUFELEVBQWtCRSxrQkFBbEIsQ0FBUCxlQUE2Q0Usa0RBQUksQ0FBQ2pJLFFBQUQsQ0FBakQsQ0FBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqZkE7QUFDQTtBQUNBO0FBQ0E7QUFFTyxJQUFNa0ksS0FBSyxHQUFHLFNBQVJBLEtBQVEsQ0FBQzNDLEdBQUQsRUFBS3RELElBQUw7QUFBQSxNQUFVTyxPQUFWLHVFQUFvQixFQUFwQjtBQUFBLFNBQTJCLFVBQUEyRixRQUFRLEVBQUk7QUFDeEQvRixnREFBSyxDQUFDQyxJQUFOLFdBQWNDLDZCQUFkLFNBQWdEaUQsR0FBaEQsR0FBc0R0RCxJQUF0RCxFQUEyRDtBQUN2RE8sYUFBTyxFQUFDQTtBQUQrQyxLQUEzRCxFQUdHSSxJQUhIO0FBQUEsb1VBR1EsaUJBQU1DLEdBQU47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFDYUEsR0FBRyxDQUFDWixJQURqQjs7QUFBQTtBQUNBQSxvQkFEQTtBQUVKa0csd0JBQVEsQ0FBQ0Msc0RBQUssQ0FBQ25HLElBQUQsQ0FBTixDQUFSO0FBQ0FvRyxrRUFBTSxDQUFDMUUsSUFBUCxDQUFZLFdBQVo7O0FBSEk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FIUjs7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFPVyxVQUFBcEQsTUFBTSxFQUFJO0FBQ2pCNEgsY0FBUSxDQUFDQyxzREFBSyxDQUFDO0FBQUNFLGVBQU8sRUFBQyxJQUFUO0FBQWMvSCxjQUFNLEVBQUNBLE1BQU0sQ0FBQzBDLFFBQVAsQ0FBZ0JoQjtBQUFyQyxPQUFELENBQU4sQ0FBUjtBQUNELEtBVEg7QUFVSCxHQVhvQjtBQUFBLENBQWQ7QUFjQSxJQUFNc0csWUFBWSxHQUFHLFNBQWZBLFlBQWUsQ0FBQ2hELEdBQUQsRUFBS3RELElBQUw7QUFBQSxNQUFVTyxPQUFWLHVFQUFvQixFQUFwQjtBQUFBLFNBQTJCLFVBQUEyRixRQUFRLEVBQUk7QUFDakUvRixnREFBSyxDQUFDQyxJQUFOLFdBQWNDLDZCQUFkLFNBQWdEaUQsR0FBaEQsR0FBc0R0RCxJQUF0RCxFQUEyRDtBQUN2RE8sYUFBTyxFQUFDQTtBQUQrQyxLQUEzRCxFQUdHSSxJQUhIO0FBQUEscVVBR1Esa0JBQU1DLEdBQU47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0prRCxrRUFBSSxDQUFDQyxJQUFMLENBQVU7QUFDUkMsc0JBQUksRUFBRSw2QkFERTtBQUVSQyxzQkFBSSxFQUFFLFNBRkU7QUFHUkMsbUNBQWlCLEVBQUU7QUFIWCxpQkFBVixFQUlHdkQsSUFKSCxDQUlRLFVBQUFDLEdBQUcsRUFBSTtBQUNiLHNCQUFHQSxHQUFHLENBQUMyRixXQUFQLEVBQW1CO0FBQ2pCSCxzRUFBTSxDQUFDMUUsSUFBUCxDQUFZLGNBQVo7QUFDRDtBQUNGLGlCQVJEO0FBREk7QUFBQSx1QkFVYWQsR0FBRyxDQUFDWixJQVZqQjs7QUFBQTtBQVVBQSxvQkFWQTtBQVdKa0csd0JBQVEsQ0FBQzlILHlEQUFRLENBQUM0QixJQUFELENBQVQsQ0FBUjs7QUFYSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUhSOztBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQWVXLFVBQUFjLEdBQUcsRUFBSTtBQUNkb0YsY0FBUSxDQUFDOUgseURBQVEsQ0FBQztBQUFDaUksZUFBTyxFQUFDLElBQVQ7QUFBYy9ILGNBQU0sRUFBQ3dDLEdBQUcsQ0FBQ0UsUUFBSixDQUFhaEI7QUFBbEMsT0FBRCxDQUFULENBQVI7QUFDRCxLQWpCSDtBQWtCRCxHQW5CMkI7QUFBQSxDQUFyQjtBQXFCQSxJQUFNd0csTUFBTSxHQUFHLFNBQVRBLE1BQVM7QUFBQSxTQUFNLFVBQUFOLFFBQVEsRUFBSTtBQUNwQ0EsWUFBUSxDQUFDTyx1REFBTSxFQUFQLENBQVI7QUFDSCxHQUZxQjtBQUFBLENBQWY7QUFJQSxJQUFNQyxVQUFVLEdBQUcsU0FBYkEsVUFBYSxDQUFDcEQsR0FBRCxFQUFLdEQsSUFBTDtBQUFBLE1BQVVPLE9BQVYsdUVBQW9CLEVBQXBCO0FBQUEsU0FBMkIsVUFBQTJGLFFBQVEsRUFBSTtBQUU3RC9GLGdEQUFLLENBQUN3RyxHQUFOLFdBQWF0Ryw2QkFBYixTQUErQ2lELEdBQS9DLEdBQXFEdEQsSUFBckQsRUFBMEQ7QUFDdERPLGFBQU8sRUFBRUE7QUFENkMsS0FBMUQsRUFHR0ksSUFISCxDQUdTLFVBQUFDLEdBQUcsRUFBSTtBQUNac0YsY0FBUSxDQUFDVSwyREFBVSxDQUFDaEcsR0FBRyxDQUFDWixJQUFMLENBQVgsQ0FBUjtBQUNDOEQsd0RBQUksQ0FBQ0MsSUFBTCxDQUFVO0FBQ1JDLFlBQUksRUFBRSxtQ0FERTtBQUVSQyxZQUFJLEVBQUUsU0FGRTtBQUdSQyx5QkFBaUIsRUFBRTtBQUhYLE9BQVY7QUFLRixLQVZILFdBV1MsVUFBQXBELEdBQUcsRUFBSTtBQUNab0YsY0FBUSxDQUFDVSwyREFBVSxDQUFDO0FBQUNQLGVBQU8sRUFBQyxJQUFUO0FBQWMvSCxjQUFNLEVBQUN3QyxHQUFHLENBQUNFLFFBQUosQ0FBYWhCO0FBQWxDLE9BQUQsQ0FBWCxDQUFSO0FBQ0QsS0FiSDtBQWVILEdBakJ5QjtBQUFBLENBQW5CO0FBbUJFLElBQU00RCxrQkFBa0IsR0FBRyxTQUFyQkEsa0JBQXFCLENBQUNOLEdBQUQsRUFBS3RELElBQUwsRUFBVU8sT0FBVjtBQUFBLFNBQXNCLFVBQUEyRixRQUFRLEVBQUk7QUFDbEUvRixnREFBSyxDQUFDQyxJQUFOLFdBQWNDLDZCQUFkLFNBQWdEaUQsR0FBaEQsR0FBc0R0RCxJQUF0RCxFQUEyRDtBQUN6RE8sYUFBTyxFQUFDQTtBQURpRCxLQUEzRCxFQUVHSSxJQUZILENBRVEsVUFBQUMsR0FBRyxFQUFJO0FBQ2JYLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQVosRUFBa0JVLEdBQUcsQ0FBQ1osSUFBSixDQUFTMkQsT0FBM0I7QUFDRUcsd0RBQUksQ0FBQ0MsSUFBTCxDQUFVO0FBQ1JDLFlBQUksRUFBRXBELEdBQUcsQ0FBQ1osSUFBSixDQUFTZSxPQURQO0FBRVJrRCxZQUFJLEVBQUUsU0FGRTtBQUdSQyx5QkFBaUIsRUFBRTtBQUhYLE9BQVY7QUFLQWdDLGNBQVEsQ0FBQ1csNkRBQVksQ0FBQ2pHLEdBQUcsQ0FBQ1osSUFBSixDQUFTMkQsT0FBVixDQUFiLENBQVI7QUFDQXlDLHdEQUFNLENBQUMxRSxJQUFQLDRCQUFnQ2QsR0FBRyxDQUFDWixJQUFKLENBQVNlLE9BQXpDO0FBQ0gsS0FYRCxXQVdTLFVBQUFELEdBQUc7QUFBQSxhQUFJYixPQUFPLENBQUNDLEdBQVIsQ0FBWVksR0FBWixDQUFKO0FBQUEsS0FYWjtBQVlELEdBYmlDO0FBQUEsQ0FBM0I7QUFlRixJQUFNZ0cscUJBQXFCLEdBQUcsU0FBeEJBLHFCQUF3QixDQUFDbkQsT0FBRDtBQUFBLFNBQWEsVUFBQXVDLFFBQVEsRUFBSTtBQUMxREEsWUFBUSxDQUFDYSxnRUFBZSxDQUFDcEQsT0FBRCxDQUFoQixDQUFSO0FBQ0gsR0FGb0M7QUFBQSxDQUE5QiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9wYWNrYWdlcy42MGU2MDE4OGJjYTVlZWZhZGZiMC5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IFJlYWN0LCB7IG1lbW8sIHVzZUxheW91dEVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VGb3JtIH0gZnJvbSBcInJlYWN0LWhvb2stZm9ybVwiO1xyXG5pbXBvcnQgeyB1c2VJbnRsIH0gZnJvbSBcInJlYWN0LWludGxcIjtcclxuaW1wb3J0IHsgY29ubmVjdCB9IGZyb20gXCJyZWFjdC1yZWR1eFwiO1xyXG5pbXBvcnQgQXNpZGVNZW51IGZyb20gXCIuLi9jb21wb25lbnRzL2FzaWRlLW1lbnUvaW5kZXhcIjtcclxuaW1wb3J0IEFzaWRlIGZyb20gXCIuLi9jb21wb25lbnRzL2FzaWRlL2FzaWRlXCI7XHJcbmltcG9ydCBCdXR0b25Db21wb25lbnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvYnV0dG9uXCI7XHJcbmltcG9ydCBDYXJkIGZyb20gXCIuLi9jb21wb25lbnRzL2NhcmQvY2FyZFwiO1xyXG5pbXBvcnQgQ2hlY2tib3ggZnJvbSBcIi4uL2NvbXBvbmVudHMvY2hlY2tib3gvY2hlY2tib3hcIjtcclxuaW1wb3J0IEZyb21Hcm91cCBmcm9tIFwiLi4vY29tcG9uZW50cy9mb3JtLWdyb3VwL2Zvcm0tZ3JvdXBcIjtcclxuaW1wb3J0IElucHV0IGZyb20gXCIuLi9jb21wb25lbnRzL2lucHV0L2lucHV0XCI7XHJcbmltcG9ydCBNYWluIGZyb20gXCIuLi9jb21wb25lbnRzL21haW4vbWFpblwiO1xyXG5pbXBvcnQgUGFja2FnZUl0ZW0gZnJvbSBcIi4uL2NvbXBvbmVudHMvcGFja2FnZV9pdGVtL3BhY2thZ2UtaXRlbVwiO1xyXG5pbXBvcnQgUGFnZSBmcm9tIFwiLi4vY29tcG9uZW50cy9wYWdlL3BhZ2VcIjtcclxuaW1wb3J0IFJlZGlyZWN0IGZyb20gXCIuLi9jb21wb25lbnRzL3JlZGlyZWN0L3JlZGlyZWN0XCI7XHJcbmltcG9ydCBUYWJlbCBmcm9tIFwiLi4vY29tcG9uZW50cy90YWJlbC90YWJlbFwiO1xyXG5pbXBvcnQgeyBQYXlCeUJhbGFuY2VBY3Rpb24gfSBmcm9tICcuLi9yZWR1eC9lbnRyeS9lbnRyeUFjdGlvbnMnO1xyXG5cclxuZnVuY3Rpb24gUGFja2FnZXMocHJvcHMpIHtcclxuICBpZiAoIXByb3BzLmVudHJ5LmlzTG9nZWQpIHtcclxuICAgIHJldHVybiA8UmVkaXJlY3QgLz47XHJcbiAgfVxyXG5cclxuICBjb25zdCB7IHJlZ2lzdGVyLCBoYW5kbGVTdWJtaXQsIGVycm9ycywgc2V0RXJyb3IgfSA9IHVzZUZvcm0oKTtcclxuICBjb25zdCB7IGZvcm1hdE1lc3NhZ2U6IGYgfSA9IHVzZUludGwoKTtcclxuICBjb25zdCBbcGFja2FnZXMsIHNldFBhY2thZ2VzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZmlsdGVyZWRQYWNrcywgc2V0RmlsdGVyZWRQYWNrc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3N0YXR1cywgc2V0U3RhdHVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VsZWN0ZWRQYWNrYWdlcywgc2V0U2VsZWN0ZWRQYWNrYWdlc10gPSB1c2VTdGF0ZSh7XHJcbiAgICBwYWNrYWdlczogW10sXHJcbiAgICB0b3RhbDogMCxcclxuICAgIGRpc2NvdW50VG90YWw6MCxcclxuICAgIGNvZGU6IFwiXCIsXHJcbiAgICBpc0FjY2VwdGVkOiBmYWxzZSxcclxuICAgIHN0YXR1czogMCxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgeyBsb2NhbGUgfSA9IHVzZVJvdXRlcigpO1xyXG4gIGNvbnN0IG1haW5DaGVja1JlZiA9IHVzZVJlZigpO1xyXG4gIGNvbnN0IGNoZWNrUmVmcyA9IHVzZVJlZihbXSk7XHJcbiAgY2hlY2tSZWZzLmN1cnJlbnQgPSBbXTtcclxuICBjb25zdCB0YWJSZWZzID0gdXNlUmVmKFtdKTtcclxuICB0YWJSZWZzLmN1cnJlbnQgPSBbXTtcclxuXHJcbiAgY29uc3Qgc3VibWl0ID0gKGRhdGEpID0+IHtcclxuICAgIGNvbnNvbGUubG9nKGRhdGEpO1xyXG5cclxuICAgIGF4aW9zXHJcbiAgICAgIC5wb3N0KFxyXG4gICAgICAgIGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9cHJvbW9jb2RlP3Byb21vY29kZT0ke2RhdGEucHJvbW9jb2RlfSZzdGF0dXM9JHtzZWxlY3RlZFBhY2thZ2VzLnN0YXR1c31gLFxyXG4gICAgICAgIHt9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgXCJjb250ZW50LXR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbiAgICAgICAgICAgIGF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtwcm9wcy5lbnRyeS51c2VyLmFjY2Vzc1Rva2VufWAsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gICAgICAudGhlbigocmVzKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2cocmVzLmRhdGEuYmF0Y2hlcyk7XHJcbiAgICAgICAgc2V0UGFja2FnZXMocmVzLmRhdGEuYmF0Y2hlcyk7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRQYWNrcyhyZXMuZGF0YS5iYXRjaGVzKTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnIpID0+IHtcclxuICAgICAgICBzZXRFcnJvcihcInByb21vY29kZVwiLCB7IG1lc3NhZ2U6IGVyci5yZXNwb25zZS5kYXRhLmVycm9yIH0pO1xyXG4gICAgICB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBQcm9taXNBbGwgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBsZXQgYmF0Y2hlc0RhdGEgPSBhd2FpdCBheGlvcy5nZXQoYCR7cHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQVBJX1VSTH1iYXRjaGVzP2xhbj0ke2xvY2FsZX1gLCB7XHJcbiAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICBhdXRob3JpemF0aW9uOiBgQmVhcmVyICR7cHJvcHMuZW50cnkudXNlci5hY2Nlc3NUb2tlbn1gLFxyXG4gICAgICB9LFxyXG4gICAgfSk7XHJcbiAgICBsZXQgc3RhdHVzRGF0YSA9IGF3YWl0IGF4aW9zLmdldChgJHtwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19BUElfVVJMfXN0YXR1cz9sYW49JHtsb2NhbGV9YCwge1xyXG4gICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgYXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Byb3BzLmVudHJ5LnVzZXIuYWNjZXNzVG9rZW59YCxcclxuICAgICAgfSxcclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIGJhdGNoZXNEYXRhOmJhdGNoZXNEYXRhLmRhdGEsXHJcbiAgICAgIHN0YXR1c0RhdGE6c3RhdHVzRGF0YS5kYXRhXHJcbiAgICB9XHJcbiAgfVxyXG4gIHVzZUxheW91dEVmZmVjdCgoKSA9PiB7XHJcbiAgICBQcm9taXNBbGwoKS50aGVuKHJlcyA9PiB7XHJcbiAgICAgIHNldFBhY2thZ2VzKHJlcy5iYXRjaGVzRGF0YSk7XHJcbiAgICAgIHNldEZpbHRlcmVkUGFja3MocmVzLmJhdGNoZXNEYXRhKTtcclxuICAgICAgc2V0U3RhdHVzKHJlcy5zdGF0dXNEYXRhKTtcclxuICAgIH0pLmNhdGNoKGVyciA9PiBjb25zb2xlLmxvZyhlcnIpKVxyXG5cclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IGFkZFRhYlJlZnMgPSAocmVmKSA9PiB7XHJcbiAgICBpZiAocmVmICYmICF0YWJSZWZzLmN1cnJlbnQuaW5jbHVkZXMocmVmKSkge1xyXG4gICAgICB0YWJSZWZzLmN1cnJlbnQucHVzaChyZWYpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHRvZ2dsZVRhYlJlZnMgPSBhc3luYyAoZXYpID0+IHtcclxuICAgIHRhYlJlZnMuY3VycmVudC5mb3JFYWNoKCh4KSA9PiB4LmNsYXNzTGlzdC5yZW1vdmUoXCJwYWNrLWFjdGl2ZVwiKSk7XHJcbiAgICBldi50YXJnZXQuY2xhc3NMaXN0LmFkZChcInBhY2stYWN0aXZlXCIpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdldEJhdGNoZXNCeVN0YXRhdXNJZCA9IGFzeW5jIChpZCkgPT57XHJcbiAgICAgYXhpb3MuZ2V0KGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9YmF0Y2hlcz9zdGF0dXM9JHtpZH0mbGFuPSR7bG9jYWxlfWAsIHtcclxuICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgIGF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtwcm9wcy5lbnRyeS51c2VyLmFjY2Vzc1Rva2VufWAsXHJcbiAgICAgIH0sXHJcbiAgICB9KS50aGVuKChyZXMpID0+IHtcclxuICAgICAgc2V0UGFja2FnZXMocmVzLmRhdGEpO1xyXG4gICAgICBzZXRGaWx0ZXJlZFBhY2tzKHJlcy5kYXRhKTtcclxuICAgIH0pLmNhdGNoKGVyciA9PiBjb25zb2xlLmxvZyhlcnIpKVxyXG5cclxuICBcclxuICB9O1xyXG5cclxuICBjb25zdCB0YWJCdXR0b25DbGljayA9IChldikgPT4ge1xyXG4gICAgbGV0IGlkID0gZXYudGFyZ2V0LmdldEF0dHJpYnV0ZShcImRhdGEtaWRcIik7XHJcbiAgICB0b2dnbGVUYWJSZWZzKGV2KTtcclxuICAgIGdldEJhdGNoZXNCeVN0YXRhdXNJZChpZClcclxuICAgIGlmIChpZCAhPSAwKSB7XHJcbiAgICAgIGxldCBuZXdQYWNrYWdlcyA9IHBhY2thZ2VzLmZpbHRlcigoeCkgPT4geC5zdGF0dXMuaWQgPT0gaWQpO1xyXG4gICAgICBzZXRGaWx0ZXJlZFBhY2tzKFsuLi5uZXdQYWNrYWdlc10pO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0RmlsdGVyZWRQYWNrcyhbLi4ucGFja2FnZXNdKTtcclxuICAgIH1cclxuXHJcbiAgICBzZXRTZWxlY3RlZFBhY2thZ2VzKHtcclxuICAgICAgZGlzY291bnRUb3RhbDogMCxcclxuICAgICAgcGFja2FnZXM6IFtdLFxyXG4gICAgICB0b3RhbDogMCxcclxuICAgICAgY29kZTogXCJcIixcclxuICAgICAgaXNBY2NlcHRlZDogZmFsc2UsXHJcbiAgICAgIHN0YXR1czogaWQsXHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBhZGRDaGVja1JlZnMgPSAocmVmKSA9PiB7XHJcbiAgICBpZiAocmVmICYmICFjaGVja1JlZnMuY3VycmVudC5pbmNsdWRlcyhyZWYpKSB7XHJcbiAgICAgIGNoZWNrUmVmcy5jdXJyZW50LnB1c2gocmVmKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBjaGVja0hhbmRsZXIgPSAoZXYpID0+IHtcclxuICAgIGxldCB7IHZhbHVlLCBjaGVja2VkIH0gPSBldi50YXJnZXQ7XHJcbiAgICBsZXQgcHJpY2UgPSBldi50YXJnZXQuZ2V0QXR0cmlidXRlKFwiZGF0YS1wcmljZVwiKTtcclxuICAgIGxldCBkYXRhRGlzY291bnQgPSBldi50YXJnZXQuZ2V0QXR0cmlidXRlKFwiZGF0YS1kaXNjb3VudFwiKTtcclxuICAgIGxldCB0b3RhbD0wXHJcbiAgICBsZXQgZGlzYz0wXHJcbiAgICBjb25zb2xlLmxvZygnZGlzJyxkYXRhRGlzY291bnQpXHJcbiAgICBpZiAoY2hlY2tlZCkge1xyXG4gICAgICBzZWxlY3RlZFBhY2thZ2VzLnBhY2thZ2VzLnB1c2godmFsdWUpO1xyXG4gICAgICBpZihkYXRhRGlzY291bnQhPTApe1xyXG4gICAgICAgIHNldFNlbGVjdGVkUGFja2FnZXMoe1xyXG4gICAgICAgICAgLi4uc2VsZWN0ZWRQYWNrYWdlcyxcclxuXHJcbiAgICAgICAgICB0b3RhbDogKHNlbGVjdGVkUGFja2FnZXMudG90YWwrcGFyc2VGbG9hdChwcmljZSkpLFxyXG4gICAgICAgICBcclxuICAgICAgICAgIGRpc2NvdW50VG90YWw6IChzZWxlY3RlZFBhY2thZ2VzLmRpc2NvdW50VG90YWwrcGFyc2VGbG9hdChkYXRhRGlzY291bnQpKSxcclxuICAgICAgICAgIHBhY2thZ2VzOiBbLi4uc2VsZWN0ZWRQYWNrYWdlcy5wYWNrYWdlc10sXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIFxyXG4gICAgICB9ZWxzZXtcclxuICAgICAgICBzZXRTZWxlY3RlZFBhY2thZ2VzKHtcclxuICAgICAgICAgIC4uLnNlbGVjdGVkUGFja2FnZXMsXHJcbiAgICAgICAgICBkaXNjb3VudFRvdGFsOiAoc2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsK3BhcnNlRmxvYXQocHJpY2UpKSxcclxuICAgICAgICAgIHRvdGFsOiAoc2VsZWN0ZWRQYWNrYWdlcy50b3RhbCtwYXJzZUZsb2F0KHByaWNlKSksXHJcbiAgICAgICAgICBwYWNrYWdlczogWy4uLnNlbGVjdGVkUGFja2FnZXMucGFja2FnZXNdLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICAgXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBsZXQgbmV3UGFja2FnZXMgPSBzZWxlY3RlZFBhY2thZ2VzLnBhY2thZ2VzLmZpbHRlcigoeCkgPT4geCAhPT0gdmFsdWUpO1xyXG4gICAgICBpZihkYXRhRGlzY291bnQhPTApe1xyXG4gICAgICAgIHNldFNlbGVjdGVkUGFja2FnZXMoe1xyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAuLi5zZWxlY3RlZFBhY2thZ2VzLFxyXG5cclxuICAgICAgICAgIHRvdGFsOiBzZWxlY3RlZFBhY2thZ2VzLnRvdGFsID49MCAmJiAoc2VsZWN0ZWRQYWNrYWdlcy50b3RhbC1wYXJzZUZsb2F0KHByaWNlKSksXHJcbiAgICAgICAgIFxyXG4gICAgICAgICAgZGlzY291bnRUb3RhbDogc2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsID49MCAmJiAgKHNlbGVjdGVkUGFja2FnZXMuZGlzY291bnRUb3RhbC1wYXJzZUZsb2F0KGRhdGFEaXNjb3VudCkpLFxyXG4gICAgICAgICAgcGFja2FnZXM6IG5ld1BhY2thZ2VzXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIFxyXG4gICAgICB9ZWxzZXtcclxuICAgICAgICBzZXRTZWxlY3RlZFBhY2thZ2VzKHtcclxuICAgICAgICAgIC4uLnNlbGVjdGVkUGFja2FnZXMsXHJcbiAgICAgICAgICBkaXNjb3VudFRvdGFsOnNlbGVjdGVkUGFja2FnZXMuZGlzY291bnRUb3RhbCA+PTAgJiYgKHNlbGVjdGVkUGFja2FnZXMuZGlzY291bnRUb3RhbC1wYXJzZUZsb2F0KHByaWNlKSksXHJcbiAgICAgICAgICB0b3RhbDpzZWxlY3RlZFBhY2thZ2VzLnRvdGFsID49MCAmJiAoc2VsZWN0ZWRQYWNrYWdlcy50b3RhbC1wYXJzZUZsb2F0KHByaWNlKSksXHJcbiAgICAgICAgICBwYWNrYWdlczpuZXdQYWNrYWdlc1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICAgXHJcbiAgICB9XHJcbiAgICAhc2VsZWN0ZWRQYWNrYWdlcy5wYWNrYWdlcy5zb21lKCh4KSA9PiB4KVxyXG4gICAgICA/IChtYWluQ2hlY2tSZWYuY3VycmVudC5jaGVja2VkID0gZmFsc2UpXHJcbiAgICAgIDogbnVsbDtcclxuICB9O1xyXG5cclxuICBjb25zdCBzZWxlY3RBbGwgPSAoZSkgPT4ge1xyXG4gICAgbGV0IHRvdGFsID0gMDtcclxuICAgIGxldCBkaXNjb3VudFRvdGFsID0gMDtcclxuICAgIGxldCBwYWNrYWdlcyA9IFtdO1xyXG4gICAgY2hlY2tSZWZzLmN1cnJlbnQuZm9yRWFjaCgoeCkgPT4ge1xyXG4gICAgICB4LmNoZWNrZWQgPSBlLnRhcmdldC5jaGVja2VkO1xyXG5cclxuICAgICAgaWYgKGUudGFyZ2V0LmNoZWNrZWQgJiYgIXBhY2thZ2VzLmluY2x1ZGVzKHgudmFsdWUpKSB7XHJcbiAgICAgICAgcGFja2FnZXMucHVzaCh4LnZhbHVlKTtcclxuICAgICAgICB0b3RhbCArPSAreC5nZXRBdHRyaWJ1dGUoXCJkYXRhLXByaWNlXCIpO1xyXG4gICAgICAgIGRpc2NvdW50VG90YWwgKz0gK3guZ2V0QXR0cmlidXRlKFwiZGF0YS1kaXNjb3VudFwiKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBwYWNrYWdlcyA9IHBhY2thZ2VzLmZpbHRlcigocCkgPT4gcCAhPT0geC52YWx1ZSk7XHJcbiAgICAgICAgdG90YWwgLT0gdG90YWwgPj0gMCAmJiAreC5nZXRBdHRyaWJ1dGUoXCJkYXRhLXByaWNlXCIpO1xyXG4gICAgICAgIGRpc2NvdW50VG90YWwgLT0gZGlzY291bnRUb3RhbCA+PTAgJiYgK3guZ2V0QXR0cmlidXRlKFwiZGF0YS1kaXNjb3VudFwiKTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgc2V0U2VsZWN0ZWRQYWNrYWdlcyh7XHJcbiAgICAgIC4uLnNlbGVjdGVkUGFja2FnZXMsXHJcbiAgICAgIHRvdGFsOiBzZWxlY3RlZFBhY2thZ2VzLnRvdGFsLXRvdGFsLFxyXG4gICAgICBwYWNrYWdlczogcGFja2FnZXMsXHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBQYXlieUNhcmQgPSAoZGF0YSA9IHt9KSA9PiB7XHJcbiAgICBheGlvcy5wb3N0KGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9cGF5bWVudGAsZGF0YSx7XHJcbiAgICAgIGhlYWRlcnM6e1xyXG4gICAgICAgIGF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtwcm9wcy5lbnRyeS51c2VyLmFjY2Vzc1Rva2VufWAsXHJcbiAgICAgIH1cclxuICAgIH0pLnRoZW4ocmVzID0+IHtcclxuICAgICAgY29uc29sZS5sb2coJ3JlZCcscmVzLmRhdGEudXJsKTtcclxuICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gcmVzLmRhdGEudXJsO1xyXG4gICAgfSkuY2F0Y2goZXJyID0+IGNvbnNvbGUubG9nKGVycikpXHJcbiAgfVxyXG5cclxuICBjb25zdCBQYXlieUJhbGFuY2UgPSAoKSA9PiB7XHJcbiAgICBpZihwcm9wcy5lbnRyeS51c2VyLnVzZXIuYmFsYW5jZSA+PSAwKXtcclxuICAgICAgcHJvcHMuUGF5QnlCYWxhbmNlQWN0aW9uKCdwYXltZW50Jyx7XHJcbiAgICAgICAgcHJpY2U6c2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsLFxyXG4gICAgICAgIHNvdXJjZXR5cGU6MyxcclxuICAgICAgICBiYXRjaGVzOnNlbGVjdGVkUGFja2FnZXMucGFja2FnZXMgICAgICAgICAgICAgICAgICBcclxuICAgICAgfSxcclxuICAgICAge1xyXG4gICAgICAgICdhdXRob3JpemF0aW9uJzpgQmVhcmVyICR7cHJvcHMuZW50cnkudXNlci5hY2Nlc3NUb2tlbn1gXHJcbiAgICAgIH0pXHJcbiAgICB9ZWxzZXtcclxuICAgICAgU3dhbC5maXJlKHtcclxuICAgICAgICB0ZXh0OiAnQmFsYW5zZGEga2lmYXnJmXQgccmZZMmZciBtyZlibMmZxJ8geW94ZHVyJyxcclxuICAgICAgICBpY29uOiAnaW5mbycsXHJcbiAgICAgICAgY29uZmlybUJ1dHRvblRleHQ6ICdPSycsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICB9XHJcbiBcclxuICByZXR1cm4gKFxyXG4gICAgPFBhZ2UgY2xhc3NOYW1lPVwiYmctYmcgcHQtbGcgcGItbGdcIj5cclxuICAgICAgPEFzaWRlIGNsYXNzTmFtZT1cIm1yLXNtXCI+XHJcbiAgICAgICAgPEFzaWRlTWVudSAvPlxyXG4gICAgICA8L0FzaWRlPlxyXG4gICAgICA8TWFpbiBjbGFzc05hbWU9XCJiZy1jIHAtbm9uZVwiPlxyXG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cImJnLWJnIHBiLXNtIG1nbV9zcyBwLXNtXCI+XHJcbiAgICAgICAgICA8Q2FyZC5IZWFkZXJcclxuICAgICAgICAgICAgdGV4dD17Zih7IGlkOiBcImFjdGl2ZS1wYWNcIiB9KX1cclxuICAgICAgICAgICAgZW5kRWxlbG1lbnQ9e1xyXG4gICAgICAgICAgICAgIDxDaGVja2JveFxyXG4gICAgICAgICAgICAgICAgdGV4dD17Zih7IGlkOiBcImNob29zZS1hbGxcIiB9KX1cclxuICAgICAgICAgICAgICAgIFJlZj17KHJlZikgPT4gKG1haW5DaGVja1JlZi5jdXJyZW50ID0gcmVmKX1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3NlbGVjdEFsbH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlci1zdWJ0aXRsZVwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJzc2NcIiBzdHlsZT17eyBvdmVyZmxvd1g6IFwic2Nyb2xsXCIgfX0+XHJcbiAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCIgcGwtbm9uZVwiXHJcbiAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxyXG4gICAgICAgICAgICAgICAgbWFyZ2luQm90dG9tOiBcIjIwcHhcIixcclxuICAgICAgICAgICAgICAgIHdpZHRoOiBcIm1heC1jb250ZW50XCIsXHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgPlxyXG5cclxuICAgICAgICAgICAgICA8QnV0dG9uQ29tcG9uZW50XHJcbiAgICAgICAgICAgICAgICBsYWJlbD17YEhhbXPEsSAoJHtwYWNrYWdlcy5sZW5ndGh9KWB9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtci14cyBwLXhzIGJnLWJnIHBhY2stYWN0aXZlXCJcclxuICAgICAgICAgICAgICAgIGRhdGEtaWQ9ezB9XHJcbiAgICAgICAgICAgICAgICBSZWY9e2FkZFRhYlJlZnN9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXt0YWJCdXR0b25DbGlja31cclxuICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAge3N0YXR1cy5tYXAoKHgpID0+IChcclxuICAgICAgICAgICAgICAgIDxCdXR0b25Db21wb25lbnRcclxuICAgICAgICAgICAgICAgICAgbGFiZWw9e2Ake3gubmFtZX0gKCR7eC5jb3VudH0pYH1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiIHAteHMgYmctYmcgXCJcclxuICAgICAgICAgICAgICAgICAgZGF0YS1pZD17eC5pZH1cclxuICAgICAgICAgICAgICAgICAgUmVmPXthZGRUYWJSZWZzfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXt0YWJCdXR0b25DbGlja31cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKSl9IFxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxDYXJkLkJvZHkgY2xhc3NOYW1lPVwicC1ub25lXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGFja2FnZXNfX2ZyXCI+XHJcbiAgICAgICAgICAgICAge2ZpbHRlcmVkUGFja3NcclxuICAgICAgICAgICAgICAgIC5maWx0ZXIoKHgpID0+IHguc3RhdHVzLmlkICE9PSA2KVxyXG4gICAgICAgICAgICAgICAgLm1hcCgocCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8UGFja2FnZUl0ZW1cclxuICAgICAgICAgICAgICAgICAgICBrZXk9e3AuaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tSZWY9e2FkZENoZWNrUmVmc31cclxuICAgICAgICAgICAgICAgICAgICBpdGVtPXtwfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hlY2s9e2NoZWNrSGFuZGxlcn1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvQ2FyZC5Cb2R5PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb290ZXJfX3Bja1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhY2thZ2UtdG90YWxcIj5cclxuICAgICAgICAgICAgICA8c21hbGw+XHJcbiAgICAgICAgICAgICAgICB7c2VsZWN0ZWRQYWNrYWdlcy5wYWNrYWdlcy5sZW5ndGh9IHtmKHsgaWQ6IFwiY2hvc2VkXCIgfSl9XHJcbiAgICAgICAgICAgICAgPC9zbWFsbD5cclxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIgfX0+XHJcbiAgICAgICAgICAgICAgICA8Yj57Zih7IGlkOiBcInRvdGFsXCIgfSl9OjwvYj5cclxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIgfX0+XHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgIHNlbGVjdGVkUGFja2FnZXMuZGlzY291bnRUb3RhbCA+IDAgPyBcclxuICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgPGRlbCBzdHlsZT17eyB0ZXh0RGVjb3JhdGlvbkNvbG9yOiBcInJlZFwiIH19PntwYXJzZUZsb2F0KHNlbGVjdGVkUGFja2FnZXMudG90YWwpLnRvRml4ZWQoMil9IEFaTjwvZGVsPlxyXG4gICAgICAgICAgICAgICAgICAgPGI+e3BhcnNlRmxvYXQoc2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsKS50b0ZpeGVkKDIpfSBBWk48L2I+XHJcbiAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgIDogIDxiPntwYXJzZUZsb2F0KHNlbGVjdGVkUGFja2FnZXMuZGlzY291bnRUb3RhbCkudG9GaXhlZCgyKX0gQVpOPC9iPlxyXG4gICAgICAgICAgICAgICAgfSAgXHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYWNrYWdlX19idG5zXCI+XHJcbiAgICAgICAgICAgICAgPGZvcm0+XHJcbiAgICAgICAgICAgICAgICA8RnJvbUdyb3VwXHJcbiAgICAgICAgICAgICAgICAgIGJvZHlDbGFzcz1cImJnLXdoaXRlIHBsLXhzXCJcclxuICAgICAgICAgICAgICAgICAgYm9keVN0eWxlPXt7IGhlaWdodDogXCI0NHB4XCIsIHdpZHRoOiBcIjIwMHB4XCIgfX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXIteHMgY2huZ19fYm9keXN0eWxlXCJcclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiBcIjBweFwiIH19XHJcbiAgICAgICAgICAgICAgICAgIGVycm9yPXtlcnJvcnMucHJvbW9jb2RlPy5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17Zih7IGlkOiBcImFkZGNvZGVcIiB9KX1cclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicHJvbW9jb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICBSZWY9e3JlZ2lzdGVyKHtcclxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBmKHsgaWQ6IFwicHJvbW8tcmVxdWlyXCIgfSksXHJcbiAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkUGFja2FnZXMoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5zZWxlY3RlZFBhY2thZ2VzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2RlOiBlLnRhcmdldC52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRQYWNrYWdlcy5pc0FjY2VwdGVkID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b25Db21wb25lbnRcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIHctNTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGV4dERlY29yYXRpb25MaW5lOiBcInVuZGVybGluZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogXCJkYXJrYmx1ZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiBcIjBweCAxMHB4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJMyZnEn3YgZXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFBhY2thZ2VzKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5zZWxlY3RlZFBhY2thZ2VzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlzQWNjZXB0ZWQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uQ29tcG9uZW50XHJcbiAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IXNlbGVjdGVkUGFja2FnZXMuY29kZSA/IHRydWUgOiBmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHBhZGRpbmc6IFwiMCAxMHB4XCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNvbG9yLXdoaXRlIGJnLXN1Y2Nlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw9e2YoeyBpZDogXCJjb25maXJtXCIgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVN1Ym1pdChzdWJtaXQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gIG9uQ2xpY2s9eygpID0+e1xyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gICAgIC8vICBzZXRTZWxlY3RlZFBhY2thZ2VzKHtcclxuICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAvLyAgICAuLi5zZWxlY3RlZFBhY2thZ2VzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gICAgIC8vICAgIGlzQWNjZXB0ZWQ6dHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gICAgIC8vICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgIC8vICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvRnJvbUdyb3VwPlxyXG4gICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICA8QnV0dG9uQ29tcG9uZW50XHJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyBwYWRkaW5nOiBcIjAgMjBweFwiIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjb2xvci13aGl0ZSBiZy1zdWNjZXNzIG1yLXhzIGRlc2tcIlxyXG4gICAgICAgICAgICAgICAgbGFiZWw9e2YoeyBpZDogXCJwYXlieWNhcmRcIiB9KX1cclxuICAgICAgICAgICAgICAgIGVuZEVsZW1lbnQ9ezxzcGFuIGNsYXNzTmFtZT1cImNvbG9yLXdoaXRlIHBsLXNtXCI+JiM4NTk0Ozwvc3Bhbj59XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrID0geygpID0+IFBheWJ5Q2FyZCh7XHJcbiAgICAgICAgICAgICAgICAgIHByaWNlOnNlbGVjdGVkUGFja2FnZXMuZGlzY291bnRUb3RhbCxcclxuICAgICAgICAgICAgICAgICAgc291cmNldHlwZToyLFxyXG4gICAgICAgICAgICAgICAgICBiYXRjaGVzOnNlbGVjdGVkUGFja2FnZXMucGFja2FnZXNcclxuICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvbkNvbXBvbmVudFxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgcGFkZGluZzogXCIwIDEwcHhcIiB9fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZGVza1wiXHJcbiAgICAgICAgICAgICAgICBsYWJlbD17Zih7IGlkOiBcInBheWJ5YmFsYW5jZVwiIH0pfVxyXG4gICAgICAgICAgICAgICAgZW5kRWxlbWVudD17XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNvbG9yLWJsYWNrIG1yLXhzIHBsLXNtIFwiPiYjODU5NDs8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrID0ge1BheWJ5QmFsYW5jZX1cclxuICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJ0bl9fZmtsXCI+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uQ29tcG9uZW50XHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHBhZGRpbmc6IFwiMCAxMHB4XCIgfX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY29sb3Itd2hpdGUgYmctc3VjY2VzcyBtci14c1wiXHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsPXtmKHsgaWQ6IFwicGF5YnljYXJkXCIgfSl9XHJcbiAgICAgICAgICAgICAgICAgIGVuZEVsZW1lbnQ9e1xyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNvbG9yLXdoaXRlIHBsLXNtXCI+JiM4NTk0Ozwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrID0geygpID0+IFBheWJ5Q2FyZCh7XHJcbiAgICAgICAgICAgICAgICAgICAgcHJpY2U6c2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsLFxyXG4gICAgICAgICAgICAgICAgICAgIHNvdXJjZXR5cGU6MixcclxuICAgICAgICAgICAgICAgICAgICBiYXRjaGVzOnNlbGVjdGVkUGFja2FnZXMucGFja2FnZXNcclxuICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvbkNvbXBvbmVudFxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBwYWRkaW5nOiBcIjAgMTBweFwiIH19XHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsPXtmKHsgaWQ6IFwicGF5YnliYWxhbmNlXCIgfSl9XHJcbiAgICAgICAgICAgICAgICAgIGVuZEVsZW1lbnQ9e1xyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNvbG9yLWJsYWNrIG1yLXhzIHBsLXNtXCI+JiM4NTk0Ozwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrID0ge1BheWJ5QmFsYW5jZX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9DYXJkPlxyXG5cclxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLXNtIGJnLXdoaXRlXCI+XHJcbiAgICAgICAgICA8Q2FyZC5IZWFkZXIgdGV4dD17Zih7IGlkOiBcIm9yZGVyLWhpc3RvcnlcIiB9KX0gLz5cclxuICAgICAgICAgIDxDYXJkLkJvZHkgY2xhc3NOYW1lPVwicC1ub25lIG92ZXJmbG93X19wYWNrYWdlXCI+XHJcbiAgICAgICAgICAgIDxUYWJlbFxyXG4gICAgICAgICAgICAgIHRoPXtbXHJcbiAgICAgICAgICAgICAgICBmKHsgaWQ6IFwidHJhY2tpbmdcIiB9KSxcclxuICAgICAgICAgICAgICAgIGYoeyBpZDogXCJzaG9wXCIgfSksXHJcbiAgICAgICAgICAgICAgICBmKHsgaWQ6IFwiY2F0ZWdvcnlcIiB9KSxcclxuICAgICAgICAgICAgICAgIGYoeyBpZDogXCJhbW91bnRcIiB9KSxcclxuICAgICAgICAgICAgICAgIGYoeyBpZDogXCJ3ZWlnaHRcIiB9KSxcclxuICAgICAgICAgICAgICAgIGYoeyBpZDogXCJkZWxpdmVyeVwiIH0pLFxyXG4gICAgICAgICAgICAgICAgZih7IGlkOiBcInN0YXR1c1wiIH0pLFxyXG4gICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgZGF0YT17XHJcbiAgICAgICAgICAgICAgICBwYWNrYWdlcy5tYXAoKHgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgaWYgKHguc3RhdHVzLmlkID09IDYpIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgdHJhY2tfbnVtYmVyOiB4LnRyYWNrX251bWJlcixcclxuICAgICAgICAgICAgICAgICAgICAgIHNob3A6IHguc2hvcCxcclxuICAgICAgICAgICAgICAgICAgICAgIGNhdGVnb3J5OiB4LmNhdGVnb3J5LFxyXG4gICAgICAgICAgICAgICAgICAgICAgcHJpY2U6IGAke3gucHJpY2V9ICR7eC5jdXJyZW5jeX1gLFxyXG4gICAgICAgICAgICAgICAgICAgICAgd2VpZ2h0OiBgJHtwYXJzZUZsb2F0KHgud2VpZ2h0KS50b0ZpeGVkKDIpIHx8IDB9IGtxYCxcclxuICAgICAgICAgICAgICAgICAgICAgIGRlbGl2ZXJ5X3ByaWNlOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXJzZUZsb2F0KHguZGVsaXZlcnlfcHJpY2UpLnRvRml4ZWQoMikgfHwgMCxcclxuICAgICAgICAgICAgICAgICAgICAgIHN0YXR1czogYCR7eC5zdGF0dXMubmFtZX1cXG4gJHt4LmRhdGV9YCxcclxuICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KSB8fCBbXVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICByZW5kZXJCb2R5PXsoeCwgaSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIDx0ZCBrZXk9e2krK30+e3h9PC90ZD47XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvQ2FyZC5Cb2R5PlxyXG4gICAgICAgIDwvQ2FyZD5cclxuICAgICAgPC9NYWluPlxyXG4gICAgPC9QYWdlPlxyXG4gICk7XHJcbn1cclxuXHJcbmNvbnN0IG1hcFN0YXRlVG9Qcm9wcyA9IChzdGF0ZSkgPT4gKHtcclxuICBlbnRyeTogc3RhdGUuZW50cnksXHJcbn0pO1xyXG5jb25zdCBtYXBEaXNwYXRjaFRvUHJvcHMgPSAge1xyXG4gIFBheUJ5QmFsYW5jZUFjdGlvblxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY29ubmVjdChtYXBTdGF0ZVRvUHJvcHMsIG1hcERpc3BhdGNoVG9Qcm9wcykobWVtbyhQYWNrYWdlcykpOyIsIlxyXG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCByb3V0ZXIgZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcbmltcG9ydCBTd2FsIGZyb20gXCJzd2VldGFsZXJ0MlwiO1xyXG5pbXBvcnQgeyBJbmNyZWFzZUJhbGFuY2UsIGxvZ2luLCBsb2dvdXQsIFBheUJ5QmFsYW5jZSwgcmVnaXN0ZXIsIHVwZGF0ZVVzZXIgfSBmcm9tIFwiLi9hY3Rpb25zXCI7XHJcblxyXG5leHBvcnQgY29uc3QgTG9naW4gPSAodXJsLGRhdGEsaGVhZGVycyA9IHt9KSA9PiBkaXNwYXRjaCA9PiB7XHJcbiAgICBheGlvcy5wb3N0KGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9JHt1cmx9YCxkYXRhLHtcclxuICAgICAgICBoZWFkZXJzOmhlYWRlcnMsXHJcbiAgICAgIH0pXHJcbiAgICAgIC50aGVuKGFzeW5jIHJlcyA9PiB7XHJcbiAgICAgICAgbGV0IGRhdGEgPSBhd2FpdCByZXMuZGF0YTtcclxuICAgICAgICBkaXNwYXRjaChsb2dpbihkYXRhKSlcclxuICAgICAgICByb3V0ZXIucHVzaCgnL3BhY2thZ2VzJylcclxuICAgICAgfSkuY2F0Y2goZXJyb3JzID0+IHtcclxuICAgICAgICBkaXNwYXRjaChsb2dpbih7aXNFcnJvcjp0cnVlLGVycm9yczplcnJvcnMucmVzcG9uc2UuZGF0YX0pKVxyXG4gICAgICB9KVxyXG59XHJcblxyXG5cclxuZXhwb3J0IGNvbnN0IFVzZXJSZWdpc3RlciA9ICh1cmwsZGF0YSxoZWFkZXJzID0ge30pID0+IGRpc3BhdGNoID0+IHtcclxuICBheGlvcy5wb3N0KGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9JHt1cmx9YCxkYXRhLHtcclxuICAgICAgaGVhZGVyczpoZWFkZXJzLFxyXG4gICAgfSlcclxuICAgIC50aGVuKGFzeW5jIHJlcyA9PiB7XHJcbiAgICAgIFN3YWwuZmlyZSh7XHJcbiAgICAgICAgdGV4dDogJ8aPbcmZbGl5eWF0IHXEn3VybGEgdGFtYW1sYW5kxLEnLFxyXG4gICAgICAgIGljb246ICdzdWNjZXNzJyxcclxuICAgICAgICBjb25maXJtQnV0dG9uVGV4dDogJ09LJyxcclxuICAgICAgfSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgIGlmKHJlcy5pc0NvbmZpcm1lZCl7XHJcbiAgICAgICAgICByb3V0ZXIucHVzaCgnL215YWRkcmVzc2VzJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgICBsZXQgZGF0YSA9IGF3YWl0IHJlcy5kYXRhO1xyXG4gICAgICBkaXNwYXRjaChyZWdpc3RlcihkYXRhKSlcclxuICAgIH0pLmNhdGNoKGVyciA9PiB7XHJcbiAgICAgIGRpc3BhdGNoKHJlZ2lzdGVyKHtpc0Vycm9yOnRydWUsZXJyb3JzOmVyci5yZXNwb25zZS5kYXRhfSkpXHJcbiAgICB9KVxyXG59XHJcblxyXG5leHBvcnQgY29uc3QgTG9nT3V0ID0gKCkgPT4gZGlzcGF0Y2ggPT4ge1xyXG4gICAgZGlzcGF0Y2gobG9nb3V0KCkpXHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBVcGRhdGVVc2VyID0gKHVybCxkYXRhLGhlYWRlcnMgPSB7fSkgPT4gZGlzcGF0Y2ggPT4ge1xyXG5cclxuICAgIGF4aW9zLnB1dChgJHtwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19BUElfVVJMfSR7dXJsfWAsZGF0YSx7XHJcbiAgICAgICAgaGVhZGVyczogaGVhZGVyc1xyXG4gICAgICB9KVxyXG4gICAgICAudGhlbiggcmVzID0+IHtcclxuICAgICAgICBkaXNwYXRjaCh1cGRhdGVVc2VyKHJlcy5kYXRhKSlcclxuICAgICAgICAgU3dhbC5maXJlKHtcclxuICAgICAgICAgICB0ZXh0OiAnxo9tyZlsaXl5YXQgdcSfdXJsYSB5ZXJpbsmZIHlldGlyaWxkaScsXHJcbiAgICAgICAgICAgaWNvbjogJ3N1Y2Nlc3MnLFxyXG4gICAgICAgICAgIGNvbmZpcm1CdXR0b25UZXh0OiAnT0snLFxyXG4gICAgICAgICB9KVxyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goZXJyID0+IHtcclxuICAgICAgICBkaXNwYXRjaCh1cGRhdGVVc2VyKHtpc0Vycm9yOnRydWUsZXJyb3JzOmVyci5yZXNwb25zZS5kYXRhfSkpXHJcbiAgICAgIH0pXHJcbiAgXHJcbn1cclxuXHJcbiAgZXhwb3J0IGNvbnN0IFBheUJ5QmFsYW5jZUFjdGlvbiA9ICh1cmwsZGF0YSxoZWFkZXJzKSA9PiBkaXNwYXRjaCA9PiB7XHJcbiAgICBheGlvcy5wb3N0KGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9JHt1cmx9YCxkYXRhLHtcclxuICAgICAgaGVhZGVyczpoZWFkZXJzLFxyXG4gICAgfSkudGhlbihyZXMgPT4ge1xyXG4gICAgICBjb25zb2xlLmxvZygncmVxJyxyZXMuZGF0YS5iYWxhbmNlKSBcclxuICAgICAgICBTd2FsLmZpcmUoe1xyXG4gICAgICAgICAgdGV4dDogcmVzLmRhdGEubWVzc2FnZSxcclxuICAgICAgICAgIGljb246ICdzdWNjZXNzJyxcclxuICAgICAgICAgIGNvbmZpcm1CdXR0b25UZXh0OiAnT0snLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGRpc3BhdGNoKFBheUJ5QmFsYW5jZShyZXMuZGF0YS5iYWxhbmNlKSk7XHJcbiAgICAgICAgcm91dGVyLnB1c2goYC9zdWNjZXNzP21lc3NhZ2U9JHtyZXMuZGF0YS5tZXNzYWdlfWApO1xyXG4gICAgfSkuY2F0Y2goZXJyID0+IGNvbnNvbGUubG9nKGVycikpO1xyXG4gIH1cclxuXHJcbmV4cG9ydCBjb25zdCBJbmNyZWFzZUJhbGFuY2VBY3Rpb24gPSAoYmFsYW5jZSkgPT4gZGlzcGF0Y2ggPT4ge1xyXG4gICAgZGlzcGF0Y2goSW5jcmVhc2VCYWxhbmNlKGJhbGFuY2UpKVxyXG59XHJcblxyXG5cclxuXHJcbiJdLCJzb3VyY2VSb290IjoiIn0=