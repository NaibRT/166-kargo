webpackHotUpdate_N_E("pages/packages",{

/***/ "./pages/packages.js":
/*!***************************!*\
  !*** ./pages/packages.js ***!
  \***************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/toConsumableArray */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/regenerator */ "./node_modules/next/node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-hook-form */ "./node_modules/react-hook-form/dist/index.esm.js");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-intl */ "./node_modules/react-intl/lib/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _components_aside_menu_index__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../components/aside-menu/index */ "./components/aside-menu/index.js");
/* harmony import */ var _components_aside_aside__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../components/aside/aside */ "./components/aside/aside.js");
/* harmony import */ var _components_button__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../components/button */ "./components/button/index.js");
/* harmony import */ var _components_card_card__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../components/card/card */ "./components/card/card.js");
/* harmony import */ var _components_checkbox_checkbox__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../components/checkbox/checkbox */ "./components/checkbox/checkbox.js");
/* harmony import */ var _components_form_group_form_group__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../components/form-group/form-group */ "./components/form-group/form-group.js");
/* harmony import */ var _components_input_input__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../components/input/input */ "./components/input/input.js");
/* harmony import */ var _components_main_main__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../components/main/main */ "./components/main/main.js");
/* harmony import */ var _components_package_item_package_item__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../components/package_item/package-item */ "./components/package_item/package-item.js");
/* harmony import */ var _components_page_page__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../components/page/page */ "./components/page/page.js");
/* harmony import */ var _components_redirect_redirect__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../components/redirect/redirect */ "./components/redirect/redirect.js");
/* harmony import */ var _components_tabel_tabel__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../components/tabel/tabel */ "./components/tabel/tabel.js");
/* harmony import */ var _redux_entry_entryActions__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../redux/entry/entryActions */ "./redux/entry/entryActions.js");







var _jsxFileName = "C:\\Users\\Home\\Desktop\\166\\166-kargo\\pages\\packages.js",
    _s = $RefreshSig$();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }





















function Packages(props) {
  _s();

  var _this = this,
      _errors$promocode;

  if (!props.entry.isLoged) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_redirect_redirect__WEBPACK_IMPORTED_MODULE_21__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 23,
      columnNumber: 12
    }, this);
  }

  var _useForm = Object(react_hook_form__WEBPACK_IMPORTED_MODULE_8__["useForm"])(),
      register = _useForm.register,
      handleSubmit = _useForm.handleSubmit,
      errors = _useForm.errors,
      setError = _useForm.setError;

  var _useIntl = Object(react_intl__WEBPACK_IMPORTED_MODULE_9__["useIntl"])(),
      f = _useIntl.formatMessage;

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])([]),
      packages = _useState[0],
      setPackages = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])([]),
      filteredPacks = _useState2[0],
      setFilteredPacks = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])([]),
      status = _useState3[0],
      setStatus = _useState3[1];

  var _useState4 = Object(react__WEBPACK_IMPORTED_MODULE_7__["useState"])({
    packages: [],
    total: 0,
    discountTotal: 0,
    code: "",
    isAccepted: false,
    status: 0
  }),
      selectedPackages = _useState4[0],
      setSelectedPackages = _useState4[1];

  var _useRouter = Object(next_router__WEBPACK_IMPORTED_MODULE_6__["useRouter"])(),
      locale = _useRouter.locale;

  var mainCheckRef = Object(react__WEBPACK_IMPORTED_MODULE_7__["useRef"])();
  var checkRefs = Object(react__WEBPACK_IMPORTED_MODULE_7__["useRef"])([]);
  checkRefs.current = [];
  var tabRefs = Object(react__WEBPACK_IMPORTED_MODULE_7__["useRef"])([]);
  tabRefs.current = [];

  var submit = function submit(data) {
    console.log(data);
    axios__WEBPACK_IMPORTED_MODULE_5___default.a.post("".concat("https://166api.titr.az/api/", "promocode?promocode=").concat(data.promocode, "&status=").concat(selectedPackages.status), {}, {
      headers: {
        "content-type": "application/json",
        authorization: "Bearer ".concat(props.entry.user.accessToken)
      }
    }).then(function (res) {
      console.log(res.data.batches);
      setPackages(res.data.batches);
      setFilteredPacks(res.data.batches);
    })["catch"](function (err) {
      setError("promocode", {
        message: err.response.data.error
      });
    });
  };

  Object(react__WEBPACK_IMPORTED_MODULE_7__["useLayoutEffect"])(function () {
    // axios.get(`${process.env.NEXT_PUBLIC_API_URL}batches?lan=${locale}`, {
    //     headers: {
    //       authorization: `Bearer ${props.entry.user.accessToken}`,
    //     },
    //   })
    //   .then((res) => {
    //     setPackages(res.data);
    //     setFilteredPacks(res.data);
    //   })
    //   .catch((err) => console.log(err));
    Promise.all([axios__WEBPACK_IMPORTED_MODULE_5___default.a.get("".concat("https://166api.titr.az/api/", "batches?lan=").concat(locale), {
      headers: {
        authorization: "Bearer ".concat(props.entry.user.accessToken)
      }
    }), axios__WEBPACK_IMPORTED_MODULE_5___default.a.get("".concat("https://166api.titr.az/api/", "status?lan=").concat(locale), {
      headers: {
        authorization: "Bearer ".concat(props.entry.user.accessToken)
      }
    })]).then(function (res) {
      console.log(res.data);
      setPackages(res[0].data);
      setFilteredPacks(res[0].data);
      setStatus(res[1].data);
    })["catch"](function (err) {
      return console.log(err);
    });
  }, []);

  var addTabRefs = function addTabRefs(ref) {
    if (ref && !tabRefs.current.includes(ref)) {
      tabRefs.current.push(ref);
    }
  };

  var toggleTabRefs = /*#__PURE__*/function () {
    var _ref = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_4__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.mark(function _callee(ev) {
      return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              tabRefs.current.forEach(function (x) {
                return x.classList.remove("pack-active");
              });
              ev.target.classList.add("pack-active");

            case 2:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function toggleTabRefs(_x) {
      return _ref.apply(this, arguments);
    };
  }();

  var tabButtonClick = function tabButtonClick(ev) {
    toggleTabRefs(ev);
    var id = ev.target.getAttribute("data-id");

    if (id != 0) {
      var newPackages = packages.filter(function (x) {
        return x.status.id == id;
      });
      setFilteredPacks(Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(newPackages));
    } else {
      setFilteredPacks(Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(packages));
    }

    setSelectedPackages({
      discountTotal: 0,
      packages: [],
      total: 0,
      code: "",
      isAccepted: false,
      status: id
    });
  };

  var addCheckRefs = function addCheckRefs(ref) {
    if (ref && !checkRefs.current.includes(ref)) {
      checkRefs.current.push(ref);
    }
  };

  var checkHandler = function checkHandler(ev) {
    var _ev$target = ev.target,
        value = _ev$target.value,
        checked = _ev$target.checked;
    var price = ev.target.getAttribute("data-price");
    var dataDiscount = ev.target.getAttribute("data-discount");
    var total = 0;
    var disc = 0;
    console.log('dis', dataDiscount);

    if (checked) {
      selectedPackages.packages.push(value);

      if (dataDiscount != 0) {
        setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
          total: selectedPackages.total + parseFloat(price),
          discountTotal: selectedPackages.discountTotal + parseFloat(dataDiscount),
          packages: Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(selectedPackages.packages)
        }));
      } else {
        setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
          discountTotal: selectedPackages.discountTotal + parseFloat(price),
          total: selectedPackages.total + parseFloat(price),
          packages: Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(selectedPackages.packages)
        }));
      }
    } else {
      var newPackages = selectedPackages.packages.filter(function (x) {
        return x !== value;
      });

      if (dataDiscount != 0) {
        setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
          total: selectedPackages.total >= 0 && selectedPackages.total - parseFloat(price),
          discountTotal: selectedPackages.discountTotal >= 0 && selectedPackages.discountTotal - parseFloat(dataDiscount),
          packages: newPackages
        }));
      } else {
        setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
          discountTotal: selectedPackages.discountTotal >= 0 && selectedPackages.discountTotal - parseFloat(price),
          total: selectedPackages.total >= 0 && selectedPackages.total - parseFloat(price),
          packages: newPackages
        }));
      }
    }

    !selectedPackages.packages.some(function (x) {
      return x;
    }) ? mainCheckRef.current.checked = false : null;
  };

  var selectAll = function selectAll(e) {
    var total = 0;
    var discountTotal = 0;
    var packages = [];
    checkRefs.current.forEach(function (x) {
      x.checked = e.target.checked;

      if (e.target.checked && !packages.includes(x.value)) {
        packages.push(x.value);
        total += +x.getAttribute("data-price");
        discountTotal += +x.getAttribute("data-discount");
      } else {
        packages = packages.filter(function (p) {
          return p !== x.value;
        });
        total -= total >= 0 && +x.getAttribute("data-price");
        discountTotal -= discountTotal >= 0 && +x.getAttribute("data-discount");
      }
    });
    setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
      total: selectedPackages.total - total,
      packages: packages
    }));
  };

  var PaybyCard = function PaybyCard() {
    var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    axios__WEBPACK_IMPORTED_MODULE_5___default.a.post("".concat("https://166api.titr.az/api/", "payment"), data, {
      headers: {
        authorization: "Bearer ".concat(props.entry.user.accessToken)
      }
    }).then(function (res) {
      console.log('red', res.data.url);
      window.location.href = res.data.url;
    })["catch"](function (err) {
      return console.log(err);
    });
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_page_page__WEBPACK_IMPORTED_MODULE_20__["default"], {
    className: "bg-bg pt-lg pb-lg",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_aside_aside__WEBPACK_IMPORTED_MODULE_12__["default"], {
      className: "mr-sm",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_aside_menu_index__WEBPACK_IMPORTED_MODULE_11__["default"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 236,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 235,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_main_main__WEBPACK_IMPORTED_MODULE_18__["default"], {
      className: "bg-c p-none",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"], {
        className: "bg-bg pb-sm mgm_ss p-sm",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"].Header, {
          text: f({
            id: "active-pac"
          }),
          endElelment: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_checkbox_checkbox__WEBPACK_IMPORTED_MODULE_15__["default"], {
            text: f({
              id: "choose-all"
            }),
            Ref: function Ref(ref) {
              return mainCheckRef.current = ref;
            },
            onClick: selectAll,
            className: "bg-white border-subtitle"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 243,
            columnNumber: 15
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 240,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          "class": "ssc",
          style: {
            overflowX: "scroll"
          },
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: " pl-none",
            style: {
              display: "flex",
              marginBottom: "20px",
              width: "max-content"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
              label: "Hams\u0131 (".concat(packages.length, ")"),
              className: "mr-xs p-sm bg-bg pack-active",
              "data-id": 0,
              Ref: addTabRefs,
              onClick: tabButtonClick
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 261,
              columnNumber: 15
            }, this), status.map(function (x) {
              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                label: "".concat(x.name, " (").concat(packages.filter(function (x) {
                  return x.status.id == 3;
                }).length, ")"),
                className: " mr-xs p-sm bg-bg ",
                "data-id": x.id,
                Ref: addTabRefs,
                onClick: tabButtonClick
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 270,
                columnNumber: 17
              }, _this);
            })]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 252,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 251,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"].Body, {
          className: "p-none",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "packages__fr",
            children: filteredPacks.filter(function (x) {
              return x.status.id !== 6;
            }).map(function (p) {
              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_package_item_package_item__WEBPACK_IMPORTED_MODULE_19__["default"], {
                checkRef: addCheckRefs,
                item: p,
                onCheck: checkHandler
              }, p.id, false, {
                fileName: _jsxFileName,
                lineNumber: 290,
                columnNumber: 19
              }, _this);
            })
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 286,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 285,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "footer__pck",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "package-total",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("small", {
              children: [selectedPackages.packages.length, " ", f({
                id: "chosed"
              })]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 301,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                display: "flex",
                justifyContent: "space-between"
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                children: [f({
                  id: "total"
                }), ":"]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 305,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                style: {
                  display: "flex",
                  flexDirection: "column"
                },
                children: selectedPackages.discountTotal > 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("del", {
                    style: {
                      textDecorationColor: "red"
                    },
                    children: [parseFloat(selectedPackages.total).toFixed(2), " AZN"]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 310,
                    columnNumber: 19
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                    children: [parseFloat(selectedPackages.discountTotal).toFixed(2), " AZN"]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 311,
                    columnNumber: 20
                  }, this)]
                }, void 0, true) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                  children: [parseFloat(selectedPackages.discountTotal).toFixed(2), " AZN"]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 313,
                  columnNumber: 23
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 306,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 304,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 300,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "package__btns",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("form", {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_form_group_form_group__WEBPACK_IMPORTED_MODULE_16__["default"], {
                bodyClass: "bg-white pl-xs",
                bodyStyle: {
                  height: "44px",
                  width: "200px"
                },
                className: "mr-xs chng__bodystyle",
                style: {
                  marginBottom: "0px"
                },
                error: (_errors$promocode = errors.promocode) === null || _errors$promocode === void 0 ? void 0 : _errors$promocode.message,
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_input_input__WEBPACK_IMPORTED_MODULE_17__["default"], {
                  placeholder: f({
                    id: "addcode"
                  }),
                  name: "promocode",
                  Ref: register({
                    required: {
                      value: true,
                      message: f({
                        id: "promo-requir"
                      })
                    }
                  }),
                  onChange: function onChange(e) {
                    return setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
                      code: e.target.value
                    }));
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 329,
                  columnNumber: 19
                }, this), selectedPackages.isAccepted ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                  className: "bg-white w-50",
                  style: {
                    textDecorationLine: "underline",
                    color: "darkblue",
                    padding: "0px 10px"
                  },
                  label: "L\u0259\u011Fv et",
                  onClick: function onClick() {
                    setSelectedPackages(_objectSpread(_objectSpread({}, selectedPackages), {}, {
                      isAccepted: false
                    }));
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 346,
                  columnNumber: 21
                }, this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                  disabled: !selectedPackages.code ? true : false,
                  style: {
                    padding: "0 10px"
                  },
                  className: "color-white bg-success",
                  label: f({
                    id: "confirm"
                  }),
                  type: "submit",
                  onClick: handleSubmit(submit) //  onClick={() =>{
                  //     //  setSelectedPackages({
                  //     //    ...selectedPackages,
                  //     //    isAccepted:true
                  //     //  });
                  //    }}

                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 362,
                  columnNumber: 21
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 322,
                columnNumber: 17
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 321,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
              style: {
                padding: "0 20px"
              },
              className: "color-white bg-success mr-xs desk",
              label: f({
                id: "paybycard"
              }),
              endElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                className: "color-white pl-sm",
                children: "\u2192"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 384,
                columnNumber: 29
              }, this),
              onClick: function onClick() {
                return PaybyCard({
                  price: selectedPackages.discountTotal,
                  sourcetype: 2
                });
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 380,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
              style: {
                padding: "0 10px"
              },
              className: "desk",
              label: f({
                id: "paybybalance"
              }),
              endElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                className: "color-black mr-xs pl-sm ",
                children: "\u2192"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 395,
                columnNumber: 19
              }, this),
              onClick: function onClick() {
                return props.PayByBalanceAction('payment', {
                  price: selectedPackages.discountTotal,
                  sourcetype: 3
                }, {
                  'authorization': "Bearer ".concat(props.entry.user.accessToken)
                });
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 390,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "btn__fkl",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                style: {
                  padding: "0 10px"
                },
                className: "color-white bg-success mr-xs",
                label: f({
                  id: "paybycard"
                }),
                endElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "color-white pl-sm",
                  children: "\u2192"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 413,
                  columnNumber: 21
                }, this),
                onClick: function onClick() {
                  return PaybyCard({
                    price: selectedPackages.discountTotal,
                    sourcetype: 2
                  });
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 408,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button__WEBPACK_IMPORTED_MODULE_13__["default"], {
                style: {
                  padding: "0 10px"
                },
                label: f({
                  id: "paybybalance"
                }),
                endElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "color-black mr-xs pl-sm",
                  children: "\u2192"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 424,
                  columnNumber: 21
                }, this),
                onClick: function onClick() {
                  return props.PayByBalanceAction('payment', {
                    price: selectedPackages.discountTotal,
                    sourcetype: 3
                  }, {
                    'authorization': "Bearer ".concat(props.entry.user.accessToken)
                  });
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 420,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 407,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 320,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 299,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 239,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"], {
        className: "p-sm bg-white",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"].Header, {
          text: f({
            id: "order-history"
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 440,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_card_card__WEBPACK_IMPORTED_MODULE_14__["default"].Body, {
          className: "p-none overflow__package",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_tabel_tabel__WEBPACK_IMPORTED_MODULE_22__["default"], {
            th: [f({
              id: "tracking"
            }), f({
              id: "shop"
            }), f({
              id: "category"
            }), f({
              id: "amount"
            }), f({
              id: "weight"
            }), f({
              id: "delivery"
            }), f({
              id: "status"
            })],
            data: packages.map(function (x) {
              if (x.status.id == 6) {
                return {
                  track_number: x.track_number,
                  shop: x.shop,
                  category: x.category,
                  price: "".concat(x.price, " ").concat(x.currency),
                  weight: "".concat(parseFloat(x.weight).toFixed(2) || 0, " kq"),
                  delivery_price: parseFloat(x.delivery_price).toFixed(2) || 0,
                  status: "".concat(x.status.name, "\n ").concat(x.date)
                };
              }
            }) || [],
            renderBody: function renderBody(x, i) {
              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {
                children: x
              }, i++, false, {
                fileName: _jsxFileName,
                lineNumber: 469,
                columnNumber: 24
              }, _this);
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 442,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 441,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 439,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 238,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 234,
    columnNumber: 5
  }, this);
}

_s(Packages, "3E201Kyf6S2uVJ0+DS1LdJkJE1g=", false, function () {
  return [react_hook_form__WEBPACK_IMPORTED_MODULE_8__["useForm"], react_intl__WEBPACK_IMPORTED_MODULE_9__["useIntl"], next_router__WEBPACK_IMPORTED_MODULE_6__["useRouter"]];
});

_c = Packages;

var mapStateToProps = function mapStateToProps(state) {
  return {
    entry: state.entry
  };
};

var mapDispatchToProps = {
  PayByBalanceAction: _redux_entry_entryActions__WEBPACK_IMPORTED_MODULE_23__["PayByBalanceAction"]
};
/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_10__["connect"])(mapStateToProps, mapDispatchToProps)( /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_7__["memo"])(Packages)));

var _c;

$RefreshReg$(_c, "Packages");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvcGFja2FnZXMuanMiXSwibmFtZXMiOlsiUGFja2FnZXMiLCJwcm9wcyIsImVudHJ5IiwiaXNMb2dlZCIsInVzZUZvcm0iLCJyZWdpc3RlciIsImhhbmRsZVN1Ym1pdCIsImVycm9ycyIsInNldEVycm9yIiwidXNlSW50bCIsImYiLCJmb3JtYXRNZXNzYWdlIiwidXNlU3RhdGUiLCJwYWNrYWdlcyIsInNldFBhY2thZ2VzIiwiZmlsdGVyZWRQYWNrcyIsInNldEZpbHRlcmVkUGFja3MiLCJzdGF0dXMiLCJzZXRTdGF0dXMiLCJ0b3RhbCIsImRpc2NvdW50VG90YWwiLCJjb2RlIiwiaXNBY2NlcHRlZCIsInNlbGVjdGVkUGFja2FnZXMiLCJzZXRTZWxlY3RlZFBhY2thZ2VzIiwidXNlUm91dGVyIiwibG9jYWxlIiwibWFpbkNoZWNrUmVmIiwidXNlUmVmIiwiY2hlY2tSZWZzIiwiY3VycmVudCIsInRhYlJlZnMiLCJzdWJtaXQiLCJkYXRhIiwiY29uc29sZSIsImxvZyIsImF4aW9zIiwicG9zdCIsInByb2Nlc3MiLCJwcm9tb2NvZGUiLCJoZWFkZXJzIiwiYXV0aG9yaXphdGlvbiIsInVzZXIiLCJhY2Nlc3NUb2tlbiIsInRoZW4iLCJyZXMiLCJiYXRjaGVzIiwiZXJyIiwibWVzc2FnZSIsInJlc3BvbnNlIiwiZXJyb3IiLCJ1c2VMYXlvdXRFZmZlY3QiLCJQcm9taXNlIiwiYWxsIiwiZ2V0IiwiYWRkVGFiUmVmcyIsInJlZiIsImluY2x1ZGVzIiwicHVzaCIsInRvZ2dsZVRhYlJlZnMiLCJldiIsImZvckVhY2giLCJ4IiwiY2xhc3NMaXN0IiwicmVtb3ZlIiwidGFyZ2V0IiwiYWRkIiwidGFiQnV0dG9uQ2xpY2siLCJpZCIsImdldEF0dHJpYnV0ZSIsIm5ld1BhY2thZ2VzIiwiZmlsdGVyIiwiYWRkQ2hlY2tSZWZzIiwiY2hlY2tIYW5kbGVyIiwidmFsdWUiLCJjaGVja2VkIiwicHJpY2UiLCJkYXRhRGlzY291bnQiLCJkaXNjIiwicGFyc2VGbG9hdCIsInNvbWUiLCJzZWxlY3RBbGwiLCJlIiwicCIsIlBheWJ5Q2FyZCIsInVybCIsIndpbmRvdyIsImxvY2F0aW9uIiwiaHJlZiIsIm92ZXJmbG93WCIsImRpc3BsYXkiLCJtYXJnaW5Cb3R0b20iLCJ3aWR0aCIsImxlbmd0aCIsIm1hcCIsIm5hbWUiLCJqdXN0aWZ5Q29udGVudCIsImZsZXhEaXJlY3Rpb24iLCJ0ZXh0RGVjb3JhdGlvbkNvbG9yIiwidG9GaXhlZCIsImhlaWdodCIsInJlcXVpcmVkIiwidGV4dERlY29yYXRpb25MaW5lIiwiY29sb3IiLCJwYWRkaW5nIiwic291cmNldHlwZSIsIlBheUJ5QmFsYW5jZUFjdGlvbiIsInRyYWNrX251bWJlciIsInNob3AiLCJjYXRlZ29yeSIsImN1cnJlbmN5Iiwid2VpZ2h0IiwiZGVsaXZlcnlfcHJpY2UiLCJkYXRlIiwiaSIsIm1hcFN0YXRlVG9Qcm9wcyIsInN0YXRlIiwibWFwRGlzcGF0Y2hUb1Byb3BzIiwiY29ubmVjdCIsIm1lbW8iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFNBQVNBLFFBQVQsQ0FBa0JDLEtBQWxCLEVBQXlCO0FBQUE7O0FBQUE7QUFBQTs7QUFDdkIsTUFBSSxDQUFDQSxLQUFLLENBQUNDLEtBQU4sQ0FBWUMsT0FBakIsRUFBMEI7QUFDeEIsd0JBQU8scUVBQUMsc0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUFQO0FBQ0Q7O0FBSHNCLGlCQUs4QkMsK0RBQU8sRUFMckM7QUFBQSxNQUtmQyxRQUxlLFlBS2ZBLFFBTGU7QUFBQSxNQUtMQyxZQUxLLFlBS0xBLFlBTEs7QUFBQSxNQUtTQyxNQUxULFlBS1NBLE1BTFQ7QUFBQSxNQUtpQkMsUUFMakIsWUFLaUJBLFFBTGpCOztBQUFBLGlCQU1NQywwREFBTyxFQU5iO0FBQUEsTUFNQUMsQ0FOQSxZQU1mQyxhQU5lOztBQUFBLGtCQU9TQyxzREFBUSxDQUFDLEVBQUQsQ0FQakI7QUFBQSxNQU9oQkMsUUFQZ0I7QUFBQSxNQU9OQyxXQVBNOztBQUFBLG1CQVFtQkYsc0RBQVEsQ0FBQyxFQUFELENBUjNCO0FBQUEsTUFRaEJHLGFBUmdCO0FBQUEsTUFRREMsZ0JBUkM7O0FBQUEsbUJBU0tKLHNEQUFRLENBQUMsRUFBRCxDQVRiO0FBQUEsTUFTaEJLLE1BVGdCO0FBQUEsTUFTUkMsU0FUUTs7QUFBQSxtQkFVeUJOLHNEQUFRLENBQUM7QUFDdkRDLFlBQVEsRUFBRSxFQUQ2QztBQUV2RE0sU0FBSyxFQUFFLENBRmdEO0FBR3ZEQyxpQkFBYSxFQUFDLENBSHlDO0FBSXZEQyxRQUFJLEVBQUUsRUFKaUQ7QUFLdkRDLGNBQVUsRUFBRSxLQUwyQztBQU12REwsVUFBTSxFQUFFO0FBTitDLEdBQUQsQ0FWakM7QUFBQSxNQVVoQk0sZ0JBVmdCO0FBQUEsTUFVRUMsbUJBVkY7O0FBQUEsbUJBbUJKQyw2REFBUyxFQW5CTDtBQUFBLE1BbUJmQyxNQW5CZSxjQW1CZkEsTUFuQmU7O0FBb0J2QixNQUFNQyxZQUFZLEdBQUdDLG9EQUFNLEVBQTNCO0FBQ0EsTUFBTUMsU0FBUyxHQUFHRCxvREFBTSxDQUFDLEVBQUQsQ0FBeEI7QUFDQUMsV0FBUyxDQUFDQyxPQUFWLEdBQW9CLEVBQXBCO0FBQ0EsTUFBTUMsT0FBTyxHQUFHSCxvREFBTSxDQUFDLEVBQUQsQ0FBdEI7QUFDQUcsU0FBTyxDQUFDRCxPQUFSLEdBQWtCLEVBQWxCOztBQUVBLE1BQU1FLE1BQU0sR0FBRyxTQUFUQSxNQUFTLENBQUNDLElBQUQsRUFBVTtBQUN2QkMsV0FBTyxDQUFDQyxHQUFSLENBQVlGLElBQVo7QUFFQUcsZ0RBQUssQ0FDRkMsSUFESCxXQUVPQyw2QkFGUCxpQ0FFNkRMLElBQUksQ0FBQ00sU0FGbEUscUJBRXNGaEIsZ0JBQWdCLENBQUNOLE1BRnZHLEdBR0ksRUFISixFQUlJO0FBQ0V1QixhQUFPLEVBQUU7QUFDUCx3QkFBZ0Isa0JBRFQ7QUFFUEMscUJBQWEsbUJBQVl4QyxLQUFLLENBQUNDLEtBQU4sQ0FBWXdDLElBQVosQ0FBaUJDLFdBQTdCO0FBRk47QUFEWCxLQUpKLEVBV0dDLElBWEgsQ0FXUSxVQUFDQyxHQUFELEVBQVM7QUFDYlgsYUFBTyxDQUFDQyxHQUFSLENBQVlVLEdBQUcsQ0FBQ1osSUFBSixDQUFTYSxPQUFyQjtBQUNBaEMsaUJBQVcsQ0FBQytCLEdBQUcsQ0FBQ1osSUFBSixDQUFTYSxPQUFWLENBQVg7QUFDQTlCLHNCQUFnQixDQUFDNkIsR0FBRyxDQUFDWixJQUFKLENBQVNhLE9BQVYsQ0FBaEI7QUFDRCxLQWZILFdBZ0JTLFVBQUNDLEdBQUQsRUFBUztBQUNkdkMsY0FBUSxDQUFDLFdBQUQsRUFBYztBQUFFd0MsZUFBTyxFQUFFRCxHQUFHLENBQUNFLFFBQUosQ0FBYWhCLElBQWIsQ0FBa0JpQjtBQUE3QixPQUFkLENBQVI7QUFDRCxLQWxCSDtBQW1CRCxHQXRCRDs7QUF3QkFDLCtEQUFlLENBQUMsWUFBTTtBQUNwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQyxXQUFPLENBQUNDLEdBQVIsQ0FBWSxDQUNWakIsNENBQUssQ0FBQ2tCLEdBQU4sV0FBYWhCLDZCQUFiLHlCQUEyRFosTUFBM0QsR0FBcUU7QUFDbkVjLGFBQU8sRUFBRTtBQUNQQyxxQkFBYSxtQkFBWXhDLEtBQUssQ0FBQ0MsS0FBTixDQUFZd0MsSUFBWixDQUFpQkMsV0FBN0I7QUFETjtBQUQwRCxLQUFyRSxDQURVLEVBTVZQLDRDQUFLLENBQUNrQixHQUFOLFdBQWFoQiw2QkFBYix3QkFBMERaLE1BQTFELEdBQW9FO0FBQ2xFYyxhQUFPLEVBQUU7QUFDUEMscUJBQWEsbUJBQVl4QyxLQUFLLENBQUNDLEtBQU4sQ0FBWXdDLElBQVosQ0FBaUJDLFdBQTdCO0FBRE47QUFEeUQsS0FBcEUsQ0FOVSxDQUFaLEVBWUdDLElBWkgsQ0FZUSxVQUFDQyxHQUFELEVBQVM7QUFDYlgsYUFBTyxDQUFDQyxHQUFSLENBQVlVLEdBQUcsQ0FBQ1osSUFBaEI7QUFDQW5CLGlCQUFXLENBQUMrQixHQUFHLENBQUMsQ0FBRCxDQUFILENBQU9aLElBQVIsQ0FBWDtBQUNBakIsc0JBQWdCLENBQUM2QixHQUFHLENBQUMsQ0FBRCxDQUFILENBQU9aLElBQVIsQ0FBaEI7QUFDQWYsZUFBUyxDQUFDMkIsR0FBRyxDQUFDLENBQUQsQ0FBSCxDQUFPWixJQUFSLENBQVQ7QUFDRCxLQWpCSCxXQWtCUyxVQUFDYyxHQUFEO0FBQUEsYUFBU2IsT0FBTyxDQUFDQyxHQUFSLENBQVlZLEdBQVosQ0FBVDtBQUFBLEtBbEJUO0FBbUJELEdBL0JjLEVBK0JaLEVBL0JZLENBQWY7O0FBaUNBLE1BQU1RLFVBQVUsR0FBRyxTQUFiQSxVQUFhLENBQUNDLEdBQUQsRUFBUztBQUMxQixRQUFJQSxHQUFHLElBQUksQ0FBQ3pCLE9BQU8sQ0FBQ0QsT0FBUixDQUFnQjJCLFFBQWhCLENBQXlCRCxHQUF6QixDQUFaLEVBQTJDO0FBQ3pDekIsYUFBTyxDQUFDRCxPQUFSLENBQWdCNEIsSUFBaEIsQ0FBcUJGLEdBQXJCO0FBQ0Q7QUFDRixHQUpEOztBQU1BLE1BQU1HLGFBQWE7QUFBQSxrVUFBRyxpQkFBT0MsRUFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3BCN0IscUJBQU8sQ0FBQ0QsT0FBUixDQUFnQitCLE9BQWhCLENBQXdCLFVBQUNDLENBQUQ7QUFBQSx1QkFBT0EsQ0FBQyxDQUFDQyxTQUFGLENBQVlDLE1BQVosQ0FBbUIsYUFBbkIsQ0FBUDtBQUFBLGVBQXhCO0FBQ0FKLGdCQUFFLENBQUNLLE1BQUgsQ0FBVUYsU0FBVixDQUFvQkcsR0FBcEIsQ0FBd0IsYUFBeEI7O0FBRm9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQUg7O0FBQUEsb0JBQWJQLGFBQWE7QUFBQTtBQUFBO0FBQUEsS0FBbkI7O0FBS0EsTUFBTVEsY0FBYyxHQUFHLFNBQWpCQSxjQUFpQixDQUFDUCxFQUFELEVBQVE7QUFDN0JELGlCQUFhLENBQUNDLEVBQUQsQ0FBYjtBQUNBLFFBQUlRLEVBQUUsR0FBR1IsRUFBRSxDQUFDSyxNQUFILENBQVVJLFlBQVYsQ0FBdUIsU0FBdkIsQ0FBVDs7QUFDQSxRQUFJRCxFQUFFLElBQUksQ0FBVixFQUFhO0FBQ1gsVUFBSUUsV0FBVyxHQUFHekQsUUFBUSxDQUFDMEQsTUFBVCxDQUFnQixVQUFDVCxDQUFEO0FBQUEsZUFBT0EsQ0FBQyxDQUFDN0MsTUFBRixDQUFTbUQsRUFBVCxJQUFlQSxFQUF0QjtBQUFBLE9BQWhCLENBQWxCO0FBQ0FwRCxzQkFBZ0IsQ0FBQyw4SkFBSXNELFdBQUwsRUFBaEI7QUFDRCxLQUhELE1BR087QUFDTHRELHNCQUFnQixDQUFDLDhKQUFJSCxRQUFMLEVBQWhCO0FBQ0Q7O0FBRURXLHVCQUFtQixDQUFDO0FBQ2xCSixtQkFBYSxFQUFFLENBREc7QUFFbEJQLGNBQVEsRUFBRSxFQUZRO0FBR2xCTSxXQUFLLEVBQUUsQ0FIVztBQUlsQkUsVUFBSSxFQUFFLEVBSlk7QUFLbEJDLGdCQUFVLEVBQUUsS0FMTTtBQU1sQkwsWUFBTSxFQUFFbUQ7QUFOVSxLQUFELENBQW5CO0FBUUQsR0FsQkQ7O0FBb0JBLE1BQU1JLFlBQVksR0FBRyxTQUFmQSxZQUFlLENBQUNoQixHQUFELEVBQVM7QUFDNUIsUUFBSUEsR0FBRyxJQUFJLENBQUMzQixTQUFTLENBQUNDLE9BQVYsQ0FBa0IyQixRQUFsQixDQUEyQkQsR0FBM0IsQ0FBWixFQUE2QztBQUMzQzNCLGVBQVMsQ0FBQ0MsT0FBVixDQUFrQjRCLElBQWxCLENBQXVCRixHQUF2QjtBQUNEO0FBQ0YsR0FKRDs7QUFNQSxNQUFNaUIsWUFBWSxHQUFHLFNBQWZBLFlBQWUsQ0FBQ2IsRUFBRCxFQUFRO0FBQUEscUJBQ0ZBLEVBQUUsQ0FBQ0ssTUFERDtBQUFBLFFBQ3JCUyxLQURxQixjQUNyQkEsS0FEcUI7QUFBQSxRQUNkQyxPQURjLGNBQ2RBLE9BRGM7QUFFM0IsUUFBSUMsS0FBSyxHQUFHaEIsRUFBRSxDQUFDSyxNQUFILENBQVVJLFlBQVYsQ0FBdUIsWUFBdkIsQ0FBWjtBQUNBLFFBQUlRLFlBQVksR0FBR2pCLEVBQUUsQ0FBQ0ssTUFBSCxDQUFVSSxZQUFWLENBQXVCLGVBQXZCLENBQW5CO0FBQ0EsUUFBSWxELEtBQUssR0FBQyxDQUFWO0FBQ0EsUUFBSTJELElBQUksR0FBQyxDQUFUO0FBQ0E1QyxXQUFPLENBQUNDLEdBQVIsQ0FBWSxLQUFaLEVBQWtCMEMsWUFBbEI7O0FBQ0EsUUFBSUYsT0FBSixFQUFhO0FBQ1hwRCxzQkFBZ0IsQ0FBQ1YsUUFBakIsQ0FBMEI2QyxJQUExQixDQUErQmdCLEtBQS9COztBQUNBLFVBQUdHLFlBQVksSUFBRSxDQUFqQixFQUFtQjtBQUNqQnJELDJCQUFtQixpQ0FDZEQsZ0JBRGM7QUFHakJKLGVBQUssRUFBR0ksZ0JBQWdCLENBQUNKLEtBQWpCLEdBQXVCNEQsVUFBVSxDQUFDSCxLQUFELENBSHhCO0FBS2pCeEQsdUJBQWEsRUFBR0csZ0JBQWdCLENBQUNILGFBQWpCLEdBQStCMkQsVUFBVSxDQUFDRixZQUFELENBTHhDO0FBTWpCaEUsa0JBQVEsRUFBRSw4SkFBSVUsZ0JBQWdCLENBQUNWLFFBQXZCO0FBTlMsV0FBbkI7QUFTRCxPQVZELE1BVUs7QUFDSFcsMkJBQW1CLGlDQUNkRCxnQkFEYztBQUVqQkgsdUJBQWEsRUFBR0csZ0JBQWdCLENBQUNILGFBQWpCLEdBQStCMkQsVUFBVSxDQUFDSCxLQUFELENBRnhDO0FBR2pCekQsZUFBSyxFQUFHSSxnQkFBZ0IsQ0FBQ0osS0FBakIsR0FBdUI0RCxVQUFVLENBQUNILEtBQUQsQ0FIeEI7QUFJakIvRCxrQkFBUSxFQUFFLDhKQUFJVSxnQkFBZ0IsQ0FBQ1YsUUFBdkI7QUFKUyxXQUFuQjtBQU1EO0FBRUYsS0FyQkQsTUFxQk87QUFDTCxVQUFJeUQsV0FBVyxHQUFHL0MsZ0JBQWdCLENBQUNWLFFBQWpCLENBQTBCMEQsTUFBMUIsQ0FBaUMsVUFBQ1QsQ0FBRDtBQUFBLGVBQU9BLENBQUMsS0FBS1ksS0FBYjtBQUFBLE9BQWpDLENBQWxCOztBQUNBLFVBQUdHLFlBQVksSUFBRSxDQUFqQixFQUFtQjtBQUNqQnJELDJCQUFtQixpQ0FFZEQsZ0JBRmM7QUFJakJKLGVBQUssRUFBRUksZ0JBQWdCLENBQUNKLEtBQWpCLElBQXlCLENBQXpCLElBQStCSSxnQkFBZ0IsQ0FBQ0osS0FBakIsR0FBdUI0RCxVQUFVLENBQUNILEtBQUQsQ0FKdEQ7QUFNakJ4RCx1QkFBYSxFQUFFRyxnQkFBZ0IsQ0FBQ0gsYUFBakIsSUFBaUMsQ0FBakMsSUFBd0NHLGdCQUFnQixDQUFDSCxhQUFqQixHQUErQjJELFVBQVUsQ0FBQ0YsWUFBRCxDQU4vRTtBQU9qQmhFLGtCQUFRLEVBQUV5RDtBQVBPLFdBQW5CO0FBVUQsT0FYRCxNQVdLO0FBQ0g5QywyQkFBbUIsaUNBQ2RELGdCQURjO0FBRWpCSCx1QkFBYSxFQUFDRyxnQkFBZ0IsQ0FBQ0gsYUFBakIsSUFBaUMsQ0FBakMsSUFBdUNHLGdCQUFnQixDQUFDSCxhQUFqQixHQUErQjJELFVBQVUsQ0FBQ0gsS0FBRCxDQUY3RTtBQUdqQnpELGVBQUssRUFBQ0ksZ0JBQWdCLENBQUNKLEtBQWpCLElBQXlCLENBQXpCLElBQStCSSxnQkFBZ0IsQ0FBQ0osS0FBakIsR0FBdUI0RCxVQUFVLENBQUNILEtBQUQsQ0FIckQ7QUFJakIvRCxrQkFBUSxFQUFDeUQ7QUFKUSxXQUFuQjtBQU1EO0FBRUY7O0FBQ0QsS0FBQy9DLGdCQUFnQixDQUFDVixRQUFqQixDQUEwQm1FLElBQTFCLENBQStCLFVBQUNsQixDQUFEO0FBQUEsYUFBT0EsQ0FBUDtBQUFBLEtBQS9CLENBQUQsR0FDS25DLFlBQVksQ0FBQ0csT0FBYixDQUFxQjZDLE9BQXJCLEdBQStCLEtBRHBDLEdBRUksSUFGSjtBQUdELEdBdEREOztBQXdEQSxNQUFNTSxTQUFTLEdBQUcsU0FBWkEsU0FBWSxDQUFDQyxDQUFELEVBQU87QUFDdkIsUUFBSS9ELEtBQUssR0FBRyxDQUFaO0FBQ0EsUUFBSUMsYUFBYSxHQUFHLENBQXBCO0FBQ0EsUUFBSVAsUUFBUSxHQUFHLEVBQWY7QUFDQWdCLGFBQVMsQ0FBQ0MsT0FBVixDQUFrQitCLE9BQWxCLENBQTBCLFVBQUNDLENBQUQsRUFBTztBQUMvQkEsT0FBQyxDQUFDYSxPQUFGLEdBQVlPLENBQUMsQ0FBQ2pCLE1BQUYsQ0FBU1UsT0FBckI7O0FBRUEsVUFBSU8sQ0FBQyxDQUFDakIsTUFBRixDQUFTVSxPQUFULElBQW9CLENBQUM5RCxRQUFRLENBQUM0QyxRQUFULENBQWtCSyxDQUFDLENBQUNZLEtBQXBCLENBQXpCLEVBQXFEO0FBQ25EN0QsZ0JBQVEsQ0FBQzZDLElBQVQsQ0FBY0ksQ0FBQyxDQUFDWSxLQUFoQjtBQUNBdkQsYUFBSyxJQUFJLENBQUMyQyxDQUFDLENBQUNPLFlBQUYsQ0FBZSxZQUFmLENBQVY7QUFDQWpELHFCQUFhLElBQUksQ0FBQzBDLENBQUMsQ0FBQ08sWUFBRixDQUFlLGVBQWYsQ0FBbEI7QUFDRCxPQUpELE1BSU87QUFDTHhELGdCQUFRLEdBQUdBLFFBQVEsQ0FBQzBELE1BQVQsQ0FBZ0IsVUFBQ1ksQ0FBRDtBQUFBLGlCQUFPQSxDQUFDLEtBQUtyQixDQUFDLENBQUNZLEtBQWY7QUFBQSxTQUFoQixDQUFYO0FBQ0F2RCxhQUFLLElBQUlBLEtBQUssSUFBSSxDQUFULElBQWMsQ0FBQzJDLENBQUMsQ0FBQ08sWUFBRixDQUFlLFlBQWYsQ0FBeEI7QUFDQWpELHFCQUFhLElBQUlBLGFBQWEsSUFBRyxDQUFoQixJQUFxQixDQUFDMEMsQ0FBQyxDQUFDTyxZQUFGLENBQWUsZUFBZixDQUF2QztBQUNEO0FBQ0YsS0FaRDtBQWNBN0MsdUJBQW1CLGlDQUNkRCxnQkFEYztBQUVqQkosV0FBSyxFQUFFSSxnQkFBZ0IsQ0FBQ0osS0FBakIsR0FBdUJBLEtBRmI7QUFHakJOLGNBQVEsRUFBRUE7QUFITyxPQUFuQjtBQUtELEdBdkJEOztBQXlCQSxNQUFNdUUsU0FBUyxHQUFHLFNBQVpBLFNBQVksR0FBZTtBQUFBLFFBQWRuRCxJQUFjLHVFQUFQLEVBQU87QUFDL0JHLGdEQUFLLENBQUNDLElBQU4sV0FBY0MsNkJBQWQsY0FBdURMLElBQXZELEVBQTREO0FBQzFETyxhQUFPLEVBQUM7QUFDTkMscUJBQWEsbUJBQVl4QyxLQUFLLENBQUNDLEtBQU4sQ0FBWXdDLElBQVosQ0FBaUJDLFdBQTdCO0FBRFA7QUFEa0QsS0FBNUQsRUFJR0MsSUFKSCxDQUlRLFVBQUFDLEdBQUcsRUFBSTtBQUNiWCxhQUFPLENBQUNDLEdBQVIsQ0FBWSxLQUFaLEVBQWtCVSxHQUFHLENBQUNaLElBQUosQ0FBU29ELEdBQTNCO0FBQ0RDLFlBQU0sQ0FBQ0MsUUFBUCxDQUFnQkMsSUFBaEIsR0FBdUIzQyxHQUFHLENBQUNaLElBQUosQ0FBU29ELEdBQWhDO0FBQ0EsS0FQRCxXQU9TLFVBQUF0QyxHQUFHO0FBQUEsYUFBSWIsT0FBTyxDQUFDQyxHQUFSLENBQVlZLEdBQVosQ0FBSjtBQUFBLEtBUFo7QUFRRCxHQVREOztBQVdBLHNCQUNFLHFFQUFDLDhEQUFEO0FBQU0sYUFBUyxFQUFDLG1CQUFoQjtBQUFBLDRCQUNFLHFFQUFDLGdFQUFEO0FBQU8sZUFBUyxFQUFDLE9BQWpCO0FBQUEsNkJBQ0UscUVBQUMscUVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQUlFLHFFQUFDLDhEQUFEO0FBQU0sZUFBUyxFQUFDLGFBQWhCO0FBQUEsOEJBQ0UscUVBQUMsOERBQUQ7QUFBTSxpQkFBUyxFQUFDLHlCQUFoQjtBQUFBLGdDQUNFLHFFQUFDLDhEQUFELENBQU0sTUFBTjtBQUNFLGNBQUksRUFBRXJDLENBQUMsQ0FBQztBQUFFMEQsY0FBRSxFQUFFO0FBQU4sV0FBRCxDQURUO0FBRUUscUJBQVcsZUFDVCxxRUFBQyxzRUFBRDtBQUNFLGdCQUFJLEVBQUUxRCxDQUFDLENBQUM7QUFBRTBELGdCQUFFLEVBQUU7QUFBTixhQUFELENBRFQ7QUFFRSxlQUFHLEVBQUUsYUFBQ1osR0FBRDtBQUFBLHFCQUFVN0IsWUFBWSxDQUFDRyxPQUFiLEdBQXVCMEIsR0FBakM7QUFBQSxhQUZQO0FBR0UsbUJBQU8sRUFBRXlCLFNBSFg7QUFJRSxxQkFBUyxFQUFDO0FBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFZRTtBQUFLLG1CQUFNLEtBQVg7QUFBaUIsZUFBSyxFQUFFO0FBQUVRLHFCQUFTLEVBQUU7QUFBYixXQUF4QjtBQUFBLGlDQUNFO0FBQ0UscUJBQVMsRUFBQyxVQURaO0FBRUUsaUJBQUssRUFBRTtBQUNMQyxxQkFBTyxFQUFFLE1BREo7QUFFTEMsMEJBQVksRUFBRSxNQUZUO0FBR0xDLG1CQUFLLEVBQUU7QUFIRixhQUZUO0FBQUEsb0NBU0UscUVBQUMsMkRBQUQ7QUFDRSxtQkFBSyx3QkFBWS9FLFFBQVEsQ0FBQ2dGLE1BQXJCLE1BRFA7QUFFRSx1QkFBUyxFQUFDLDhCQUZaO0FBR0UseUJBQVMsQ0FIWDtBQUlFLGlCQUFHLEVBQUV0QyxVQUpQO0FBS0UscUJBQU8sRUFBRVk7QUFMWDtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVRGLEVBaUJJbEQsTUFBTSxDQUFDNkUsR0FBUCxDQUFXLFVBQUNoQyxDQUFEO0FBQUEsa0NBQ1gscUVBQUMsMkRBQUQ7QUFDRSxxQkFBSyxZQUFLQSxDQUFDLENBQUNpQyxJQUFQLGVBQ0hsRixRQUFRLENBQUMwRCxNQUFULENBQWdCLFVBQUNULENBQUQ7QUFBQSx5QkFBT0EsQ0FBQyxDQUFDN0MsTUFBRixDQUFTbUQsRUFBVCxJQUFlLENBQXRCO0FBQUEsaUJBQWhCLEVBQXlDeUIsTUFEdEMsTUFEUDtBQUtFLHlCQUFTLEVBQUMsb0JBTFo7QUFNRSwyQkFBUy9CLENBQUMsQ0FBQ00sRUFOYjtBQU9FLG1CQUFHLEVBQUViLFVBUFA7QUFRRSx1QkFBTyxFQUFFWTtBQVJYO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRFc7QUFBQSxhQUFYLENBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWkYsZUE4Q0UscUVBQUMsOERBQUQsQ0FBTSxJQUFOO0FBQVcsbUJBQVMsRUFBQyxRQUFyQjtBQUFBLGlDQUNFO0FBQUsscUJBQVMsRUFBQyxjQUFmO0FBQUEsc0JBQ0dwRCxhQUFhLENBQ1h3RCxNQURGLENBQ1MsVUFBQ1QsQ0FBRDtBQUFBLHFCQUFPQSxDQUFDLENBQUM3QyxNQUFGLENBQVNtRCxFQUFULEtBQWdCLENBQXZCO0FBQUEsYUFEVCxFQUVFMEIsR0FGRixDQUVNLFVBQUNYLENBQUQ7QUFBQSxrQ0FDSCxxRUFBQyw4RUFBRDtBQUVFLHdCQUFRLEVBQUVYLFlBRlo7QUFHRSxvQkFBSSxFQUFFVyxDQUhSO0FBSUUsdUJBQU8sRUFBRVY7QUFKWCxpQkFDT1UsQ0FBQyxDQUFDZixFQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREc7QUFBQSxhQUZOO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBOUNGLGVBNERFO0FBQUssbUJBQVMsRUFBQyxhQUFmO0FBQUEsa0NBQ0U7QUFBSyxxQkFBUyxFQUFDLGVBQWY7QUFBQSxvQ0FDRTtBQUFBLHlCQUNHN0MsZ0JBQWdCLENBQUNWLFFBQWpCLENBQTBCZ0YsTUFEN0IsT0FDc0NuRixDQUFDLENBQUM7QUFBRTBELGtCQUFFLEVBQUU7QUFBTixlQUFELENBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFERixlQUlFO0FBQUssbUJBQUssRUFBRTtBQUFFc0IsdUJBQU8sRUFBRSxNQUFYO0FBQW1CTSw4QkFBYyxFQUFFO0FBQW5DLGVBQVo7QUFBQSxzQ0FDRTtBQUFBLDJCQUFJdEYsQ0FBQyxDQUFDO0FBQUUwRCxvQkFBRSxFQUFFO0FBQU4saUJBQUQsQ0FBTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBREYsZUFFRTtBQUFLLHFCQUFLLEVBQUU7QUFBRXNCLHlCQUFPLEVBQUUsTUFBWDtBQUFtQk8sK0JBQWEsRUFBRTtBQUFsQyxpQkFBWjtBQUFBLDBCQUVFMUUsZ0JBQWdCLENBQUNILGFBQWpCLEdBQWlDLENBQWpDLGdCQUNBO0FBQUEsMENBQ0E7QUFBSyx5QkFBSyxFQUFFO0FBQUU4RSx5Q0FBbUIsRUFBRTtBQUF2QixxQkFBWjtBQUFBLCtCQUE2Q25CLFVBQVUsQ0FBQ3hELGdCQUFnQixDQUFDSixLQUFsQixDQUFWLENBQW1DZ0YsT0FBbkMsQ0FBMkMsQ0FBM0MsQ0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQURBLGVBRUM7QUFBQSwrQkFBSXBCLFVBQVUsQ0FBQ3hELGdCQUFnQixDQUFDSCxhQUFsQixDQUFWLENBQTJDK0UsT0FBM0MsQ0FBbUQsQ0FBbkQsQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBRkQ7QUFBQSxnQ0FEQSxnQkFLSTtBQUFBLDZCQUFJcEIsVUFBVSxDQUFDeEQsZ0JBQWdCLENBQUNILGFBQWxCLENBQVYsQ0FBMkMrRSxPQUEzQyxDQUFtRCxDQUFuRCxDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVBOO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERixlQXFCRTtBQUFLLHFCQUFTLEVBQUMsZUFBZjtBQUFBLG9DQUNFO0FBQUEscUNBQ0UscUVBQUMsMEVBQUQ7QUFDRSx5QkFBUyxFQUFDLGdCQURaO0FBRUUseUJBQVMsRUFBRTtBQUFFQyx3QkFBTSxFQUFFLE1BQVY7QUFBa0JSLHVCQUFLLEVBQUU7QUFBekIsaUJBRmI7QUFHRSx5QkFBUyxFQUFDLHVCQUhaO0FBSUUscUJBQUssRUFBRTtBQUFFRCw4QkFBWSxFQUFFO0FBQWhCLGlCQUpUO0FBS0UscUJBQUssdUJBQUVwRixNQUFNLENBQUNnQyxTQUFULHNEQUFFLGtCQUFrQlMsT0FMM0I7QUFBQSx3Q0FPRSxxRUFBQyxnRUFBRDtBQUNFLDZCQUFXLEVBQUV0QyxDQUFDLENBQUM7QUFBRTBELHNCQUFFLEVBQUU7QUFBTixtQkFBRCxDQURoQjtBQUVFLHNCQUFJLEVBQUMsV0FGUDtBQUdFLHFCQUFHLEVBQUUvRCxRQUFRLENBQUM7QUFDWmdHLDRCQUFRLEVBQUU7QUFDUjNCLDJCQUFLLEVBQUUsSUFEQztBQUVSMUIsNkJBQU8sRUFBRXRDLENBQUMsQ0FBQztBQUFFMEQsMEJBQUUsRUFBRTtBQUFOLHVCQUFEO0FBRkY7QUFERSxtQkFBRCxDQUhmO0FBU0UsMEJBQVEsRUFBRSxrQkFBQ2MsQ0FBRDtBQUFBLDJCQUNSMUQsbUJBQW1CLGlDQUNkRCxnQkFEYztBQUVqQkYsMEJBQUksRUFBRTZELENBQUMsQ0FBQ2pCLE1BQUYsQ0FBU1M7QUFGRSx1QkFEWDtBQUFBO0FBVFo7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFQRixFQXVCR25ELGdCQUFnQixDQUFDRCxVQUFqQixnQkFDQyxxRUFBQywyREFBRDtBQUNFLDJCQUFTLEVBQUMsZUFEWjtBQUVFLHVCQUFLLEVBQUU7QUFDTGdGLHNDQUFrQixFQUFFLFdBRGY7QUFFTEMseUJBQUssRUFBRSxVQUZGO0FBR0xDLDJCQUFPLEVBQUU7QUFISixtQkFGVDtBQU9FLHVCQUFLLEVBQUMsbUJBUFI7QUFRRSx5QkFBTyxFQUFFLG1CQUFNO0FBQ2JoRix1Q0FBbUIsaUNBQ2RELGdCQURjO0FBRWpCRCxnQ0FBVSxFQUFFO0FBRkssdUJBQW5CO0FBSUQ7QUFiSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQURELGdCQWlCQyxxRUFBQywyREFBRDtBQUNFLDBCQUFRLEVBQUUsQ0FBQ0MsZ0JBQWdCLENBQUNGLElBQWxCLEdBQXlCLElBQXpCLEdBQWdDLEtBRDVDO0FBRUUsdUJBQUssRUFBRTtBQUFFbUYsMkJBQU8sRUFBRTtBQUFYLG1CQUZUO0FBR0UsMkJBQVMsRUFBQyx3QkFIWjtBQUlFLHVCQUFLLEVBQUU5RixDQUFDLENBQUM7QUFBRTBELHNCQUFFLEVBQUU7QUFBTixtQkFBRCxDQUpWO0FBS0Usc0JBQUksRUFBQyxRQUxQO0FBTUUseUJBQU8sRUFBRTlELFlBQVksQ0FBQzBCLE1BQUQsQ0FOdkIsQ0FPRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkF4Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFERixlQTRERSxxRUFBQywyREFBRDtBQUNFLG1CQUFLLEVBQUU7QUFBRXdFLHVCQUFPLEVBQUU7QUFBWCxlQURUO0FBRUUsdUJBQVMsRUFBQyxtQ0FGWjtBQUdFLG1CQUFLLEVBQUU5RixDQUFDLENBQUM7QUFBRTBELGtCQUFFLEVBQUU7QUFBTixlQUFELENBSFY7QUFJRSx3QkFBVSxlQUFFO0FBQU0seUJBQVMsRUFBQyxtQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBSmQ7QUFLRSxxQkFBTyxFQUFJO0FBQUEsdUJBQU1nQixTQUFTLENBQUM7QUFDekJSLHVCQUFLLEVBQUNyRCxnQkFBZ0IsQ0FBQ0gsYUFERTtBQUV6QnFGLDRCQUFVLEVBQUM7QUFGYyxpQkFBRCxDQUFmO0FBQUE7QUFMYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQTVERixlQXNFRSxxRUFBQywyREFBRDtBQUNFLG1CQUFLLEVBQUU7QUFBRUQsdUJBQU8sRUFBRTtBQUFYLGVBRFQ7QUFFRSx1QkFBUyxFQUFDLE1BRlo7QUFHRSxtQkFBSyxFQUFFOUYsQ0FBQyxDQUFDO0FBQUUwRCxrQkFBRSxFQUFFO0FBQU4sZUFBRCxDQUhWO0FBSUUsd0JBQVUsZUFDUjtBQUFNLHlCQUFTLEVBQUMsMEJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUxKO0FBT0UscUJBQU8sRUFBSTtBQUFBLHVCQUFNbkUsS0FBSyxDQUFDeUcsa0JBQU4sQ0FBeUIsU0FBekIsRUFBbUM7QUFDbEQ5Qix1QkFBSyxFQUFDckQsZ0JBQWdCLENBQUNILGFBRDJCO0FBRWxEcUYsNEJBQVUsRUFBQztBQUZ1QyxpQkFBbkMsRUFLakI7QUFDRSxvREFBMEJ4RyxLQUFLLENBQUNDLEtBQU4sQ0FBWXdDLElBQVosQ0FBaUJDLFdBQTNDO0FBREYsaUJBTGlCLENBQU47QUFBQTtBQVBiO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBdEVGLGVBdUZFO0FBQUssdUJBQVMsRUFBQyxVQUFmO0FBQUEsc0NBQ0UscUVBQUMsMkRBQUQ7QUFDRSxxQkFBSyxFQUFFO0FBQUU2RCx5QkFBTyxFQUFFO0FBQVgsaUJBRFQ7QUFFRSx5QkFBUyxFQUFDLDhCQUZaO0FBR0UscUJBQUssRUFBRTlGLENBQUMsQ0FBQztBQUFFMEQsb0JBQUUsRUFBRTtBQUFOLGlCQUFELENBSFY7QUFJRSwwQkFBVSxlQUNSO0FBQU0sMkJBQVMsRUFBQyxtQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBTEo7QUFPRSx1QkFBTyxFQUFJO0FBQUEseUJBQU1nQixTQUFTLENBQUM7QUFDekJSLHlCQUFLLEVBQUNyRCxnQkFBZ0IsQ0FBQ0gsYUFERTtBQUV6QnFGLDhCQUFVLEVBQUM7QUFGYyxtQkFBRCxDQUFmO0FBQUE7QUFQYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQURGLGVBYUUscUVBQUMsMkRBQUQ7QUFDRSxxQkFBSyxFQUFFO0FBQUVELHlCQUFPLEVBQUU7QUFBWCxpQkFEVDtBQUVFLHFCQUFLLEVBQUU5RixDQUFDLENBQUM7QUFBRTBELG9CQUFFLEVBQUU7QUFBTixpQkFBRCxDQUZWO0FBR0UsMEJBQVUsZUFDUjtBQUFNLDJCQUFTLEVBQUMseUJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUpKO0FBTUUsdUJBQU8sRUFBSTtBQUFBLHlCQUFNbkUsS0FBSyxDQUFDeUcsa0JBQU4sQ0FBeUIsU0FBekIsRUFBbUM7QUFDbEQ5Qix5QkFBSyxFQUFDckQsZ0JBQWdCLENBQUNILGFBRDJCO0FBRWxEcUYsOEJBQVUsRUFBQztBQUZ1QyxtQkFBbkMsRUFJakI7QUFDRSxzREFBMEJ4RyxLQUFLLENBQUNDLEtBQU4sQ0FBWXdDLElBQVosQ0FBaUJDLFdBQTNDO0FBREYsbUJBSmlCLENBQU47QUFBQTtBQU5iO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQXZGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkE1REY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUF5TUUscUVBQUMsOERBQUQ7QUFBTSxpQkFBUyxFQUFDLGVBQWhCO0FBQUEsZ0NBQ0UscUVBQUMsOERBQUQsQ0FBTSxNQUFOO0FBQWEsY0FBSSxFQUFFakMsQ0FBQyxDQUFDO0FBQUUwRCxjQUFFLEVBQUU7QUFBTixXQUFEO0FBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFFRSxxRUFBQyw4REFBRCxDQUFNLElBQU47QUFBVyxtQkFBUyxFQUFDLDBCQUFyQjtBQUFBLGlDQUNFLHFFQUFDLGdFQUFEO0FBQ0UsY0FBRSxFQUFFLENBQ0YxRCxDQUFDLENBQUM7QUFBRTBELGdCQUFFLEVBQUU7QUFBTixhQUFELENBREMsRUFFRjFELENBQUMsQ0FBQztBQUFFMEQsZ0JBQUUsRUFBRTtBQUFOLGFBQUQsQ0FGQyxFQUdGMUQsQ0FBQyxDQUFDO0FBQUUwRCxnQkFBRSxFQUFFO0FBQU4sYUFBRCxDQUhDLEVBSUYxRCxDQUFDLENBQUM7QUFBRTBELGdCQUFFLEVBQUU7QUFBTixhQUFELENBSkMsRUFLRjFELENBQUMsQ0FBQztBQUFFMEQsZ0JBQUUsRUFBRTtBQUFOLGFBQUQsQ0FMQyxFQU1GMUQsQ0FBQyxDQUFDO0FBQUUwRCxnQkFBRSxFQUFFO0FBQU4sYUFBRCxDQU5DLEVBT0YxRCxDQUFDLENBQUM7QUFBRTBELGdCQUFFLEVBQUU7QUFBTixhQUFELENBUEMsQ0FETjtBQVVFLGdCQUFJLEVBQ0Z2RCxRQUFRLENBQUNpRixHQUFULENBQWEsVUFBQ2hDLENBQUQsRUFBTztBQUNsQixrQkFBSUEsQ0FBQyxDQUFDN0MsTUFBRixDQUFTbUQsRUFBVCxJQUFlLENBQW5CLEVBQXNCO0FBQ3BCLHVCQUFPO0FBQ0x1Qyw4QkFBWSxFQUFFN0MsQ0FBQyxDQUFDNkMsWUFEWDtBQUVMQyxzQkFBSSxFQUFFOUMsQ0FBQyxDQUFDOEMsSUFGSDtBQUdMQywwQkFBUSxFQUFFL0MsQ0FBQyxDQUFDK0MsUUFIUDtBQUlMakMsdUJBQUssWUFBS2QsQ0FBQyxDQUFDYyxLQUFQLGNBQWdCZCxDQUFDLENBQUNnRCxRQUFsQixDQUpBO0FBS0xDLHdCQUFNLFlBQUtoQyxVQUFVLENBQUNqQixDQUFDLENBQUNpRCxNQUFILENBQVYsQ0FBcUJaLE9BQXJCLENBQTZCLENBQTdCLEtBQW1DLENBQXhDLFFBTEQ7QUFNTGEsZ0NBQWMsRUFDWmpDLFVBQVUsQ0FBQ2pCLENBQUMsQ0FBQ2tELGNBQUgsQ0FBVixDQUE2QmIsT0FBN0IsQ0FBcUMsQ0FBckMsS0FBMkMsQ0FQeEM7QUFRTGxGLHdCQUFNLFlBQUs2QyxDQUFDLENBQUM3QyxNQUFGLENBQVM4RSxJQUFkLGdCQUF3QmpDLENBQUMsQ0FBQ21ELElBQTFCO0FBUkQsaUJBQVA7QUFVRDtBQUNGLGFBYkQsS0FhTSxFQXhCVjtBQTBCRSxzQkFBVSxFQUFFLG9CQUFDbkQsQ0FBRCxFQUFJb0QsQ0FBSixFQUFVO0FBQ3BCLGtDQUFPO0FBQUEsMEJBQWVwRDtBQUFmLGlCQUFTb0QsQ0FBQyxFQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQVA7QUFDRDtBQTVCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0F6TUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFvUEQ7O0dBeGNRbEgsUTtVQUs4Q0ksdUQsRUFDeEJLLGtELEVBYVZnQixxRDs7O0tBbkJaekIsUTs7QUEwY1QsSUFBTW1ILGVBQWUsR0FBRyxTQUFsQkEsZUFBa0IsQ0FBQ0MsS0FBRDtBQUFBLFNBQVk7QUFDbENsSCxTQUFLLEVBQUVrSCxLQUFLLENBQUNsSDtBQURxQixHQUFaO0FBQUEsQ0FBeEI7O0FBR0EsSUFBTW1ILGtCQUFrQixHQUFJO0FBQzFCWCxvQkFBa0IsRUFBbEJBLDZFQUFrQkE7QUFEUSxDQUE1QjtBQUllWSwySEFBTyxDQUFDSCxlQUFELEVBQWtCRSxrQkFBbEIsQ0FBUCxlQUE2Q0Usa0RBQUksQ0FBQ3ZILFFBQUQsQ0FBakQsQ0FBZiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9wYWNrYWdlcy4zM2FlMDFlMjJkMTc3OGFkYzc2ZS5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IFJlYWN0LCB7IG1lbW8sIHVzZUxheW91dEVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VGb3JtIH0gZnJvbSBcInJlYWN0LWhvb2stZm9ybVwiO1xyXG5pbXBvcnQgeyB1c2VJbnRsIH0gZnJvbSBcInJlYWN0LWludGxcIjtcclxuaW1wb3J0IHsgY29ubmVjdCB9IGZyb20gXCJyZWFjdC1yZWR1eFwiO1xyXG5pbXBvcnQgQXNpZGVNZW51IGZyb20gXCIuLi9jb21wb25lbnRzL2FzaWRlLW1lbnUvaW5kZXhcIjtcclxuaW1wb3J0IEFzaWRlIGZyb20gXCIuLi9jb21wb25lbnRzL2FzaWRlL2FzaWRlXCI7XHJcbmltcG9ydCBCdXR0b25Db21wb25lbnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvYnV0dG9uXCI7XHJcbmltcG9ydCBDYXJkIGZyb20gXCIuLi9jb21wb25lbnRzL2NhcmQvY2FyZFwiO1xyXG5pbXBvcnQgQ2hlY2tib3ggZnJvbSBcIi4uL2NvbXBvbmVudHMvY2hlY2tib3gvY2hlY2tib3hcIjtcclxuaW1wb3J0IEZyb21Hcm91cCBmcm9tIFwiLi4vY29tcG9uZW50cy9mb3JtLWdyb3VwL2Zvcm0tZ3JvdXBcIjtcclxuaW1wb3J0IElucHV0IGZyb20gXCIuLi9jb21wb25lbnRzL2lucHV0L2lucHV0XCI7XHJcbmltcG9ydCBNYWluIGZyb20gXCIuLi9jb21wb25lbnRzL21haW4vbWFpblwiO1xyXG5pbXBvcnQgUGFja2FnZUl0ZW0gZnJvbSBcIi4uL2NvbXBvbmVudHMvcGFja2FnZV9pdGVtL3BhY2thZ2UtaXRlbVwiO1xyXG5pbXBvcnQgUGFnZSBmcm9tIFwiLi4vY29tcG9uZW50cy9wYWdlL3BhZ2VcIjtcclxuaW1wb3J0IFJlZGlyZWN0IGZyb20gXCIuLi9jb21wb25lbnRzL3JlZGlyZWN0L3JlZGlyZWN0XCI7XHJcbmltcG9ydCBUYWJlbCBmcm9tIFwiLi4vY29tcG9uZW50cy90YWJlbC90YWJlbFwiO1xyXG5pbXBvcnQgeyBQYXlCeUJhbGFuY2VBY3Rpb24gfSBmcm9tICcuLi9yZWR1eC9lbnRyeS9lbnRyeUFjdGlvbnMnXHJcblxyXG5mdW5jdGlvbiBQYWNrYWdlcyhwcm9wcykge1xyXG4gIGlmICghcHJvcHMuZW50cnkuaXNMb2dlZCkge1xyXG4gICAgcmV0dXJuIDxSZWRpcmVjdCAvPjtcclxuICB9XHJcblxyXG4gIGNvbnN0IHsgcmVnaXN0ZXIsIGhhbmRsZVN1Ym1pdCwgZXJyb3JzLCBzZXRFcnJvciB9ID0gdXNlRm9ybSgpO1xyXG4gIGNvbnN0IHsgZm9ybWF0TWVzc2FnZTogZiB9ID0gdXNlSW50bCgpO1xyXG4gIGNvbnN0IFtwYWNrYWdlcywgc2V0UGFja2FnZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtmaWx0ZXJlZFBhY2tzLCBzZXRGaWx0ZXJlZFBhY2tzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc3RhdHVzLCBzZXRTdGF0dXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFBhY2thZ2VzLCBzZXRTZWxlY3RlZFBhY2thZ2VzXSA9IHVzZVN0YXRlKHtcclxuICAgIHBhY2thZ2VzOiBbXSxcclxuICAgIHRvdGFsOiAwLFxyXG4gICAgZGlzY291bnRUb3RhbDowLFxyXG4gICAgY29kZTogXCJcIixcclxuICAgIGlzQWNjZXB0ZWQ6IGZhbHNlLFxyXG4gICAgc3RhdHVzOiAwLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCB7IGxvY2FsZSB9ID0gdXNlUm91dGVyKCk7XHJcbiAgY29uc3QgbWFpbkNoZWNrUmVmID0gdXNlUmVmKCk7XHJcbiAgY29uc3QgY2hlY2tSZWZzID0gdXNlUmVmKFtdKTtcclxuICBjaGVja1JlZnMuY3VycmVudCA9IFtdO1xyXG4gIGNvbnN0IHRhYlJlZnMgPSB1c2VSZWYoW10pO1xyXG4gIHRhYlJlZnMuY3VycmVudCA9IFtdO1xyXG5cclxuICBjb25zdCBzdWJtaXQgPSAoZGF0YSkgPT4ge1xyXG4gICAgY29uc29sZS5sb2coZGF0YSk7XHJcblxyXG4gICAgYXhpb3NcclxuICAgICAgLnBvc3QoXHJcbiAgICAgICAgYCR7cHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQVBJX1VSTH1wcm9tb2NvZGU/cHJvbW9jb2RlPSR7ZGF0YS5wcm9tb2NvZGV9JnN0YXR1cz0ke3NlbGVjdGVkUGFja2FnZXMuc3RhdHVzfWAsXHJcbiAgICAgICAge30sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICBcImNvbnRlbnQtdHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAgICAgICAgICAgYXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Byb3BzLmVudHJ5LnVzZXIuYWNjZXNzVG9rZW59YCxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgICAgIC50aGVuKChyZXMpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhyZXMuZGF0YS5iYXRjaGVzKTtcclxuICAgICAgICBzZXRQYWNrYWdlcyhyZXMuZGF0YS5iYXRjaGVzKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZFBhY2tzKHJlcy5kYXRhLmJhdGNoZXMpO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycikgPT4ge1xyXG4gICAgICAgIHNldEVycm9yKFwicHJvbW9jb2RlXCIsIHsgbWVzc2FnZTogZXJyLnJlc3BvbnNlLmRhdGEuZXJyb3IgfSk7XHJcbiAgICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIHVzZUxheW91dEVmZmVjdCgoKSA9PiB7XHJcbiAgICAvLyBheGlvcy5nZXQoYCR7cHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQVBJX1VSTH1iYXRjaGVzP2xhbj0ke2xvY2FsZX1gLCB7XHJcbiAgICAvLyAgICAgaGVhZGVyczoge1xyXG4gICAgLy8gICAgICAgYXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Byb3BzLmVudHJ5LnVzZXIuYWNjZXNzVG9rZW59YCxcclxuICAgIC8vICAgICB9LFxyXG4gICAgLy8gICB9KVxyXG4gICAgLy8gICAudGhlbigocmVzKSA9PiB7XHJcbiAgICAvLyAgICAgc2V0UGFja2FnZXMocmVzLmRhdGEpO1xyXG4gICAgLy8gICAgIHNldEZpbHRlcmVkUGFja3MocmVzLmRhdGEpO1xyXG4gICAgLy8gICB9KVxyXG4gICAgLy8gICAuY2F0Y2goKGVycikgPT4gY29uc29sZS5sb2coZXJyKSk7XHJcblxyXG4gICAgUHJvbWlzZS5hbGwoW1xyXG4gICAgICBheGlvcy5nZXQoYCR7cHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQVBJX1VSTH1iYXRjaGVzP2xhbj0ke2xvY2FsZX1gLCB7XHJcbiAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgYXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Byb3BzLmVudHJ5LnVzZXIuYWNjZXNzVG9rZW59YCxcclxuICAgICAgICB9LFxyXG4gICAgICB9KSxcclxuICAgICAgYXhpb3MuZ2V0KGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9c3RhdHVzP2xhbj0ke2xvY2FsZX1gLCB7XHJcbiAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgYXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Byb3BzLmVudHJ5LnVzZXIuYWNjZXNzVG9rZW59YCxcclxuICAgICAgICB9LFxyXG4gICAgICB9KSxcclxuICAgIF0pXHJcbiAgICAgIC50aGVuKChyZXMpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhyZXMuZGF0YSk7XHJcbiAgICAgICAgc2V0UGFja2FnZXMocmVzWzBdLmRhdGEpO1xyXG4gICAgICAgIHNldEZpbHRlcmVkUGFja3MocmVzWzBdLmRhdGEpO1xyXG4gICAgICAgIHNldFN0YXR1cyhyZXNbMV0uZGF0YSk7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyKSA9PiBjb25zb2xlLmxvZyhlcnIpKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IGFkZFRhYlJlZnMgPSAocmVmKSA9PiB7XHJcbiAgICBpZiAocmVmICYmICF0YWJSZWZzLmN1cnJlbnQuaW5jbHVkZXMocmVmKSkge1xyXG4gICAgICB0YWJSZWZzLmN1cnJlbnQucHVzaChyZWYpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHRvZ2dsZVRhYlJlZnMgPSBhc3luYyAoZXYpID0+IHtcclxuICAgIHRhYlJlZnMuY3VycmVudC5mb3JFYWNoKCh4KSA9PiB4LmNsYXNzTGlzdC5yZW1vdmUoXCJwYWNrLWFjdGl2ZVwiKSk7XHJcbiAgICBldi50YXJnZXQuY2xhc3NMaXN0LmFkZChcInBhY2stYWN0aXZlXCIpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHRhYkJ1dHRvbkNsaWNrID0gKGV2KSA9PiB7XHJcbiAgICB0b2dnbGVUYWJSZWZzKGV2KTtcclxuICAgIGxldCBpZCA9IGV2LnRhcmdldC5nZXRBdHRyaWJ1dGUoXCJkYXRhLWlkXCIpO1xyXG4gICAgaWYgKGlkICE9IDApIHtcclxuICAgICAgbGV0IG5ld1BhY2thZ2VzID0gcGFja2FnZXMuZmlsdGVyKCh4KSA9PiB4LnN0YXR1cy5pZCA9PSBpZCk7XHJcbiAgICAgIHNldEZpbHRlcmVkUGFja3MoWy4uLm5ld1BhY2thZ2VzXSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRGaWx0ZXJlZFBhY2tzKFsuLi5wYWNrYWdlc10pO1xyXG4gICAgfVxyXG5cclxuICAgIHNldFNlbGVjdGVkUGFja2FnZXMoe1xyXG4gICAgICBkaXNjb3VudFRvdGFsOiAwLFxyXG4gICAgICBwYWNrYWdlczogW10sXHJcbiAgICAgIHRvdGFsOiAwLFxyXG4gICAgICBjb2RlOiBcIlwiLFxyXG4gICAgICBpc0FjY2VwdGVkOiBmYWxzZSxcclxuICAgICAgc3RhdHVzOiBpZCxcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGFkZENoZWNrUmVmcyA9IChyZWYpID0+IHtcclxuICAgIGlmIChyZWYgJiYgIWNoZWNrUmVmcy5jdXJyZW50LmluY2x1ZGVzKHJlZikpIHtcclxuICAgICAgY2hlY2tSZWZzLmN1cnJlbnQucHVzaChyZWYpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNoZWNrSGFuZGxlciA9IChldikgPT4ge1xyXG4gICAgbGV0IHsgdmFsdWUsIGNoZWNrZWQgfSA9IGV2LnRhcmdldDtcclxuICAgIGxldCBwcmljZSA9IGV2LnRhcmdldC5nZXRBdHRyaWJ1dGUoXCJkYXRhLXByaWNlXCIpO1xyXG4gICAgbGV0IGRhdGFEaXNjb3VudCA9IGV2LnRhcmdldC5nZXRBdHRyaWJ1dGUoXCJkYXRhLWRpc2NvdW50XCIpO1xyXG4gICAgbGV0IHRvdGFsPTBcclxuICAgIGxldCBkaXNjPTBcclxuICAgIGNvbnNvbGUubG9nKCdkaXMnLGRhdGFEaXNjb3VudClcclxuICAgIGlmIChjaGVja2VkKSB7XHJcbiAgICAgIHNlbGVjdGVkUGFja2FnZXMucGFja2FnZXMucHVzaCh2YWx1ZSk7XHJcbiAgICAgIGlmKGRhdGFEaXNjb3VudCE9MCl7XHJcbiAgICAgICAgc2V0U2VsZWN0ZWRQYWNrYWdlcyh7XHJcbiAgICAgICAgICAuLi5zZWxlY3RlZFBhY2thZ2VzLFxyXG5cclxuICAgICAgICAgIHRvdGFsOiAoc2VsZWN0ZWRQYWNrYWdlcy50b3RhbCtwYXJzZUZsb2F0KHByaWNlKSksXHJcbiAgICAgICAgIFxyXG4gICAgICAgICAgZGlzY291bnRUb3RhbDogKHNlbGVjdGVkUGFja2FnZXMuZGlzY291bnRUb3RhbCtwYXJzZUZsb2F0KGRhdGFEaXNjb3VudCkpLFxyXG4gICAgICAgICAgcGFja2FnZXM6IFsuLi5zZWxlY3RlZFBhY2thZ2VzLnBhY2thZ2VzXSxcclxuICAgICAgICB9KTtcclxuICAgICAgXHJcbiAgICAgIH1lbHNle1xyXG4gICAgICAgIHNldFNlbGVjdGVkUGFja2FnZXMoe1xyXG4gICAgICAgICAgLi4uc2VsZWN0ZWRQYWNrYWdlcyxcclxuICAgICAgICAgIGRpc2NvdW50VG90YWw6IChzZWxlY3RlZFBhY2thZ2VzLmRpc2NvdW50VG90YWwrcGFyc2VGbG9hdChwcmljZSkpLFxyXG4gICAgICAgICAgdG90YWw6IChzZWxlY3RlZFBhY2thZ2VzLnRvdGFsK3BhcnNlRmxvYXQocHJpY2UpKSxcclxuICAgICAgICAgIHBhY2thZ2VzOiBbLi4uc2VsZWN0ZWRQYWNrYWdlcy5wYWNrYWdlc10sXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgICBcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGxldCBuZXdQYWNrYWdlcyA9IHNlbGVjdGVkUGFja2FnZXMucGFja2FnZXMuZmlsdGVyKCh4KSA9PiB4ICE9PSB2YWx1ZSk7XHJcbiAgICAgIGlmKGRhdGFEaXNjb3VudCE9MCl7XHJcbiAgICAgICAgc2V0U2VsZWN0ZWRQYWNrYWdlcyh7XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIC4uLnNlbGVjdGVkUGFja2FnZXMsXHJcblxyXG4gICAgICAgICAgdG90YWw6IHNlbGVjdGVkUGFja2FnZXMudG90YWwgPj0wICYmIChzZWxlY3RlZFBhY2thZ2VzLnRvdGFsLXBhcnNlRmxvYXQocHJpY2UpKSxcclxuICAgICAgICAgXHJcbiAgICAgICAgICBkaXNjb3VudFRvdGFsOiBzZWxlY3RlZFBhY2thZ2VzLmRpc2NvdW50VG90YWwgPj0wICYmICAoc2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsLXBhcnNlRmxvYXQoZGF0YURpc2NvdW50KSksXHJcbiAgICAgICAgICBwYWNrYWdlczogbmV3UGFja2FnZXNcclxuICAgICAgICB9KTtcclxuICAgICAgXHJcbiAgICAgIH1lbHNle1xyXG4gICAgICAgIHNldFNlbGVjdGVkUGFja2FnZXMoe1xyXG4gICAgICAgICAgLi4uc2VsZWN0ZWRQYWNrYWdlcyxcclxuICAgICAgICAgIGRpc2NvdW50VG90YWw6c2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsID49MCAmJiAoc2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsLXBhcnNlRmxvYXQocHJpY2UpKSxcclxuICAgICAgICAgIHRvdGFsOnNlbGVjdGVkUGFja2FnZXMudG90YWwgPj0wICYmIChzZWxlY3RlZFBhY2thZ2VzLnRvdGFsLXBhcnNlRmxvYXQocHJpY2UpKSxcclxuICAgICAgICAgIHBhY2thZ2VzOm5ld1BhY2thZ2VzXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgICBcclxuICAgIH1cclxuICAgICFzZWxlY3RlZFBhY2thZ2VzLnBhY2thZ2VzLnNvbWUoKHgpID0+IHgpXHJcbiAgICAgID8gKG1haW5DaGVja1JlZi5jdXJyZW50LmNoZWNrZWQgPSBmYWxzZSlcclxuICAgICAgOiBudWxsO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHNlbGVjdEFsbCA9IChlKSA9PiB7XHJcbiAgICBsZXQgdG90YWwgPSAwO1xyXG4gICAgbGV0IGRpc2NvdW50VG90YWwgPSAwO1xyXG4gICAgbGV0IHBhY2thZ2VzID0gW107XHJcbiAgICBjaGVja1JlZnMuY3VycmVudC5mb3JFYWNoKCh4KSA9PiB7XHJcbiAgICAgIHguY2hlY2tlZCA9IGUudGFyZ2V0LmNoZWNrZWQ7XHJcblxyXG4gICAgICBpZiAoZS50YXJnZXQuY2hlY2tlZCAmJiAhcGFja2FnZXMuaW5jbHVkZXMoeC52YWx1ZSkpIHtcclxuICAgICAgICBwYWNrYWdlcy5wdXNoKHgudmFsdWUpO1xyXG4gICAgICAgIHRvdGFsICs9ICt4LmdldEF0dHJpYnV0ZShcImRhdGEtcHJpY2VcIik7XHJcbiAgICAgICAgZGlzY291bnRUb3RhbCArPSAreC5nZXRBdHRyaWJ1dGUoXCJkYXRhLWRpc2NvdW50XCIpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHBhY2thZ2VzID0gcGFja2FnZXMuZmlsdGVyKChwKSA9PiBwICE9PSB4LnZhbHVlKTtcclxuICAgICAgICB0b3RhbCAtPSB0b3RhbCA+PSAwICYmICt4LmdldEF0dHJpYnV0ZShcImRhdGEtcHJpY2VcIik7XHJcbiAgICAgICAgZGlzY291bnRUb3RhbCAtPSBkaXNjb3VudFRvdGFsID49MCAmJiAreC5nZXRBdHRyaWJ1dGUoXCJkYXRhLWRpc2NvdW50XCIpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgICBzZXRTZWxlY3RlZFBhY2thZ2VzKHtcclxuICAgICAgLi4uc2VsZWN0ZWRQYWNrYWdlcyxcclxuICAgICAgdG90YWw6IHNlbGVjdGVkUGFja2FnZXMudG90YWwtdG90YWwsXHJcbiAgICAgIHBhY2thZ2VzOiBwYWNrYWdlcyxcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IFBheWJ5Q2FyZCA9IChkYXRhID0ge30pID0+IHtcclxuICAgIGF4aW9zLnBvc3QoYCR7cHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQVBJX1VSTH1wYXltZW50YCxkYXRhLHtcclxuICAgICAgaGVhZGVyczp7XHJcbiAgICAgICAgYXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Byb3BzLmVudHJ5LnVzZXIuYWNjZXNzVG9rZW59YCxcclxuICAgICAgfVxyXG4gICAgfSkudGhlbihyZXMgPT4ge1xyXG4gICAgICBjb25zb2xlLmxvZygncmVkJyxyZXMuZGF0YS51cmwpO1xyXG4gICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gcmVzLmRhdGEudXJsO1xyXG4gICAgfSkuY2F0Y2goZXJyID0+IGNvbnNvbGUubG9nKGVycikpXHJcbiAgfVxyXG4gXHJcbiAgcmV0dXJuIChcclxuICAgIDxQYWdlIGNsYXNzTmFtZT1cImJnLWJnIHB0LWxnIHBiLWxnXCI+XHJcbiAgICAgIDxBc2lkZSBjbGFzc05hbWU9XCJtci1zbVwiPlxyXG4gICAgICAgIDxBc2lkZU1lbnUgLz5cclxuICAgICAgPC9Bc2lkZT5cclxuICAgICAgPE1haW4gY2xhc3NOYW1lPVwiYmctYyBwLW5vbmVcIj5cclxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJiZy1iZyBwYi1zbSBtZ21fc3MgcC1zbVwiPlxyXG4gICAgICAgICAgPENhcmQuSGVhZGVyXHJcbiAgICAgICAgICAgIHRleHQ9e2YoeyBpZDogXCJhY3RpdmUtcGFjXCIgfSl9XHJcbiAgICAgICAgICAgIGVuZEVsZWxtZW50PXtcclxuICAgICAgICAgICAgICA8Q2hlY2tib3hcclxuICAgICAgICAgICAgICAgIHRleHQ9e2YoeyBpZDogXCJjaG9vc2UtYWxsXCIgfSl9XHJcbiAgICAgICAgICAgICAgICBSZWY9eyhyZWYpID0+IChtYWluQ2hlY2tSZWYuY3VycmVudCA9IHJlZil9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtzZWxlY3RBbGx9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXItc3VidGl0bGVcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwic3NjXCIgc3R5bGU9e3sgb3ZlcmZsb3dYOiBcInNjcm9sbFwiIH19PlxyXG4gICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiIHBsLW5vbmVcIlxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcclxuICAgICAgICAgICAgICAgIG1hcmdpbkJvdHRvbTogXCIyMHB4XCIsXHJcbiAgICAgICAgICAgICAgICB3aWR0aDogXCJtYXgtY29udGVudFwiLFxyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgID5cclxuXHJcbiAgICAgICAgICAgICAgPEJ1dHRvbkNvbXBvbmVudFxyXG4gICAgICAgICAgICAgICAgbGFiZWw9e2BIYW1zxLEgKCR7cGFja2FnZXMubGVuZ3RofSlgfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXIteHMgcC1zbSBiZy1iZyBwYWNrLWFjdGl2ZVwiXHJcbiAgICAgICAgICAgICAgICBkYXRhLWlkPXswfVxyXG4gICAgICAgICAgICAgICAgUmVmPXthZGRUYWJSZWZzfVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17dGFiQnV0dG9uQ2xpY2t9XHJcbiAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgIHtzdGF0dXMubWFwKCh4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uQ29tcG9uZW50XHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsPXtgJHt4Lm5hbWV9ICgke1xyXG4gICAgICAgICAgICAgICAgICAgIHBhY2thZ2VzLmZpbHRlcigoeCkgPT4geC5zdGF0dXMuaWQgPT0gMykubGVuZ3RoXHJcbiAgICAgICAgICAgICAgICAgIH0pYH1cclxuICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiIG1yLXhzIHAtc20gYmctYmcgXCJcclxuICAgICAgICAgICAgICAgICAgZGF0YS1pZD17eC5pZH1cclxuICAgICAgICAgICAgICAgICAgUmVmPXthZGRUYWJSZWZzfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXt0YWJCdXR0b25DbGlja31cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKSl9IFxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxDYXJkLkJvZHkgY2xhc3NOYW1lPVwicC1ub25lXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGFja2FnZXNfX2ZyXCI+XHJcbiAgICAgICAgICAgICAge2ZpbHRlcmVkUGFja3NcclxuICAgICAgICAgICAgICAgIC5maWx0ZXIoKHgpID0+IHguc3RhdHVzLmlkICE9PSA2KVxyXG4gICAgICAgICAgICAgICAgLm1hcCgocCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8UGFja2FnZUl0ZW1cclxuICAgICAgICAgICAgICAgICAgICBrZXk9e3AuaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tSZWY9e2FkZENoZWNrUmVmc31cclxuICAgICAgICAgICAgICAgICAgICBpdGVtPXtwfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hlY2s9e2NoZWNrSGFuZGxlcn1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvQ2FyZC5Cb2R5PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb290ZXJfX3Bja1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhY2thZ2UtdG90YWxcIj5cclxuICAgICAgICAgICAgICA8c21hbGw+XHJcbiAgICAgICAgICAgICAgICB7c2VsZWN0ZWRQYWNrYWdlcy5wYWNrYWdlcy5sZW5ndGh9IHtmKHsgaWQ6IFwiY2hvc2VkXCIgfSl9XHJcbiAgICAgICAgICAgICAgPC9zbWFsbD5cclxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIgfX0+XHJcbiAgICAgICAgICAgICAgICA8Yj57Zih7IGlkOiBcInRvdGFsXCIgfSl9OjwvYj5cclxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIgfX0+XHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgIHNlbGVjdGVkUGFja2FnZXMuZGlzY291bnRUb3RhbCA+IDAgPyBcclxuICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgPGRlbCBzdHlsZT17eyB0ZXh0RGVjb3JhdGlvbkNvbG9yOiBcInJlZFwiIH19PntwYXJzZUZsb2F0KHNlbGVjdGVkUGFja2FnZXMudG90YWwpLnRvRml4ZWQoMil9IEFaTjwvZGVsPlxyXG4gICAgICAgICAgICAgICAgICAgPGI+e3BhcnNlRmxvYXQoc2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsKS50b0ZpeGVkKDIpfSBBWk48L2I+XHJcbiAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgIDogIDxiPntwYXJzZUZsb2F0KHNlbGVjdGVkUGFja2FnZXMuZGlzY291bnRUb3RhbCkudG9GaXhlZCgyKX0gQVpOPC9iPlxyXG4gICAgICAgICAgICAgICAgfSAgXHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYWNrYWdlX19idG5zXCI+XHJcbiAgICAgICAgICAgICAgPGZvcm0+XHJcbiAgICAgICAgICAgICAgICA8RnJvbUdyb3VwXHJcbiAgICAgICAgICAgICAgICAgIGJvZHlDbGFzcz1cImJnLXdoaXRlIHBsLXhzXCJcclxuICAgICAgICAgICAgICAgICAgYm9keVN0eWxlPXt7IGhlaWdodDogXCI0NHB4XCIsIHdpZHRoOiBcIjIwMHB4XCIgfX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXIteHMgY2huZ19fYm9keXN0eWxlXCJcclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiBcIjBweFwiIH19XHJcbiAgICAgICAgICAgICAgICAgIGVycm9yPXtlcnJvcnMucHJvbW9jb2RlPy5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17Zih7IGlkOiBcImFkZGNvZGVcIiB9KX1cclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicHJvbW9jb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICBSZWY9e3JlZ2lzdGVyKHtcclxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBmKHsgaWQ6IFwicHJvbW8tcmVxdWlyXCIgfSksXHJcbiAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkUGFja2FnZXMoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5zZWxlY3RlZFBhY2thZ2VzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2RlOiBlLnRhcmdldC52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRQYWNrYWdlcy5pc0FjY2VwdGVkID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b25Db21wb25lbnRcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIHctNTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGV4dERlY29yYXRpb25MaW5lOiBcInVuZGVybGluZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogXCJkYXJrYmx1ZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiBcIjBweCAxMHB4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJMyZnEn3YgZXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFBhY2thZ2VzKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5zZWxlY3RlZFBhY2thZ2VzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlzQWNjZXB0ZWQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uQ29tcG9uZW50XHJcbiAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IXNlbGVjdGVkUGFja2FnZXMuY29kZSA/IHRydWUgOiBmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHBhZGRpbmc6IFwiMCAxMHB4XCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNvbG9yLXdoaXRlIGJnLXN1Y2Nlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw9e2YoeyBpZDogXCJjb25maXJtXCIgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVN1Ym1pdChzdWJtaXQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gIG9uQ2xpY2s9eygpID0+e1xyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gICAgIC8vICBzZXRTZWxlY3RlZFBhY2thZ2VzKHtcclxuICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAvLyAgICAuLi5zZWxlY3RlZFBhY2thZ2VzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gICAgIC8vICAgIGlzQWNjZXB0ZWQ6dHJ1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gICAgIC8vICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgIC8vICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvRnJvbUdyb3VwPlxyXG4gICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICA8QnV0dG9uQ29tcG9uZW50XHJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyBwYWRkaW5nOiBcIjAgMjBweFwiIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjb2xvci13aGl0ZSBiZy1zdWNjZXNzIG1yLXhzIGRlc2tcIlxyXG4gICAgICAgICAgICAgICAgbGFiZWw9e2YoeyBpZDogXCJwYXlieWNhcmRcIiB9KX1cclxuICAgICAgICAgICAgICAgIGVuZEVsZW1lbnQ9ezxzcGFuIGNsYXNzTmFtZT1cImNvbG9yLXdoaXRlIHBsLXNtXCI+JiM4NTk0Ozwvc3Bhbj59XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrID0geygpID0+IFBheWJ5Q2FyZCh7XHJcbiAgICAgICAgICAgICAgICAgIHByaWNlOnNlbGVjdGVkUGFja2FnZXMuZGlzY291bnRUb3RhbCxcclxuICAgICAgICAgICAgICAgICAgc291cmNldHlwZToyXHJcbiAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxCdXR0b25Db21wb25lbnRcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IHBhZGRpbmc6IFwiMCAxMHB4XCIgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImRlc2tcIlxyXG4gICAgICAgICAgICAgICAgbGFiZWw9e2YoeyBpZDogXCJwYXlieWJhbGFuY2VcIiB9KX1cclxuICAgICAgICAgICAgICAgIGVuZEVsZW1lbnQ9e1xyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjb2xvci1ibGFjayBtci14cyBwbC1zbSBcIj4mIzg1OTQ7PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgb25DbGljayA9IHsoKSA9PiBwcm9wcy5QYXlCeUJhbGFuY2VBY3Rpb24oJ3BheW1lbnQnLHtcclxuICAgICAgICAgICAgICAgICAgcHJpY2U6c2VsZWN0ZWRQYWNrYWdlcy5kaXNjb3VudFRvdGFsLFxyXG4gICAgICAgICAgICAgICAgICBzb3VyY2V0eXBlOjMsXHJcbiAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgJ2F1dGhvcml6YXRpb24nOmBCZWFyZXIgJHtwcm9wcy5lbnRyeS51c2VyLmFjY2Vzc1Rva2VufWBcclxuICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYnRuX19ma2xcIj5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25Db21wb25lbnRcclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgcGFkZGluZzogXCIwIDEwcHhcIiB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjb2xvci13aGl0ZSBiZy1zdWNjZXNzIG1yLXhzXCJcclxuICAgICAgICAgICAgICAgICAgbGFiZWw9e2YoeyBpZDogXCJwYXlieWNhcmRcIiB9KX1cclxuICAgICAgICAgICAgICAgICAgZW5kRWxlbWVudD17XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY29sb3Itd2hpdGUgcGwtc21cIj4mIzg1OTQ7PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2sgPSB7KCkgPT4gUGF5YnlDYXJkKHtcclxuICAgICAgICAgICAgICAgICAgICBwcmljZTpzZWxlY3RlZFBhY2thZ2VzLmRpc2NvdW50VG90YWwsXHJcbiAgICAgICAgICAgICAgICAgICAgc291cmNldHlwZToyXHJcbiAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25Db21wb25lbnRcclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgcGFkZGluZzogXCIwIDEwcHhcIiB9fVxyXG4gICAgICAgICAgICAgICAgICBsYWJlbD17Zih7IGlkOiBcInBheWJ5YmFsYW5jZVwiIH0pfVxyXG4gICAgICAgICAgICAgICAgICBlbmRFbGVtZW50PXtcclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjb2xvci1ibGFjayBtci14cyBwbC1zbVwiPiYjODU5NDs8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgb25DbGljayA9IHsoKSA9PiBwcm9wcy5QYXlCeUJhbGFuY2VBY3Rpb24oJ3BheW1lbnQnLHtcclxuICAgICAgICAgICAgICAgICAgICBwcmljZTpzZWxlY3RlZFBhY2thZ2VzLmRpc2NvdW50VG90YWwsXHJcbiAgICAgICAgICAgICAgICAgICAgc291cmNldHlwZTozLFxyXG4gICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ2F1dGhvcml6YXRpb24nOmBCZWFyZXIgJHtwcm9wcy5lbnRyeS51c2VyLmFjY2Vzc1Rva2VufWBcclxuICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvQ2FyZD5cclxuXHJcbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwicC1zbSBiZy13aGl0ZVwiPlxyXG4gICAgICAgICAgPENhcmQuSGVhZGVyIHRleHQ9e2YoeyBpZDogXCJvcmRlci1oaXN0b3J5XCIgfSl9IC8+XHJcbiAgICAgICAgICA8Q2FyZC5Cb2R5IGNsYXNzTmFtZT1cInAtbm9uZSBvdmVyZmxvd19fcGFja2FnZVwiPlxyXG4gICAgICAgICAgICA8VGFiZWxcclxuICAgICAgICAgICAgICB0aD17W1xyXG4gICAgICAgICAgICAgICAgZih7IGlkOiBcInRyYWNraW5nXCIgfSksXHJcbiAgICAgICAgICAgICAgICBmKHsgaWQ6IFwic2hvcFwiIH0pLFxyXG4gICAgICAgICAgICAgICAgZih7IGlkOiBcImNhdGVnb3J5XCIgfSksXHJcbiAgICAgICAgICAgICAgICBmKHsgaWQ6IFwiYW1vdW50XCIgfSksXHJcbiAgICAgICAgICAgICAgICBmKHsgaWQ6IFwid2VpZ2h0XCIgfSksXHJcbiAgICAgICAgICAgICAgICBmKHsgaWQ6IFwiZGVsaXZlcnlcIiB9KSxcclxuICAgICAgICAgICAgICAgIGYoeyBpZDogXCJzdGF0dXNcIiB9KSxcclxuICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgIGRhdGE9e1xyXG4gICAgICAgICAgICAgICAgcGFja2FnZXMubWFwKCh4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGlmICh4LnN0YXR1cy5pZCA9PSA2KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgICAgICAgIHRyYWNrX251bWJlcjogeC50cmFja19udW1iZXIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG9wOiB4LnNob3AsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjYXRlZ29yeTogeC5jYXRlZ29yeSxcclxuICAgICAgICAgICAgICAgICAgICAgIHByaWNlOiBgJHt4LnByaWNlfSAke3guY3VycmVuY3l9YCxcclxuICAgICAgICAgICAgICAgICAgICAgIHdlaWdodDogYCR7cGFyc2VGbG9hdCh4LndlaWdodCkudG9GaXhlZCgyKSB8fCAwfSBrcWAsXHJcbiAgICAgICAgICAgICAgICAgICAgICBkZWxpdmVyeV9wcmljZTpcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGFyc2VGbG9hdCh4LmRlbGl2ZXJ5X3ByaWNlKS50b0ZpeGVkKDIpIHx8IDAsXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IGAke3guc3RhdHVzLm5hbWV9XFxuICR7eC5kYXRlfWAsXHJcbiAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSkgfHwgW11cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgcmVuZGVyQm9keT17KHgsIGkpID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiA8dGQga2V5PXtpKyt9Pnt4fTwvdGQ+O1xyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L0NhcmQuQm9keT5cclxuICAgICAgICA8L0NhcmQ+XHJcbiAgICAgIDwvTWFpbj5cclxuICAgIDwvUGFnZT5cclxuICApO1xyXG59XHJcblxyXG5jb25zdCBtYXBTdGF0ZVRvUHJvcHMgPSAoc3RhdGUpID0+ICh7XHJcbiAgZW50cnk6IHN0YXRlLmVudHJ5LFxyXG59KTtcclxuY29uc3QgbWFwRGlzcGF0Y2hUb1Byb3BzID0gIHtcclxuICBQYXlCeUJhbGFuY2VBY3Rpb25cclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3QobWFwU3RhdGVUb1Byb3BzLCBtYXBEaXNwYXRjaFRvUHJvcHMpKG1lbW8oUGFja2FnZXMpKTtcclxuIl0sInNvdXJjZVJvb3QiOiIifQ==