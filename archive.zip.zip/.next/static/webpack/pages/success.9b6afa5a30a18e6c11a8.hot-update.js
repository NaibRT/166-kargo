webpackHotUpdate_N_E("pages/success",{

/***/ "./pages/success.js":
/*!**************************!*\
  !*** ./pages/success.js ***!
  \**************************/
/*! exports provided: __N_SSP, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__N_SSP", function() { return __N_SSP; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _components_aside_menu_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/aside-menu/index */ "./components/aside-menu/index.js");
/* harmony import */ var _components_aside_aside__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/aside/aside */ "./components/aside/aside.js");
/* harmony import */ var _components_main_main__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/main/main */ "./components/main/main.js");
/* harmony import */ var _components_page_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../components/page/page */ "./components/page/page.js");
/* harmony import */ var _components_ResponcePage_ResponcePage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../components/ResponcePage/ResponcePage */ "./components/ResponcePage/ResponcePage.js");
/* harmony import */ var _redux_entry_entryActions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../redux/entry/entryActions */ "./redux/entry/entryActions.js");


var _jsxFileName = "C:\\Users\\Home\\Desktop\\166\\166-kargo\\pages\\success.js",
    _s = $RefreshSig$();










function SuccessPage(props) {
  _s();

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useLayoutEffect"])(function () {
    if (props.balance) {
      props.IncreaseBalanceAction(props.balance);
    }
  }, []);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_page_page__WEBPACK_IMPORTED_MODULE_6__["default"], {
    className: "bg-bg pt-lg pb-lg",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_aside_aside__WEBPACK_IMPORTED_MODULE_4__["default"], {
      className: "mr-sm",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_aside_menu_index__WEBPACK_IMPORTED_MODULE_3__["default"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 22,
        columnNumber: 11
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 21,
      columnNumber: 9
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_main_main__WEBPACK_IMPORTED_MODULE_5__["default"], {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_ResponcePage_ResponcePage__WEBPACK_IMPORTED_MODULE_7__["default"], {
        url: "/assets/icons/success.svg",
        msg: props.message
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 9
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 20,
    columnNumber: 9
  }, this);
}

_s(SuccessPage, "n7/vCynhJvM+pLkyL2DMQUF0odM=");

_c = SuccessPage;

var mapStateToProp = function mapStateToProp(state) {
  return {};
};

var mapDispatchToProps = {
  IncreaseBalanceAction: _redux_entry_entryActions__WEBPACK_IMPORTED_MODULE_8__["IncreaseBalanceAction"]
};
var __N_SSP = true;
/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToProp, mapDispatchToProps)( /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_1__["memo"])(SuccessPage)));

var _c;

$RefreshReg$(_c, "SuccessPage");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./redux/entry/entryActions.js":
/*!*************************************!*\
  !*** ./redux/entry/entryActions.js ***!
  \*************************************/
/*! exports provided: Login, UserRegister, LogOut, UpdateUser, PayByBalanceAction, IncreaseBalanceAction */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Login", function() { return Login; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserRegister", function() { return UserRegister; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogOut", function() { return LogOut; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UpdateUser", function() { return UpdateUser; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PayByBalanceAction", function() { return PayByBalanceAction; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IncreaseBalanceAction", function() { return IncreaseBalanceAction; });
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/regenerator */ "./node_modules/next/node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! sweetalert2 */ "./node_modules/sweetalert2/dist/sweetalert2.all.js");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./actions */ "./redux/entry/actions.js");






var Login = function Login(url, data) {
  var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return function (dispatch) {
    axios__WEBPACK_IMPORTED_MODULE_2___default.a.post("".concat("https://166api.titr.az/api/").concat(url), data, {
      headers: headers
    }).then( /*#__PURE__*/function () {
      var _ref = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(res) {
        var data;
        return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return res.data;

              case 2:
                data = _context.sent;
                dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["login"])(data));
                next_router__WEBPACK_IMPORTED_MODULE_3___default.a.push('/packages');

              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));

      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }())["catch"](function (errors) {
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["login"])({
        isError: true,
        errors: errors.response.data
      }));
    });
  };
};
var UserRegister = function UserRegister(url, data) {
  var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return function (dispatch) {
    axios__WEBPACK_IMPORTED_MODULE_2___default.a.post("".concat("https://166api.titr.az/api/").concat(url), data, {
      headers: headers
    }).then( /*#__PURE__*/function () {
      var _ref2 = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2(res) {
        var data;
        return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                sweetalert2__WEBPACK_IMPORTED_MODULE_4___default.a.fire({
                  text: 'Əməliyyat uğurla tamamlandı',
                  icon: 'success',
                  confirmButtonText: 'OK'
                }).then(function (res) {
                  if (res.isConfirmed) {
                    next_router__WEBPACK_IMPORTED_MODULE_3___default.a.push('/myaddresses');
                  }
                });
                _context2.next = 3;
                return res.data;

              case 3:
                data = _context2.sent;
                dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["register"])(data));

              case 5:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }));

      return function (_x2) {
        return _ref2.apply(this, arguments);
      };
    }())["catch"](function (err) {
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["register"])({
        isError: true,
        errors: err.response.data
      }));
    });
  };
};
var LogOut = function LogOut() {
  return function (dispatch) {
    console.log('wordek logout');
    dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["logout"])());
  };
};
var UpdateUser = function UpdateUser(url, data) {
  var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return function (dispatch) {
    axios__WEBPACK_IMPORTED_MODULE_2___default.a.put("".concat("https://166api.titr.az/api/").concat(url), data, {
      headers: headers
    }).then(function (res) {
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["updateUser"])(res.data));
      sweetalert2__WEBPACK_IMPORTED_MODULE_4___default.a.fire({
        text: 'Əməliyyat uğurla yerinə yetirildi',
        icon: 'success',
        confirmButtonText: 'OK'
      });
    })["catch"](function (err) {
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["updateUser"])({
        isError: true,
        errors: err.response.data
      }));
    });
  };
};
var PayByBalanceAction = function PayByBalanceAction(url, data, headers) {
  return function (dispatch) {
    axios__WEBPACK_IMPORTED_MODULE_2___default.a.post("".concat("https://166api.titr.az/api/").concat(url), data, {
      headers: headers
    }).then(function (res) {
      if (res.status == 'success') {
        sweetalert2__WEBPACK_IMPORTED_MODULE_4___default.a.fire({
          text: res.data.message,
          icon: 'success',
          confirmButtonText: 'OK'
        });
        dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["PayByBalance"])(data.balance));
      }
    })["catch"](function (err) {
      return console.log(err);
    });
  };
};
var IncreaseBalanceAction = function IncreaseBalanceAction(balance) {
  return function (dispatch) {
    dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["IncreaseBalance"])(balance));
  };
};

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvc3VjY2Vzcy5qcyIsIndlYnBhY2s6Ly9fTl9FLy4vcmVkdXgvZW50cnkvZW50cnlBY3Rpb25zLmpzIl0sIm5hbWVzIjpbIlN1Y2Nlc3NQYWdlIiwicHJvcHMiLCJ1c2VMYXlvdXRFZmZlY3QiLCJiYWxhbmNlIiwiSW5jcmVhc2VCYWxhbmNlQWN0aW9uIiwibWVzc2FnZSIsIm1hcFN0YXRlVG9Qcm9wIiwic3RhdGUiLCJtYXBEaXNwYXRjaFRvUHJvcHMiLCJjb25uZWN0IiwibWVtbyIsIkxvZ2luIiwidXJsIiwiZGF0YSIsImhlYWRlcnMiLCJkaXNwYXRjaCIsImF4aW9zIiwicG9zdCIsInByb2Nlc3MiLCJ0aGVuIiwicmVzIiwibG9naW4iLCJyb3V0ZXIiLCJwdXNoIiwiZXJyb3JzIiwiaXNFcnJvciIsInJlc3BvbnNlIiwiVXNlclJlZ2lzdGVyIiwiU3dhbCIsImZpcmUiLCJ0ZXh0IiwiaWNvbiIsImNvbmZpcm1CdXR0b25UZXh0IiwiaXNDb25maXJtZWQiLCJyZWdpc3RlciIsImVyciIsIkxvZ091dCIsImNvbnNvbGUiLCJsb2ciLCJsb2dvdXQiLCJVcGRhdGVVc2VyIiwicHV0IiwidXBkYXRlVXNlciIsIlBheUJ5QmFsYW5jZUFjdGlvbiIsInN0YXR1cyIsIlBheUJ5QmFsYW5jZSIsIkluY3JlYXNlQmFsYW5jZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBS0MsU0FBU0EsV0FBVCxDQUFxQkMsS0FBckIsRUFBNEI7QUFBQTs7QUFDNUJDLCtEQUFlLENBQUMsWUFBTTtBQUNuQixRQUFHRCxLQUFLLENBQUNFLE9BQVQsRUFBaUI7QUFDZkYsV0FBSyxDQUFDRyxxQkFBTixDQUE0QkgsS0FBSyxDQUFDRSxPQUFsQztBQUNEO0FBQ0gsR0FKYyxFQUliLEVBSmEsQ0FBZjtBQUtHLHNCQUNJLHFFQUFDLDZEQUFEO0FBQU0sYUFBUyxFQUFDLG1CQUFoQjtBQUFBLDRCQUNBLHFFQUFDLCtEQUFEO0FBQU8sZUFBUyxFQUFDLE9BQWpCO0FBQUEsNkJBQ0UscUVBQUMsb0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFEQSxlQUlBLHFFQUFDLDZEQUFEO0FBQUEsNkJBQ0EscUVBQUMsNkVBQUQ7QUFBYyxXQUFHLEVBQUMsMkJBQWxCO0FBQ0UsV0FBRyxFQUFFRixLQUFLLENBQUNJO0FBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFKQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFESjtBQVlIOztHQWxCU0wsVzs7S0FBQUEsVzs7QUE4QlYsSUFBTU0sY0FBYyxHQUFHLFNBQWpCQSxjQUFpQixDQUFBQyxLQUFLO0FBQUEsU0FBSyxFQUFMO0FBQUEsQ0FBNUI7O0FBR0EsSUFBTUMsa0JBQWtCLEdBQUc7QUFDekJKLHVCQUFxQixFQUFyQkEsK0VBQXFCQTtBQURJLENBQTNCOztBQUllSywwSEFBTyxDQUFDSCxjQUFELEVBQWdCRSxrQkFBaEIsQ0FBUCxlQUEyQ0Usa0RBQUksQ0FBQ1YsV0FBRCxDQUEvQyxDQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2hEQTtBQUNBO0FBQ0E7QUFDQTtBQUVPLElBQU1XLEtBQUssR0FBRyxTQUFSQSxLQUFRLENBQUNDLEdBQUQsRUFBS0MsSUFBTDtBQUFBLE1BQVVDLE9BQVYsdUVBQW9CLEVBQXBCO0FBQUEsU0FBMkIsVUFBQUMsUUFBUSxFQUFJO0FBQ3hEQyxnREFBSyxDQUFDQyxJQUFOLFdBQWNDLDZCQUFkLFNBQWdETixHQUFoRCxHQUFzREMsSUFBdEQsRUFBMkQ7QUFDdkRDLGFBQU8sRUFBQ0E7QUFEK0MsS0FBM0QsRUFHR0ssSUFISDtBQUFBLG9VQUdRLGlCQUFNQyxHQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQ2FBLEdBQUcsQ0FBQ1AsSUFEakI7O0FBQUE7QUFDQUEsb0JBREE7QUFFSkUsd0JBQVEsQ0FBQ00sc0RBQUssQ0FBQ1IsSUFBRCxDQUFOLENBQVI7QUFDQVMsa0VBQU0sQ0FBQ0MsSUFBUCxDQUFZLFdBQVo7O0FBSEk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FIUjs7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFPVyxVQUFBQyxNQUFNLEVBQUk7QUFDakJULGNBQVEsQ0FBQ00sc0RBQUssQ0FBQztBQUFDSSxlQUFPLEVBQUMsSUFBVDtBQUFjRCxjQUFNLEVBQUNBLE1BQU0sQ0FBQ0UsUUFBUCxDQUFnQmI7QUFBckMsT0FBRCxDQUFOLENBQVI7QUFDRCxLQVRIO0FBVUgsR0FYb0I7QUFBQSxDQUFkO0FBY0EsSUFBTWMsWUFBWSxHQUFHLFNBQWZBLFlBQWUsQ0FBQ2YsR0FBRCxFQUFLQyxJQUFMO0FBQUEsTUFBVUMsT0FBVix1RUFBb0IsRUFBcEI7QUFBQSxTQUEyQixVQUFBQyxRQUFRLEVBQUk7QUFDakVDLGdEQUFLLENBQUNDLElBQU4sV0FBY0MsNkJBQWQsU0FBZ0ROLEdBQWhELEdBQXNEQyxJQUF0RCxFQUEyRDtBQUN2REMsYUFBTyxFQUFDQTtBQUQrQyxLQUEzRCxFQUdHSyxJQUhIO0FBQUEscVVBR1Esa0JBQU1DLEdBQU47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0pRLGtFQUFJLENBQUNDLElBQUwsQ0FBVTtBQUNSQyxzQkFBSSxFQUFFLDZCQURFO0FBRVJDLHNCQUFJLEVBQUUsU0FGRTtBQUdSQyxtQ0FBaUIsRUFBRTtBQUhYLGlCQUFWLEVBSUdiLElBSkgsQ0FJUSxVQUFBQyxHQUFHLEVBQUk7QUFDYixzQkFBR0EsR0FBRyxDQUFDYSxXQUFQLEVBQW1CO0FBQ2pCWCxzRUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWjtBQUNEO0FBQ0YsaUJBUkQ7QUFESTtBQUFBLHVCQVVhSCxHQUFHLENBQUNQLElBVmpCOztBQUFBO0FBVUFBLG9CQVZBO0FBV0pFLHdCQUFRLENBQUNtQix5REFBUSxDQUFDckIsSUFBRCxDQUFULENBQVI7O0FBWEk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FIUjs7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFlVyxVQUFBc0IsR0FBRyxFQUFJO0FBQ2RwQixjQUFRLENBQUNtQix5REFBUSxDQUFDO0FBQUNULGVBQU8sRUFBQyxJQUFUO0FBQWNELGNBQU0sRUFBQ1csR0FBRyxDQUFDVCxRQUFKLENBQWFiO0FBQWxDLE9BQUQsQ0FBVCxDQUFSO0FBQ0QsS0FqQkg7QUFrQkQsR0FuQjJCO0FBQUEsQ0FBckI7QUFxQkEsSUFBTXVCLE1BQU0sR0FBRyxTQUFUQSxNQUFTO0FBQUEsU0FBTSxVQUFBckIsUUFBUSxFQUFJO0FBQ3JDc0IsV0FBTyxDQUFDQyxHQUFSLENBQVksZUFBWjtBQUNDdkIsWUFBUSxDQUFDd0IsdURBQU0sRUFBUCxDQUFSO0FBQ0gsR0FIcUI7QUFBQSxDQUFmO0FBS0EsSUFBTUMsVUFBVSxHQUFHLFNBQWJBLFVBQWEsQ0FBQzVCLEdBQUQsRUFBS0MsSUFBTDtBQUFBLE1BQVVDLE9BQVYsdUVBQW9CLEVBQXBCO0FBQUEsU0FBMkIsVUFBQUMsUUFBUSxFQUFJO0FBRTdEQyxnREFBSyxDQUFDeUIsR0FBTixXQUFhdkIsNkJBQWIsU0FBK0NOLEdBQS9DLEdBQXFEQyxJQUFyRCxFQUEwRDtBQUN0REMsYUFBTyxFQUFFQTtBQUQ2QyxLQUExRCxFQUdHSyxJQUhILENBR1MsVUFBQUMsR0FBRyxFQUFJO0FBQ1pMLGNBQVEsQ0FBQzJCLDJEQUFVLENBQUN0QixHQUFHLENBQUNQLElBQUwsQ0FBWCxDQUFSO0FBQ0NlLHdEQUFJLENBQUNDLElBQUwsQ0FBVTtBQUNSQyxZQUFJLEVBQUUsbUNBREU7QUFFUkMsWUFBSSxFQUFFLFNBRkU7QUFHUkMseUJBQWlCLEVBQUU7QUFIWCxPQUFWO0FBS0YsS0FWSCxXQVdTLFVBQUFHLEdBQUcsRUFBSTtBQUNacEIsY0FBUSxDQUFDMkIsMkRBQVUsQ0FBQztBQUFDakIsZUFBTyxFQUFDLElBQVQ7QUFBY0QsY0FBTSxFQUFDVyxHQUFHLENBQUNULFFBQUosQ0FBYWI7QUFBbEMsT0FBRCxDQUFYLENBQVI7QUFDRCxLQWJIO0FBZUgsR0FqQnlCO0FBQUEsQ0FBbkI7QUFtQkUsSUFBTThCLGtCQUFrQixHQUFHLFNBQXJCQSxrQkFBcUIsQ0FBQy9CLEdBQUQsRUFBS0MsSUFBTCxFQUFVQyxPQUFWO0FBQUEsU0FBc0IsVUFBQUMsUUFBUSxFQUFJO0FBQ2xFQyxnREFBSyxDQUFDQyxJQUFOLFdBQWNDLDZCQUFkLFNBQWdETixHQUFoRCxHQUFzREMsSUFBdEQsRUFBMkQ7QUFDekRDLGFBQU8sRUFBQ0E7QUFEaUQsS0FBM0QsRUFFR0ssSUFGSCxDQUVRLFVBQUFDLEdBQUcsRUFBSTtBQUNiLFVBQUdBLEdBQUcsQ0FBQ3dCLE1BQUosSUFBYyxTQUFqQixFQUEyQjtBQUN6QmhCLDBEQUFJLENBQUNDLElBQUwsQ0FBVTtBQUNSQyxjQUFJLEVBQUVWLEdBQUcsQ0FBQ1AsSUFBSixDQUFTUixPQURQO0FBRVIwQixjQUFJLEVBQUUsU0FGRTtBQUdSQywyQkFBaUIsRUFBRTtBQUhYLFNBQVY7QUFLQWpCLGdCQUFRLENBQUM4Qiw2REFBWSxDQUFDaEMsSUFBSSxDQUFDVixPQUFOLENBQWIsQ0FBUjtBQUNEO0FBQ0YsS0FYRCxXQVdTLFVBQUFnQyxHQUFHO0FBQUEsYUFBSUUsT0FBTyxDQUFDQyxHQUFSLENBQVlILEdBQVosQ0FBSjtBQUFBLEtBWFo7QUFZRCxHQWJpQztBQUFBLENBQTNCO0FBZUYsSUFBTS9CLHFCQUFxQixHQUFHLFNBQXhCQSxxQkFBd0IsQ0FBQ0QsT0FBRDtBQUFBLFNBQWEsVUFBQVksUUFBUSxFQUFJO0FBQzFEQSxZQUFRLENBQUMrQixnRUFBZSxDQUFDM0MsT0FBRCxDQUFoQixDQUFSO0FBQ0gsR0FGb0M7QUFBQSxDQUE5QiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9zdWNjZXNzLjliNmFmYTVhMzBhMThlNmMxMWE4LmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgbWVtbywgdXNlTGF5b3V0RWZmZWN0IH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IGNvbm5lY3QgfSBmcm9tIFwicmVhY3QtcmVkdXhcIlxyXG5pbXBvcnQgQXNpZGVNZW51IGZyb20gXCIuLi9jb21wb25lbnRzL2FzaWRlLW1lbnUvaW5kZXhcIlxyXG5pbXBvcnQgQXNpZGUgZnJvbSAnLi4vY29tcG9uZW50cy9hc2lkZS9hc2lkZSdcclxuaW1wb3J0IE1haW4gZnJvbSAnLi4vY29tcG9uZW50cy9tYWluL21haW4nXHJcbmltcG9ydCBQYWdlIGZyb20gJy4uL2NvbXBvbmVudHMvcGFnZS9wYWdlJ1xyXG5pbXBvcnQgUmVzcG9uY2VQYWdlIGZyb20gJy4uL2NvbXBvbmVudHMvUmVzcG9uY2VQYWdlL1Jlc3BvbmNlUGFnZSdcclxuaW1wb3J0XHJcbiAge1xyXG4gICAgSW5jcmVhc2VCYWxhbmNlQWN0aW9uXHJcbiAgfSBmcm9tICcuLi9yZWR1eC9lbnRyeS9lbnRyeUFjdGlvbnMnXHJcblxyXG4gZnVuY3Rpb24gU3VjY2Vzc1BhZ2UocHJvcHMpIHsgICAgICBcclxuIHVzZUxheW91dEVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZihwcm9wcy5iYWxhbmNlKXtcclxuICAgICAgcHJvcHMuSW5jcmVhc2VCYWxhbmNlQWN0aW9uKHByb3BzLmJhbGFuY2UpO1xyXG4gICAgfVxyXG4gfSxbXSlcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPFBhZ2UgY2xhc3NOYW1lPVwiYmctYmcgcHQtbGcgcGItbGdcIj5cclxuICAgICAgICA8QXNpZGUgY2xhc3NOYW1lPVwibXItc21cIj5cclxuICAgICAgICAgIDxBc2lkZU1lbnUgLz5cclxuICAgICAgICA8L0FzaWRlPlxyXG4gICAgICAgIDxNYWluPlxyXG4gICAgICAgIDxSZXNwb25jZVBhZ2UgdXJsPScvYXNzZXRzL2ljb25zL3N1Y2Nlc3Muc3ZnJ1xyXG4gICAgICAgICAgbXNnPXtwcm9wcy5tZXNzYWdlfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPC9NYWluPlxyXG4gICAgICAgIDwvUGFnZT5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcnZlclNpZGVQcm9wcyh7cXVlcnl9KSB7XHJcblxyXG4gIHJldHVybiB7XHJcbiAgICBwcm9wczoge1xyXG4gICAgICBiYWxhbmNlOiBxdWVyeS5iYWxhbmNlID8gcXVlcnkuYmFsYW5jZSA6IG51bGwsXHJcbiAgICAgIG1lc3NhZ2U6IHF1ZXJ5Lm1lc3NhZ2UsXHJcbiAgICB9LFxyXG4gIH1cclxuXHJcbn1cclxuY29uc3QgbWFwU3RhdGVUb1Byb3AgPSBzdGF0ZSA9PiAoe1xyXG4gIFxyXG59KTtcclxuY29uc3QgbWFwRGlzcGF0Y2hUb1Byb3BzID0ge1xyXG4gIEluY3JlYXNlQmFsYW5jZUFjdGlvblxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBjb25uZWN0KG1hcFN0YXRlVG9Qcm9wLG1hcERpc3BhdGNoVG9Qcm9wcykobWVtbyhTdWNjZXNzUGFnZSkpXHJcbiIsIlxyXG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCByb3V0ZXIgZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcbmltcG9ydCBTd2FsIGZyb20gXCJzd2VldGFsZXJ0MlwiO1xyXG5pbXBvcnQgeyBJbmNyZWFzZUJhbGFuY2UsIGxvZ2luLCBsb2dvdXQsIFBheUJ5QmFsYW5jZSwgcmVnaXN0ZXIsIHVwZGF0ZVVzZXIgfSBmcm9tIFwiLi9hY3Rpb25zXCI7XHJcblxyXG5leHBvcnQgY29uc3QgTG9naW4gPSAodXJsLGRhdGEsaGVhZGVycyA9IHt9KSA9PiBkaXNwYXRjaCA9PiB7XHJcbiAgICBheGlvcy5wb3N0KGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9JHt1cmx9YCxkYXRhLHtcclxuICAgICAgICBoZWFkZXJzOmhlYWRlcnMsXHJcbiAgICAgIH0pXHJcbiAgICAgIC50aGVuKGFzeW5jIHJlcyA9PiB7XHJcbiAgICAgICAgbGV0IGRhdGEgPSBhd2FpdCByZXMuZGF0YTtcclxuICAgICAgICBkaXNwYXRjaChsb2dpbihkYXRhKSlcclxuICAgICAgICByb3V0ZXIucHVzaCgnL3BhY2thZ2VzJylcclxuICAgICAgfSkuY2F0Y2goZXJyb3JzID0+IHtcclxuICAgICAgICBkaXNwYXRjaChsb2dpbih7aXNFcnJvcjp0cnVlLGVycm9yczplcnJvcnMucmVzcG9uc2UuZGF0YX0pKVxyXG4gICAgICB9KVxyXG59XHJcblxyXG5cclxuZXhwb3J0IGNvbnN0IFVzZXJSZWdpc3RlciA9ICh1cmwsZGF0YSxoZWFkZXJzID0ge30pID0+IGRpc3BhdGNoID0+IHtcclxuICBheGlvcy5wb3N0KGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9JHt1cmx9YCxkYXRhLHtcclxuICAgICAgaGVhZGVyczpoZWFkZXJzLFxyXG4gICAgfSlcclxuICAgIC50aGVuKGFzeW5jIHJlcyA9PiB7XHJcbiAgICAgIFN3YWwuZmlyZSh7XHJcbiAgICAgICAgdGV4dDogJ8aPbcmZbGl5eWF0IHXEn3VybGEgdGFtYW1sYW5kxLEnLFxyXG4gICAgICAgIGljb246ICdzdWNjZXNzJyxcclxuICAgICAgICBjb25maXJtQnV0dG9uVGV4dDogJ09LJyxcclxuICAgICAgfSkudGhlbihyZXMgPT4ge1xyXG4gICAgICAgIGlmKHJlcy5pc0NvbmZpcm1lZCl7XHJcbiAgICAgICAgICByb3V0ZXIucHVzaCgnL215YWRkcmVzc2VzJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgICBsZXQgZGF0YSA9IGF3YWl0IHJlcy5kYXRhO1xyXG4gICAgICBkaXNwYXRjaChyZWdpc3RlcihkYXRhKSlcclxuICAgIH0pLmNhdGNoKGVyciA9PiB7XHJcbiAgICAgIGRpc3BhdGNoKHJlZ2lzdGVyKHtpc0Vycm9yOnRydWUsZXJyb3JzOmVyci5yZXNwb25zZS5kYXRhfSkpXHJcbiAgICB9KVxyXG59XHJcblxyXG5leHBvcnQgY29uc3QgTG9nT3V0ID0gKCkgPT4gZGlzcGF0Y2ggPT4ge1xyXG4gICBjb25zb2xlLmxvZygnd29yZGVrIGxvZ291dCcpXHJcbiAgICBkaXNwYXRjaChsb2dvdXQoKSlcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IFVwZGF0ZVVzZXIgPSAodXJsLGRhdGEsaGVhZGVycyA9IHt9KSA9PiBkaXNwYXRjaCA9PiB7XHJcblxyXG4gICAgYXhpb3MucHV0KGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9JHt1cmx9YCxkYXRhLHtcclxuICAgICAgICBoZWFkZXJzOiBoZWFkZXJzXHJcbiAgICAgIH0pXHJcbiAgICAgIC50aGVuKCByZXMgPT4ge1xyXG4gICAgICAgIGRpc3BhdGNoKHVwZGF0ZVVzZXIocmVzLmRhdGEpKVxyXG4gICAgICAgICBTd2FsLmZpcmUoe1xyXG4gICAgICAgICAgIHRleHQ6ICfGj23JmWxpeXlhdCB1xJ91cmxhIHllcmluyZkgeWV0aXJpbGRpJyxcclxuICAgICAgICAgICBpY29uOiAnc3VjY2VzcycsXHJcbiAgICAgICAgICAgY29uZmlybUJ1dHRvblRleHQ6ICdPSycsXHJcbiAgICAgICAgIH0pXHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaChlcnIgPT4ge1xyXG4gICAgICAgIGRpc3BhdGNoKHVwZGF0ZVVzZXIoe2lzRXJyb3I6dHJ1ZSxlcnJvcnM6ZXJyLnJlc3BvbnNlLmRhdGF9KSlcclxuICAgICAgfSlcclxuICBcclxufVxyXG5cclxuICBleHBvcnQgY29uc3QgUGF5QnlCYWxhbmNlQWN0aW9uID0gKHVybCxkYXRhLGhlYWRlcnMpID0+IGRpc3BhdGNoID0+IHtcclxuICAgIGF4aW9zLnBvc3QoYCR7cHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQVBJX1VSTH0ke3VybH1gLGRhdGEse1xyXG4gICAgICBoZWFkZXJzOmhlYWRlcnMsXHJcbiAgICB9KS50aGVuKHJlcyA9PiB7XHJcbiAgICAgIGlmKHJlcy5zdGF0dXMgPT0gJ3N1Y2Nlc3MnKXsgXHJcbiAgICAgICAgU3dhbC5maXJlKHtcclxuICAgICAgICAgIHRleHQ6IHJlcy5kYXRhLm1lc3NhZ2UsXHJcbiAgICAgICAgICBpY29uOiAnc3VjY2VzcycsXHJcbiAgICAgICAgICBjb25maXJtQnV0dG9uVGV4dDogJ09LJyxcclxuICAgICAgICB9KTtcclxuICAgICAgICBkaXNwYXRjaChQYXlCeUJhbGFuY2UoZGF0YS5iYWxhbmNlKSlcclxuICAgICAgfVxyXG4gICAgfSkuY2F0Y2goZXJyID0+IGNvbnNvbGUubG9nKGVycikpO1xyXG4gIH1cclxuXHJcbmV4cG9ydCBjb25zdCBJbmNyZWFzZUJhbGFuY2VBY3Rpb24gPSAoYmFsYW5jZSkgPT4gZGlzcGF0Y2ggPT4ge1xyXG4gICAgZGlzcGF0Y2goSW5jcmVhc2VCYWxhbmNlKGJhbGFuY2UpKVxyXG59XHJcblxyXG5cclxuXHJcbiJdLCJzb3VyY2VSb290IjoiIn0=