webpackHotUpdate_N_E("pages/_app",{

/***/ "./redux/entry/entryActions.js":
/*!*************************************!*\
  !*** ./redux/entry/entryActions.js ***!
  \*************************************/
/*! exports provided: Login, UserRegister, LogOut, UpdateUser, PayByBalanceAction, IncreaseBalanceAction */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Login", function() { return Login; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserRegister", function() { return UserRegister; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogOut", function() { return LogOut; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UpdateUser", function() { return UpdateUser; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PayByBalanceAction", function() { return PayByBalanceAction; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IncreaseBalanceAction", function() { return IncreaseBalanceAction; });
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/regenerator */ "./node_modules/next/node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! sweetalert2 */ "./node_modules/sweetalert2/dist/sweetalert2.all.js");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./actions */ "./redux/entry/actions.js");






var Login = function Login(url, data) {
  var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return function (dispatch) {
    axios__WEBPACK_IMPORTED_MODULE_2___default.a.post("".concat("https://166api.titr.az/api/").concat(url), data, {
      headers: headers
    }).then( /*#__PURE__*/function () {
      var _ref = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(res) {
        var data;
        return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return res.data;

              case 2:
                data = _context.sent;
                dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["login"])(data));
                next_router__WEBPACK_IMPORTED_MODULE_3___default.a.push('/packages');

              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));

      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }())["catch"](function (errors) {
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["login"])({
        isError: true,
        errors: errors.response.data
      }));
    });
  };
};
var UserRegister = function UserRegister(url, data) {
  var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return function (dispatch) {
    axios__WEBPACK_IMPORTED_MODULE_2___default.a.post("".concat("https://166api.titr.az/api/").concat(url), data, {
      headers: headers
    }).then( /*#__PURE__*/function () {
      var _ref2 = Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2(res) {
        var data;
        return C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                sweetalert2__WEBPACK_IMPORTED_MODULE_4___default.a.fire({
                  text: 'Əməliyyat uğurla tamamlandı',
                  icon: 'success',
                  confirmButtonText: 'OK'
                }).then(function (res) {
                  if (res.isConfirmed) {
                    next_router__WEBPACK_IMPORTED_MODULE_3___default.a.push('/myaddresses');
                  }
                });
                _context2.next = 3;
                return res.data;

              case 3:
                data = _context2.sent;
                dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["register"])(data));

              case 5:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }));

      return function (_x2) {
        return _ref2.apply(this, arguments);
      };
    }())["catch"](function (err) {
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["register"])({
        isError: true,
        errors: err.response.data
      }));
    });
  };
};
var LogOut = function LogOut() {
  return function (dispatch) {
    console.log('wordek logout');
    dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["logout"])());
  };
};
var UpdateUser = function UpdateUser(url, data) {
  var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return function (dispatch) {
    axios__WEBPACK_IMPORTED_MODULE_2___default.a.put("".concat("https://166api.titr.az/api/").concat(url), data, {
      headers: headers
    }).then(function (res) {
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["updateUser"])(res.data));
      sweetalert2__WEBPACK_IMPORTED_MODULE_4___default.a.fire({
        text: 'Əməliyyat uğurla yerinə yetirildi',
        icon: 'success',
        confirmButtonText: 'OK'
      });
    })["catch"](function (err) {
      dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["updateUser"])({
        isError: true,
        errors: err.response.data
      }));
    });
  };
};
var PayByBalanceAction = function PayByBalanceAction(url, data, headers) {
  return function (dispatch) {
    axios__WEBPACK_IMPORTED_MODULE_2___default.a.post("".concat("https://166api.titr.az/api/").concat(url), data, {
      headers: headers
    }).then(function (res) {
      if (res.status == 'success') {
        sweetalert2__WEBPACK_IMPORTED_MODULE_4___default.a.fire({
          text: res.data.message,
          icon: 'success',
          confirmButtonText: 'OK'
        });
        dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["PayByBalance"])(data.balance));
      }
    })["catch"](function (err) {
      return console.log(err);
    });
  };
};
var IncreaseBalanceAction = function IncreaseBalanceAction(balance) {
  return function (dispatch) {
    dispatch(Object(_actions__WEBPACK_IMPORTED_MODULE_5__["IncreaseBalance"])(balance));
  };
};

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./redux/entry/reducer.js":
/*!********************************!*\
  !*** ./redux/entry/reducer.js ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! redux-persist */ "./node_modules/redux-persist/es/index.js");
/* harmony import */ var _actionTypes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./actionTypes */ "./redux/entry/actionTypes.js");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_Users_Home_Desktop_166_166_kargo_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }



var initialState = {
  user: {},
  errorMessages: {},
  isLoged: false
};

var entryReducer = function entryReducer() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : initialState;
  var action = arguments.length > 1 ? arguments[1] : undefined;

  switch (action.type) {
    case redux_persist__WEBPACK_IMPORTED_MODULE_1__["REHYDRATE"]:
      break;

    case _actionTypes__WEBPACK_IMPORTED_MODULE_2__["LOGIN"]:
      if (action.payload.isError) {
        state = _objectSpread(_objectSpread({}, state), {}, {
          errorMessages: _objectSpread({}, action.payload.errors)
        });
      } else {
        state = _objectSpread(_objectSpread({}, state), {}, {
          errorMessages: {},
          user: _objectSpread({}, action.payload),
          isLoged: true
        });
      }

      break;

    case _actionTypes__WEBPACK_IMPORTED_MODULE_2__["LOGOUT"]:
      state = {
        user: {},
        errorMessages: [],
        isLoged: false
      };
      break;

    case _actionTypes__WEBPACK_IMPORTED_MODULE_2__["REGISTER"]:
      if (action.payload.isError) {
        state = _objectSpread(_objectSpread({}, state), {}, {
          errorMessages: _objectSpread({}, action.payload.errors)
        });
      } else {
        state = {
          user: _objectSpread({}, action.payload),
          errorMessages: {},
          isLoged: false
        };
      }

      break;

    case _actionTypes__WEBPACK_IMPORTED_MODULE_2__["UPDATE_USER"]:
      if (action.payload.isError) {
        state = _objectSpread(_objectSpread({}, state), {}, {
          user: _objectSpread({}, state.user),
          errorMessages: _objectSpread({}, action.payload.errors)
        });
      } else {
        state = _objectSpread(_objectSpread({}, state), {}, {
          user: _objectSpread(_objectSpread({}, state.user), {}, {
            user: _objectSpread({}, action.payload.user)
          }),
          errorMessages: {}
        });
      }

      break;

    case _actionTypes__WEBPACK_IMPORTED_MODULE_2__["INCREASE_BALANCE"]:
      state = _objectSpread(_objectSpread({}, state), {}, {
        user: _objectSpread(_objectSpread({}, state.user), {}, {
          user: _objectSpread(_objectSpread({}, state.user.user), {}, {
            balance: action.payload
          })
        })
      });
      break;

    case _actionTypes__WEBPACK_IMPORTED_MODULE_2__["PAY_BY_BALANCE"]:
      state = _objectSpread(_objectSpread({}, state), {}, {
        user: _objectSpread(_objectSpread({}, state.user), {}, {
          user: _objectSpread(_objectSpread({}, action.payload.user), {}, {
            balance: action.payload.user - action.payload
          })
        })
      });
      break;

    default:
      state = _objectSpread({}, state);
      break;
  }

  return state;
};

/* harmony default export */ __webpack_exports__["default"] = (entryReducer);

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcmVkdXgvZW50cnkvZW50cnlBY3Rpb25zLmpzIiwid2VicGFjazovL19OX0UvLi9yZWR1eC9lbnRyeS9yZWR1Y2VyLmpzIl0sIm5hbWVzIjpbIkxvZ2luIiwidXJsIiwiZGF0YSIsImhlYWRlcnMiLCJkaXNwYXRjaCIsImF4aW9zIiwicG9zdCIsInByb2Nlc3MiLCJ0aGVuIiwicmVzIiwibG9naW4iLCJyb3V0ZXIiLCJwdXNoIiwiZXJyb3JzIiwiaXNFcnJvciIsInJlc3BvbnNlIiwiVXNlclJlZ2lzdGVyIiwiU3dhbCIsImZpcmUiLCJ0ZXh0IiwiaWNvbiIsImNvbmZpcm1CdXR0b25UZXh0IiwiaXNDb25maXJtZWQiLCJyZWdpc3RlciIsImVyciIsIkxvZ091dCIsImNvbnNvbGUiLCJsb2ciLCJsb2dvdXQiLCJVcGRhdGVVc2VyIiwicHV0IiwidXBkYXRlVXNlciIsIlBheUJ5QmFsYW5jZUFjdGlvbiIsInN0YXR1cyIsIm1lc3NhZ2UiLCJQYXlCeUJhbGFuY2UiLCJiYWxhbmNlIiwiSW5jcmVhc2VCYWxhbmNlQWN0aW9uIiwiSW5jcmVhc2VCYWxhbmNlIiwiaW5pdGlhbFN0YXRlIiwidXNlciIsImVycm9yTWVzc2FnZXMiLCJpc0xvZ2VkIiwiZW50cnlSZWR1Y2VyIiwic3RhdGUiLCJhY3Rpb24iLCJ0eXBlIiwiUkVIWURSQVRFIiwiTE9HSU4iLCJwYXlsb2FkIiwiTE9HT1VUIiwiUkVHSVNURVIiLCJVUERBVEVfVVNFUiIsIklOQ1JFQVNFX0JBTEFOQ0UiLCJQQVlfQllfQkFMQU5DRSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVPLElBQU1BLEtBQUssR0FBRyxTQUFSQSxLQUFRLENBQUNDLEdBQUQsRUFBS0MsSUFBTDtBQUFBLE1BQVVDLE9BQVYsdUVBQW9CLEVBQXBCO0FBQUEsU0FBMkIsVUFBQUMsUUFBUSxFQUFJO0FBQ3hEQyxnREFBSyxDQUFDQyxJQUFOLFdBQWNDLDZCQUFkLFNBQWdETixHQUFoRCxHQUFzREMsSUFBdEQsRUFBMkQ7QUFDdkRDLGFBQU8sRUFBQ0E7QUFEK0MsS0FBM0QsRUFHR0ssSUFISDtBQUFBLG9VQUdRLGlCQUFNQyxHQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQ2FBLEdBQUcsQ0FBQ1AsSUFEakI7O0FBQUE7QUFDQUEsb0JBREE7QUFFSkUsd0JBQVEsQ0FBQ00sc0RBQUssQ0FBQ1IsSUFBRCxDQUFOLENBQVI7QUFDQVMsa0VBQU0sQ0FBQ0MsSUFBUCxDQUFZLFdBQVo7O0FBSEk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FIUjs7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFPVyxVQUFBQyxNQUFNLEVBQUk7QUFDakJULGNBQVEsQ0FBQ00sc0RBQUssQ0FBQztBQUFDSSxlQUFPLEVBQUMsSUFBVDtBQUFjRCxjQUFNLEVBQUNBLE1BQU0sQ0FBQ0UsUUFBUCxDQUFnQmI7QUFBckMsT0FBRCxDQUFOLENBQVI7QUFDRCxLQVRIO0FBVUgsR0FYb0I7QUFBQSxDQUFkO0FBY0EsSUFBTWMsWUFBWSxHQUFHLFNBQWZBLFlBQWUsQ0FBQ2YsR0FBRCxFQUFLQyxJQUFMO0FBQUEsTUFBVUMsT0FBVix1RUFBb0IsRUFBcEI7QUFBQSxTQUEyQixVQUFBQyxRQUFRLEVBQUk7QUFDakVDLGdEQUFLLENBQUNDLElBQU4sV0FBY0MsNkJBQWQsU0FBZ0ROLEdBQWhELEdBQXNEQyxJQUF0RCxFQUEyRDtBQUN2REMsYUFBTyxFQUFDQTtBQUQrQyxLQUEzRCxFQUdHSyxJQUhIO0FBQUEscVVBR1Esa0JBQU1DLEdBQU47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0pRLGtFQUFJLENBQUNDLElBQUwsQ0FBVTtBQUNSQyxzQkFBSSxFQUFFLDZCQURFO0FBRVJDLHNCQUFJLEVBQUUsU0FGRTtBQUdSQyxtQ0FBaUIsRUFBRTtBQUhYLGlCQUFWLEVBSUdiLElBSkgsQ0FJUSxVQUFBQyxHQUFHLEVBQUk7QUFDYixzQkFBR0EsR0FBRyxDQUFDYSxXQUFQLEVBQW1CO0FBQ2pCWCxzRUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWjtBQUNEO0FBQ0YsaUJBUkQ7QUFESTtBQUFBLHVCQVVhSCxHQUFHLENBQUNQLElBVmpCOztBQUFBO0FBVUFBLG9CQVZBO0FBV0pFLHdCQUFRLENBQUNtQix5REFBUSxDQUFDckIsSUFBRCxDQUFULENBQVI7O0FBWEk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FIUjs7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFlVyxVQUFBc0IsR0FBRyxFQUFJO0FBQ2RwQixjQUFRLENBQUNtQix5REFBUSxDQUFDO0FBQUNULGVBQU8sRUFBQyxJQUFUO0FBQWNELGNBQU0sRUFBQ1csR0FBRyxDQUFDVCxRQUFKLENBQWFiO0FBQWxDLE9BQUQsQ0FBVCxDQUFSO0FBQ0QsS0FqQkg7QUFrQkQsR0FuQjJCO0FBQUEsQ0FBckI7QUFxQkEsSUFBTXVCLE1BQU0sR0FBRyxTQUFUQSxNQUFTO0FBQUEsU0FBTSxVQUFBckIsUUFBUSxFQUFJO0FBQ3JDc0IsV0FBTyxDQUFDQyxHQUFSLENBQVksZUFBWjtBQUNDdkIsWUFBUSxDQUFDd0IsdURBQU0sRUFBUCxDQUFSO0FBQ0gsR0FIcUI7QUFBQSxDQUFmO0FBS0EsSUFBTUMsVUFBVSxHQUFHLFNBQWJBLFVBQWEsQ0FBQzVCLEdBQUQsRUFBS0MsSUFBTDtBQUFBLE1BQVVDLE9BQVYsdUVBQW9CLEVBQXBCO0FBQUEsU0FBMkIsVUFBQUMsUUFBUSxFQUFJO0FBRTdEQyxnREFBSyxDQUFDeUIsR0FBTixXQUFhdkIsNkJBQWIsU0FBK0NOLEdBQS9DLEdBQXFEQyxJQUFyRCxFQUEwRDtBQUN0REMsYUFBTyxFQUFFQTtBQUQ2QyxLQUExRCxFQUdHSyxJQUhILENBR1MsVUFBQUMsR0FBRyxFQUFJO0FBQ1pMLGNBQVEsQ0FBQzJCLDJEQUFVLENBQUN0QixHQUFHLENBQUNQLElBQUwsQ0FBWCxDQUFSO0FBQ0NlLHdEQUFJLENBQUNDLElBQUwsQ0FBVTtBQUNSQyxZQUFJLEVBQUUsbUNBREU7QUFFUkMsWUFBSSxFQUFFLFNBRkU7QUFHUkMseUJBQWlCLEVBQUU7QUFIWCxPQUFWO0FBS0YsS0FWSCxXQVdTLFVBQUFHLEdBQUcsRUFBSTtBQUNacEIsY0FBUSxDQUFDMkIsMkRBQVUsQ0FBQztBQUFDakIsZUFBTyxFQUFDLElBQVQ7QUFBY0QsY0FBTSxFQUFDVyxHQUFHLENBQUNULFFBQUosQ0FBYWI7QUFBbEMsT0FBRCxDQUFYLENBQVI7QUFDRCxLQWJIO0FBZUgsR0FqQnlCO0FBQUEsQ0FBbkI7QUFtQkUsSUFBTThCLGtCQUFrQixHQUFHLFNBQXJCQSxrQkFBcUIsQ0FBQy9CLEdBQUQsRUFBS0MsSUFBTCxFQUFVQyxPQUFWO0FBQUEsU0FBc0IsVUFBQUMsUUFBUSxFQUFJO0FBQ2xFQyxnREFBSyxDQUFDQyxJQUFOLFdBQWNDLDZCQUFkLFNBQWdETixHQUFoRCxHQUFzREMsSUFBdEQsRUFBMkQ7QUFDekRDLGFBQU8sRUFBQ0E7QUFEaUQsS0FBM0QsRUFFR0ssSUFGSCxDQUVRLFVBQUFDLEdBQUcsRUFBSTtBQUNiLFVBQUdBLEdBQUcsQ0FBQ3dCLE1BQUosSUFBYyxTQUFqQixFQUEyQjtBQUN6QmhCLDBEQUFJLENBQUNDLElBQUwsQ0FBVTtBQUNSQyxjQUFJLEVBQUVWLEdBQUcsQ0FBQ1AsSUFBSixDQUFTZ0MsT0FEUDtBQUVSZCxjQUFJLEVBQUUsU0FGRTtBQUdSQywyQkFBaUIsRUFBRTtBQUhYLFNBQVY7QUFLQWpCLGdCQUFRLENBQUMrQiw2REFBWSxDQUFDakMsSUFBSSxDQUFDa0MsT0FBTixDQUFiLENBQVI7QUFDRDtBQUNGLEtBWEQsV0FXUyxVQUFBWixHQUFHO0FBQUEsYUFBSUUsT0FBTyxDQUFDQyxHQUFSLENBQVlILEdBQVosQ0FBSjtBQUFBLEtBWFo7QUFZRCxHQWJpQztBQUFBLENBQTNCO0FBZUYsSUFBTWEscUJBQXFCLEdBQUcsU0FBeEJBLHFCQUF3QixDQUFDRCxPQUFEO0FBQUEsU0FBYSxVQUFBaEMsUUFBUSxFQUFJO0FBQzFEQSxZQUFRLENBQUNrQyxnRUFBZSxDQUFDRixPQUFELENBQWhCLENBQVI7QUFDSCxHQUZvQztBQUFBLENBQTlCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaEZQO0FBQ0E7QUFPQSxJQUFNRyxZQUFZLEdBQUc7QUFDbkJDLE1BQUksRUFBRSxFQURhO0FBRW5CQyxlQUFhLEVBQUUsRUFGSTtBQUduQkMsU0FBTyxFQUFFO0FBSFUsQ0FBckI7O0FBTUEsSUFBTUMsWUFBWSxHQUFHLFNBQWZBLFlBQWUsR0FBa0M7QUFBQSxNQUFqQ0MsS0FBaUMsdUVBQXpCTCxZQUF5QjtBQUFBLE1BQVhNLE1BQVc7O0FBQ3JELFVBQVFBLE1BQU0sQ0FBQ0MsSUFBZjtBQUNFLFNBQUtDLHVEQUFMO0FBQ0U7O0FBQ0YsU0FBS0Msa0RBQUw7QUFDRSxVQUFJSCxNQUFNLENBQUNJLE9BQVAsQ0FBZW5DLE9BQW5CLEVBQTRCO0FBQzFCOEIsYUFBSyxtQ0FDQUEsS0FEQTtBQUVISCx1QkFBYSxvQkFBT0ksTUFBTSxDQUFDSSxPQUFQLENBQWVwQyxNQUF0QjtBQUZWLFVBQUw7QUFJRCxPQUxELE1BS087QUFDTCtCLGFBQUssbUNBQ0FBLEtBREE7QUFFSEgsdUJBQWEsRUFBRSxFQUZaO0FBR0hELGNBQUksb0JBQ0NLLE1BQU0sQ0FBQ0ksT0FEUixDQUhEO0FBTUhQLGlCQUFPLEVBQUU7QUFOTixVQUFMO0FBUUQ7O0FBRUQ7O0FBQ0YsU0FBS1EsbURBQUw7QUFDRU4sV0FBSyxHQUFHO0FBQ05KLFlBQUksRUFBRSxFQURBO0FBRU5DLHFCQUFhLEVBQUUsRUFGVDtBQUdOQyxlQUFPLEVBQUU7QUFISCxPQUFSO0FBS0E7O0FBQ0YsU0FBS1MscURBQUw7QUFDRSxVQUFJTixNQUFNLENBQUNJLE9BQVAsQ0FBZW5DLE9BQW5CLEVBQTRCO0FBQzFCOEIsYUFBSyxtQ0FDQUEsS0FEQTtBQUVISCx1QkFBYSxvQkFBT0ksTUFBTSxDQUFDSSxPQUFQLENBQWVwQyxNQUF0QjtBQUZWLFVBQUw7QUFJRCxPQUxELE1BS087QUFDTCtCLGFBQUssR0FBRztBQUNOSixjQUFJLG9CQUFPSyxNQUFNLENBQUNJLE9BQWQsQ0FERTtBQUVOUix1QkFBYSxFQUFFLEVBRlQ7QUFHTkMsaUJBQU8sRUFBRTtBQUhILFNBQVI7QUFLRDs7QUFDRDs7QUFDRixTQUFLVSx3REFBTDtBQUNFLFVBQUlQLE1BQU0sQ0FBQ0ksT0FBUCxDQUFlbkMsT0FBbkIsRUFBNEI7QUFDMUI4QixhQUFLLG1DQUNBQSxLQURBO0FBRUhKLGNBQUksb0JBQ0NJLEtBQUssQ0FBQ0osSUFEUCxDQUZEO0FBS0hDLHVCQUFhLG9CQUFPSSxNQUFNLENBQUNJLE9BQVAsQ0FBZXBDLE1BQXRCO0FBTFYsVUFBTDtBQU9ELE9BUkQsTUFRTztBQUNMK0IsYUFBSyxtQ0FDQUEsS0FEQTtBQUVISixjQUFJLGtDQUNDSSxLQUFLLENBQUNKLElBRFA7QUFFRkEsZ0JBQUksb0JBQU9LLE1BQU0sQ0FBQ0ksT0FBUCxDQUFlVCxJQUF0QjtBQUZGLFlBRkQ7QUFNSEMsdUJBQWEsRUFBRTtBQU5aLFVBQUw7QUFRRDs7QUFDRDs7QUFDRixTQUFLWSw2REFBTDtBQUNFVCxXQUFLLG1DQUNBQSxLQURBO0FBRUhKLFlBQUksa0NBQ0NJLEtBQUssQ0FBQ0osSUFEUDtBQUVGQSxjQUFJLGtDQUNDSSxLQUFLLENBQUNKLElBQU4sQ0FBV0EsSUFEWjtBQUVGSixtQkFBTyxFQUFDUyxNQUFNLENBQUNJO0FBRmI7QUFGRjtBQUZELFFBQUw7QUFVQTs7QUFDRixTQUFLSywyREFBTDtBQUNFVixXQUFLLG1DQUNBQSxLQURBO0FBRUhKLFlBQUksa0NBQ0NJLEtBQUssQ0FBQ0osSUFEUDtBQUVGQSxjQUFJLGtDQUNDSyxNQUFNLENBQUNJLE9BQVAsQ0FBZVQsSUFEaEI7QUFFRkosbUJBQU8sRUFBRVMsTUFBTSxDQUFDSSxPQUFQLENBQWVULElBQWYsR0FBc0JLLE1BQU0sQ0FBQ0k7QUFGcEM7QUFGRjtBQUZELFFBQUw7QUFVQTs7QUFDRjtBQUNFTCxXQUFLLHFCQUFRQSxLQUFSLENBQUw7QUFDQTtBQXhGSjs7QUEyRkEsU0FBT0EsS0FBUDtBQUNELENBN0ZEOztBQStGZUQsMkVBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvX2FwcC45YjZhZmE1YTMwYTE4ZTZjMTFhOC5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuaW1wb3J0IHJvdXRlciBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IFN3YWwgZnJvbSBcInN3ZWV0YWxlcnQyXCI7XHJcbmltcG9ydCB7IEluY3JlYXNlQmFsYW5jZSwgbG9naW4sIGxvZ291dCwgUGF5QnlCYWxhbmNlLCByZWdpc3RlciwgdXBkYXRlVXNlciB9IGZyb20gXCIuL2FjdGlvbnNcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBMb2dpbiA9ICh1cmwsZGF0YSxoZWFkZXJzID0ge30pID0+IGRpc3BhdGNoID0+IHtcclxuICAgIGF4aW9zLnBvc3QoYCR7cHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQVBJX1VSTH0ke3VybH1gLGRhdGEse1xyXG4gICAgICAgIGhlYWRlcnM6aGVhZGVycyxcclxuICAgICAgfSlcclxuICAgICAgLnRoZW4oYXN5bmMgcmVzID0+IHtcclxuICAgICAgICBsZXQgZGF0YSA9IGF3YWl0IHJlcy5kYXRhO1xyXG4gICAgICAgIGRpc3BhdGNoKGxvZ2luKGRhdGEpKVxyXG4gICAgICAgIHJvdXRlci5wdXNoKCcvcGFja2FnZXMnKVxyXG4gICAgICB9KS5jYXRjaChlcnJvcnMgPT4ge1xyXG4gICAgICAgIGRpc3BhdGNoKGxvZ2luKHtpc0Vycm9yOnRydWUsZXJyb3JzOmVycm9ycy5yZXNwb25zZS5kYXRhfSkpXHJcbiAgICAgIH0pXHJcbn1cclxuXHJcblxyXG5leHBvcnQgY29uc3QgVXNlclJlZ2lzdGVyID0gKHVybCxkYXRhLGhlYWRlcnMgPSB7fSkgPT4gZGlzcGF0Y2ggPT4ge1xyXG4gIGF4aW9zLnBvc3QoYCR7cHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQVBJX1VSTH0ke3VybH1gLGRhdGEse1xyXG4gICAgICBoZWFkZXJzOmhlYWRlcnMsXHJcbiAgICB9KVxyXG4gICAgLnRoZW4oYXN5bmMgcmVzID0+IHtcclxuICAgICAgU3dhbC5maXJlKHtcclxuICAgICAgICB0ZXh0OiAnxo9tyZlsaXl5YXQgdcSfdXJsYSB0YW1hbWxhbmTEsScsXHJcbiAgICAgICAgaWNvbjogJ3N1Y2Nlc3MnLFxyXG4gICAgICAgIGNvbmZpcm1CdXR0b25UZXh0OiAnT0snLFxyXG4gICAgICB9KS50aGVuKHJlcyA9PiB7XHJcbiAgICAgICAgaWYocmVzLmlzQ29uZmlybWVkKXtcclxuICAgICAgICAgIHJvdXRlci5wdXNoKCcvbXlhZGRyZXNzZXMnKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pXHJcbiAgICAgIGxldCBkYXRhID0gYXdhaXQgcmVzLmRhdGE7XHJcbiAgICAgIGRpc3BhdGNoKHJlZ2lzdGVyKGRhdGEpKVxyXG4gICAgfSkuY2F0Y2goZXJyID0+IHtcclxuICAgICAgZGlzcGF0Y2gocmVnaXN0ZXIoe2lzRXJyb3I6dHJ1ZSxlcnJvcnM6ZXJyLnJlc3BvbnNlLmRhdGF9KSlcclxuICAgIH0pXHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBMb2dPdXQgPSAoKSA9PiBkaXNwYXRjaCA9PiB7XHJcbiAgIGNvbnNvbGUubG9nKCd3b3JkZWsgbG9nb3V0JylcclxuICAgIGRpc3BhdGNoKGxvZ291dCgpKVxyXG59XHJcblxyXG5leHBvcnQgY29uc3QgVXBkYXRlVXNlciA9ICh1cmwsZGF0YSxoZWFkZXJzID0ge30pID0+IGRpc3BhdGNoID0+IHtcclxuXHJcbiAgICBheGlvcy5wdXQoYCR7cHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQVBJX1VSTH0ke3VybH1gLGRhdGEse1xyXG4gICAgICAgIGhlYWRlcnM6IGhlYWRlcnNcclxuICAgICAgfSlcclxuICAgICAgLnRoZW4oIHJlcyA9PiB7XHJcbiAgICAgICAgZGlzcGF0Y2godXBkYXRlVXNlcihyZXMuZGF0YSkpXHJcbiAgICAgICAgIFN3YWwuZmlyZSh7XHJcbiAgICAgICAgICAgdGV4dDogJ8aPbcmZbGl5eWF0IHXEn3VybGEgeWVyaW7JmSB5ZXRpcmlsZGknLFxyXG4gICAgICAgICAgIGljb246ICdzdWNjZXNzJyxcclxuICAgICAgICAgICBjb25maXJtQnV0dG9uVGV4dDogJ09LJyxcclxuICAgICAgICAgfSlcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKGVyciA9PiB7XHJcbiAgICAgICAgZGlzcGF0Y2godXBkYXRlVXNlcih7aXNFcnJvcjp0cnVlLGVycm9yczplcnIucmVzcG9uc2UuZGF0YX0pKVxyXG4gICAgICB9KVxyXG4gIFxyXG59XHJcblxyXG4gIGV4cG9ydCBjb25zdCBQYXlCeUJhbGFuY2VBY3Rpb24gPSAodXJsLGRhdGEsaGVhZGVycykgPT4gZGlzcGF0Y2ggPT4ge1xyXG4gICAgYXhpb3MucG9zdChgJHtwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19BUElfVVJMfSR7dXJsfWAsZGF0YSx7XHJcbiAgICAgIGhlYWRlcnM6aGVhZGVycyxcclxuICAgIH0pLnRoZW4ocmVzID0+IHtcclxuICAgICAgaWYocmVzLnN0YXR1cyA9PSAnc3VjY2VzcycpeyBcclxuICAgICAgICBTd2FsLmZpcmUoe1xyXG4gICAgICAgICAgdGV4dDogcmVzLmRhdGEubWVzc2FnZSxcclxuICAgICAgICAgIGljb246ICdzdWNjZXNzJyxcclxuICAgICAgICAgIGNvbmZpcm1CdXR0b25UZXh0OiAnT0snLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGRpc3BhdGNoKFBheUJ5QmFsYW5jZShkYXRhLmJhbGFuY2UpKVxyXG4gICAgICB9XHJcbiAgICB9KS5jYXRjaChlcnIgPT4gY29uc29sZS5sb2coZXJyKSk7XHJcbiAgfVxyXG5cclxuZXhwb3J0IGNvbnN0IEluY3JlYXNlQmFsYW5jZUFjdGlvbiA9IChiYWxhbmNlKSA9PiBkaXNwYXRjaCA9PiB7XHJcbiAgICBkaXNwYXRjaChJbmNyZWFzZUJhbGFuY2UoYmFsYW5jZSkpXHJcbn1cclxuXHJcblxyXG5cclxuIiwiaW1wb3J0IHsgUkVIWURSQVRFIH0gZnJvbSBcInJlZHV4LXBlcnNpc3RcIjtcclxuaW1wb3J0XHJcbiAge1xyXG4gICAgSU5DUkVBU0VfQkFMQU5DRSwgTE9HSU4sXHJcbiAgICBMT0dPVVQsIFBBWV9CWV9CQUxBTkNFLCBSRUdJU1RFUixcclxuICAgIFVQREFURV9VU0VSXHJcbiAgfSBmcm9tIFwiLi9hY3Rpb25UeXBlc1wiO1xyXG5cclxuY29uc3QgaW5pdGlhbFN0YXRlID0ge1xyXG4gIHVzZXI6IHt9LFxyXG4gIGVycm9yTWVzc2FnZXM6IHt9LFxyXG4gIGlzTG9nZWQ6IGZhbHNlLFxyXG59O1xyXG5cclxuY29uc3QgZW50cnlSZWR1Y2VyID0gKHN0YXRlID0gaW5pdGlhbFN0YXRlLCBhY3Rpb24pID0+IHtcclxuICBzd2l0Y2ggKGFjdGlvbi50eXBlKSB7XHJcbiAgICBjYXNlIFJFSFlEUkFURTpcclxuICAgICAgYnJlYWs7XHJcbiAgICBjYXNlIExPR0lOOlxyXG4gICAgICBpZiAoYWN0aW9uLnBheWxvYWQuaXNFcnJvcikge1xyXG4gICAgICAgIHN0YXRlID0ge1xyXG4gICAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgICBlcnJvck1lc3NhZ2VzOiB7IC4uLmFjdGlvbi5wYXlsb2FkLmVycm9ycyB9LFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc3RhdGUgPSB7XHJcbiAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgIGVycm9yTWVzc2FnZXM6IHt9LFxyXG4gICAgICAgICAgdXNlcjoge1xyXG4gICAgICAgICAgICAuLi5hY3Rpb24ucGF5bG9hZCxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBpc0xvZ2VkOiB0cnVlLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGJyZWFrO1xyXG4gICAgY2FzZSBMT0dPVVQ6XHJcbiAgICAgIHN0YXRlID0ge1xyXG4gICAgICAgIHVzZXI6IHt9LFxyXG4gICAgICAgIGVycm9yTWVzc2FnZXM6IFtdLFxyXG4gICAgICAgIGlzTG9nZWQ6IGZhbHNlLFxyXG4gICAgICB9O1xyXG4gICAgICBicmVhaztcclxuICAgIGNhc2UgUkVHSVNURVI6XHJcbiAgICAgIGlmIChhY3Rpb24ucGF5bG9hZC5pc0Vycm9yKSB7XHJcbiAgICAgICAgc3RhdGUgPSB7XHJcbiAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgIGVycm9yTWVzc2FnZXM6IHsgLi4uYWN0aW9uLnBheWxvYWQuZXJyb3JzIH0sXHJcbiAgICAgICAgfTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzdGF0ZSA9IHtcclxuICAgICAgICAgIHVzZXI6IHsgLi4uYWN0aW9uLnBheWxvYWQgfSxcclxuICAgICAgICAgIGVycm9yTWVzc2FnZXM6IHt9LFxyXG4gICAgICAgICAgaXNMb2dlZDogZmFsc2UsXHJcbiAgICAgICAgfTtcclxuICAgICAgfVxyXG4gICAgICBicmVhaztcclxuICAgIGNhc2UgVVBEQVRFX1VTRVI6XHJcbiAgICAgIGlmIChhY3Rpb24ucGF5bG9hZC5pc0Vycm9yKSB7XHJcbiAgICAgICAgc3RhdGUgPSB7XHJcbiAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgIHVzZXI6IHtcclxuICAgICAgICAgICAgLi4uc3RhdGUudXNlcixcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBlcnJvck1lc3NhZ2VzOiB7IC4uLmFjdGlvbi5wYXlsb2FkLmVycm9ycyB9LFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc3RhdGUgPSB7XHJcbiAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgIHVzZXI6IHtcclxuICAgICAgICAgICAgLi4uc3RhdGUudXNlcixcclxuICAgICAgICAgICAgdXNlcjogeyAuLi5hY3Rpb24ucGF5bG9hZC51c2VyIH0sXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgZXJyb3JNZXNzYWdlczoge30sXHJcbiAgICAgICAgfTtcclxuICAgICAgfVxyXG4gICAgICBicmVhaztcclxuICAgIGNhc2UgSU5DUkVBU0VfQkFMQU5DRTpcclxuICAgICAgc3RhdGUgPSB7XHJcbiAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgdXNlcjogeyBcclxuICAgICAgICAgIC4uLnN0YXRlLnVzZXIsXHJcbiAgICAgICAgICB1c2VyOiB7IFxyXG4gICAgICAgICAgICAuLi5zdGF0ZS51c2VyLnVzZXIsXHJcbiAgICAgICAgICAgIGJhbGFuY2U6YWN0aW9uLnBheWxvYWRcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgYnJlYWs7XHJcbiAgICBjYXNlIFBBWV9CWV9CQUxBTkNFOlxyXG4gICAgICBzdGF0ZSA9IHtcclxuICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICB1c2VyOiB7IFxyXG4gICAgICAgICAgLi4uc3RhdGUudXNlcixcclxuICAgICAgICAgIHVzZXI6IHsgXHJcbiAgICAgICAgICAgIC4uLmFjdGlvbi5wYXlsb2FkLnVzZXIsXHJcbiAgICAgICAgICAgIGJhbGFuY2U6KGFjdGlvbi5wYXlsb2FkLnVzZXIgLSBhY3Rpb24ucGF5bG9hZClcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgYnJlYWs7XHJcbiAgICBkZWZhdWx0OlxyXG4gICAgICBzdGF0ZSA9IHsgLi4uc3RhdGUgfTtcclxuICAgICAgYnJlYWs7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gc3RhdGU7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBlbnRyeVJlZHVjZXI7XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=