export const LOGIN = 'LOGIN';

export const LOGOUT = 'LOGOUT';

export const REGISTER = 'REGISTER';

export const UPDATE_USER = 'UPDATE_USER';

export const INCREASE_BALANCE = 'INCREASE_BALANCE';

export const PAY_BY_BALANCE = 'PAY_BY_BALANCE';



