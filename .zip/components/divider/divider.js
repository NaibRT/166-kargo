import React from 'react'

function Divider() {
 return (
  <hr className='border-color'/>
 )
}

export default Divider
