module.exports = {
 i18n: {
  locales: ['az', 'en', 'ru'],
  defaultLocale: 'az',
  localeDetection: true,
 },
 distDir: '_next'
};
