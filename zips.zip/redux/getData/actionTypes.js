
export const GETDATA = 'GETDATA';