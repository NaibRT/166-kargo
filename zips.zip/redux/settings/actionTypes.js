export const GETSETTING = 'GETSETTING';
